------------------------------------------------------------------------------------------------------------------------------------------------------

local g = require("code.globals")
local f = require("code.functions")

------------------------------------------------------------------------------------------------------------------------------------------------------

data:extend({{
	type = "item-subgroup",
	name = "loader",
	group = "logistics",
	order = "bb",
}})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- loaders

if g.loaders_enabled then
	for _, loader in pairs(g.loaders) do
		f.make_machine_item(loader)
		f.make_loader_entity(loader)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- beltboxes

if g.beltboxes_enabled then
	for _, beltbox in pairs(g.beltboxes) do
		f.make_machine_item(beltbox)
		f.make_beltbox_entity(beltbox)
	end
end
------------------------------------------------------------------------------------------------------------------------------------------------------

-- stacked items

if g.beltboxes_enabled then

	data:extend({
		{
			type = "recipe-category",
			name = g.stacking_category_name
		},
		{
			type = "recipe-category",
			name = g.unstacking_category_name
		},
		{
			type = "item-subgroup",
			name = "stacked-items",
			group = "ir-basics",
			order = "zzzzzz",
		},
		
	})

	local components = {
		ingot = {
			"copper",
			"tin",
			"bronze",
			"iron",
			"gold",
			"steel",
			"lead",
			"nickel",
			"platinum",
			"chromium",
			"brass",
			"stone",
			"glass",
			"plastic",
			"nanoglass",
		},
		block = {
			"concrete",
		},
		circuit = {
			"copper",
			"gold",
			"electrum",
		},
	}

	for component, materials in pairs(components) do
		for _, material in pairs(materials) do
			local item_name = DIR.get_item_name(material, component)
			local name = "stacked-" .. item_name
			data:extend(
				{
					{
						name = name,
						localised_name = {"stacking.stack", {"item-name." .. item_name}},
						localised_description = {"stacking.stack-description", "[img=item/"..item_name.."]", g.stacking_ratio, {"item-name."..item_name}},
						type = "item",
						icons = {
							{
								icon = DIR.get_icon_path(name,64,g.icon_path),
								icon_size = 64,
								icon_mipmaps = 4
							}
						},
						stack_size = (DIR.components[component].stack_size or 100) / g.stacking_ratio,
						subgroup = "stacked-items",
						order = DIR.materials[material].order .. "-" .. DIR.components[component].order,
						pictures = (settings.startup["ir-belt-brightness-variation"].value == "on") and DIR.get_belt_brightness_variation_pictures(name,64,4,g.icon_path) or nil
					},
					{
						name = item_name .. "-stacking",
						localised_name = {"stacking.stacking", {"item-name." .. item_name}},
						type = "recipe",
						icons = {
							{
								icon = DIR.get_icon_path(name,64,g.icon_path),
								icon_size = 64,
								icon_mipmaps = 4
							},
							-- {
								-- icon = DIR.get_icon_path(item_name),
								-- icon_size = 64,
								-- icon_mipmaps = 4,
								-- scale = 0.25,
								-- shift = {-8,-8},
							-- },
						},
						category = g.stacking_category_name,
						subgroup = "stacked-items",
						order = "a-"..DIR.materials[material].order .. "-" .. DIR.components[component].order,
						energy_required = g.stacking_speed * g.stacking_multiplier,
						ingredients = {
							{item_name, g.stacking_ratio * g.stacking_multiplier}
						},
						result = name,
						result_count = g.stacking_multiplier,
						enabled = true,
						allow_as_intermediate = false,
						allow_intermediates = false,
						always_show_products = true,
						hide_from_player_crafting = true,
						allow_decomposition = false,
					},
					{
						name = item_name .. "-unstacking",
						localised_name = {"stacking.unstacking", {"item-name." .. item_name}},
						type = "recipe",
						icons = {
							{
								icon = DIR.get_icon_path(item_name),
								icon_size = 64,
								icon_mipmaps = 4
							},
							{
								icon = DIR.get_icon_path(name,64,g.icon_path),
								icon_size = 64,
								icon_mipmaps = 4,
								scale = 0.25,
								shift = {-8,-8},
							},
						},
						category = g.unstacking_category_name,
						subgroup = "stacked-items",
						order = "b-"..DIR.materials[material].order .. "-" .. DIR.components[component].order,
						energy_required = g.stacking_speed,
						ingredients = {
							{name, 1}
						},
						result = item_name,
						result_count = g.stacking_ratio,
						enabled = true,
						allow_as_intermediate = false,
						allow_intermediates = false,
						always_show_products = true,
						hide_from_player_crafting = true,
						allow_decomposition = false,
					},
				}
			)
		end
	end

end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- gui

data:extend({
    {
        type = "custom-input",
        name = "ir3ls-left-click",
		linked_game_control = "build",
		key_sequence = "",
    },
})

data:extend({
	{
		type = "sprite",
		name = "ir3ls-both",
		filename = DIR.get_icon_path("ir3ls-both",64,g.icon_path),
		priority = "extra-high",
		width = 64,
		height = 64,
		flags = {"gui-icon"},
	},
	{
		type = "sprite",
		name = "ir3ls-loader",
		filename = DIR.get_icon_path("ir3-loader",64,g.icon_path),
		priority = "extra-high",
		width = 64,
		height = 64,
		flags = {"gui-icon"},
	},
	{
		type = "sprite",
		name = "ir3ls-beltbox",
		filename = DIR.get_icon_path("ir3-beltbox",64,g.icon_path),
		priority = "extra-high",
		width = 64,
		height = 64,
		flags = {"gui-icon"},
	},
	{
		type = "sprite",
		name = "ir3ls-batch",
		filename = DIR.get_icon_path("ir3ls-batch",64,g.icon_path),
		priority = "extra-high",
		width = 64,
		height = 64,
		flags = {"gui-icon"},
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------
