------------------------------------------------------------------------------------------------------------------------------------------------------

local g = require("code/globals")

local opposite_directions = {
	[defines.direction.north] = defines.direction.south,
	[defines.direction.east] = defines.direction.west,
	[defines.direction.south] = defines.direction.north,
	[defines.direction.west] = defines.direction.east,
}

local opposite_modes = {
	["input"] = "output",
	["output"] = "input",
}

local direction_vectors = {
	[defines.direction.north] = {x = 0, y =-1},
	[defines.direction.east] = {x = 1, y =0},
	[defines.direction.south] = {x = 0, y =1},
	[defines.direction.west] = {x = -1, y =0},
}

local loaders_list = {}
local loaders_array = {}
for _,loader in pairs(g.loaders) do
	table.insert(loaders_list, loader.name)
	loaders_array[loader.name] = true
end

------------------------------------------------------------------------------------------------------------------------------------------------------

local function values_to_keys(t)
    local t2 = {}
    for _,v in pairs(t) do t2[v] = true end
    return t2
end

local function is_loader(entity)
	return loaders_array[entity.name]
end

local function get_one_entity_or_ghost_offset(surface, position, x_offset, y_offset, types, names)
	types = types or {}
	table.insert(types, "entity-ghost")
	local e = surface.find_entities_filtered {
		position = {x = position.x + x_offset, y = position.y + y_offset},
		type = types,
		name = names,
		limit = 1
	}
	if e[1] and (e[1].type == "entity-ghost") then
		return values_to_keys(types)[e[1].ghost_type] and e[1] or nil
	end
	return e[1]
end

local function snap_loader(entity)
	if settings.global["ir3ls-belt-snapping"].value then
		local direction_to_check = (entity.loader_type == "output") and entity.direction or opposite_directions[entity.direction]
		local offset = direction_vectors[direction_to_check]
		local target = get_one_entity_or_ghost_offset(entity.surface, entity.position, offset.x, offset.y, {"transport-belt","underground-belt","splitter","loader-1x1"})
		if target and target.valid and target.direction == opposite_directions[entity.direction] then
			entity.loader_type = opposite_modes[entity.loader_type]
			return
		end
	end
end

local function on_built(event, entity)
	local entity = entity or event.created_entity or event.entity
	if entity and entity.valid and is_loader(entity) then
		snap_loader(entity)
	end
end

local function escape(str)
    return str:gsub("[%(%)%.%%%+%-%*%?%[%]%^%$]", function(c) return "%" .. c end)
end

local function escaped_gsub(str,old,new)
	return string.gsub(str, escape(old), new)
end

local function is_a_stacked_item_name(name)
	return string.find(name, "stacked%-")
end

local function unstack_stack(stack,player,messages)
	local inventory = player.get_main_inventory()
	messages = messages or {}
	messages.added = messages.added or {}
	local name = escaped_gsub(stack.name, "stacked-", "")
	if not game.item_prototypes[name] then error("No such item as "..name) end
	local count = math.min(stack.count * g.stacking_ratio, game.item_prototypes[name].stack_size) 
	stack.set_stack({name = name, count = count})
	messages.added[name] = (messages.added[name] or 0) + count
	return messages
end

local function unstack_messages(player, messages)
	if player and player.valid and messages then 
		local message = ""
		for name,count in pairs(messages.added) do
			message = (message == "") and message or (message.." ")
			message = message .. "[img=item/"..name.."] [color=0.75,0.75,0.75]+"..count.."[/color]"
		end
		if message ~= "" then
			remote.call("ir-utils", "fading-flying-text-player", player, message)
		end
		player.play_sound{path = "utility/crafting_finished"}
	end
end

local function unstack_cursor_stack(event)
	local player = game.players[event.player_index]
	local selected = (player.selected and player.selected.valid) and player.selected or nil
	if selected ~= nil then return end
	if player and player.valid and player.cursor_stack and player.cursor_stack.valid_for_read and is_a_stacked_item_name(player.cursor_stack.name) then
		unstack_messages(player, unstack_stack(player.cursor_stack, player))
	end
end

local function unstack_all_stacks(event)
	local player = game.players[event.player_index]
	if not (player and player.valid) then return end
	local selected = (player.selected and player.selected.valid) and player.selected or nil
	if selected ~= nil then return end
	if player.cursor_stack and player.cursor_stack.valid_for_read and is_a_stacked_item_name(player.cursor_stack.name) then
		local inventory = player.get_main_inventory()
		local messages = unstack_stack(player.cursor_stack, player)
		for i=1,#inventory do
			if inventory[i] and inventory[i].valid_for_read and is_a_stacked_item_name(inventory[i].name) then
				local name = escaped_gsub(inventory[i].name, "stacked-", "")
				if game.item_prototypes[name] then
					messages = unstack_stack(inventory[i], player, messages)
				end
			end
		end
		unstack_messages(player, messages)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

script.on_event({
	defines.events.on_built_entity,
	defines.events.on_robot_built_entity,
	defines.events.script_raised_built,
	defines.events.script_raised_revive,
	defines.events.on_entity_cloned,
}, on_built)

local filters = { {filter="type", type = "loader-1x1"} }

script.set_event_filter(defines.events.on_built_entity, filters)
script.set_event_filter(defines.events.on_robot_built_entity, filters)

script.on_event("ir3ls-left-click", unstack_cursor_stack)
script.on_event("ir-entity-adjustment", unstack_all_stacks)

local blueprint = require("code.blueprint")
if settings.startup["ir3ls-enabled"].value == "both" then
	remote.add_interface("IndustrialRevolution3LoadersStacking-ir-manifesto", {
		["titles"] = function()
			return {
				["ir-stacking"] = true,
			}
		end,
		["content"] = function(page_name, element)
			local pages = {
				["ir-stacking"] = function(element)
					remote.call("ir-manifesto", "add-camera", element, 900, 256, "ir3-beltbox")
					element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-stacking_1"}}
					element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-stacking_2"}}
					element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-stacking_3"}}
					element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-stacking_4"}}
					return true
				end,
			}
			pages[page_name](element)
		end,
		["blueprint"] = function()
			return blueprint
		end,
	})
end

------------------------------------------------------------------------------------------------------------------------------------------------------
