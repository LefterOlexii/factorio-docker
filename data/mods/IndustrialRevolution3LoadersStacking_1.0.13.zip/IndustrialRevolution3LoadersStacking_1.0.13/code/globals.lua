------------------------------------------------------------------------------------------------------------------------------------------------------

local g = {}

g.this_mod_name = "IndustrialRevolution3LoadersStacking"
g.icon_path = "__"..g.this_mod_name.."__/graphics/icons"
g.entities_path = "__"..g.this_mod_name.."__/graphics/entities"
g.tech_icon_path = "__"..g.this_mod_name.."__/graphics/icons"

g.stacking_ratio = 4
g.stacking_multiplier = (settings.startup["ir3ls-batch-mode"].value == "batch") and 4 or 1
g.stacking_speed = (g.stacking_ratio/15)
g.stacking_energy_per_item = 0.06 / 15 --MJ?
g.stacking_category_name = "stacking"
g.unstacking_category_name = "unstacking"

g.loaders_enabled = (settings.startup["ir3ls-enabled"].value ~= "beltboxes")
g.beltboxes_enabled = (settings.startup["ir3ls-enabled"].value ~= "loaders")

g.front_patch_cut = 98
g.vertical_shift = 0
g.beltbox_shift = -4 / 64

g.loaders = {
    {
        name = "ir3-loader-steam",
        transport_belt = "transport-belt",
		material = "copper",
        technology = "ir3-loader-steam",
		prerequisites = {"logistics"},
		crafting_category = "crafting",
		ingredients = {
			{"tin-plate", 4},
			{"transport-belt", 1},
			{"copper-piston", 2},
			{"steam-pipe", 2}
		},
		energy_required = 2,
        order = "a",
        upgrade = "ir3-loader",
        energy_source = "steam",
        energy_per_item = g.stacking_energy_per_item,
    },
    {
        name = "ir3-loader",
        transport_belt = "transport-belt",
		material = "iron",
        technology = "ir3-loader",
		prerequisites = {"ir-inserters-1"},
		crafting_category = "crafting",
		ingredients = {
			{"iron-frame-small", 1},
			{"transport-belt", 1},
			{"iron-piston", 2},
			{"electronic-circuit", 1}
		},
		energy_required = 2,
        order = "ab",
        upgrade = "ir3-fast-loader",
        energy_source = "electric",
        energy_per_item = g.stacking_energy_per_item,
		energy_tier = 1,
    },
    {
        name = "ir3-fast-loader",
        transport_belt = "fast-transport-belt",
		material = "iron2",
		alternative_backpatch_material = "iron",
		health_material = "iron",
        technology = "ir3-fast-loader",
		prerequisites = {"ir3-loader","logistics-2"},
		crafting_category = "crafting",
		ingredients = {
			{"iron-frame-small", 1},
			{"fast-transport-belt", 1},
			{"iron-piston", 4},
			{"electronic-circuit", 2}
		},
		energy_required = 2,
        order = "ac",
        upgrade = "ir3-express-loader",
        energy_source = "electric",
        energy_per_item = g.stacking_energy_per_item,
		energy_tier = 2,
    },
    {
        name = "ir3-express-loader",
        transport_belt = "express-transport-belt",
		material = "steel",
        technology = "ir3-express-loader",
		prerequisites = {"ir3-fast-loader","ir-inserters-2","logistics-3"},
		crafting_category = "crafting",
		ingredients = {
			{"steel-frame-small", 1},
			{"express-transport-belt", 1},
			{"steel-piston", 6},
			{"advanced-circuit", 2}
		},
		energy_required = 2,
        order = "ad",
        upgrade = nil,
        energy_source = "electric",
        energy_per_item = g.stacking_energy_per_item,
		energy_tier = 3,
    }
}

g.beltboxes = {
    {
        name = "ir3-beltbox-steam",
		material = "copper",
		colour = "yellow",
        technology = "ir3-beltbox-steam",
		technology_description = "ir3-beltbox",
		prerequisites = g.loaders_enabled and {"ir3-loader-steam"} or {"logistics"},
		crafting_category = "crafting",
		ingredients = {
			{"copper-frame-small", 1},
			{"copper-motor", 1},
			{"copper-gear-wheel", 2},
			{"steam-pipe", 1}
		},
		energy_required = 2,
        order = "ba",
        upgrade = "ir3-beltbox",
        energy_source = "steam",
        energy_usage = "60kW",
		crafting_speed = 1,
		working_sound = "small-machine-1",
	},
    {
        name = "ir3-beltbox",
		material = "iron",
		colour = "yellow",
        technology = "ir3-beltbox",
		technology_description = "ir3-beltbox",
		prerequisites = g.loaders_enabled and {"ir3-loader"} or {"ir-inserters-1"},
		crafting_category = "crafting",
		ingredients = {
			{"iron-frame-small", 1},
			{"iron-motor", 1},
			{"iron-gear-wheel", 2},
			{"electronic-circuit", 1}
		},
		energy_required = 2,
        order = "bb",
        upgrade = "ir3-fast-beltbox",
        energy_source = "electric",
        energy_usage = "60kW",
		energy_tier = 1,
		crafting_speed = 1,
		working_sound = "small-machine-2",
	},
    {
        name = "ir3-fast-beltbox",
		material = "iron2",
		health_material = "iron",
		colour = "red",
        technology = "ir3-fast-beltbox",
		technology_description = "ir3-beltbox",
		prerequisites = g.loaders_enabled and {"ir3-fast-loader","ir3-beltbox"} or {"ir3-beltbox","logistics-2"},
		crafting_category = "crafting",
		ingredients = {
			{"iron-frame-small", 1},
			{"iron-motor", 2},
			{"iron-gear-wheel", 3},
			{"electronic-circuit", 2}
		},
		energy_required = 2,
        order = "bc",
        upgrade = "ir3-express-beltbox",
        energy_source = "electric",
        energy_usage = "120kW",
		energy_tier = 2,
		crafting_speed = 2,
		working_sound = "small-machine-2",
	},
    {
        name = "ir3-express-beltbox",
		material = "steel",
		colour = "blue",
        technology = "ir3-express-beltbox",
		technology_description = "ir3-beltbox",
		prerequisites = g.loaders_enabled and {"ir3-express-loader","ir3-fast-beltbox"} or {"ir3-fast-beltbox","logistics-3"},
		crafting_category = "crafting",
		ingredients = {
			{"steel-frame-small", 1},
			{"electric-engine-unit", 2},
			{"brass-gear-wheel", 4},
			{"advanced-circuit", 2}
		},
		energy_required = 2,
        order = "bd",
        upgrade = nil,
        energy_source = "electric",
        energy_usage = "180kW",
		energy_tier = 3,
		crafting_speed = 3,
		working_sound = "small-machine-2",
	},
}

return g

------------------------------------------------------------------------------------------------------------------------------------------------------
