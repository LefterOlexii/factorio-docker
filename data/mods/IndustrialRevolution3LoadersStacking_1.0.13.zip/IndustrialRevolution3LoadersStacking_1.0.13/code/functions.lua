local f = {}
local g = require("code/globals")

function f.hsva2rgba(h, s, v, a)
    a = (a ~= nil) and a or 1
    local r, g, b
    local i = math.floor(h * 6)
    local f = h * 6 - i
    local p = v * (1 - s)
    local q = v * (1 - f * s)
    local t = v * (1 - (1 - f) * s)
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    elseif i == 5 then r, g, b = v, p, q
    end
    return {r = r, g = g, b = b, a = a}
end

local function get_steam_energy_source()
    return {
        type = "fluid",
        fluid_box = {
            filter = "steam",
            base_area = 0.5,
            base_level = -1,
            height = 2,
            production_type = "input-output",
            pipe_picture = nil,
            pipe_connections = {
                {type = "input-output", position = {1, 0}},
                {type = "input-output", position = {-1, 0}}
            },
            pipe_covers = DIR.pipe_covers.steam,
            secondary_draw_orders = {north = -2, east = -2, west = -2}
        },
        maximum_temperature = 165,
        scale_fluid_usage = true,
        light_flicker = standard_zero_light_flicker(),
		smoke = {{
			north_position = {0,-0.375},
			south_position = {0,-0.375},
			east_position = {0,-0.375},
			west_position = {0,-0.375},
			frequency = 2,
			name = "light-smoke",
			slow_down_factor = 1,
			starting_frame_deviation = 60,
			starting_vertical_speed = 0.08,
			starting_vertical_speed_deviation = 0.02,
			starting_frame_speed_deviation = 0.02,
		}},
    }
end

local function get_electric_energy_source(per_item,speed)
    return {
        type = "electric",
        usage_priority = "secondary-input",
		drain = "0W",
		-- nope, can't juggle this so it removes sawing on the graph - the way the per-item joules mechanic works is what it is
		-- buffer = per_item and speed and (per_item * speed * 15) .. "MJ" or nil,
		-- input_flow_limit = per_item and speed and (per_item * speed * 15) .. "MW" or nil,
		-- input_flow_limit = per_item and g.stacking_energy_per_item .. "MJ" or nil,
    }
end

function f.make_loader_entity(input)
	if input.energy_source == "electric" and not input.energy_tier then
		error("Loader "..input.name.." specifies electric energy source without energy_tier")
	end
	local shadow = (input.energy_source == "steam") and "loader-shadow-steam" or "loader-shadow"
	local material_y_offset = {
		["copper"] = 0,
		["iron"] = 128,
		["iron2"] = 256,
		["steel"] = 384,
	}
	if not material_y_offset[input.material] then error("Unrecognised material, no y offset") end
	local y_front_offset = material_y_offset[input.material] * 2
	local y_back_offset = material_y_offset[input.material]
	local y_shadow_offset = math.min(y_back_offset, 128)
    local entity = {
        name = input.name,
		localised_description = {"entity-description.ir3-loader"},
        type = "loader-1x1",
        order = input.order,
		filter_count = input.filter_count or 5,
        icons = {
			{
				icon = DIR.get_icon_path(input.name,64,g.icon_path),
				icon_size = 64,
				icon_mipmaps = 4,
			},
        },
        flags = {"placeable-neutral", "player-creation"},
        minable = {
            mining_time = 0.2,
            result = input.name
        },
        energy_per_item = input.energy_per_item .. "MJ",
        energy_source = (input.energy_source == "steam") and get_steam_energy_source() or get_electric_energy_source(input.energy_per_item,input.energy_tier),
        max_health = standard_health(input.health_material or input.material or "iron", 1),
        resistances = standard_resistances(input.health_material or input.material or "iron"),
		collision_mask = {"object-layer", "item-layer", "transport-belt-layer", "water-tile", "player-layer"},
        collision_box = {{-0.4, -0.45}, {0.4, 0.45}},
        selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
        drawing_box = {{-0.4, -0.4}, {0.4, 0.4}},
        animation_speed_coefficient = 32,
        container_distance = 1,
        belt_length = 0.5, 
        belt_animation_set = data.raw["transport-belt"][input.transport_belt].belt_animation_set,
        fast_replaceable_group = input.fast_replaceable_group or "transport-belt",
        next_upgrade = input.upgrade,
        speed = data.raw["transport-belt"][input.transport_belt].speed,
        corpse = "small-remnants",
        structure_render_layer = "object",
        structure = {
			front_patch = {
				sheets = {
                    {
                        filename = g.entities_path .. "/loaders-base-front.png",
                        priority = "extra-high",
                        height = 128-g.front_patch_cut,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift+(g.front_patch_cut/128)},
						-- flags = flags,
						y = g.front_patch_cut + y_front_offset,
                    },
				},
			},
			back_patch = {
				sheets = {
                    {
                        filename = g.entities_path .. "/loaders-base-back.png",
                        priority = "extra-high",
                        height = 128,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift},
						-- flags = flags,
						y = y_back_offset,
                    },
				},
			},
            direction_out = {
                sheets = {
                    {
                        filename = g.entities_path .. "/loaders-shadow.png",
                        priority = "extra-high",
                        height = 128,
                        width = 160,
						scale = 0.5,
						shift = {0,g.vertical_shift},
						draw_as_shadow = true,
						y = y_shadow_offset,
                    },
                    {
                        filename = g.entities_path .. "/loaders-integration.png",
                        priority = "extra-high",
                        height = 128,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift},
						draw_as_shadow = true,
                    },
                    {
                        filename = g.entities_path .. "/loaders-base-front.png",
                        priority = "extra-high",
                        height = g.front_patch_cut,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift+((128-g.front_patch_cut)/-128)},
						-- flags = flags,
						y = y_front_offset,
                    },
                }
            },
            direction_in = {
                sheets = {
                    {
                        filename = g.entities_path .. "/loaders-shadow.png",
                        priority = "extra-high",
                        height = 128,
                        width = 160,
						scale = 0.5,
						shift = {0,g.vertical_shift},
						draw_as_shadow = true,
						y = y_shadow_offset,
                    },
                    {
                        filename = g.entities_path .. "/loaders-integration.png",
                        priority = "extra-high",
                        height = 128,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift},
						draw_as_shadow = true,
                    },
                    {
                        filename = g.entities_path .. "/loaders-base-front.png",
                        priority = "extra-high",
                        height = g.front_patch_cut,
                        width = 128,
						scale = 0.5,
						shift = {0,g.vertical_shift+((128-g.front_patch_cut)/-128)},
						-- flags = flags,
						y = y_front_offset + 128,
                    },
                }
            },
        },
    }
	
    data:extend {entity}
end

function f.make_machine_item(input)
    data:extend {
        {
            name = input.name,
            type = "item",
            icons = {
                {
                    icon = DIR.get_icon_path(input.name,64,g.icon_path),
                    icon_size = 64,
					icon_mipmaps = 4,
                },
            },
            stack_size = 50,
            subgroup = input.subgroup or "loader",
            order = input.order,
            place_result = input.name
        },
        {
            name = input.name,
            type = "recipe",
            category = input.crafting_category,
            energy_required = input.energy_required,
            ingredients = input.ingredients,
            result = input.name,
            result_count = 1,
            enabled = (input.technology == nil),
			always_show_products = true,
			show_amount_in_title = false,
        }
    }
    if input.technology and data.raw.technology[input.technology] then
        data.raw.technology[input.technology].effects = data.raw.technology[input.technology].effects or {}
        table.insert(
            data.raw.technology[input.technology].effects,
            {
                type = "unlock-recipe",
                recipe = input.name
            }
        )
	elseif input.technology then
		DIR.add_new_minimal_tech(input.technology, input.name, g.tech_icon_path, {input.name}, input.prerequisites and input.prerequisites or {}) 
		data.raw.technology[input.technology].localised_description = {"technology-description." .. (input.technology_description and input.technology_description or "ir3-loader")}
    end
end

-- name, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, tw, th, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, scale, sequence, sprite_path

function f.make_beltbox_entity(input)
	local flags = nil
	local material_y_offset = {
		["copper"] = 0,
		["iron"] = 1,
		["iron2"] = 2,
		["steel"] = 3,
	}
	if not material_y_offset[input.material] then error("Unrecognised material, no y offset") end

	local base_y_offset = material_y_offset[input.material]
	local working_y_offset = (base_y_offset > 1) and (base_y_offset - 1) or base_y_offset
	local shadow_y_offset = math.min(1,base_y_offset)
	local fluids = {
		ns = {
			layers = {
				DIR.get_layer("beltbox-shadow", 1, 1, true, 60, DIR.anim_speed, 192, 128, 0, shadow_y_offset*128, 192, 128, {0.5,g.vertical_shift-(shadow_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
				DIR.get_layer("beltbox-base", 1, 1, false, 60, DIR.anim_speed, 128, 128, 0, base_y_offset*128, 128, 128, {0,g.vertical_shift-(base_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
				DIR.get_layer("beltbox-working", 60, 10, false, nil, DIR.anim_speed, 64, 32, 0, working_y_offset*192, 64, 32, {0,-0.25+g.vertical_shift-(working_y_offset*3)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
			}
		},
		ew = {
			layers = {
				DIR.get_layer("beltbox-shadow", 1, 1, true, 60, DIR.anim_speed, 192, 128, 0, shadow_y_offset*128, 192, 128, {0.5,g.vertical_shift-(shadow_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
				DIR.get_layer("beltbox-base", 1, 1, false, 60, DIR.anim_speed, 128, 128, 128, base_y_offset*128, 128, 128, {-2,g.vertical_shift-(base_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
				DIR.get_layer("beltbox-working", 60, 10, false, nil, DIR.anim_speed, 64, 32, 0, working_y_offset*192, 64, 32, {0,-0.25+g.vertical_shift-(working_y_offset*3)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
			}
		},
	}
	local animation = (input.energy_source == "steam") and {
		north = fluids.ew,
		south = fluids.ew,
		east = fluids.ns,
		west = fluids.ns,
	} or {
		layers = {
			DIR.get_layer("beltbox-shadow", 1, 1, true, 60, DIR.anim_speed, 192, 128, 0, shadow_y_offset*128, 192, 128, {0.5,g.vertical_shift-(shadow_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
			DIR.get_layer("beltbox-base", 1, 1, false, 60, DIR.anim_speed, 128, 128, 0, base_y_offset*128, 128, 128, {0,g.vertical_shift-(base_y_offset*2)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
			DIR.get_layer("beltbox-working", 60, 10, false, nil, DIR.anim_speed, 64, 32, 0, working_y_offset*192, 64, 32, {0,-0.25+g.vertical_shift-(working_y_offset*3)}, nil, nil, nil, nil, nil, nil, nil, nil, g.entities_path),
		}
	}
	local working_animation = (input.energy_source ~= "steam") and {
		{
			animation = DIR.get_layer("beltbox-status", 30, 5, "glow", nil, DIR.anim_speed / input.crafting_speed, 128, 128, 0, 0, 128, 128, {0,0}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, nil, nil, g.entities_path),
			apply_tint = "status",
			always_draw = true,
		}
	} or nil

    local entity = {
        name = input.name,
		localised_description = {"entity-description.ir3-beltbox"},
        type = "furnace",
		crafting_categories = {g.stacking_category_name, g.unstacking_category_name},
		source_inventory_size = 1,
		result_inventory_size = 1,
        energy_usage = input.energy_usage,
        energy_source = (input.energy_source == "steam") and get_steam_energy_source() or get_electric_energy_source(),
        icons = {
			{
				icon = DIR.get_icon_path(input.name,64,g.icon_path),
				icon_size = 64,
				icon_mipmaps = 4,
			},
        },
        flags = {"placeable-neutral", "player-creation"},
        minable = {
            mining_time = 0.2,
            result = input.name
        },
        max_health = standard_health(input.health_material or input.material or "iron", 2),
        resistances = standard_resistances(input.health_material or input.material or "iron"),
        corpse = "small-remnants",
        collision_box = {{-0.45, -0.45}, {0.45, 0.45}},
        selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
        drawing_box = {{-0.4, -0.4}, {0.4, 0.4}},
        fast_replaceable_group = input.fast_replaceable_group or "transport-belt",
        next_upgrade = input.upgrade,
        crafting_speed = input.crafting_speed,
        order = input.order,
		animation = animation,
		working_visualisations = working_animation,
		entity_info_icon_shift = {0,-0.425},
		status_colors = standard_status_colours(),
		working_sound = {
			sound = {
				filename = string.format("%s/%s.ogg", DIR.sound_path, input.working_sound),
				volume = 0.4,
			},
			fade_in_ticks = 20,
			fade_out_ticks = 20,
			max_sounds_per_type = 3,
		},
    }

    data:extend {entity}
end

return f
