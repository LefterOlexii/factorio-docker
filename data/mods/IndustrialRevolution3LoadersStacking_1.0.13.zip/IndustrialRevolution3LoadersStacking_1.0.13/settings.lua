------------------------------------------------------------------------------------------------------------------------------------------------------

data:extend({
    {
        type = "string-setting",
        name = "ir3ls-enabled",
		order = "a",
        setting_type = "startup",
        default_value = "both",
		allowed_values = {"both","loaders","beltboxes"},
    },
    {
        type = "string-setting",
        name = "ir3ls-batch-mode",
		order = "b",
        setting_type = "startup",
        default_value = "normal",
		allowed_values = {"normal","batch"},
    },
    {
        type = "bool-setting",
        name = "ir3ls-belt-snapping",
		order = "a",
        setting_type = "runtime-global",
        default_value = true,
    },
})


------------------------------------------------------------------------------------------------------------------------------------------------------
