------------------------------------------------------------------------------------------------------------------------------------------------------

local g = require("code/globals")

DIR = {}
require("__IndustrialRevolution3__/code/data/globals")

CONTROL = {}
require("__IndustrialRevolution3__/code/control/control-delayed-actions")
require("__IndustrialRevolution3__/code/control/control-transmats")
require("__IndustrialRevolution3__/code/control/control-terrain")
require("code/functions-control")

CONTROL.transmat_gui = "ir-cargo-transmat-gui"
CONTROL.limbo_surface_name = "IR-limbo"
CONTROL.cargo_transmat_interval = 25000
CONTROL.cargo_transmat_spacing = 180
CONTROL.ore_stack_size = DIR.components.ore.stack_size or 100
CONTROL.mined_items = {
	["iron-ore"] = 0.4,
	["copper-ore"] = 0.25,
	["gold-ore"] = 0.15,
	["tin-ore"] = 0.1,
	["comet-ice-ore"] = 0.1,
}

-- add to delayed actions

CONTROL.delayed_actions["cargo_transmat_sequence"] = function(action)
	if action.entity and action.entity.valid then
		CONTROL.cargo_transmat_sequence(action.entity)
	end
end

CONTROL.delayed_actions["deliver"] = function(action)
	if action.entity and action.entity.valid and action.delivery and action.container and action.container.valid then
		local inv = action.container.get_inventory(defines.inventory.chest)
		for name,count in pairs(action.delivery) do
			inv.insert({name=name, count=count})
		end
		CONTROL.delete_pending_storage(action.container)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

script.on_event({
	defines.events.on_player_mined_entity,
	defines.events.on_robot_mined_entity,
	defines.events.script_raised_destroy,
}, CONTROL.event_destroyed)

script.on_event({
	defines.events.on_built_entity,
	defines.events.on_robot_built_entity,
	defines.events.script_raised_built,
	defines.events.script_raised_revive,
	defines.events.on_entity_cloned,
}, CONTROL.event_built)

CONTROL.event_filters = {
	{filter = "name", name = "cargo-transmat"},
	{filter = "type", type = "container"},
	{filter = "type", type = "logistic-container"},
}

script.set_event_filter(defines.events.on_built_entity, CONTROL.event_filters)
script.set_event_filter(defines.events.on_robot_built_entity, CONTROL.event_filters)
script.set_event_filter(defines.events.on_entity_died, CONTROL.event_filters)
script.set_event_filter(defines.events.on_player_mined_entity, CONTROL.event_filters)
script.set_event_filter(defines.events.on_robot_mined_entity, CONTROL.event_filters)

script.on_event(defines.events.script_raised_teleported, CONTROL.event_teleported, CONTROL.event_filters)

script.on_configuration_changed(CONTROL.config_refresh)

script.on_event(defines.events.on_gui_opened, CONTROL.on_gui_opened)
script.on_event(defines.events.on_gui_closed, CONTROL.on_gui_close)
script.on_event(defines.events.on_gui_click, CONTROL.on_gui_click)

script.on_nth_tick(CONTROL.cargo_transmat_interval, CONTROL.cargo_transmat_cycle) 

local function on_init()
	if remote.interfaces["ir-manifesto"] and remote.interfaces["ir-manifesto"]["register-cycle"] then
		remote.call("ir-manifesto", "register-cycle", g.this_mod_name, true)
	else
		log("IR3SM: Could not call ir-manifesto/register-cycle")
	end
end

script.on_init(on_init)
script.on_load(on_init)

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir3sm", {
	["cycle"] = function(deliver_only)
		CONTROL.cargo_transmat_cycle(deliver_only)
	end,
	["reset"] = function()
		CONTROL.rebuild_all_transmat_data()
	end,
	["set_launches"] = function(launches)
		game.forces["player"].set_item_launched("quantum-satellite", launches)
		global.launches = launches
	end,
})

local blueprint = require("code.blueprint")
remote.add_interface(g.this_mod_name.."-ir-manifesto", {
	["titles"] = function()
		return {
			["ir-spacemining"] = true,
		}
	end,
	["content"] = function(page_name, element)
		local pages = {
			["ir-spacemining"] = function(element)
				remote.call("ir-manifesto", "add-camera", element, 900, 256, "fake-cargo-transmat")
				element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-spacemining_1"}}
				element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-spacemining_2", math.floor(DIR.transmat_cost/10^6)}}
				element.add{type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_ir-spacemining_3", g.maximum_launches, g.maximum_transmats}}
				return true
			end,
		}
		pages[page_name](element)
	end,
	["blueprint"] = function()
		return blueprint
	end,
	["cycle"] = function(surface)
		if global.fake_cargo_transmats ~= nil then
			for _,c in pairs(global.fake_cargo_transmats) do
				if not (c and c.valid) then
					global.fake_cargo_transmats = nil
					break
				end
			end
		end
		if global.fake_cargo_transmats == nil then
			global.fake_cargo_transmats = surface.find_entities_filtered{name = {"fake-cargo-transmat"}}
		end
		if global.fake_cargo_transmats and (table_size(global.fake_cargo_transmats) == 2) then
			global.fake_cargo_cycle_cycle = (global.fake_cargo_cycle_cycle or 0) + 1
			if global.fake_cargo_cycle_cycle % 3 == 0 then
				global.fake_cargo_cycle_cycle = 0
				for c,offset in pairs({[1]=0,[2]=120}) do
					for i=1,6 do
						CONTROL.add_delayed_action(offset+1+((i-1)*20), {action = "render_transmat_hex_light", light = i, from = global.fake_cargo_transmats[c], to = global.fake_cargo_transmats[c], ttl = 300})
					end
					CONTROL.add_delayed_action(offset+120, {action = "rings", surface = surface, position = global.fake_cargo_transmats[c].position, no_base = false, no_sound = true})
					CONTROL.add_delayed_action(offset+180, {action = "appear", surface = surface, position = global.fake_cargo_transmats[c].position})
					CONTROL.add_delayed_action(offset+200, {
						action = "create_entity", surface = surface, position = global.fake_cargo_transmats[c].position, 
						name = "cargo-transmat-rocks-"..((c==1) and "gold" or "copper").."-ore-1"
					})
					local containers = CONTROL.get_containers_around_transmat(global.fake_cargo_transmats[c])
					for _,container in pairs(containers) do
						CONTROL.add_delayed_action(offset+220, {
							action = "insert_into_inventory",
							inventory = container.get_inventory(defines.inventory.chest),
							item = ((c==1) and "gold" or "copper").."-ore",
							count = 80
						})
					end
				end
			end
		end
	end,
})

------------------------------------------------------------------------------------------------------------------------------------------------------
