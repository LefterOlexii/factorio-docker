------------------------------------------------------------------------------------------------------------------------------------------------------

local g = require("code.globals")
local f = require("code.functions")

DIR.materials["comet-ice"] = {
	hue = 0.475,
	saturation = 0.15,
	order = "zzza",
}

DIR.components["ore"].rotate_icon_variants = DIR.components["ore"].rotate_icon_variants or {} 
DIR.components["ore"].rotate_icon_variants["comet-ice"] = true

------------------------------------------------------------------------------------------------------------------------------------------------------

-- entities

local t = table.deepcopy(data.raw["electric-energy-interface"]["chrome-transmat"])
t.name = "cargo-transmat"
t.icon = DIR.get_icon_path("cargo-transmat",DIR.icon_size,g.icon_path)
t.minable.result = "cargo-transmat"
t.placeable_by = {item = "cargo-transmat", count = 1}
t.collision_box = {{-1.55,-1.55},{1.55,1.55}}
t.selection_box = {{-2,-2},{2,2}}
t.collision_mask = {"item-layer", "object-layer", "player-layer", "water-tile"} 
t.localised_name = {"entity-name.cargo-transmat"}
t.localised_description = {"entity-description.cargo-transmat", g.maximum_transmats}
t.picture = {
	layers = {
		DIR.get_layer("machines/misc/chrome-transmat-base-shadow", 1, 1, true, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}),
		DIR.get_layer("cargo-transmat-base", 1, 1, false, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}, nil, DIR.recommended_sprite_flags, nil, nil, nil, nil, nil, nil, g.entities_path),
	},
}
data:extend({t})

data:extend({{
	name = "cargo-transmat-base",
	type = "explosion",
	flags = {
		"not-on-map",
		"placeable-off-grid"
	},
	icon = DIR.get_icon_path("cargo-transmat",DIR.icon_size,g.icon_path),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	render_layer = "transport-belt-endings",
	height = 0,
	rotate = false,
	animations = {
		{
			animation_speed = 1,
			filename = g.entities_path.. "cargo-transmat-base.png",
			draw_as_shadow = false,
			frame_count = 70,
			height = 256,
			line_length = 10,
			priority = "high",
			width = 256,
			shift = {0,0},
			scale = 0.5,
			frame_sequence = data.raw.explosion["transmat-base"].animations[1].frame_sequence,
			flags = DIR.recommended_sprite_flags,
		},
	},
}})

data:extend({{
	name = "fake-cargo-transmat",
	type = "simple-entity-with-owner",
	flags = {
		"hidden",
		"placeable-player",
		"placeable-neutral",
		"player-creation",
	},
	placeable_by = {item = "cargo-transmat", count = 1},
	collision_box = {{-1.55,-1.55},{1.55,1.55}},
	selection_box = {{-2,-2},{2,2}},
	collision_mask = {"item-layer", "object-layer", "player-layer", "water-tile"}, 
	icon = DIR.get_icon_path("cargo-transmat",DIR.icon_size,g.icon_path),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	render_layer = "transport-belt-endings",
	picture = {
		filename = g.entities_path.. "cargo-transmat-base.png",
		draw_as_shadow = false,
		height = 256,
		priority = "high",
		width = 256,
		shift = {0,0},
		scale = 0.5,
		flags = DIR.recommended_sprite_flags,
	},
}})

for variant = 1,g.rock_variants do
	for _,material in pairs({"iron","copper","gold","tin","comet-ice"}) do
		local tint = (DIR.materials[material].hue and DIR.materials[material].saturation) and DIR.hsva2rgba(DIR.materials[material].hue, DIR.materials[material].saturation, 1) or DIR.materials[material].rgba
		data:extend({{
			name = "cargo-transmat-rocks-"..material.."-ore-"..variant,
			type = "explosion",
			flags = {
				"not-on-map",
				"placeable-off-grid"
			},
			icon = DIR.get_icon_path("placeholder"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			render_layer = "object",
			height = 0,
			rotate = false,
			animations = {
				{
					animation_speed = 1,
					filename = g.entities_path.. "cargo-transmat-rocks-"..variant..".png",
					tint = tint,
					draw_as_shadow = false,
					frame_count = 60,
					line_length = 10,
					width = 128,
					height = 192,
					priority = "high",
					shift = {0,-0.5},
					scale = 0.5,
					flags = DIR.recommended_sprite_flags,
				},
			},
		}})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- technology

DIR.add_new_minimal_tech("ir-quantum-mining", "quantum-satellite", g.tech_icon_path, {"quantum-satellite","cargo-transmat","comet-ice-processing"}, {"ir-transmat","space-science-pack"}) 

data.raw.technology["ir-quantum-mining"].IR_minimum_cost = 3000

------------------------------------------------------------------------------------------------------------------------------------------------------

-- items

DIR.generate_system_item("comet-ice","ore",nil,g.icon_path)

local machines = {
    ["cargo-transmat"] = {
        ingredients = {
            {"chrome-transmat", 1},
            {"electrum-plate-special", 6},
            {"field-effector", 3},
        },
        enabled = false,
        subgroup = "train-transport",
		category = "crafting",
        order = "zb"
    },
}

for machine,machinedata in pairs(machines) do
	DIR.add_new_machine(machine,machinedata,g.icon_path)
end

data:extend({
    -- {
        -- type = "item-subgroup",
        -- name = "space-processing",
        -- group = "ir-processing",
        -- order = "zzzzz",
    -- },
    {
        type = "item",
        name = "quantum-satellite",
		localised_description = {"item-description.quantum-satellite", g.maximum_launches},
        order = "zzz-b",
        stack_size = 1,
        icon = DIR.get_icon_path("quantum-satellite",DIR.icon_size,g.icon_path),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "quantum-satellite",
        result = "quantum-satellite",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
			{"helium-laser",16},
			{"nuclear-reactor",1},
			{"uranium-fuel-cell",80},
			{"steel-hull",360},
			{"computer-mk3",16},
			{"chrome-transmat",1},
        },
        energy_required = DIR.standard_crafting_time * 60,
		show_amount_in_title = false,
		always_show_products = true,
    },
    {
        type = "recipe",
        name = "comet-ice-processing",
        category = "chemistry",
        enabled = false,
        ingredients = {
			{name = "comet-ice-ore", type = "item", amount = 1},
        },
        results = {
			{name = "natural-gas", type = "fluid", amount = 10},
			{name = "water", type = "fluid", amount = 10},
        },
        icon = DIR.get_icon_path("comet-ice-processing",DIR.icon_size,g.icon_path),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        energy_required = DIR.standard_crafting_time,
		subgroup = "ir-fluid-recipes",
		order = "zzzzz",
		show_amount_in_title = false,
		always_show_products = true,
		IR_tech_rebuild_ignore = true,
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------
