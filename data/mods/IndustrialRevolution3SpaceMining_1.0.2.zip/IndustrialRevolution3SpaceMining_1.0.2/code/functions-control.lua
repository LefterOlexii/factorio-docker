------------------------------------------------------------------------------------------------------------------------------------------------------

local g = require("code/globals")

local function print_debug(text)
	-- game.print(game.tick .. ": "..text)
	-- log(game.tick .. ": "..text)
end

local function convert_corner_to_vector(corner)
	return {x = corner[1] or corner.x, y = corner[2] or corner.y}
end

local function convert_corners_to_area(corners)
	return {convert_corner_to_vector(corners[1]), convert_corner_to_vector(corners[2])}
end

function CONTROL.search_around_entity(entity,radius,types,names)
	if radius == nil then radius = 1 end
	local box = entity.prototype.collision_box
	for _,corner in pairs(box) do
		for k,v in pairs(corner) do
			local s = (v < 0) and -1 or 1
			corner[k] = v + (radius * s)
		end
	end
	box = { DIR.get_vector_sum(entity.position, box.left_top), DIR.get_vector_sum(entity.position, box.right_bottom) }
	return entity.surface.find_entities_filtered { name = names, type = types, area = box }
end

local function draw_offset_animation(frames,speed,params)
	params.animation_offset = -(game.tick * speed) % frames
	params.animation_speed = speed
	rendering.draw_animation(params)
end

function CONTROL.cargo_transmat_failure_visual(transmat,tint)
	-- transmat.surface.play_sound{path="klaxon", position=transmat.position}
	draw_offset_animation(2, 1/60, {
		animation = "transmat-glow-status",
		render_layer = "lower-object-above-shadow",
		target = transmat,
		surface = transmat.surface,
		time_to_live = 360,
		tint = tint,
	})
end

function CONTROL.get_buffer_item(item)
	global.buffers = global.buffers or {}
	global.buffers[item] = global.buffers[item] or 0
	return global.buffers[item]
end

function CONTROL.set_buffer_item(item,amount)
	global.buffers = global.buffers or {}
	global.buffers[item] = amount
end

function CONTROL.buffers_not_empty()
	global.buffers = global.buffers or {}
	for _,amount in pairs(global.buffers) do
		if amount > 0 then return true end
	end
	return false
end

function CONTROL.get_or_create_pending_storage(container)
	global.pending_clones = global.pending_clones or {}
	if global.pending_clones[container.unit_number] == nil then
		global.pending_clones[container.unit_number] = container.clone{position={0,0}, surface=CONTROL.get_or_create_limbo(), force=container.force, create_build_effect_smoke=false}
		print_debug("Container "..container.unit_number.." cloned")
	end
	return global.pending_clones[container.unit_number] 
end

function CONTROL.delete_pending_storage(container)
	global.pending_clones = global.pending_clones or {}
	if global.pending_clones[container.unit_number] and global.pending_clones[container.unit_number].valid then
		global.pending_clones[container.unit_number].destroy()
		print_debug("Container "..container.unit_number.." clone destroyed")
	end
	global.pending_clones[container.unit_number] = nil
end

function CONTROL.cargo_transmat_sequence(transmat)
	if not CONTROL.buffers_not_empty() then
		print_debug("Nothing to deliver")
		return
	end
	if transmat and transmat.valid then
		print_debug("Attempting connection to transmat "..transmat.unit_number)
		if transmat.energy < DIR.transmat_cost then
			CONTROL.cargo_transmat_failure_visual(transmat, {1,0,0})
			return
		else
			local delivered = false
			local highest_material = "iron-ore"
			local highest_amount = 0
			local containers = CONTROL.get_transmat_containers(transmat)
			for _,container in pairs(containers) do
				local delivery = {}
				local clone = CONTROL.get_or_create_pending_storage(container)
				if clone and clone.valid then
					local inv = clone.get_inventory(defines.inventory.chest)
					for item,_ in pairs(CONTROL.mined_items) do
						local amount = CONTROL.get_buffer_item(item)
						if amount > 0 then
							local accepted = clone.insert({name=item,count=amount})
							if accepted > 0 then
								CONTROL.set_buffer_item(item, amount - accepted)
								delivery[item] = accepted
								print_debug("Delivering "..accepted.." "..item.." to cargo "..container.unit_number..", leaving "..CONTROL.get_buffer_item(item))
								if accepted > highest_amount then
									highest_amount = accepted
									highest_material = item
								end
							end
						end
					end
				end
				if table_size(delivery) > 0 then
					CONTROL.add_delayed_action(240, {action = "deliver", entity = transmat, container = container, delivery = delivery})
					delivered = true
				else
					print_debug("Could not deliver anything to container "..container.unit_number)
					CONTROL.delete_pending_storage(container)
				end
			end
			if delivered then
				transmat.energy = transmat.energy - DIR.transmat_cost
				local delay = 1
				for i = 1,6 do
					CONTROL.add_delayed_action(delay, {action = "render_transmat_hex_light", target = transmat, light = i, force_lights = true})					
					delay = delay + 20
				end
				CONTROL.add_delayed_action(delay, {action = "rings", surface = transmat.surface, position = transmat.position, entity = transmat, no_base = false, base_entity = "cargo-transmat-base"})
				delay = delay + 60
				CONTROL.add_delayed_action(delay, {action = "appear", surface = transmat.surface, position = transmat.position})
				CONTROL.add_delayed_action(delay+20, {
					action = "create_entity",
					name = "cargo-transmat-rocks-"..highest_material.."-"..CONTROL.get_RNG(transmat.surface,1,g.rock_variants),
					surface = transmat.surface,
					position = transmat.position,
					create_build_effect_smoke=false,
				})
				return
			else
				print_debug("Not enough power in transmat "..transmat.unit_number)
				CONTROL.cargo_transmat_failure_visual(transmat,{0.1,0.9,1.0})
			end
		end
	else
		print_debug("Transmat not valid")
		return
	end
end

function CONTROL.get_launches()
	local soft_launches = game.forces["player"].get_item_launched("quantum-satellite")
	global.launches = global.launches or 0
	global.launches = (soft_launches > global.launches) and soft_launches or global.launches
	return global.launches
end

function CONTROL.get_capped_launches()
	return math.min(CONTROL.get_launches(), g.maximum_launches)
end

function CONTROL.cargo_transmat_cycle(deliver_only)
	local surface = game.surfaces["nauvis"]
	if not surface then return end
	local launches = CONTROL.get_capped_launches()
	if launches > 0 then 
		print_debug("Transmat cycle begins, probes active: "..launches)
		-- add to buffers
		if deliver_only ~= true then
			for item,multiplier in pairs(CONTROL.mined_items) do
				local yield = math.floor(g.total_mining_yield_per_launch_per_day * launches * multiplier) 
				CONTROL.set_buffer_item(item, math.min(g.buffer_maximum_per_launch * launches, CONTROL.get_buffer_item(item) + yield))
				print_debug("Mined "..item..", buffer is now "..CONTROL.get_buffer_item(item))
			end
		end
		-- cycle
		local delay = 5
		for _,transmat in pairs(CONTROL.get_tracked_transmats()) do
			CONTROL.add_delayed_action(delay, {action = "cargo_transmat_sequence", entity = transmat})
			delay = delay + CONTROL.cargo_transmat_spacing
		end
	end
end

local function info_row(root,caption1,caption2)
	local t = root.add {
		type = "table",
		column_count = 2,
	}
	t.style.horizontally_stretchable = true
	t.style.horizontal_spacing = 4
	t.style.top_margin = 4
	t.style.bottom_margin = 4
	local label = t.add {
		type = "label",
		caption = caption1,
		style = "description_property_name_label",
	}
	label.style.vertical_align = "top"
	label.style.horizontal_align = "right"
	label.style.width = 152
	local label = t.add {
		type = "label",
		caption = caption2,
		style = "description_value_label",
	}
	label.style.vertical_align = "top"
end

local function get_red_if_limit(localisation,value,limit)
	if value <= limit then return localisation end
	return {"", "[color=red]", localisation, "[/color]"}
end

local function get_total_slots(containers)
	local count = 0 
	for _,container in pairs(containers) do
		count = count + #container.get_inventory(defines.inventory.chest)
	end
	return count
end

function CONTROL.create_transmat_gui(player, selected)

    if not player or not selected then return end
	
	player.opened = player.gui.screen
	if player.gui.screen[CONTROL.transmat_gui] then player.gui.screen[CONTROL.transmat_gui].destroy() end
	
	-- create frame

	local frame = player.gui.screen.add {
		type = "frame",
		name = CONTROL.transmat_gui,
		direction = "vertical",
		style = "transmat_frame",
	}
	-- cache which entity this gui belongs to
	frame.tags = { unit_number = selected.unit_number }
	frame.style.minimal_width = 400
		
	-- update frame location if cached
	if CONTROL.get_player_global(player.index,"transmat_gui_location") then
		frame.location = CONTROL.get_player_global(player.index,"transmat_gui_location")
	else
		frame.force_auto_center()
	end

	-- header
	local header = frame.add {
		type = "flow",
		direction = "horizontal",
		name = "transmat-header",
	}
	header.style.bottom_padding = -4
	header.style.horizontally_stretchable = true
	
	-- icon
	local icon = header.add {
		name = "icon",
		type = "sprite",
		sprite = "item/cargo-transmat",
		style = "transmat_header_icon",
	}
	icon.style.size = 24
	icon.style.margin = 0
	icon.style.padding = 0
	icon.style.right_margin = 4
	
	-- title
	local title = header.add {
		name = "cargo-transmat-header-title",
		type = "label",
		caption = {"entity-name.cargo-transmat"},
		style = "frame_title",
	}
	title.style.right_padding = 8

	-- "drag filler"
	local filler = header.add {
		type = "empty-widget",
		style = "draggable_space_header",
	}
	filler.style.natural_height = 24
	filler.style.horizontally_stretchable = true
	filler.drag_target = frame
	
	-- help button
	local help_button = header.add {
		name = "cargo-transmat-header-help",
		type = "sprite-button",
		style = "transmat_small_button",
		sprite = "help-button",
		hovered_sprite = "help-button-black",
		clicked_sprite = "help-button-black",
		tooltip = {"gui.open-manifesto"},
	}

	-- close button
	local close_button = header.add {
		name = "cargo-transmat-header-close",
		type = "sprite-button",
		style = "transmat_small_button",
		sprite = "utility/close_white",
		hovered_sprite = "utility/close_black",
		clicked_sprite = "utility/close_black",
		tooltip = {"gui.close-gui"},
	}
	
	-- MAIN panels
	
	local main_table = frame.add {
		type = "table",
		column_count = 2,
	}
	main_table.style.horizontal_spacing = 8
	main_table.style.top_margin = 8
	
	local panel = main_table.add {
		type = "frame",
		style = "transmat_deep_frame",
		direction = "vertical",
	}
	
	-- left
	local preview = panel.add {
		type = "camera",
		position = selected.position,
		surface_index = selected.surface.index,
		zoom = player.display_scale,
	}
	preview.style.height = 256
	preview.style.width = 256

	-- right
	local panel = main_table.add {
		type = "frame",
		style = "transmat_deep_frame",
		direction = "vertical",
	}
	panel.style.height = 256
	panel.style.width = 320
	panel = panel.add {
		type = "frame",
		style = "tooltip_panel_background",
		direction = "vertical",
	}
	panel.style.horizontally_stretchable = true
	panel.style.vertically_stretchable = true
	panel.style.padding = 8
	panel.style.top_padding = 4
	
	info_row(panel, {"gui.local-capacity"}, {"gui.local-slots", get_total_slots(CONTROL.get_transmat_containers(selected))})
	info_row(panel, {"gui.active-transmats"}, {"", get_red_if_limit(CONTROL.get_tracked_transmat_count(),CONTROL.get_tracked_transmat_count(),g.maximum_transmats), "/", g.maximum_transmats})
	info_row(panel, {"gui.probes-launched"}, {"", get_red_if_limit(CONTROL.get_launches(),CONTROL.get_launches(),g.maximum_launches), "/", g.maximum_launches})

	local first = true
	for item,amount in pairs(CONTROL.mined_items) do
		info_row(panel, first and {"gui.maximum-haul"} or "", {"gui.local-stacks", "[img=item/"..item.."] " .. math.ceil((g.total_mining_yield_per_launch_per_day / CONTROL.ore_stack_size) * amount * CONTROL.get_launches())})
		first = false
	end
end

function CONTROL.get_player_global(player_index,info)
	global.players = global.players or {}
	global.players[player_index] = global.players[player_index] or {}
	return global.players[player_index][info]
end

function CONTROL.set_player_global(player_index,info,value)
	global.players = global.players or {}
	global.players[player_index] = global.players[player_index] or {}
	global.players[player_index][info] = value
end

function CONTROL.clear_transmat_data(transmat)
	print_debug("Clearing transmat "..transmat.unit_number)
	global.transmat_data = global.transmat_data or {}
	global.transmat_data[transmat.unit_number] = nil
end

function CONTROL.get_tracked_transmat_count()
	global.transmat_data = global.transmat_data or {}
	return table_size(global.transmat_data)
end

function CONTROL.rebuild_all_transmat_data()
	global.transmat_data = {}
	for _,surface in pairs(game.surfaces) do
		for _,transmat in pairs(surface.find_entities_filtered{name="cargo-transmat", force="player"}) do
			local containers = CONTROL.get_containers_around_transmat(transmat)
			for _,container in pairs(containers) do
				CONTROL.delete_pending_storage(container)
				CONTROL.add_transmat_container(transmat,container)
			end
		end
	end
end

local function draw_line_from_container_to_transmat(transmat,container)
	local colour = {0.5,1,0.5}
	rendering.draw_line {
		color = colour,
		width = 1.5,
		dash_length = 0.125,
		gap_length = 0.125,
		only_in_alt_mode = true,
		from = container,
		to = transmat,
		surface = transmat.surface,
		forces = {transmat.force},
	}
	rendering.draw_circle {
		color = colour,
		radius = 0.125,
		filled = true,
		only_in_alt_mode = true,
		target = container,
		surface = container.surface,
		forces = {transmat.force},
	}
	rendering.draw_circle {
		color = colour,
		radius = 0.125,
		filled = true,
		only_in_alt_mode = true,
		target = transmat,
		surface = transmat.surface,
		forces = {transmat.force},
	}
end

local function remove_lines_from_entity(entity)
	local ids = {}
	for _,id in pairs(rendering.get_all_ids(g.this_mod_name)) do
		if rendering.get_target(id) and (rendering.get_target(id).entity == entity) then ids[id] = true
		elseif rendering.get_from(id) and (rendering.get_from(id).entity == entity) then ids[id] = true
		end
	end
	for id,_ in pairs(ids) do
		rendering.destroy(id)
	end
end

function CONTROL.add_transmat_container(transmat,container)
	print_debug("Registering container "..container.unit_number.." with transmat "..transmat.unit_number)
	global.transmat_data = global.transmat_data or {}
	global.transmat_data[transmat.unit_number] = global.transmat_data[transmat.unit_number] or {transmat = transmat, containers = {}}
	table.insert(global.transmat_data[transmat.unit_number].containers, container)
	draw_line_from_container_to_transmat(transmat,container)
end

function CONTROL.remove_transmat_container(transmat,container)
	print_debug("Deregistering container "..container.unit_number.." with transmat "..transmat.unit_number)
	global.transmat_data = global.transmat_data or {}
	global.transmat_data[transmat.unit_number] = global.transmat_data[transmat.unit_number] or {transmat = transmat, containers = {}}
	local containers = {}
	for _,ocontainer in pairs(global.transmat_data[transmat.unit_number].containers) do
		if ocontainer.valid and (ocontainer.unit_number ~= container.unit_number) then table.insert(containers, ocontainer) end
	end
	global.transmat_data[transmat.unit_number].containers = containers
end

function CONTROL.fetch_and_validate_transmat_containers(transmat)
	global.transmat_data = global.transmat_data or {}
	global.transmat_data[transmat.unit_number] = global.transmat_data[transmat.unit_number] or {transmat = transmat, containers = {}}
	local validated = {}
	for _,container in pairs(global.transmat_data[transmat.unit_number].containers) do
		if container and container.valid then table.insert(validated,container) end
	end
	global.transmat_data[transmat.unit_number].containers = validated	
	return validated
end

function CONTROL.get_transmat_containers(transmat)
	-- eh
	return CONTROL.fetch_and_validate_transmat_containers(transmat)
end

function CONTROL.get_container_transmats(container)
	local transmats = {}
	global.transmat_data = global.transmat_data or {}
	for unit,tdata in pairs(global.transmat_data) do
		if tdata.transmat and tdata.transmat.valid then
			for _,tcontainer in pairs(tdata.containers) do
				if tcontainer.valid and (tcontainer.unit_number == container.unit_number) then
					table.insert(transmats, tdata.transmat)
				end
			end
		end
	end
	return transmats
end

function CONTROL.get_tracked_transmats()
	global.transmat_data = global.transmat_data or {}
	local list = {}
	local count = 0
	for _,transmat in pairs(global.transmat_data) do
		table.insert(list, transmat.transmat)
		count = count + 1
		if count == g.maximum_transmats then return list end
	end
	return list
end

local function containers()
	return {
		["container"] = true,
		["logistic-container"] = true,
	}
end

local function is_a_container(etype)
	return containers()[etype] or false
end

local function container_list()
	return DIR.keys_to_values(containers())
end

function CONTROL.event_destroyed(event)
    if event.entity and event.entity.valid then
		if event.entity.name == "cargo-transmat" then
			CONTROL.clear_transmat_data(event.entity)
		end
		if is_a_container(event.entity.type) then
			local entities = CONTROL.get_container_transmats(event.entity)
			for _,e in pairs(entities) do
				CONTROL.remove_transmat_container(e,event.entity)
			end
			CONTROL.delete_pending_storage(event.entity)
		end
	end
end

function CONTROL.get_containers_around_transmat(transmat)
	return CONTROL.search_around_entity(transmat, 1, container_list())
end

function CONTROL.get_transmats_around_container(container)
	return CONTROL.search_around_entity(container, 1, "electric-energy-interface", "cargo-transmat")
end

function CONTROL.event_built(event)
	local entity = event.created_entity or event.entity or event.destination
	if entity and entity.valid then
		if entity.name == "cargo-transmat" then
			local entities = CONTROL.get_containers_around_transmat(entity)
			for _,e in pairs(entities) do
				CONTROL.add_transmat_container(entity,e)
			end
		elseif is_a_container(entity.type) then
			local entities = CONTROL.get_transmats_around_container(entity)
			for _,e in pairs(entities) do
				CONTROL.add_transmat_container(e,entity)
			end
		end
	end
end

function CONTROL.on_gui_opened(event)
	if event.gui_type ~= defines.gui_type.entity then return end
    local entity = event.entity
    if entity and entity.valid then
		local player = game.players[event.player_index]
		if entity.name == "cargo-transmat" then
			CONTROL.create_transmat_gui(player, entity)
		end
	end
end

function CONTROL.on_gui_close(event)
    local player = game.players[event.player_index]
    local frame = player.gui.screen[CONTROL.transmat_gui]
    if frame then
		CONTROL.set_player_global(player.index,"transmat_gui_location",frame.location)
		player.opened = nil
        return frame.destroy()
    end
	return false
end

CONTROL.gui_click = {
	["cargo-transmat-header-help"] = function (event)
        CONTROL.on_gui_close(event)
		remote.call("ir-manifesto", "open", {player_index = event.player_index, page_name = "ir-spacemining"})
	end,
    ["cargo-transmat-header-close"] = function (event)
        CONTROL.on_gui_close(event)
    end,
}

function CONTROL.on_gui_click(event)
	if CONTROL.gui_click[event.element.name] then
		CONTROL.gui_click[event.element.name](event)
	end
end

function CONTROL.config_refresh(event)
	if (event.mod_changes[g.this_mod_name] and (event.mod_changes[g.this_mod_name].new_version ~= event.mod_changes[g.this_mod_name].old_version)) then
		CONTROL.rebuild_all_transmat_data()
	end
end

function CONTROL.event_teleported(event)
	local entity = event.entity
	if entity and entity.valid then
		if entity.type == "container" or entity.type == "logistic-container" then
			remove_lines_from_entity(entity)
			CONTROL.event_destroyed(event)
			CONTROL.event_built(event)			
		elseif entity.name == "cargo-transmat" then
			remove_lines_from_entity(entity)
			for _,container in pairs(CONTROL.get_transmat_containers(entity)) do
				remove_lines_from_entity(container)
			end
			CONTROL.event_destroyed(event)
			CONTROL.event_built(event)			
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
