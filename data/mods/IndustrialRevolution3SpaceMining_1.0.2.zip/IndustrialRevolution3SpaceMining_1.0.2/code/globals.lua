------------------------------------------------------------------------------------------------------------------------------------------------------

local g = {}

g.this_mod_name = "IndustrialRevolution3SpaceMining"

g.icon_path = "__"..g.this_mod_name.."__/graphics/icons"
g.entities_path = "__"..g.this_mod_name.."__/graphics/entities/"
g.tech_icon_path = "__"..g.this_mod_name.."__/graphics/icons"

g.rock_variants = 2
g.maximum_launches = 1000
g.maximum_transmats = 100
g.total_mining_yield_per_launch_per_day = 1600
g.buffer_maximum_per_launch = 4000

return g

------------------------------------------------------------------------------------------------------------------------------------------------------
