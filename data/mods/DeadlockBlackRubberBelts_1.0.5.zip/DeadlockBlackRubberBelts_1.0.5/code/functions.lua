local F = {}

F.graphics_path = "__DeadlockBlackRubberBelts__/graphics"
F.icons_path = F.graphics_path .. "/icons"
F.sprites_path = F.graphics_path .. "/entities"

function F.get_icon_path(name, dir)
	return string.format("%s/%s.png", F.graphics_path .. "/" .. (dir or "icons"), name)
end

function F.replace_item_icon(item_name, icon, entity_type, entity_name)
	if not icon then icon = item_name end
	local item = data.raw.item[item_name] or data.raw.fluid[item_name] or data.raw.tool[item_name] or data.raw.module[item_name]
	item.icon = F.get_icon_path(icon)
	item.icons = nil
	item.icon_size = 64
	item.icon_mipmaps = 4
	item.pictures = nil
end

function F.add_mask_to_item_icon(item_name, icon, tint)
	local item = data.raw.item[item_name] or data.raw.fluid[item_name] or data.raw.tool[item_name] or data.raw.module[item_name]
	if item.icons == nil then
		item.icons = item.icon ~= nil and {{icon = item.icon, icon_size = item.icon_size, icon_mipmaps = item.icon_mipmaps }} or {}
	end
	table.insert(item.icons, 
		{ icon = F.get_icon_path(icon), icon_size = 64, icon_mipmaps = 4, tint = tint }
	)
end

function F.copy_item_icons_to_entity(entity_type, name)
	local entity = data.raw[entity_type][name]
	local item = data.raw.item[name]
	if entity and item then
		entity.icon = item.icon
		entity.icon_size = item.icon_size
		entity.icon_mipmaps = item.icon_mipmaps
		entity.icons = item.icons
	end
end

function F.get_belt_animation(suffix,tint,frame_count,repeat_count)
	frame_count = frame_count or 16
	return {
		filename = F.sprites_path.."/rubber-belt-"..suffix..".png",
		priority = "extra-high",
		width = 128,
		height = 128,
		frame_count = frame_count,
		repeat_count = repeat_count,
		direction_count = 20,
		scale = 0.5,
		tint = tint,
	}
end

function F.get_belt_animation_set(tint, base)
	local a = settings.startup["ir2rb-arrows"].value and settings.startup["ir2rb-arrows-doubled"].value and "arrow-doubled" or "arrow"
	local f = settings.startup["ir2rb-arrows"].value and settings.startup["ir2rb-arrows-doubled"].value and 32 or 16
	local layers = {
		layers = {
			F.get_belt_animation("base-"..base, nil, 8, f/8),
		}
	}
	if settings.startup["ir2rb-arrows"].value then 
		table.insert(layers.layers, F.get_belt_animation(a, tint, f))
	end
	if settings.startup["ir2rb-rails"].value then table.insert(layers.layers, F.get_belt_animation("rails", tint, 8, f/8)) end
	return #layers.layers > 1 and layers or layers.layers[1]
end

function F.hsva2rgba(h, s, v, a)
	if a == nil then a = 1 end
    local r, g, b
    local i = math.floor(h * 6);
    local f = h * 6 - i;
    local p = v * (1 - s);
    local q = v * (1 - f * s);
    local t = v * (1 - (1 - f) * s);
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    elseif i == 5 then r, g, b = v, p, q
    end
    return { r = r, g = g, b = b, a = a }
end

return F