------------------------------------------------------------------------------------------------------------------------------------------------------

-- DEADLOCK'S INDUSTRIAL REVOLUTION 3
-- See LICENSE.txt for license details

------------------------------------------------------------------------------------------------------------------------------------------------------

CONTROL = {}

CONTROL.generated_event_ids = {
	["on_forestry_chunk_updated"] = script.generate_event_name(),
	["on_transfer_plate_or_hotkey"] = script.generate_event_name(),
}

require("code.control.control-globals")
require("code.control.control-events")
require("code.control.control-pollution")
require("code.control.control-simulated-simulations")
require("code.control.control-documentation")
require("code.control.control-misc")
require("code.control.control-delayed-actions")
require("code.control.control-mapmarkers")
require("code.control.control-terrain")
require("code.control.control-transmats")
require("code.control.control-fuel-manager")
require("code.control.control-fetchport")
require("control-remote")

CONTROL.debug = false

------------------------------------------------------------------------------------------------------------------------------------------------------

-- initialisation

script.on_init(CONTROL.initialise)
script.on_configuration_changed(CONTROL.config_refresh)
script.on_load(CONTROL.on_load)
script.on_event(defines.events.on_runtime_mod_setting_changed, CONTROL.runtime_setting_changed)
script.on_event(defines.events.on_technology_effects_reset, CONTROL.technology_effects_reset)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- building destruction and fluid flushing

script.on_event({
	defines.events.on_built_entity,
	defines.events.on_robot_built_entity,
	defines.events.script_raised_built,
	defines.events.script_raised_revive,
	defines.events.on_entity_cloned,
}, CONTROL.event_built)

script.on_event({
	defines.events.on_player_mined_entity,
	defines.events.on_robot_mined_entity,
	defines.events.script_raised_destroy,
}, CONTROL.event_destroyed)

script.on_event(defines.events.on_entity_died, CONTROL.event_died)
script.on_event(defines.events.on_player_flushed_fluid, CONTROL.event_raised_flush)
script.on_event(defines.events.on_player_setup_blueprint, CONTROL.event_setup_blueprint)
script.on_event(defines.events.on_post_entity_died, CONTROL.event_post_entity_died)

script.set_event_filter(defines.events.on_built_entity, CONTROL.build_event_filters)
script.set_event_filter(defines.events.on_entity_died, CONTROL.destroy_event_filters)
script.set_event_filter(defines.events.on_player_mined_entity, CONTROL.destroy_event_filters)
script.set_event_filter(defines.events.on_post_entity_died, CONTROL.post_died_event_filters)
script.set_event_filter(defines.events.on_robot_built_entity, CONTROL.build_event_filters)
-- script.set_event_filter(defines.events.on_robot_mined_entity, CONTROL.destroy_event_filters) -- currently needed for every entity

script.on_event(defines.events.script_raised_teleported, CONTROL.event_teleported, CONTROL.teleport_event_filters)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fuel manager

script.on_event(defines.events.on_lua_shortcut, function(event)
	local player = game.players[event.player_index]
    if event.prototype_name == "ir-fuel-manager" then
        player.set_shortcut_toggled("ir-fuel-manager", not player.is_shortcut_toggled("ir-fuel-manager"))
    end
    if event.prototype_name == "ir-manifesto" then
		CONTROL.toggle_manifesto(event)
    end
end)

script.on_event("ir-control-fuel-manager", function(event)
	local player = game.players[event.player_index]
    if player and player.is_shortcut_available("ir-fuel-manager") then
        player.set_shortcut_toggled("ir-fuel-manager", not player.is_shortcut_toggled("ir-fuel-manager"))
    end
end)

script.on_event({
	defines.events.on_player_placed_equipment,
	defines.events.on_player_removed_equipment,
	defines.events.on_player_armor_inventory_changed,
	defines.events.on_player_driving_changed_state,
}, function(event)
    local player = game.players[event.player_index]
    if player then player.set_shortcut_available("ir-fuel-manager", CONTROL.is_fuel_manager_unlockable(player)) end
end)

script.on_nth_tick(CONTROL.fuel_manager_interval, function(event)
    for _,player in pairs(game.players) do
        if player.valid and player.controller_type == defines.controllers.character and CONTROL.is_fuel_manager_unlockable(player) and player.is_shortcut_toggled("ir-fuel-manager") then
            CONTROL.refuel(player)
        end
    end
end)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- machine guis

script.on_event(defines.events.on_gui_opened, CONTROL.on_gui_opened)
script.on_event(defines.events.on_gui_text_changed, CONTROL.on_gui_text_changed)
script.on_event(defines.events.on_gui_confirmed, CONTROL.on_gui_confirmed)
script.on_event(defines.events.on_gui_location_changed, CONTROL.on_gui_location_changed)
script.on_event(defines.events.on_gui_closed, CONTROL.on_gui_close)
script.on_event(defines.events.on_gui_click, CONTROL.on_gui_click)
script.on_event(defines.events.on_gui_elem_changed, CONTROL.on_gui_click)
script.on_event(defines.events.on_gui_selection_state_changed, CONTROL.on_gui_click)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- non-gui player stuff

script.on_nth_tick(CONTROL.driving_autocorrect_interval, CONTROL.driving_autocorrect)

script.on_event(defines.events.on_player_created, CONTROL.on_player_created)
script.on_event(defines.events.on_cutscene_waypoint_reached, CONTROL.on_cutscene)
script.on_event(defines.events.on_selected_entity_changed, CONTROL.on_selected_entity_changed)

script.on_event("ir-entity-adjustment", CONTROL.entity_adjustment)
script.on_event("ir-increase", function(event) CONTROL.cycle_glow_recipe(event,1) end)
script.on_event("ir-decrease", function(event) CONTROL.cycle_glow_recipe(event,-1) end)

script.on_event(defines.events.on_player_left_game, function (event)
	local player = game.players[event.player_index]
	if player and player.controller_type == defines.controllers.cutscene and CONTROL.transmat_player_is_teleporting(event.player_index) then
		CONTROL.client_quits_during_teleport_cutscene(event)
	end
end)

script.on_event(defines.events.on_trigger_created_entity, function(event)
	if event.entity and event.entity.valid and event.entity.name == "lampbot" and event.source and event.source.valid then
		event.entity.orientation = DIR.get_facing_away(event.entity, event.source)
	end
end)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- custom trigger effects & misc

script.on_event(defines.events.on_script_trigger_effect, CONTROL.script_trigger_effect)
script.on_event(defines.events.on_train_changed_state, CONTROL.train_changed_state)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- sprinkle the sparklies

script.on_event(defines.events.on_chunk_generated, function (event)
	CONTROL.replace_fissures(event.surface,event.position,event.area) -- 3.1.17 fissure decoration
	CONTROL.decorate_gem_rocks(event.surface,event.position,event.area) -- 3.1.17 gem rock decoration
end)

script.on_event(defines.events.on_resource_depleted, function (event)
	CONTROL.replenish_fissure(event.entity)
end)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- cycles

script.on_nth_tick(CONTROL.forestry_cycle_interval, CONTROL.forestry_cycle) 

------------------------------------------------------------------------------------------------------------------------------------------------------

-- manifesto / informatron

CONTROL.init_informatron_interface()
script.on_event("ir-manifesto", CONTROL.toggle_manifesto)
script.on_event(defines.events.on_player_display_scale_changed, CONTROL.display_scale_changed)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- not currently used

-- script.on_event(defines.events.on_player_respawned, function(event)
	-- local player = game.players[event.player_index]
-- end)

-- script.on_event(defines.events.on_player_joined_game, function(event)
	-- local player = game.players[event.player_index]
-- end)

-- script.on_event(defines.events.on_trigger_fired_artillery, function(event)
	-- global.last_artillery = game.tick
-- end)

------------------------------------------------------------------------------------------------------------------------------------------------------
