------------------------------------------------------------------------------------------------------------------------------------------------------

-- DEADLOCK'S INDUSTRIAL REVOLUTION 3
-- See LICENSE.txt for license details

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Set up character crafting categories
require("code.entities.entities-character-final-fixes")

-- Final third party mod stuff
require("code.mods.mods-data-final-fixes")

-- Generate scrapping and voiding recipes
require("code.items-fluids-recipes.recipes-scrapping")
require("code.items-fluids-recipes.recipes-voiding") 

-- Final, final pass
require("code.technology.technology-prereq-convert")
DIR.final_recipes_pass()
DIR.final_entities_pass()
DIR.validate_kits()

-- Debug/stats
-- DIR.redundancy_scan()
-- DIR.collocation_scan(3,8)

------------------------------------------------------------------------------------------------------------------------------------------------------

