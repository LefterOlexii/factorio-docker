------------------------------------------------------------------------------------------------------------------------------------------------------

-- DEADLOCK'S INDUSTRIAL REVOLUTION 3
-- See LICENSE.txt for license details

------------------------------------------------------------------------------------------------------------------------------------------------------

-- GLOBALS
require("code.data.globals")
require("code.entities.entities-standards")

-- TERRAIN/tiles
require("code.terrain.terrain-tiles") -- before items-generated

-- ITEMS & FLUIDS -- after terrain
require("code.items-fluids-recipes.items-vanilla") -- first
require("code.items-fluids-recipes.items-groups") 
require("code.items-fluids-recipes.items-generated") -- after groups
require("code.items-fluids-recipes.items-modules") -- after generated
require("code.items-fluids-recipes.items-machines")
require("code.items-fluids-recipes.items-bots")
require("code.items-fluids-recipes.items-misc")
require("code.items-fluids-recipes.items-power")
require("code.items-fluids-recipes.items-space")
require("code.items-fluids-recipes.items-weapons")
require("code.items-fluids-recipes.items-air-purification")
require("code.items-fluids-recipes.items-selection")
require("code.items-fluids-recipes.equipment-vanilla")
require("code.items-fluids-recipes.equipment")
require("code.items-fluids-recipes.fluids-oil")
require("code.items-fluids-recipes.fluids-gas")
require("code.items-fluids-recipes.fluids-canning")
require("code.items-fluids-recipes.fluids-misc")
require("code.items-fluids-recipes.recipes-forestry")
require("code.items-fluids-recipes.recipes-coolant") -- after fluids and all items & equipment

-- SIGNALS
require("code.signals.signals")
require("code.signals.signal-colour-mapping")

-- ENTITIES -- after items and signals
require("code.entities.entities-vanilla")
require("code.entities.entities-stone-copper")
require("code.entities.entities-bronze")
require("code.entities.entities-iron")
require("code.entities.entities-steel") -- after iron
require("code.entities.entities-chrome") -- after steel
require("code.entities.entities-assemblers") -- after steel
require("code.entities.entities-fluid") -- after assemblers
require("code.entities.entities-drills")
require("code.entities.entities-labs")
require("code.entities.entities-storage")
require("code.entities.entities-vehicles")
require("code.entities.entities-inserters")
require("code.entities.entities-power")
require("code.entities.entities-forestry")
require("code.entities.entities-bots")
require("code.entities.entities-walls")
require("code.entities.entities-pipes")
require("code.entities.entities-turrets")
require("code.entities.entities-projectiles-explosions")
require("code.entities.entities-decorative") -- after labs
require("code.entities.entities-particles") -- after bots
require("code.entities.entities-target-masks") -- after turrets
require("code.entities.entities-simulations") -- after all other entities & items

-- TERRAIN/resources -- after items and entities
require("code.terrain.terrain-ores")
require("code.terrain.terrain-fissures") -- after ores
require("code.terrain.terrain-misc-resources") -- after items and ores
require("code.terrain.terrain-trees")
require("code.terrain.terrain-presets")

-- GUI and media
require("code.gui.gui")
require("code.gui.sprites-animations")
require("code.gui.sounds")
require("code.gui.documentation")
require("code.gui.menu-simulations")
require("code.gui.custom-input")
require("code.gui.cheevments")

-- TECHNOLOGIES: now entirely in data-updates

------------------------------------------------------------------------------------------------------------------------------------------------------
