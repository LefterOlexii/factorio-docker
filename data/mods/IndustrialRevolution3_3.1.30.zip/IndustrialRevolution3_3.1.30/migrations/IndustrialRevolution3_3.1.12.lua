for _,force in pairs(game.forces) do
	if force.technologies["ir-electroplating"].researched == true then
		force.technologies["ir-advanced-engine"].researched = true
	end
end
log("IR3: 3.1.12 electroplating migration")