------------------------------------------------------------------------------------------------------------------------------------------------------

local limits = {x = 60, y = 30}
local cos = math.cos
local sin = math.sin
local rads = math.pi*2

for _,bot in pairs(global.sbots) do
	if bot and bot.valid then
		local p = {x = bot.position.x + cos((bot.orientation-0.25)*rads)/10, y = bot.position.y + sin((bot.orientation-0.25)*rads)/10}
		if p.y > global.centre.y + limits.y then
			p.y = p.y - (limits.y * 2)
		elseif p.y < global.centre.y - limits.y then
			p.y = p.y + (limits.y * 2)
		end
		if p.x > global.centre.x + limits.x then
			p.x = p.x - (limits.x * 2)
		elseif p.x < global.centre.x - limits.x then
			p.x = p.x + (limits.x * 2)
		end
		bot.teleport(p)
	end
end

for _,bot in pairs(global.lbots) do
	if bot and bot.valid then
		bot.orientation = global.ldirs[bot.unit_number] - (cos(game.tick/120) / (#global.lbots*2))
		bot.time_to_live = 999
	end
end

for _,botdata in pairs(global.gbots) do
	if botdata.bot and botdata.bot.valid then
		botdata.theta = botdata.theta + botdata.sign * (0.2/botdata.distance)
		local p = {x = global.centre.x + (math.cos(botdata.theta)*botdata.distance), y = global.centre.y + 1.5 + (math.sin(botdata.theta)*botdata.distance)}
		botdata.bot.teleport(p)
		botdata.bot.orientation = (botdata.theta/(math.pi*2))-0.5+((botdata.sign == -1) and 0.5 or 0) 
	end
end

if global.fchar.position.y > global.centre.y + global.ychar then
	global.fchar.teleport({x = global.centre.x + 7.5, y = global.centre.y + global.ychar})
	global.fchar.walking_state = { direction = defines.direction.north, walking = true }
elseif global.fchar.position.y < global.centre.y - global.ychar then
	global.fchar.teleport({x = global.centre.x - 7.5, y = global.centre.y - global.ychar})
	global.fchar.walking_state = { direction = defines.direction.south, walking = true }
end

------------------------------------------------------------------------------------------------------------------------------------------------------
