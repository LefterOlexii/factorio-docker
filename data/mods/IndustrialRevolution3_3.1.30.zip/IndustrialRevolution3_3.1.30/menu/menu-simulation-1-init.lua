------------------------------------------------------------------------------------------------------------------------------------------------------

local function get_vector_sum(v1,v2)
    if not v1 or not v2 then return nil end
    return { x = v1.x + v2.x, y = v1.y + v2.y}
end

local function render_drop_text(text, target, offset)
	rendering.draw_text{text=text, surface=target.surface, target=target, target_offset=get_vector_sum(offset,{x=3/64,y=3/64}), alignment="center", color={0,0,0,0.75}, scale=1, font="default-bold", forces={target.force}, draw_on_ground=true, only_in_alt_mode=false}
	rendering.draw_text{text=text, surface=target.surface, target=target, target_offset=offset, alignment="center", color={255, 230, 192}, scale=1, font="default-bold", forces={target.force}, draw_on_ground=true, only_in_alt_mode=false}
end

-- local function spell_out_letters(material,text,surface,position)
	-- local _, c = text:gsub("%.","")
	-- position.x = position.x - (string.len(text)*0.4) + (c*0.4) 
	-- local count = 0
	-- for letter in text:gmatch(".") do 
		-- letter = (letter == ".") and "stop" or letter
		-- if letter ~= " " then
			-- surface.create_entity{name=material.."-letter-"..letter, position = {position.x + count - ((letter == "stop") and 0.2 or 0), position.y}, force="neutral"}
		-- end
		-- count = count + ((letter == "stop") and 0.4 or 0.8)
	-- end
-- end

global.centre = {x = -8, y = 10}
game.camera_position = global.centre
game.camera_zoom = 1 
game.tick_paused = false
game.surfaces.nauvis.daytime = 0.6

global.sbots = {}
for i = 0,16 do
	local bot = game.surfaces.nauvis.create_entity{name = "steambot", position = {x = global.centre.x+(math.random()*90)-45, y = global.centre.y+(math.random()*60)-30}, force = "neutral"}
	bot.orientation = math.random()
	table.insert(global.sbots, bot)
	-- for _,j in pairs({-2/5,2/5}) do
		-- local theta = (bot.orientation-0.25+j)*math.pi*2
		-- for d = 1,2 do
			-- local p = {x = bot.position.x + (math.cos(theta)*d*1.5), y = bot.position.y + (math.sin(theta)*d*1.5)}
			-- local fbot = game.surfaces.nauvis.create_entity{name = "steambot", position = p, force = "neutral"}
			-- fbot.orientation = bot.orientation
			-- table.insert(global.sbots, fbot)
		-- end
	-- end
end

global.gbots = {}
-- local sign = 1
-- for i=10,40,2 do
	-- local orientation = math.random()
	-- for j=0,2 do
		-- local theta = (orientation-0.25+(j/3))*math.pi*2
		-- local p = global.centre
		-- local bot = game.surfaces.nauvis.create_entity{name = "steambot", position = p, force = "neutral"}
		-- table.insert(global.gbots, { bot = bot, theta = theta, distance = i, sign = sign })
	-- end
	-- sign = sign * -1
-- end

global.lbots = {}
global.ldirs = {}
local d = 3.5
local b = 5
for i = 0,b-1 do
	local a = (i/b) - 0.25
	local bot = game.surfaces.nauvis.create_entity{name = "lampbot", position = { x = global.centre.x + math.cos(a*math.pi*2) * d, y = -1 + global.centre.y + math.sin(a*math.pi*2) * d}, force = "player"}
	table.insert(global.lbots, bot)
	bot.orientation = a + 0.25
	global.ldirs[bot.unit_number] = bot.orientation
end

for _,c in pairs(game.surfaces.nauvis.find_entities_filtered{type="character"}) do
	c.destroy()
end

global.ychar = 100
global.fchar = game.surfaces.nauvis.create_entity{name = "character", position = { x = global.centre.x - 7.5, y = global.centre.y - global.ychar}, force = "player"}
global.fchar.color = { r = 0.815, g = 0.024, b = 0.0, a = 0.5 }
global.fchar.walking_state = { direction = defines.direction.south, walking = true }
global.fchar.disable_flashlight()
global.fchar.get_inventory(defines.inventory.character_armor).insert({name="power-armor-mk2"})

local lab = game.surfaces.nauvis.create_entity{name = "decorative-quantum-lab", position = {x = global.centre.x, y = global.centre.y-1}}
local d989 = game.surfaces.nauvis.create_entity{name = "decorative-logo-deadlock989", position = {x = global.centre.x, y = global.centre.y + 4}}
render_drop_text("IR "..script.active_mods["IndustrialRevolution3"], d989, {x=0,y=1}, false)
rendering.draw_light{sprite = "utility/light_medium", scale = 0.85, intensity = 0.75, color = {255, 230, 192}, target = d989, surface = d989.surface}
-- spell_out_letters("bronze",script.active_mods["IndustrialRevolution3"],game.surfaces.nauvis,{x = global.centre.x, y = global.centre.y+5.5})

-- local decorative = game.surfaces.nauvis.find_entities_filtered{name="decorative-logo"}[1]
-- rendering.draw_animation{animation="ir3-logo-glow", render_layer="object", target=decorative, surface=decorative.surface}

------------------------------------------------------------------------------------------------------------------------------------------------------
