------------------------------------------------------------------------------------------------------------------------------------------------------

-- startup settings

local colours = {"red","orange","yellow","lime","green","teal","cyan","azure","blue","violet","magenta","pink"}
local colours_plus = {"red","orange","yellow","lime","green","teal","cyan","azure","blue","violet","magenta","pink","greyscale"}

data:extend({
    {
        type = "string-setting",
        name = "ir-laser-colour",
		order = "ab",
        setting_type = "startup",
        default_value = "red",
		allowed_values = colours,
    },
    {
        type = "string-setting",
        name = "ir-status-working",
		order = "ba",
        setting_type = "startup",
        default_value = "green",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-idle",
		order = "bb",
        setting_type = "startup",
        default_value = "azure",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-no-minable-resources",
		order = "bc",
        setting_type = "startup",
        default_value = "azure",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-full-output",
		order = "bd",
        setting_type = "startup",
        default_value = "orange",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-insufficient-input",
		order = "be",
        setting_type = "startup",
        default_value = "orange",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-low-power",
		order = "bf",
        setting_type = "startup",
        default_value = "red",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-status-disabled",
		order = "bg",
        setting_type = "startup",
        default_value = "red",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-ghost-tint",
		order = "bh",
        setting_type = "startup",
        default_value = "greyscale",
		allowed_values = colours_plus,
    },
    {
        type = "string-setting",
        name = "ir-no-blue-trees",
		order = "f",
        setting_type = "startup",
        default_value = "off",
		allowed_values = {"off","on"},
    },
    {
        type = "string-setting",
        name = "ir-rail-blocks",
		order = "g",
        setting_type = "startup",
        default_value = "ir",
		allowed_values = {"ir","old","new"},
    },
    {
        type = "string-setting",
        name = "ir-turret-runtime",
		order = "h",
        setting_type = "startup",
        default_value = "runtime",
		allowed_values = {"runtime","predefined","red","orange","yellow","lime","green","teal","cyan","azure","blue","violet","magenta","pink","greyscale"},
    },
    {
        type = "string-setting",
        name = "ir-belt-map-colours",
		order = "i",
        setting_type = "startup",
        default_value = "yellow",
		allowed_values = {"yellow","coloured"},
    },
    {
        type = "string-setting",
        name = "ir-inserter-overlays",
		order = "j",
        setting_type = "startup",
        default_value = "on",
		allowed_values = {"off","on"},
    },
    {
        type = "string-setting",
        name = "ir-transfer-plate-style",
		order = "k",
        setting_type = "startup",
        default_value = "1",
		allowed_values = {"1","2","3"},
    },
    {
        type = "string-setting",
        name = "ir-stone-wall-style",
		order = "kb",
        setting_type = "startup",
        default_value = "off",
		allowed_values = {"off","on"},
    },
    {
        type = "string-setting",
        name = "ir-belt-brightness-variation",
		order = "l",
        setting_type = "startup",
        default_value = "off",
		allowed_values = {"off","on"},
    },
    {
        type = "string-setting",
        name = "ir-trilinear-filtering",
		order = "m",
        setting_type = "startup",
        default_value = "some",
		allowed_values = {"none","some","all"},
    },
    {
        type = "string-setting",
        name = "ir-scrap-localisation",
		order = "n",
        setting_type = "startup",
        default_value = "no",
		allowed_values = {"no","yes"},
		hidden=true,
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- map settings

data:extend({
    {
        type = "string-setting",
        name = "ir-starting-age",
		order = "a",
        setting_type = "runtime-global",
        default_value = "stone",
		allowed_values = {"none","stone","copper","bronze","iron","steel","chrome"}
    },
    {
        type = "string-setting",
        name = "ir-bottomless-pit",
		order = "b",
        setting_type = "runtime-global",
        default_value = "notavailable",
		allowed_values = {"notavailable","available"}
    },
    {
        type = "string-setting",
        name = "ir-hide-military-technologies",
		order = "c",
        setting_type = "runtime-global",
        default_value = "not-hidden",
		allowed_values = {"not-hidden","hidden"}
    },
    {
        type = "string-setting",
        name = "ir-colour-trains",
		order = "d",
        setting_type = "runtime-global",
        default_value = "no",
		allowed_values = {"no","yes","loco"}
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- per player settings

data:extend({
    {
        type = "bool-setting",
        name = "ir-fuelman-pingemptyslot",
		order = "a",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-pingnofuel",
		order = "b",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-pingnoinv",
		order = "ca",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-spent-fuel-inventory",
		order = "cb",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-inventorynumbers",
		order = "da",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-inventorysounds",
		order = "db",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "bool-setting",
        name = "ir-fuelman-pingsounds",
		order = "dc",
        setting_type = "runtime-per-user",
        default_value = true,
    },
    {
        type = "string-setting",
        name = "ir-fetchport-containers",
		order = "f",
        setting_type = "runtime-per-user",
        default_value = "none",
		allowed_values = {"none","all","nonlogistics","logistics","pallets"}
    },
    -- {
        -- type = "bool-setting",
        -- name = "ir-research-notifications",
		-- order = "g",
        -- setting_type = "runtime-per-user",
        -- default_value = false,
    -- },
    {
        type = "bool-setting",
        name = "ir-driving-autocorrect",
		order = "h",
        setting_type = "runtime-per-user",
        default_value = false,
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------
