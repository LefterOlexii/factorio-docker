------------------------------------------d------------------------------------------------------------------------------------------------------------

-- steel template

local speed = 2
local energy = DIR.get_scaled_energy_usage(speed, DIR.standard_drain)
local animspeed = DIR.anim_speed/speed

local steel = {
	source_inventory_size = 1,
	result_inventory_size = 1,
    crafting_speed = DIR.get_standard_speed(speed),
    energy_usage = energy.active,
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        drain = energy.passive,
    },
    allowed_effects = {
        "consumption",
        "speed",
		"productivity",
        "pollution"
    },
    module_specification = {
        module_info_icon_shift = standard_entity_info_module_shift(),
        module_slots = 2
    },
    max_health = standard_health("steel",3),
    dying_explosion = "medium-explosion",
    resistances = standard_resistances("steel"),
    corpse = "medium-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
    working_sound = {
        sound = {
            filename = DIR.base_sound_path.."/furnace.ogg",
            volume = 0.8
        },
		fade_in_ticks = 10,
		fade_out_ticks = 30,
		-- max_sounds_per_type = 3,
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-large.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    tile_width = 3,
    tile_height = 3,
    entity_info_icon_shift = standard_entity_info_icon_shift(),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
	status_colors = standard_status_colours(),
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel washer

local steel_washer = table.deepcopy(steel)
steel_washer.name = "steel-washer"
steel_washer.type = "furnace"
steel_washer.source_inventory_size = 1
steel_washer.result_inventory_size = 2
steel_washer.icon = DIR.get_icon_path("steel-washer")
steel_washer.crafting_categories = {"washing","advanced-washing"}
steel_washer.crafting_speed = DIR.get_standard_speed(1)
steel_washer.allowed_effects = {
    "consumption",
    "speed",
    "productivity",
    "pollution",
}
steel_washer.gui_title_key = "gui-title.washing"
steel_washer.cant_insert_at_source_message_key = "inventory-restriction.requires-fluid"
steel_washer.animation = {
    layers = {
        DIR.get_layer("machines/washers/steel-washer-base", 30, 5, false, nil, DIR.animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5-standard_assembler_vertical_shift() }, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 30, DIR.animspeed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift() }),
    }
}
steel_washer.working_visualisations = {
    {
        animation = standard_assembler_status_glow(DIR.animspeed),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
    {
        animation = DIR.get_layer("machines/washers/steel-washer-ore-tint", 60, 10, false, nil, DIR.animspeed, 64, 64, 0, 0, 64, 64, {0.0,-0.5-standard_assembler_vertical_shift() }, nil, DIR.general_sprite_flags),
        apply_recipe_tint = "primary",
    },
    {
        animation = DIR.get_layer("machines/washers/steel-washer-ore-white", 60, 10, false, nil, DIR.animspeed, 64, 64, 0, 0, 64, 64, {0.0,-0.5-standard_assembler_vertical_shift() }, "additive", DIR.general_sprite_flags),
    },
}
steel_washer.placeable_by = {item = "steel-washer", count = 1}
steel_washer.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "steel-washer"
}
steel_washer.fast_replaceable_group = "washer"
steel_washer.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "washer")
steel_washer.working_sound.sound.volume = 0.5
steel_washer.fluid_boxes = {
	{
		production_type = "input",
		pipe_picture = assembler_pipe_pictures("steel"),
		pipe_covers = DIR.pipe_covers["steel"],
		base_area = 0.5,
		base_level = -1,
		height = 2,
		pipe_connections = {
			{ type="input-output", position = {-2, 0} },
			{ type="input-output", position = {2, 0} },
		},
		secondary_draw_orders = { north = -1, south = 10 },
		filter = "water",
	},
	{
		production_type = "output",
		pipe_picture = assembler_pipe_pictures("steel"),
		pipe_covers = DIR.pipe_covers["steel"],
		base_area = 1,
		base_level = 1,
		pipe_connections = {
			{ type="output", position = {0, 2} },
		},
		secondary_draw_orders = { north = -1, south = 10 },
		filter = "dirty-water",
	},
	off_when_no_fluid_recipe = false,
}

data:extend({table.deepcopy(steel_washer)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel electroplater

-- energy = DIR.get_scaled_energy_usage(2, DIR.standard_drain)

local steel_electroplater = table.deepcopy(steel_washer)
steel_electroplater.type = "furnace"
steel_electroplater.name = "steel-electroplater"
steel_electroplater.icon = DIR.get_icon_path("steel-electroplater")
steel_electroplater.crafting_categories = {"electroplating"}
steel_electroplater.source_inventory_size = 1
steel_electroplater.result_inventory_size = 1
steel_electroplater.crafting_speed = DIR.get_standard_speed(1)
steel_electroplater.gui_title_key = "gui-title.electroplating"
steel_electroplater.allowed_effects = {
    "consumption",
    "speed",
    "pollution",
}
steel_electroplater.energy_usage = energy.active
steel_electroplater.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}
steel_electroplater.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/steel-electroplater-base", 30, 5, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift() }, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 30, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift() }),
    }
}
steel_electroplater.working_visualisations = {
    {
        animation = DIR.get_layer("machines/assemblers/steel-electroplater-working-tint", 60, 6, false, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0,-0.5-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags),
        apply_recipe_tint = "primary",
		fadeout = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/steel-electroplater-working-white", 60, 6, false, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0,-0.5-standard_assembler_vertical_shift()}, "additive-soft", DIR.general_sprite_flags),
		fadeout = true,
    },
    {
        animation = standard_assembler_status_glow(),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    }
}
steel_electroplater.placeable_by = {item = "steel-electroplater", count = 1}
steel_electroplater.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "steel-electroplater"
}
steel_electroplater.fluid_boxes = {
	{
		production_type = "input",
		pipe_picture = assembler_pipe_pictures("steel"),
		pipe_covers = DIR.pipe_covers["steel"],
		base_area = 1,
		base_level = -1,
		height = 2,
		pipe_connections = {
			{ type="input-output", position = {0, -2} },
			{ type="input-output", position = {0, 2} },
		},
		secondary_draw_orders = { north = -1, south = 10 },
	},
	off_when_no_fluid_recipe = false,
}
steel_electroplater.fast_replaceable_group = "assembling-machine"
steel_electroplater.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "electroplater")
steel_electroplater.working_sound.sound.volume = 0.5
steel_electroplater.match_animation_speed_to_activity = false
data:extend({table.deepcopy(steel_electroplater)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel grinder

animspeed = DIR.anim_speed/speed

local grinder = table.deepcopy(data.raw["furnace"]["iron-grinder"])

grinder.name = "steel-grinder"
grinder.crafting_categories = {"grinding","grinding-2","grinding-3"}
grinder.result_inventory_size = 2
grinder.icon = DIR.get_icon_path("steel-grinder")
grinder.module_specification.module_slots = 2
grinder.max_health = standard_health("steel",3)
grinder.resistances = standard_resistances("steel")
grinder.crafting_speed = DIR.get_standard_speed(speed)
grinder.allowed_effects = {
    "consumption",
    "speed",
    "productivity",
    "pollution",
}
grinder.energy_usage = energy.active
grinder.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}
grinder.animation = {
    layers = {
        DIR.get_layer("machines/grinders/steel-grinder-base", 30, 5, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift() }, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 30, animspeed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift() }),
    }
}
grinder.working_visualisations = {
    {
		animation = DIR.get_layer("machines/assemblers/steel-indicator-3-fan", 30, 5, false, nil, animspeed, 64, 64, 0, 0, 64, 64, {0,1-standard_assembler_vertical_shift() }, nil, DIR.general_sprite_flags),
		always_draw = true,
    },
    {
        animation = standard_assembler_status_glow(animspeed),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
}
grinder.placeable_by = {item = "steel-grinder", count = 1}
grinder.next_upgrade = nil
grinder.fast_replaceable_group = "grinder"
grinder.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "steel-grinder"
}
grinder.entity_info_icon_shift = standard_grinder_info_icon_shift()

data:extend({grinder})
------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel mixer

local steel_mixer = table.deepcopy(grinder)
steel_mixer.name = "steel-mixer"
steel_mixer.type = "assembling-machine"
steel_mixer.source_inventory_size = 2
steel_mixer.result_inventory_size = 1
steel_mixer.fluid_boxes = assembler_fluid_boxes("steel")
steel_mixer.entity_info_icon_shift = standard_entity_info_icon_shift()
steel_mixer.icon = DIR.get_icon_path("steel-mixer")
steel_mixer.crafting_categories = {"mixing"}
steel_mixer.gui_title_key = "gui-title.mixing"
steel_mixer.placeable_by = {item = "steel-mixer", count = 1}
steel_mixer.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "steel-mixer"
}
steel_mixer.animation = {
	layers = {
		DIR.get_layer("machines/grinders/steel-mixer-base", 60, 10, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 60, 1, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
	}
}
steel_mixer.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
steel_mixer.working_sound.sound.volume = 0.75

data:extend({table.deepcopy(steel_mixer)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel furnace (liquid fuelled)

speed = 2
energy = DIR.get_scaled_energy_usage(speed * 0.2, 0) -- built in energy efficiency equiv of 2x eff module 3

local steel_furnace = table.deepcopy(steel)
steel_furnace.name = "steel-furnace"
steel_furnace.type = "furnace"
steel_furnace.crafting_speed = DIR.get_standard_speed(speed)
steel_furnace.energy_source = {
	type = "fluid",
	fluid_box = {
        filter = "natural-gas",
        base_area = 1,
        base_level = -1,
        height = 2,
        production_type = "input-output",
        pipe_connections = {
            { type="input-output", position = {0, -2} },
            { type="input-output", position = {0, 2} },
        },
        pipe_picture = DIR.get_furnace_pipe_pictures({0.125,0.375,0.75}, 0, 2),
        pipe_covers = DIR.pipe_covers.iron,
        secondary_draw_orders = { north = -1 },
    },
	light_flicker = standard_zero_light_flicker(),
	scale_fluid_usage = true,
	burns_fluid = true,
    emissions_per_minute = DIR.get_standard_emissions(speed),
}	
steel_furnace.energy_usage = energy.active
steel_furnace.icon = DIR.get_icon_path("steel-furnace")
steel_furnace.crafting_categories = {
	"smelting","smelting-2","smelting-3",
}
steel_furnace.allowed_effects = {}
steel_furnace.module_specification = nil
steel_furnace.gui_title_key = "gui-title.smelting"
steel_furnace.placeable_by = {item = "steel-furnace", count = 1}
steel_furnace.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "steel-furnace"
}
steel_furnace.collision_box = standard_furnace_collision()
steel_furnace.fast_replaceable_group = "furnace"
steel_furnace.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/steel-furnace-shadow", nil, nil, true, nil, DIR.anim_speed, 320, 128, 0, 0, 320, 128, {1,0.5}),
		DIR.get_layer("machines/furnaces/steel-furnace-base", nil, nil, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
	}
}
steel_furnace.status_colors = standard_status_colours()
steel_furnace.working_visualisations = {
	-- {
		-- animation = DIR.get_layer("machines/furnaces/electric-furnace-working", 60, 15, "glow", nil, 1, 64, 128, 0, 0, 64, 128, {0,-1.5}, "additive", DIR.general_sprite_flags),
		-- always_draw = false,
		-- fadeout = true,
		-- render_layer = "object",
	-- },
	{
		animation = DIR.get_layer("machines/furnaces/steel-furnace-glow", 60, 10, "glow", nil, 1, 160, 160, 0, 0, 160, 160, {0,-1.25}, "additive", DIR.general_sprite_flags),
		always_draw = false,
		fadeout = true,
		render_layer = "object",
	},
	-- {
		-- animation = DIR.get_layer("machines/furnaces/electric-furnace-status", 30, 5, "glow", nil, DIR.animspeed, 192, 128, 0, 0, 192, 128, {0,-1}, "additive", DIR.general_sprite_flags),
		-- apply_tint = "status",
		-- always_draw = true,
		-- render_layer = "object",
	-- },
}
steel_furnace.match_animation_speed_to_activity = false
steel_furnace.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "gas-loop")
steel_furnace.entity_info_icon_shift = {0,0}

data.raw.furnace["steel-furnace"] = nil
data:extend({steel_furnace})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- blast furnace

speed = 4
energy = DIR.get_scaled_energy_usage(2, 0)

local blast = table.deepcopy(steel_furnace)
blast.name = "blast-furnace"
blast.type = "furnace"
blast.crafting_speed = DIR.get_standard_speed(speed)
blast.energy_usage = energy.active
blast.energy_source = {
	effectivity = 1,
	emissions_per_minute = DIR.get_standard_emissions(5), -- new in 3.1.23
	fuel_category = "coke",
	fuel_inventory_size = 1,
	type = "burner",
	light_flicker = standard_zero_light_flicker(),
}
blast.icon = DIR.get_icon_path(blast.name)
blast.crafting_categories = {"blast-smelting","blast-alloying","blast-multi-smelting"}
blast.allowed_effects = {}
blast.module_specification = nil
blast.base_productivity = 0.2 -- new in 3.1.23
blast.placeable_by = {item = blast.name, count = 1}
blast.minable = {
    mining_time = DIR.standard_pickup_time,
    result = blast.name
}
blast.cant_insert_at_source_message_key = "inventory-restriction.requires-fluid"

blast.fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = DIR.get_furnace_pipe_pictures({0.25,0.7,0.75}, 0, 2),
        pipe_covers = DIR.pipe_covers.air,
        base_area = 0.5,
        base_level = -1, 
        height = 2,
        pipe_connections = {
			{ type="input-output", position = {-2, 0} },
			{ type="input-output", position = {2, 0} },
		},
        secondary_draw_orders = { north = -1 },
		filter = "air-gas",
    },
    {
        production_type = "output",
        pipe_picture = DIR.get_furnace_pipe_pictures({0.125,0.125,0.125}, 0, 2),
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 1,
        base_level = 1, 
        pipe_connections = {{ type="output", position = {0, -2} }},
        secondary_draw_orders = { north = -1 },
		filter = "carbon-gas",
    },
    off_when_no_fluid_recipe = false,
}

blast.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/steel-furnace-shadow", nil, nil, true, nil, DIR.anim_speed, 320, 128, 0, 0, 320, 128, {1,0.5}),
		DIR.get_layer("machines/furnaces/blast-furnace-base", nil, nil, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
	}
}
blast.working_visualisations = {
	{
		animation = DIR.get_layer("machines/furnaces/blast-furnace-glow", 30, 5, "glow", nil, 1, 192, 96, 0, 0, 192, 96, {0,-0.75}, "additive", DIR.general_sprite_flags),
		always_draw = false,
		fadeout = true,
		render_layer = "object",
	},
}
blast.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "furnace-loop")

data:extend({blast})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- casts

-- shave off some of those repeated frames
local cast_sequence = {}
for i=1,5 do table.insert(cast_sequence, 1) end
for i=1,30 do table.insert(cast_sequence, i >= 31 and i or 1) end
for i=1,15 do table.insert(cast_sequence, 31) end
for i=31,60 do table.insert(cast_sequence, i >= 31 and i or 1) end
local metal_sequence = {}
for i=1,5 do table.insert(metal_sequence, 1) end
for i=1,30 do table.insert(metal_sequence, i <= 41 and i or 1) end
for i=1,15 do table.insert(metal_sequence, 31) end
for i=31,60 do table.insert(metal_sequence, i <= 41 and i or 1) end
local glow_sequence = {}
for i=1,5 do table.insert(glow_sequence, 1) end
for i=1,30 do table.insert(glow_sequence, i) end
for i=1,15 do table.insert(glow_sequence, 1) end
for i=31,60 do table.insert(glow_sequence, 1) end

local speed = 2


-- local materials = DIR.components["molten"].materials
-- table.sort(materials, function(a, b) return (DIR.materials[a].order or "a") < (DIR.materials[b].order or "a") end)

for _,component in pairs({"ingot","plate","gear-wheel","rod"}) do
	
	local cast = table.deepcopy(grinder)
	cast.name = component.."-cast"
	cast.type = "furnace"
	cast.crafting_categories = {component.."-casting"}
	cast.source_inventory_size = 0
	cast.result_inventory_size = 1
	cast.show_recipe_icon = false
	-- cast.icon = DIR.get_icon_path(component.."-cast")
	cast.icon = DIR.get_icon_path(component.."-cast")
	cast.max_health = standard_health("steel",1)
	cast.crafting_speed = DIR.get_standard_speed(speed)
	cast.placeable_by = {item = "steel-cast", count = 1}
	cast.fast_replaceable_group = "cast"
	cast.minable = {
		mining_time = DIR.standard_pickup_time,
		result = "steel-cast"
	}
	-- cast.entity_info_icon_shift = standard_grinder_info_icon_shift()
	cast.match_animation_speed_to_activity = false
	cast.selection_box = { {-0.5,-0.5}, {0.5,0.5} }
	cast.collision_box = { {-0.4,-0.4}, {0.4,0.4} }
	cast.tile_width = 1
	cast.tile_height = 1
	cast.module_specification = nil
	cast.allowed_effects = {}

	cast.energy_usage = "1W"
	cast.energy_source = {
		type = "void",
	}

	cast.fluid_boxes = {
		{
			production_type = "input",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 1,
			base_level = -1, -- this!
			pipe_connections = {{ type="input", position = {0, -1} }},
			secondary_draw_orders = { north = -1, south = 2 }
		},
		off_when_no_fluid_recipe = false,
	}

	cast.animation = {
        north = {
            layers = {
				DIR.get_layer("machines/assemblers/steel-cast-shadow", nil, nil, true, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0.5,0}),
				DIR.get_layer("machines/assemblers/steel-cast-base", nil, nil, false, nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {0,0}),
            }
        },
        east = {
            layers = {
				DIR.get_layer("machines/assemblers/steel-cast-shadow", nil, nil, true, nil, DIR.anim_speed, 128, 128, 128, 0, 128, 128, {0.5-2,0}),
				DIR.get_layer("machines/assemblers/steel-cast-base", nil, nil, false, nil, DIR.anim_speed, 64, 128, 64, 0, 64, 128, {0-1,0}),
            }
        },
        south = {
            layers = {
				DIR.get_layer("machines/assemblers/steel-cast-shadow", nil, nil, true, nil, DIR.anim_speed, 128, 128, 256, 0, 128, 128, {0.5-4,0}),
				DIR.get_layer("machines/assemblers/steel-cast-base", nil, nil, false, nil, DIR.anim_speed, 64, 128, 128, 0, 64, 128, {0-2,0}),
            }
        },
        west = {
            layers = {
				DIR.get_layer("machines/assemblers/steel-cast-shadow", nil, nil, true, nil, DIR.anim_speed, 128, 128, 384, 0, 128, 128, {0.5-6,0}),
				DIR.get_layer("machines/assemblers/steel-cast-base", nil, nil, false, nil, DIR.anim_speed, 64, 128, 192, 0, 64, 128, {0-3,0}),
            }
        },
	}
	
	cast.working_visualisations = {
		{
			animation = DIR.get_layer("machines/assemblers/steel-cast-"..component.."-cast", 60, 10, false, nil, DIR.anim_speed, 64, 96, 0, 0, 64, 96, {0,-0.25}, nil, nil, nil, nil, nil, nil, 0.5, cast_sequence),
			always_draw = true,
		},
		{
			animation = DIR.get_layer("machines/assemblers/steel-cast-"..component.."-metal", 60, 10, false, nil, DIR.anim_speed, 64, 96, 0, 0, 64, 96, {0,-0.25}, nil, nil, nil, nil, nil, nil, 0.5, metal_sequence),
			apply_recipe_tint = "primary",
			always_draw = false,
			fadeout = true,
		},
		{
			animation = DIR.get_layer("machines/assemblers/steel-cast-"..component.."-glow", 30, 10, "glow", nil, DIR.anim_speed, 64, 96, 0, 0, 64, 96, {0,-0.25}, "additive", nil, nil, nil, nil, nil, 0.5, glow_sequence),
			always_draw = false,
			fadeout = true,
		},
	}
	
	cast.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "metal-hiss")
	cast.working_sound.sound.volume = 0.75
	cast.working_sound.sound.max_sounds_per_type = 3
	
	cast.localised_description = {"", {"entity-description."..component.."-cast"}, "\n"}
	for _,material in pairs(DIR.components[component].materials) do
		if DIR.is_value_in_list(DIR.components["molten"].materials, material)
			and not (DIR.components[component].made_from_exceptions and DIR.components[component].made_from_exceptions[material])
		then
			table.insert(cast.localised_description, "[img=item/"..DIR.get_item_name(material,component).."]")
		end
	end
	
	table.insert(cast.flags, "not-upgradable")
	cast.return_ingredients_on_change = true

	data:extend({table.deepcopy(cast)})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- arc furnace - should really be under chrome

local speed = 4
local energy = DIR.get_scaled_energy_usage(speed * 1.25, DIR.standard_drain)

local arc_furnace = table.deepcopy(steel)
arc_furnace.name = "arc-furnace"
arc_furnace.type = "assembling-machine"
arc_furnace.max_health = standard_health("steel",5)
arc_furnace.icon = DIR.get_icon_path("arc-furnace")
arc_furnace.source_inventory_size = 2
arc_furnace.result_inventory_size = 0
arc_furnace.crafting_categories = {"melting","molten-alloying","melting-with-gas","advanced-molten-alloying"}
arc_furnace.crafting_speed = DIR.get_standard_speed(speed)
arc_furnace.dying_explosion = "medium-explosion"
arc_furnace.allowed_effects = {
    "consumption",
    "pollution",
	"productivity",
	"speed",
}
arc_furnace.energy_usage = energy.active
arc_furnace.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
    emissions_per_minute = DIR.get_standard_emissions(3), 
}
arc_furnace.gui_title_key = "gui-title.melting" -- not a typo
arc_furnace.collision_box = {{-2.25,-2.25},{2.25,2.25}}
arc_furnace.selection_box = {{-2.5,-2.5},{2.5,2.5}}
arc_furnace.drawing_box = { {-2.5,-3.5}, {2.5,2.5} }
arc_furnace.module_specification.module_slots = 2
arc_furnace.module_specification.module_info_icon_shift = {0,1.25}
arc_furnace.entity_info_icon_shift = {0,-1}
arc_furnace.animation = {
    layers = {
        DIR.get_layer("machines/furnaces/arc-furnace-shadow", nil, nil, true, nil, 1, 448, 256, 0, 0, 448, 256, {1,0.5}),
        DIR.get_layer("machines/furnaces/arc-furnace-base", nil, nil, false, nil, 1, 320, 320, 0, 0, 320, 320, {0,0}, nil, DIR.general_sprite_flags),
    }
}
arc_furnace.working_visualisations = {
    {
		animation = DIR.get_layer("machines/furnaces/arc-furnace-status", 30, 6, "glow", nil, 1, 64, 64, 0, 0, 64, 64, {0,1}, "additive", DIR.general_sprite_flags),
		apply_tint = "status",
		always_draw = true,
		light = {
			intensity = 0.5,
			size = 3,
			shift = {0,1.25},
		},
    },
    {
        animation = DIR.get_layer("machines/furnaces/arc-furnace-glow", 60, 10, "glow", nil, 1, 320, 320, 0, 0, 320, 320, {0,-2}, "additive-soft", DIR.general_sprite_flags),
		fadeout = true,
    },
}
arc_furnace.placeable_by = {item = "arc-furnace", count = 1}
arc_furnace.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "arc-furnace"
}
arc_furnace.fast_replaceable_group = nil
arc_furnace.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "furnace-loop-2")
arc_furnace.match_animation_speed_to_activity = false

local pipe_pictures = {}

for i=1,3 do
	pipe_pictures[i] = {
		north = {
			layers = {
				DIR.get_layer("pipes/pipe-shadow-v", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,1}),
				DIR.get_layer("machines/furnaces/arc-furnace-pipe-pictures", nil, nil, false, nil, nil, 64, 128, DIR.tiles(i), DIR.tiles(0), 320, 448, {2-i,3}, nil, DIR.general_sprite_flags),
			},
		},
		east = {
			layers = {
				DIR.get_layer("pipes/pipe-shadow-h", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {-1,0}),
				DIR.get_layer("machines/furnaces/arc-furnace-pipe-pictures", nil, nil, false, nil, nil, 64, 64, DIR.tiles(4), DIR.tiles(i+1), 320, 448, {-3,2-i}, nil, DIR.general_sprite_flags),
			},
		},
		south = {
			layers = {
				DIR.get_layer("pipes/pipe-shadow-v", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,-1}),
				DIR.get_layer("machines/furnaces/arc-furnace-pipe-pictures-shadowcatch-"..i, nil, nil, false, nil, nil, 320, 128, 0, 0, 320, 448, {i-2,1}),
				DIR.get_layer("machines/furnaces/arc-furnace-pipe-pictures", nil, nil, false, nil, nil, 64, 128, DIR.tiles(4-i), DIR.tiles(5), 320, 448, {i-2,-3}, nil, DIR.general_sprite_flags),
			},
		},
		west = {
			layers = {
				DIR.get_layer("pipes/pipe-shadow-h", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
				DIR.get_layer("machines/furnaces/arc-furnace-pipe-pictures", nil, nil, false, nil, nil, 64, 64, DIR.tiles(0), DIR.tiles(5-i), 320, 448, {3,i-2}, nil, DIR.general_sprite_flags),
			},
		},
	}
end

arc_furnace.fluid_boxes = {
    {
        production_type = "output",
        pipe_picture = pipe_pictures[1],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = 1, 
        pipe_connections = {{ type="output", position = {-1, -3} }},
        secondary_draw_orders = { north = -1 }
    },
    {
        production_type = "output",
        pipe_picture = pipe_pictures[2],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = 1, 
        pipe_connections = {{ type="output", position = {0, -3} }},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "output",
        pipe_picture = pipe_pictures[3],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = 1, 
        pipe_connections = {{ type="output", position = {1, -3} }},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "input",
        pipe_picture = pipe_pictures[1],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = -1, 
        pipe_connections = {{ type="input", position = {1, 3} }},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "input",
        pipe_picture = pipe_pictures[2],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = -1, 
        pipe_connections = {{ type="input", position = {0, 3} }},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "input",
        pipe_picture = pipe_pictures[3],
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 10,
        base_level = -1, 
        pipe_connections = {{ type="input", position = {-1, 3} }},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "input",
        pipe_picture = pipe_pictures[2],
        pipe_covers = DIR.pipe_covers.air,
        base_area = 5,
        base_level = -1, 
		height = 2,
        pipe_connections = {
			{ type="input-output", position = {-3, 0} },
			{ type="input-output", position = {3, 0} },
		},
        secondary_draw_orders = { north = -1 },
    },
    off_when_no_fluid_recipe = true,
}

data:extend({arc_furnace})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel cleaner

local energy = DIR.get_scaled_energy_usage(0.5, DIR.standard_drain)

local steel_cleaner = table.deepcopy(steel)
steel_cleaner.name = "steel-cleaner"
steel_cleaner.type = "assembling-machine"
steel_cleaner.icon = DIR.get_icon_path("steel-cleaner")
steel_cleaner.crafting_categories = {"cleaning"}
steel_cleaner.crafting_speed = DIR.get_standard_speed(1)
steel_cleaner.show_recipe_icon = false
steel_cleaner.show_recipe_icon_on_map = false
steel_cleaner.energy_usage = energy.active
steel_cleaner.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}
steel_cleaner.allowed_effects = {
	"consumption",
	"speed",
	"pollution"
}
steel_cleaner.module_specification = {
	module_info_icon_shift = {0,0.25},
	module_slots = 1
}
steel_cleaner.animation = {
    south = {
		layers = {
			DIR.get_layer("machines/fluids/steel-cleaner-shadow", nil, nil, true, 15, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0.75,0}),
			DIR.get_layer("machines/fluids/steel-cleaner-base", nil, nil, false, 15, DIR.anim_speed, 96, 128, 0, 0, 96, 128, {0,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/fluids/steel-cleaner-working", 15, 5, false, nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, nil, DIR.general_sprite_flags),
		},
    },
    west = {
		layers = {
			DIR.get_layer("machines/fluids/steel-cleaner-shadow", nil, nil, true, 15, DIR.anim_speed, 192, 128, 192, 0, 192, 128, {-2.25,0}),
			DIR.get_layer("machines/fluids/steel-cleaner-base", nil, nil, false, 15, DIR.anim_speed, 96, 128, 96, 0, 96, 128, {-1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/fluids/steel-cleaner-working", 15, 5, false, nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, nil, DIR.general_sprite_flags),
		},
    },
    north = {
		layers = {
			DIR.get_layer("machines/fluids/steel-cleaner-shadow", nil, nil, true, 15, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0.75,0}),
			DIR.get_layer("machines/fluids/steel-cleaner-base", nil, nil, false, 15, DIR.anim_speed, 96, 128, 192, 0, 96, 128, {-3,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/fluids/steel-cleaner-working", 15, 5, false, nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, nil, DIR.general_sprite_flags),
		},
    },
    east = {
		layers = {
			DIR.get_layer("machines/fluids/steel-cleaner-shadow", nil, nil, true, 15, DIR.anim_speed, 192, 128, 192, 0, 192, 128, {-2.25,0}),
			DIR.get_layer("machines/fluids/steel-cleaner-base", nil, nil, false, 15, DIR.anim_speed, 96, 128, 288, 0, 96, 128, {-4.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/fluids/steel-cleaner-working", 15, 5, false, nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, nil, DIR.general_sprite_flags),
		},
    },
}

local lamp_sequence = {}
local lamp_length = 20
local line_length = 15
for i=1,lamp_length do table.insert(lamp_sequence, (i > line_length) and 1 or i) end

steel_cleaner.working_visualisations = {
    {
        south_animation = DIR.get_layer("machines/fluids/steel-cleaner-light", lamp_length, line_length, "glow", nil, DIR.anim_speed/2, 64, 64, 0, 0, 64, 64, {0,-0.5}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, lamp_sequence),
        west_animation = DIR.get_layer("machines/fluids/steel-cleaner-light", lamp_length, line_length, "glow", nil, DIR.anim_speed/2, 64, 64, 0, 64, 64, 64, {0,-1.5}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, lamp_sequence),
        north_animation = DIR.get_layer("machines/fluids/steel-cleaner-light", lamp_length, line_length, "glow", nil, DIR.anim_speed/2, 64, 64, 0, 128, 64, 64, {0,-2.5}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, lamp_sequence),
        east_animation = DIR.get_layer("machines/fluids/steel-cleaner-light", lamp_length, line_length, "glow", nil, DIR.anim_speed/2, 64, 64, 0, 192, 64, 64, {0,-3.5}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, lamp_sequence),
		light = {
			color = {0.5,1,0.5},
			intensity = 0.2,
			size = 1.5,
			shift = {0,-0.55}
		},
		apply_tint = "status",
		always_draw = true,
    }
}

steel_cleaner.selection_box = { {-0.5,-0.5}, {0.5,0.5} }
steel_cleaner.collision_box = { {-0.49,-0.49}, {0.49,0.49} }
steel_cleaner.tile_width = 1
steel_cleaner.tile_height = 1
steel_cleaner.placeable_by = {item = "steel-cleaner", count = 1}
steel_cleaner.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "steel-cleaner"
}
steel_cleaner.fast_replaceable_group = "cleaner"
steel_cleaner.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "water")

steel_cleaner.fluid_boxes = {
	{
		production_type = "input",
		pipe_covers = DIR.pipe_covers_tweaked.iron,
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {0, -1.25} }},
		secondary_draw_orders = { north = -1 }
	},
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers_tweaked.iron,
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {0, 1.25} }},
		secondary_draw_orders = { north = -1 }
	},
	off_when_no_fluid_recipe = false
}
for _,fbox in pairs(steel_cleaner.fluid_boxes) do
    if type(fbox) == "table" then
        if fbox.production_type == "input" then fbox.filter = "dirty-water"
        elseif fbox.production_type == "output" then fbox.filter = "water" end
    end
end
steel_cleaner.fixed_recipe = "dirty-water-cleaning"
data:extend({table.deepcopy(steel_cleaner)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- module loader

local energy = DIR.get_scaled_energy_usage(1, DIR.standard_drain)

local loader = table.deepcopy(steel)
loader.name = "module-loader"
loader.icon = DIR.get_icon_path(loader.name)
loader.icon_size = DIR.icon_size
loader.icon_mipmaps = DIR.icon_mipmaps
loader.type = "assembling-machine"
loader.crafting_speed = DIR.get_standard_speed(2)
loader.minable = {
    mining_time = DIR.standard_pickup_time,
    result = loader.name
}
loader.collision_box = {{-0.7,-0.7},{0.7,0.7}}
loader.selection_box = {{-1,-1},{1,1}}
loader.tile_width = 2
loader.tile_height = 2
loader.crafting_categories = {"module-loading"}
loader.gui_title_key = "gui-title.module-loading"
loader.energy_usage = energy.active
loader.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}
loader.animation = {
	layers = {
		DIR.get_layer("machines/assemblers/module-loader-shadow", nil, nil, true, nil, nil, 256, 128, 0, 0, 256, 128, {1,0}),
		DIR.get_layer("machines/assemblers/module-loader-base", nil, nil, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}),
	},
}
loader.working_visualisations = {
    {
        animation = DIR.get_layer("machines/assemblers/module-loader-working", 16, 4, "glow", nil, 1/30, 128, 128, 0, 0, 128, 128, {0,0}, "additive"),
	},
    {
        animation = DIR.get_layer("machines/assemblers/module-loader-status", 30, 10, "glow", nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {0.5,0}, "additive"),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
	},
}
loader.allowed_effects = {
	"consumption",
	"speed",
}
loader.module_specification = {
        module_info_icon_shift = {0,0.5},
        module_slots = 1
}
loader.entity_info_icon_shift = nil
loader.working_sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "retro-computer"),
	volume = 0.2,
	fade_in_ticks = 5,
	fade_out_ticks = 10,
	max_sounds_per_type = 1,
}

data:extend({loader})

------------------------------------------------------------------------------------------------------------------------------------------------------

