------------------------------------------------------------------------------------------------------------------------------------------------------

-- ASSEMBLERS

------------------------------------------------------------------------------------------------------------------------------------------------------

local assembler_template = {
	allowed_effects = {
		"consumption",
		"speed",
		"pollution",
		"productivity",
	},
	max_health = standard_health("copper",3),
	dying_explosion = "medium-explosion",
	resistances = standard_resistances("copper"),
	corpse = "medium-remnants",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	collision_box = standard_3x3_collision() ,
	selection_box = standard_3x3_selection() ,
	working_sound = {
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	open_sound = standard_machine_open(),
	close_sound = standard_machine_close(),
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-large.ogg"
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	tile_width = 3,
	tile_height = 3,
	entity_info_icon_shift = standard_entity_info_icon_shift(),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	status_colors = standard_status_colours(),
	minable = {
		result = "assembling-machine-1",
		mining_time = DIR.standard_pickup_time,
	},
	fast_replaceable_group = "assembler",
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- assembler 1

local speed = 0.5
local energy = DIR.get_scaled_energy_usage(1, 0)
local assembler = table.deepcopy(assembler_template)

assembler.name = "assembling-machine-1"
assembler.type = "assembling-machine"
assembler.placeable_by = {item = "assembling-machine-1", count = 1}
assembler.next_upgrade = "assembling-machine-2"

assembler.crafting_speed = DIR.get_standard_speed(speed)
-- 3.1.5 - crafting-with-fluid removed from this tier because it is set up with copper pipe pictures (i.e. water only)
-- and there are no crafting-with-water recipes
assembler.crafting_categories = {"crafting","crafting-small"} 
assembler.gui_title_key = "gui-title.crafting"
assembler.energy_source = {
	type = "fluid",
	fluid_box = standard_copper_energy_fluid_box(),
	maximum_temperature = 165,
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	light_flicker = standard_zero_light_flicker(),
	smoke = standard_copper_steam(),
}	
assembler.fluid_boxes = assembler_fluid_boxes("copper")
assembler.energy_usage = energy.active
assembler.max_health = standard_health("copper",3)
assembler.allowed_effects = {}

assembler.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/assembler1-base", 60, 10, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/copper-shadow", nil, nil, true, 60, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0}),
        DIR.get_layer("machines/assemblers/assembler1-shadow", 60, 10, true, nil, DIR.anim_speed, 128, 192, 0, 0, 128, 192, {2.5,0}),
    }
}

assembler.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "rhythmic"),
	volume = 0.5
}

assembler.icon = DIR.get_icon_path("assembler1")
assembler.entity_info_icon_shift = standard_entity_info_icon_shift()
assembler.collision_box = standard_3x3_collision()
assembler.selection_box = standard_3x3_selection()
assembler.match_animation_speed_to_activity = false
assembler.alert_icon_shift = {0,0}

data.raw["assembling-machine"]["assembling-machine-1"] = assembler

-- small version

local smallass = table.deepcopy(assembler)
smallass.name = "small-assembler-1"
smallass.minable.result = smallass.name
smallass.placeable_by = {item = smallass.name, count = 1}
smallass.next_upgrade = "small-assembler-2"
smallass.fast_replaceable_group = "small-assembler"
smallass.crafting_categories = {"crafting-small"}
smallass.ingredient_count = 1
smallass.tile_width = 1
smallass.tile_height = 1
smallass.max_health = standard_health("copper",1)
smallass.resistances = standard_resistances("copper")
smallass.fluid_boxes = nil
smallass.icon = DIR.get_icon_path(smallass.name)
smallass.entity_info_icon_shift = standard_small_entity_info_icon_shift()
smallass.selection_box = { {-0.5,-0.5}, {0.5,0.5} }
smallass.collision_box = { {-0.4,-0.4}, {0.4,0.4} }
smallass.match_animation_speed_to_activity = false
smallass.alert_icon_shift = {0,0}
smallass.corpse = "small-remnants"

energy = DIR.get_scaled_energy_usage(0.5, 0)
smallass.energy_usage = energy.active
smallass.energy_source = {
	type = "fluid",
	fluid_box = {
        filter = "steam",
        base_area = 1,
        base_level = -1,
        height = 2,
        production_type = "input-output",
        pipe_picture = nil,
        pipe_connections = {
            { type="input-output", position = {0, 1} },
            { type="input-output", position = {0, -1} },
        },
        pipe_covers = DIR.pipe_covers.steam,
		pipe_picture = {
			north = DIR.get_layer("machines/assemblers/small-assembler-pipe-pictures-steam", 4, 4, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,1}, nil, DIR.general_sprite_flags),
			east = DIR.get_layer("machines/assemblers/small-assembler-pipe-pictures-steam", 4, 4, false, nil, nil, 128, 128, 128, 0, 128, 128, {-3,0}, nil, DIR.general_sprite_flags),
			south = DIR.get_layer("machines/assemblers/small-assembler-pipe-pictures-steam", 4, 4, false, nil, nil, 128, 128, 256, 0, 128, 128, {-4,-1}, nil, DIR.general_sprite_flags),
			west = DIR.get_layer("machines/assemblers/small-assembler-pipe-pictures-steam", 4, 4, false, nil, nil, 128, 128, 384, 0, 128, 128, {-5,0}, nil, DIR.general_sprite_flags),
		},
        secondary_draw_orders = { north = -1 },
    },
	maximum_temperature = 165,
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	light_flicker = standard_zero_light_flicker(),
	smoke = {{
		north_position = {0,-0.375},
		south_position = {0,-0.375},
		east_position = {0,-0.375},
		west_position = {0,-0.375},
		frequency = 2,
		name = "light-smoke",
		slow_down_factor = 1,
		starting_frame_deviation = 60,
		starting_vertical_speed = 0.08,
		starting_vertical_speed_deviation = 0.02,
		starting_frame_speed_deviation = 0.02,
	}},
}	

smallass.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/small-assembler-1-base", 64, 8, false, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0,0}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/small-assembler-shadow", 64, 8, true, nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0.5,0}),
    }
}

smallass.working_visualisations = nil

smallass.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "small-machine-1"),
	volume = 0.4
}

data:extend({smallass})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- assembler 2

speed = 1
energy = DIR.get_scaled_energy_usage(speed, DIR.standard_drain)
assembler = table.deepcopy(assembler_template)

assembler.name = "assembling-machine-2"
assembler.type = "assembling-machine"
assembler.minable.result = "assembling-machine-2"
assembler.placeable_by = {item = "assembling-machine-2", count = 1}
assembler.next_upgrade = "assembling-machine-3"

assembler.crafting_speed = DIR.get_standard_speed(speed)
assembler.crafting_categories = {"crafting","advanced-crafting","crafting-with-fluid","crafting-small"}
assembler.gui_title_key = "gui-title.crafting"
assembler.energy_usage = energy.active
assembler.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

assembler.module_specification = {
	module_info_icon_shift = standard_entity_info_module_shift(),
	module_slots = 2
}

assembler.max_health = standard_health("iron",3)
assembler.resistances = standard_resistances("iron")

assembler.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/assembler2-base", 60, 10, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 60, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
        DIR.get_layer("machines/assemblers/assembler2-shadow", 60, 10, true, nil, DIR.anim_speed, 96, 96, 0, 0, 96, 96, {2.75,0.25-standard_assembler_vertical_shift()}),
    }
}

assembler.working_visualisations = {
    {
        animation = DIR.get_layer("machines/assemblers/assembler2-working-sparks", 60, 6, "glow", nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0,-0.5-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags),
		fadeout = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler2-working-tinted", 60, 6, "glow", nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0,-1-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags),
		apply_tint = "status",
		always_draw = true,
   },
    {
        animation = standard_assembler_status_glow(),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
}

assembler.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "saw-weld"),
	volume = 0.5
}

assembler.fluid_boxes = assembler_fluid_boxes()
assembler.icon = DIR.get_icon_path("assembler2")
assembler.entity_info_icon_shift = standard_entity_info_icon_shift()
assembler.collision_box = standard_3x3_collision()
assembler.selection_box = standard_3x3_selection()
assembler.match_animation_speed_to_activity = false
assembler.alert_icon_shift = {0,0}

data.raw["assembling-machine"]["assembling-machine-2"] = assembler

-- small version

local smallass = table.deepcopy(assembler)
smallass.name = "small-assembler-2"
smallass.minable.result = smallass.name
smallass.placeable_by = {item = smallass.name, count = 1}
smallass.next_upgrade = "small-assembler-3"
smallass.fast_replaceable_group = "small-assembler"
smallass.crafting_categories = {"crafting-small"}
smallass.ingredient_count = 1
smallass.tile_width = 1
smallass.tile_height = 1
smallass.max_health = standard_health("iron",1)
smallass.resistances = standard_resistances("iron")
smallass.fluid_boxes = nil
smallass.icon = DIR.get_icon_path("small-assembler-2")
smallass.entity_info_icon_shift = standard_small_entity_info_icon_shift()
smallass.selection_box = { {-0.5,-0.5}, {0.5,0.5} }
smallass.collision_box = { {-0.4,-0.4}, {0.4,0.4} }
smallass.match_animation_speed_to_activity = false
smallass.alert_icon_shift = {0,0}
smallass.corpse = "small-remnants"

energy = DIR.get_scaled_energy_usage(0.5, DIR.standard_drain)
smallass.energy_usage = energy.active
smallass.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

smallass.module_specification = {
	module_info_icon_shift = {0,0.375},
	module_info_icon_scale = 0.375,
	module_slots = 1
}

smallass.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/small-assembler-2-base", 64, 8, false, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0,0}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/small-assembler-shadow", 64, 8, true, nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0.5,0}),
    }
}

-- local frames = DIR.values_to_keys({13,14,15,16,17,18,19,33,34,35,36,37,38,39,53,54,55,56,57,58,59,73,74,75,76,77,78,79})
-- local sequence = {}
-- for i=1,80 do sequence[i] = frames[i] and i or 1 end

smallass.working_visualisations = {
    {
        animation = DIR.get_layer("machines/assemblers/small-assembler-status", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.25}, "additive", DIR.general_sprite_flags),
        light = standard_status_light(0.5),
		apply_tint = "status",
		always_draw = true,
    },
}

smallass.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "small-machine-2"),
	volume = 0.4
}

data:extend({smallass})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- assembler 3

speed = 2
energy = DIR.get_scaled_energy_usage(2, DIR.standard_drain)
assembler = table.deepcopy(assembler_template)

assembler.name = "assembling-machine-3"
assembler.type = "assembling-machine"
assembler.minable.result = "assembling-machine-3"
assembler.placeable_by = {item = "assembling-machine-3", count = 1}

assembler.crafting_speed = DIR.get_standard_speed(speed)
assembler.crafting_categories = {"crafting","crafting-with-fluid","crafting-small","advanced-crafting"}
assembler.gui_title_key = "gui-title.crafting"
assembler.energy_usage = energy.active
assembler.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

assembler.max_health = standard_health("steel",3)
assembler.resistances = standard_resistances("steel")

assembler.module_specification = {
    module_info_icon_shift = standard_entity_info_module_shift(),
    module_slots = 4
}

assembler.icon = DIR.get_icon_path("assembler3")
assembler.default_recipe_tint = DIR.get_crafting_tints_from_hue(1,1)

assembler.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/assembler3-base", 60, 10, false, nil, DIR.anim_speed, 192, 224, 0, 0, 192, 224, {0,-0.25-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 60, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
        DIR.get_layer("machines/assemblers/assembler2-shadow", 60, 10, true, nil, DIR.anim_speed, 96, 96, 0, 0, 96, 96, {2.75,0.25-standard_assembler_vertical_shift()}),
    }
}

assembler.working_visualisations = {
    {
		animation = DIR.get_layer("machines/assemblers/steel-indicator-3-gear", 30, 5, false, nil, 1, 64, 64, 0, 0, 64, 64, {0,1-standard_assembler_vertical_shift(), nil, DIR.general_sprite_flags }),
		always_draw = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler3-working-sparks", 60, 6, "glow", nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0,-0.5-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags),
		fadeout = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler2-working-tinted", 60, 6, "glow", nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0,-1-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags),
		apply_tint = "status",
		always_draw = true,
   },
    {
        animation = standard_assembler_status_glow(),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
}

assembler.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "saw-weld"),
	volume = 0.5
}

assembler.fluid_boxes = assembler_fluid_boxes("steel")
assembler.entity_info_icon_shift = standard_entity_info_icon_shift()
assembler.collision_box = standard_3x3_collision()
assembler.selection_box = standard_3x3_selection()
assembler.match_animation_speed_to_activity = false
assembler.alert_icon_shift = {0,0}

data.raw["assembling-machine"]["assembling-machine-3"] = assembler

-- small version

smallass = table.deepcopy(smallass)
smallass.name = "small-assembler-3"
smallass.minable.result = smallass.name
smallass.placeable_by = {item = smallass.name, count = 1}
smallass.crafting_speed = DIR.get_standard_speed(2)
smallass.next_upgrade = nil
smallass.fast_replaceable_group = "small-assembler"
smallass.max_health = standard_health("steel",1)
smallass.resistances = standard_resistances("steel")
smallass.icon = DIR.get_icon_path(smallass.name)

energy = DIR.get_scaled_energy_usage(1, DIR.standard_drain)
smallass.energy_usage = energy.active
smallass.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

smallass.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/small-assembler-3-base", 64, 8, false, nil, DIR.anim_speed, 128, 128, 0, 0, 128, 128, {0,0}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/small-assembler-shadow", 64, 8, true, nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0.5,0}),
    }
}

smallass.working_visualisations = {
    {
        animation = DIR.get_layer("machines/assemblers/small-assembler-status", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.25}, "additive", DIR.general_sprite_flags),
        light = standard_status_light(0.5),
		apply_tint = "status",
		always_draw = true,
    },
}

data:extend({smallass})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- assembler 4 (laser)

speed = 2
energy = DIR.get_scaled_energy_usage(4, DIR.standard_drain)
assembler = table.deepcopy(assembler_template)

assembler.name = "laser-assembler"
assembler.type = "assembling-machine"
assembler.minable.result = "laser-assembler"
assembler.placeable_by = {item = "laser-assembler", count = 1}

assembler.crafting_speed = DIR.get_standard_speed(speed)
assembler.crafting_categories = {"laser-crafting"}
assembler.gui_title_key = "gui-title.laser-crafting"
assembler.energy_usage = energy.active
assembler.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

assembler.max_health = standard_health("steel",3)
assembler.resistances = standard_resistances("steel")

assembler.module_specification = {
    module_info_icon_shift = standard_entity_info_module_shift(),
    module_slots = 4
}

assembler.icon = DIR.get_icon_path("laser-assembler")
assembler.default_recipe_tint = DIR.get_crafting_tints_from_hue(1,1)
assembler.animation = {
    layers = {
        DIR.get_layer("machines/assemblers/assembler4-base", 60, 10, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 60, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
        DIR.get_layer("machines/assemblers/assembler4-shadow", 60, 10, true, nil, DIR.anim_speed, 96, 96, 0, 0, 96, 96, {2.75,0.25-standard_assembler_vertical_shift()}),
    }
}
assembler.status_colors = standard_status_colours()
assembler.working_visualisations = {
    {
		animation = DIR.get_layer("machines/assemblers/steel-indicator-3-gear", 30, 5, false, nil, 1, 64, 64, 0, 0, 64, 64, {0,1-standard_assembler_vertical_shift(), nil, DIR.general_sprite_flags }),
		always_draw = true,
    },
    {
        animation = standard_assembler_status_glow(),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler4-working-sparks", 60, 10, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-1-standard_assembler_vertical_shift()}, "additive-soft", DIR.general_sprite_flags),
		fadeout = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler4-working-tinted", 60, 10, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-1-standard_assembler_vertical_shift()}, "additive-soft", DIR.general_sprite_flags),
        apply_recipe_tint = "secondary",
		fadeout = true,
    },
    {
        animation = DIR.get_layer("machines/assemblers/assembler4-working-white", 60, 10, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-1-standard_assembler_vertical_shift()}, "additive-soft", DIR.general_sprite_flags),
		fadeout = true,
    },
}

assembler.working_sound.sound = {
	filename = string.format("%s/%s.ogg", DIR.sound_path, "high-tech-industrial"),
	volume = 0.5
}

assembler.fluid_boxes = assembler_fluid_boxes("laser")
assembler.entity_info_icon_shift = standard_entity_info_icon_shift()
assembler.collision_box = standard_3x3_collision()
assembler.selection_box = standard_3x3_selection()
assembler.match_animation_speed_to_activity = false
assembler.alert_icon_shift = {0,0}

data:extend({assembler})

------------------------------------------------------------------------------------------------------------------------------------------------------
