------------------------------------------------------------------------------------------------------------------------------------------------------

local ug_cover_sprites = {
    north = "cn",
    south = "cs",
    west = "cw",
    east = "ce",
}

local ug_cover_offsets = {
    north = {0,1},
    south = {0,-1},
    east = {-1,0},
    west = {1,0},
}

DIR.pipe_covers = {}
local materials = {"copper","iron","steel","steam","air"}

for _,material in pairs(materials) do
    DIR.pipe_covers[material] = {}
    local sprite_material = (material == "steel") and "iron" or material
    local shadow_material = (material == "steam") and "steam-shadow" or "shadow"
    for spritelist,sprite in pairs(ug_cover_sprites) do
        DIR.pipe_covers[material][spritelist] = { layers = {} }
        table.insert(DIR.pipe_covers[material][spritelist].layers, {
            filename = DIR.entities_path_2.."/pipes/pipe-"..sprite_material.."-"..sprite..".png",
            priority = "extra-high",
            width = 180,
            height = 120,
            scale = 0.5,
            shift = ug_cover_offsets[spritelist],
			flags = DIR.general_sprite_flags,
        })
        table.insert(DIR.pipe_covers[material][spritelist].layers, {
            filename = DIR.entities_path_2.."/pipes/pipe-"..shadow_material.."-"..sprite..".png",
            priority = "extra-high",
            width = 180,
            height = 120,
            scale = 0.5,
            draw_as_shadow = true,
            shift = ug_cover_offsets[spritelist],
        })
    end
end

DIR.pipe_covers_tweaked = table.deepcopy(DIR.pipe_covers)
for m,mm in pairs(DIR.pipe_covers_tweaked) do
	for d,dd in pairs(mm) do
		for l,layer in pairs(dd.layers) do
			layer.shift = DIR.multiply_vector(layer.shift, 1.25)
		end
	end
end


function standard_3x3_collision()
    return { {-1.25,-1.25}, {1.25,1.25} }
end

function standard_furnace_collision()
    return standard_3x3_collision()
end

function standard_3x3_selection()
    return { {-1.5,-1.5}, {1.5,1.5} }
end

function standard_entity_info_icon_shift()
    return {0,-0.625}
end

function standard_small_entity_info_icon_shift()
    return {0,-0.425}
end

function standard_grinder_info_icon_shift()
    return {0,-0.45}
end

function standard_entity_info_module_shift()
    return {0,0.8}
end

function standard_2x2_turret_info_icon_shift()
    return {0,0.3}
end

function standard_3x3_turret_info_icon_shift()
    return {0,0.55}
end

function standard_zero_light_flicker()
    return {
        -- minimum_intensity = 0,
        -- maximum_intensity = 0,
        color = {0,0,0,0},
    }
end

function standard_small_chest_collision()
    return data.raw.container["wooden-chest"].collision_box
end

function assembler_pipe_pictures(material)
    if not material then material = "steel" end
    local shadow = (material == "steam") and "steam-shadow" or "shadow"
	return {
		north = DIR.get_layer("machines/assemblers/standard-pipe-pictures-"..material.."-north", nil, nil, false, nil, nil, 238, 238, 0, 0, 238, 238, {0,2}, nil, DIR.general_sprite_flags),
		east = DIR.get_layer("machines/assemblers/standard-pipe-pictures-"..material.."-east", nil, nil, false, nil, nil, 238, 238, 0, 0, 238, 238, {-2,0}, nil, DIR.general_sprite_flags),
		south = {
			layers = {
				DIR.get_layer("machines/assemblers/standard-pipe-pictures-"..material.."-south", nil, nil, false, nil, nil, 238, 238, 0, 0, 238, 238, {0,-2}, nil, DIR.general_sprite_flags),
				DIR.get_layer("pipes/pipe-"..shadow.."-v", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,-1}),
			},
		},
		west = DIR.get_layer("machines/assemblers/standard-pipe-pictures-"..material.."-west", nil, nil, false, nil, nil, 238, 238, 0, 0, 238, 238, {2,0}, nil, DIR.general_sprite_flags),
	}
end

function assembler_fluid_boxes(material, outputfilter, inputfilter)
    material = material or "iron"
	local m = (material == "laser") and "steel" or material
	local fb = {}
	table.insert(fb, {
		production_type = "input",
		pipe_picture = assembler_pipe_pictures(m),
		pipe_covers = DIR.pipe_covers[m],
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {0, -2} }},
		secondary_draw_orders = { north = -1, south = 10 },
		filter = inputfilter,
	})
	table.insert(fb, {
		production_type = "output",
		pipe_picture = assembler_pipe_pictures(m),
		pipe_covers = DIR.pipe_covers[m],
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {0, 2} }},
		secondary_draw_orders = { north = -1, south = 10 },
		filter = outputfilter,
	})
	if material == "laser" then
		table.insert(fb, {
			production_type = "input",
			pipe_picture = assembler_pipe_pictures(m),
			pipe_covers = DIR.pipe_covers[m],
			base_area = 10,
			base_level = -1,
			pipe_connections = {{ type="input", position = {-2, 0} }},
			secondary_draw_orders = { north = -1, south = 10 },
		})
		table.insert(fb, {
			production_type = "output",
			pipe_picture = assembler_pipe_pictures(m),
			pipe_covers = DIR.pipe_covers[m],
			base_area = 10,
			base_level = 1,
			pipe_connections = {{ type="output", position = {2, 0} }},
			secondary_draw_orders = { north = -1, south = 10 },
		})
	end
	fb.off_when_no_fluid_recipe = true
	return fb
end

function standard_copper_energy_fluid_box()
    return {
        filter = "steam",
        base_area = 1,
        base_level = -1,
        height = 2,
        production_type = "input-output",
        pipe_connections = {
            { type="input-output", position = {2, 0} },
            { type="input-output", position = {-2, 0} },
        },
        pipe_picture = assembler_pipe_pictures("steam"),
        pipe_covers = DIR.pipe_covers.steam,
        secondary_draw_orders = { north = -1 },
    }
end

function copper_steam(ns_position,ew_position,freq,time_offset)
	local position_offset = {0.0625,0}
	return {
		north_position = {ns_position[1]+position_offset[1],ns_position[2]+position_offset[2]},
		south_position = {ns_position[1]+position_offset[1],ns_position[2]+position_offset[2]},
		east_position = {ew_position[1]+position_offset[1],ew_position[2]+position_offset[2]},
		west_position = {ew_position[1]+position_offset[1],ew_position[2]+position_offset[2]},
		frequency = freq,
		offset = time_offset,
		name = "light-smoke",
		slow_down_factor = 1,
		starting_frame_deviation = 60,
		starting_vertical_speed = 0.08,
		starting_vertical_speed_deviation = 0.02,
		starting_frame_speed_deviation = 0.02,
	}
end

function standard_copper_steam()
	local freq = 2
	local factor = (1/freq)
    return {
		copper_steam({-1.3,-1},{-0.475,-1.55},freq,0),
		copper_steam({1.3,-1},{0.475,-1.55},freq,factor*1/4),
		copper_steam({-1.3,-0.3},{-0.475,0.25},freq,factor*2/4),
		copper_steam({1.3,-0.3},{0.475,0.25},freq,factor*3/4),
    }
end

function standard_machine_open()
    return {
        filename = DIR.base_sound_path.."/machine-open.ogg",
        volume = 0.5
    }
end

function standard_machine_close()
    return {
        filename = DIR.base_sound_path.."/machine-close.ogg",
        volume = 0.5
    }
end

function standard_assembler_vertical_shift()
    return 6/64
end

function standard_status_colours()
    local sat = 0.75
    local val = 1
    return {
        no_power = {0,0,0,0}, -- transparent
        idle = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-idle"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-idle"].value],sat),val),
        no_minable_resources = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-no-minable-resources"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-no-minable-resources"].value],sat),val),
        disabled = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-disabled"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-disabled"].value],sat),val),
        full_output = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-full-output"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-full-output"].value],sat),val),
        insufficient_input = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-insufficient-input"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-insufficient-input"].value],sat),val),
        low_power = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-low-power"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-low-power"].value],sat),val),
        working = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-working"].value],DIR.get_saturation(DIR.hues[settings.startup["ir-status-working"].value],sat),val),
    }
end

function standard_status_light(factor)
	factor = factor or 1
    return {
        intensity = 0.4,
        size = 3 * factor,
        shift = {0,0.75-standard_assembler_vertical_shift()},
    }
end

function standard_assembler_status_glow(speed)
	if speed == nil then speed = DIR.animspeed end
    return DIR.get_layer("machines/assemblers/assembler-glow", 30, 5, "glow", nil, speed, 192, 128, 0, 0, 192, 128, {0,0-standard_assembler_vertical_shift()}, "additive", DIR.general_sprite_flags)
end

function standard_blank_sprite(x,y,r)
	x = x or 1
	y = y or 1
	r = r or 1
	return DIR.get_layer("machines/misc/blank", nil, nil, false, r, nil, x, y, 0, 0, x, y, {0,0}, nil, nil, nil, 1, false)
end

function standard_fireproof(resistances)
	if type(resistances) ~= "table" then resistances = {} end
	for _,resistance in pairs(resistances) do
		if resistance.type == "fire" then
			resistance.percent = 100
			return resistances
		end
	end
	table.insert(resistances, {type = "fire", percent = 100})
	return resistances
end

function standard_resistances(material)
	local r = {
		wood = {
			{type = "impact", percent = 25},
		},
		stone = {
			{type = "fire", percent = 90},
			{type = "acid", percent = 75},
			{type = "impact", percent = 50},
			{type = "explosion", percent = 75, decrease = 10},
			{type = "physical", percent = 50, decrease = 3},
		},
		stone_impact = { -- walls
			{type = "fire", percent = 100},
			{type = "acid", percent = 75},
			{type = "impact", percent = 50, decrease = 40},
			{type = "explosion", percent = 75, decrease = 10},
			{type = "physical", percent = 50, decrease = 3},
		},
		tin = {
			{type = "fire", percent = 75},
			{type = "impact", percent = 25},
		},
		copper = {
			{type = "fire", percent = 75},
			{type = "impact", percent = 25},
		},
		bronze = {
			{type = "fire", percent = 75},
			{type = "acid", percent = 50},
			{type = "impact", percent = 35},
		},
		iron = {
			{type = "fire", percent = 75},
			{type = "impact", percent = 50},
			{type = "explosion", percent = 50, decrease = 5},
			{type = "physical", percent = 25, decrease = 3},
		},
		steel = {
			{type = "fire", percent = 75},
			{type = "acid", percent = 50},
			{type = "impact", percent = 65},
			{type = "explosion", percent = 75, decrease = 10},
			{type = "physical", percent = 50, decrease = 3},
		},
		steel_impact = { -- walls
			{type = "fire", percent = 100},
			{type = "acid", percent = 50},
			{type = "impact", percent = 65, decrease = 40},
			{type = "explosion", percent = 75, decrease = 10},
			{type = "physical", percent = 50, decrease = 3},
		},
		chrome = {
			{type = "fire", percent = 75},
			{type = "acid", percent = 90},
			{type = "impact", percent = 80},
			{type = "explosion", percent = 75, decrease = 10},
			{type = "physical", percent = 50, decrease = 3},
		},
	}
	if not r[material] then error("Attempt to get non-existent standard resistance for material "..material) end
	return r[material]
end

function standard_health(material,size)
	local h = {
		wood = {
			[1] = 50,
			[2] = 75,
			[3] = 125,
			[4] = 200,
		},
		tin = {
			[1] = 50,
			[2] = 75,
			[3] = 125,
			[4] = 200,
		},
		copper = {
			[1] = 50,
			[2] = 100,
			[3] = 250,
			[4] = 600,
			[5] = 1250,
		},
		bronze = {
			[1] = 75,
			[2] = 150,
			[3] = 325,
			[4] = 700,
			[5] = 1500,
		},
		iron = {
			[1] = 100,
			[2] = 225,
			[3] = 400,
			[4] = 900,
			[5] = 1750,
		},
		steel = {
			[1] = 125,
			[2] = 250,
			[3] = 600,
			[4] = 1250,
			[5] = 2000,
		},
		chrome = {
			[1] = 175,
			[2] = 300,
			[3] = 800,
			[4] = 1750,
			[5] = 3000,
		},
	}
	if not h[material] then error("No standard health scheme for material "..material) end
	if not h[material][size] then error("Standard health for material "..material.." does not specify size "..size) end
	return h[material][size]
end


function DIR.get_furnace_pipe_pictures(tint, x, y)
	return {
		north = standard_blank_sprite(),
		east = {
			layers = {
				DIR.get_layer("machines/furnaces/furnace-connectors-shadow-east", nil, nil, true, nil, nil, 256, 192, 0, 0, 256, 192, {0.5-y,0.5-x}),
				DIR.get_layer("machines/furnaces/furnace-connectors-tint", nil, nil, false, nil, nil, 192, 256, 0, 0, 192, 256, {0-y,0.5-x}, nil, DIR.general_sprite_flags, tint),
				DIR.get_layer("machines/furnaces/furnace-connectors-white", nil, nil, false, nil, nil, 192, 256, 0, 0, 192, 256, {0-y,0.5-x}, "additive", DIR.general_sprite_flags),
				DIR.get_layer("machines/furnaces/furnace-connectors-connector", nil, nil, false, nil, nil, 192, 256, 0, 0, 192, 256, {0-y,0.5-x}, nil, DIR.general_sprite_flags),
			},
		},
		south = {
			layers = {
				DIR.get_layer("machines/furnaces/furnace-connectors-shadow-south", nil, nil, true, nil, nil, 256, 192, 0, 0, 256, 192, {0.5-x,0.5-y}),
				DIR.get_layer("machines/furnaces/furnace-connectors-tint", nil, nil, false, nil, nil, 192, 256, 192, 0, 192, 256, {-3-x,0.5-y}, nil, DIR.general_sprite_flags, tint),
				DIR.get_layer("machines/furnaces/furnace-connectors-white", nil, nil, false, nil, nil, 192, 256, 192, 0, 192, 256, {-3-x,0.5-y}, "additive", DIR.general_sprite_flags),
				DIR.get_layer("machines/furnaces/furnace-connectors-connector", nil, nil, false, nil, nil, 192, 256, 192, 0, 192, 256, {-3-x,0.5-y}, nil, DIR.general_sprite_flags),
			},
		},
		west = {
			layers = {
				DIR.get_layer("machines/furnaces/furnace-connectors-shadow-west", nil, nil, true, nil, nil, 256, 192, 0, 0, 256, 192, {0.5+y,0.5-x}),
				DIR.get_layer("machines/furnaces/furnace-connectors-tint", nil, nil, false, nil, nil, 192, 256, 384, 0, 192, 256, {-6+y,0.5-x}, nil, DIR.general_sprite_flags, tint),
				DIR.get_layer("machines/furnaces/furnace-connectors-white", nil, nil, false, nil, nil, 192, 256, 384, 0, 192, 256, {-6+y,0.5-x}, "additive", DIR.general_sprite_flags),
				DIR.get_layer("machines/furnaces/furnace-connectors-connector", nil, nil, false, nil, nil, 192, 256, 384, 0, 192, 256, {-6+y,0.5-x}, nil, DIR.general_sprite_flags),
			},
		},
	}
end


------------------------------------------------------------------------------------------------------------------------------------------------------

