------------------------------------------------------------------------------------------------------------------------------------------------------

-- BRONZE MACHINES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bronze template

local speed = 1
local animspeed = DIR.anim_speed / speed
local energy = DIR.get_scaled_energy_usage(speed, 0)

local bronze = {
	source_inventory_size = 1,
	result_inventory_size = 1,
	crafting_speed = DIR.get_standard_speed(speed),
	energy_source = {
		effectivity = 1,
		emissions_per_minute = DIR.get_standard_emissions(speed),
		fuel_category = "chemical",
		fuel_inventory_size = 1,
		type = "burner",
		light_flicker = standard_zero_light_flicker(),
	},
	energy_usage = energy.active,
	max_health = standard_health("bronze",3),
	dying_explosion = "medium-explosion",
	resistances = standard_resistances("bronze"),
	corpse = "medium-remnants",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	collision_box = standard_3x3_collision(),
	selection_box = standard_3x3_selection(),
	working_sound = {
		sound = {
			filename = DIR.base_sound_path.."/furnace.ogg",
			volume = 1.0
		},
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	open_sound = standard_machine_open(),
	close_sound = standard_machine_close(),
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-large.ogg"
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	tile_width = 3,
	tile_height = 3,
	entity_info_icon_shift = standard_entity_info_icon_shift(),
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bronze furnace

speed = 2
animspeed = DIR.anim_speed / speed
energy = DIR.get_scaled_energy_usage(speed, 0)

local bronze_furnace = table.deepcopy(bronze)
bronze_furnace.name = "bronze-furnace"
bronze_furnace.crafting_speed = DIR.get_standard_speed(speed)
bronze_furnace.energy_source.emissions_per_minute = DIR.get_standard_emissions(speed)
bronze_furnace.energy_usage = energy.active
bronze_furnace.type = "furnace"
bronze_furnace.icon = DIR.get_icon_path("bronze-furnace")
bronze_furnace.icon_size = DIR.icon_size
bronze_furnace.icon_mipmaps = DIR.icon_mipmaps
bronze_furnace.crafting_categories = {"smelting","smelting-2"}
bronze_furnace.gui_title_key = "gui-title.smelting"
bronze_furnace.collision_box = standard_furnace_collision()
bronze_furnace.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/bronze-furnace-base", nil, nil, false, 30, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/furnaces/bronze-furnace-working", 30, 10, false, nil, animspeed, 32, 64, 0, 0, 32, 64, {0.25,-1.5}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/furnaces/bronze-furnace-shadow", nil, nil, true, 30, animspeed, 384, 192, 0, 0, 384, 192, {1.5,0}),
	}
}
bronze_furnace.working_visualisations = {
	{
		animation = DIR.get_layer("machines/furnaces/bronze-furnace-glow", 30, 5, "glow", nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, "additive", DIR.general_sprite_flags),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/furnaces/bronze-furnace-floor-glow", nil, nil, "light", nil, animspeed, 192, 128, 0, 0, 192, 128, {0,1.5}, "additive", nil, {1,0.5,0}),
		fadeout = true,
		effect = "flicker",
	},
}
bronze_furnace.energy_source.smoke = {
	{
		frequency = 5,
		name = "smoke",
		position = { -1.1, -1.75 },
		starting_frame_deviation = 60,
		starting_vertical_speed = 0.08
	},
	{
		frequency = 5,
		name = "smoke",
		position = { 1.1, -1.75 },
		starting_frame_deviation = 40,
		starting_vertical_speed = 0.08
	},
}
bronze_furnace.fast_replaceable_group = "furnace"
bronze_furnace.next_upgrade = "electric-furnace"
bronze_furnace.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "bronze-furnace"
}
bronze_furnace.placeable_by = {item = "bronze-furnace", count = 1}
data:extend({table.deepcopy(bronze_furnace)})


-- alloys

local alloying = table.deepcopy(bronze_furnace)
local new_name = "bronze-alloy-furnace"
alloying.name = new_name
alloying.icon = DIR.get_icon_path("bronze-alloy-furnace")
alloying.type = "assembling-machine"
alloying.minable.result = new_name
alloying.placeable_by = { item = new_name, count = 1 }
alloying.gui_title_key = "gui-title.alloying"
alloying.crafting_categories = {"alloying","alloying-2"}
alloying.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/bronze-alloy-furnace-base", nil, nil, false, 30, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/furnaces/bronze-furnace-working", 30, 10, false, nil, animspeed, 32, 64, 0, 0, 32, 64, {0.25,-1.5}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/furnaces/bronze-alloy-furnace-shadow", nil, nil, true, 30, animspeed, 384, 192, 0, 0, 384, 192, {1.5,0}),
	}
}
alloying.working_visualisations = {
	{
		animation = DIR.get_layer("machines/furnaces/bronze-alloy-furnace-glow", 30, 5, "glow", nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, "additive", DIR.general_sprite_flags),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/furnaces/bronze-furnace-floor-glow", nil, nil, "light", nil, animspeed, 192, 128, 0, 0, 192, 128, {0,1.5}, "additive", nil, {1,0.5,0}),
		fadeout = true,
		effect = "flicker",
	},
}
alloying.next_upgrade = "electric-alloy-furnace"

data:extend({alloying})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bronze telescope

local telescope = table.deepcopy(data.raw.radar.radar)
telescope.name = "bronze-telescope"
telescope.icon = DIR.get_icon_path(telescope.name)
telescope.icon_size = DIR.icon_size
telescope.icon_mipmaps = DIR.icon_mipmaps
telescope.minable = {mining_time = DIR.standard_pickup_time, result = telescope.name}
telescope.corpse = "medium-remnants"
telescope.collision_box = standard_3x3_collision()
telescope.selection_box = standard_3x3_selection()
telescope.max_health = standard_health("bronze",3)
telescope.resistances = standard_resistances("bronze")
telescope.energy_per_sector = "8MJ"
telescope.max_distance_of_sector_revealed = 14
telescope.max_distance_of_nearby_sector_revealed = 2
telescope.energy_usage = DIR.get_scaled_energy_usage(2, 0).active
telescope.energy_source = {
	type = "fluid",
	fluid_box = {
		filter = "steam",
		base_area = 1,
		base_level = -1,
		height = 2,
		production_type = "input-output",
		pipe_connections = {
			{ type="input-output", position = {-2, 0} },
			{ type="input-output", position = {0, 2} },
			{ type="input-output", position = {2, 0} },
			{ type="input-output", position = {0, -2} },
		},
		pipe_covers = DIR.pipe_covers.steam,
		secondary_draw_orders = { north = -1 },
	},
	maximum_temperature = 165,
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	light_flicker = standard_zero_light_flicker(),
	-- smoke = {
		-- copper_steam({-0.875,-0.975},{-0.875,-0.975},2,0),
		-- copper_steam({0.875,-0.975},{0.875,-0.975},2,0.25),
	-- },
}
telescope.integration_patch = {
	layers = {
		DIR.get_layer("machines/misc/bronze-telescope-shadow-base", 1, 1, true, nil, animspeed, 256, 256, 0, 0, 256, 256, {0.5,0}),
		DIR.get_layer("machines/misc/bronze-telescope-base", 1, 1, false, nil, animspeed, 192, 256, 0, 0, 192, 256, {0,0}, nil, DIR.general_sprite_flags),
	}		
}
telescope.integration_patch_render_layer = "object"
telescope.pictures = {
	layers = {
		DIR.get_layer("machines/misc/bronze-telescope-shadow-working", 64, 8, true, nil, animspeed, 256, 128, 0, 0, 256, 128, {1.5,0}, nil, nil, nil, 64),
		DIR.get_layer("machines/misc/bronze-telescope-working", 64, 8, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,-0.5}, nil, DIR.general_sprite_flags, nil, 64),
	},
}
telescope.pictures.layers[1].apply_projection = false
telescope.pictures.layers[2].apply_projection = false
telescope.rotation_speed = 0.0075

telescope.water_reflection = nil
telescope.working_sound = nil -- temp

data:extend({telescope})

------------------------------------------------------------------------------------------------------------------------------------------------------
