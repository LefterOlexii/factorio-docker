------------------------------------------------------------------------------------------------------------------------------------------------------

-- POWER MACHINES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron-battery-charger

local battery_y_shift = -0.25

local glow_sequence = {}
for i=1,10 do table.insert(glow_sequence, i) end
for i=9,1,-1 do table.insert(glow_sequence, i) end
for i=1,11 do table.insert(glow_sequence, 1) end

local battery = {
    name = "iron-battery-charger",
    type = "furnace",
    placeable_by = {item = "iron-battery-charger", count = 1},
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "iron-battery-charger"
    },
    crafting_speed = 1,
    source_inventory_size = 1,
    result_inventory_size = 1,
    show_recipe_icon = false,
    crafting_categories = {"charging"},
	fast_replaceable_group = "battery-charger",
	next_upgrade = "steel-battery-charger",
    order = "z-iron-battery-charger",
    icon = DIR.get_icon_path("iron-battery-charger"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    energy_usage = "500kW",
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        drain = "0W",
    },
    allowed_effects = {},
    module_specification = nil,
    max_health = standard_health("iron",3),
    dying_explosion = "medium-explosion",
    resistances = standard_resistances("iron"),
    corpse = "medium-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
    animation = {
        layers = {
            DIR.get_layer("machines/power/iron-battery-charger-base", 1, 1, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags),
            DIR.get_layer("machines/power/iron-battery-charger-shadow", 1, 1, true, nil, DIR.anim_speed, 320, 160, 0, 0, 320, 160, {1.0,0.75+battery_y_shift}),
        }
    },
    status_colors = standard_status_colours(),
    working_visualisations = {
        {
            animation = DIR.get_layer("machines/power/iron-battery-charger-patch-white", 1, 1, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags),
        },
        {
            animation = DIR.get_layer("machines/power/iron-battery-charger-patch-top-tint", 1, 1, false, nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {0,-0.5+battery_y_shift}, nil, DIR.general_sprite_flags),
            apply_recipe_tint = "primary",
        },
        {
            animation = DIR.get_layer("machines/power/iron-battery-charger-patch-top-white", 1, 1, false, nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {0,-0.5+battery_y_shift}, "additive", DIR.general_sprite_flags),
        },
        {
            animation = DIR.get_layer("machines/power/iron-battery-charger-working", 10, 5, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, glow_sequence),
        },
        {
            animation = DIR.get_layer("machines/power/iron-battery-charger-status", 30, 5, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,1+battery_y_shift}, "additive", DIR.general_sprite_flags),
            apply_tint = "status",
            always_draw = true,
        },
    },
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/hum.ogg",
            volume = 0.95
        },
		fade_in_ticks = 10,
		fade_out_ticks = 30,
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-medium.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    match_animation_speed_to_activity = false,
}

data:extend({battery})

local abattery = table.deepcopy(battery)

abattery.name = "steel-battery-charger"
abattery.localised_description = {"entity-description.iron-battery-charger"}
abattery.icon = DIR.get_icon_path("steel-battery-charger")
abattery.placeable_by = {item = "steel-battery-charger", count = 1}
abattery.minable.result = "steel-battery-charger"
abattery.order = "z-steel-battery-charger"
abattery.next_upgrade = nil
abattery.crafting_speed = 2
abattery.energy_usage = "1000kW"
abattery.max_health = standard_health("steel",3)
abattery.resistances = standard_resistances("steel")
abattery.animation = {
	layers = {
		DIR.get_layer("machines/power/steel-battery-charger-base", 1, 1, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/power/iron-battery-charger-shadow", 1, 1, true, nil, DIR.anim_speed, 320, 160, 0, 0, 320, 160, {1.0,0.75+battery_y_shift}),
	}
}

data:extend({abattery})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- battery discharger

local glow_sequences = {true,false,true,false,false,true,false,false,false,true,false,false,false,false}
local glow_sequence = {}
for _,s in pairs(glow_sequences) do
	for i=1,s and 30 or 10 do table.insert(glow_sequence, s and i or 1) end
end
local seqlen = table_size(glow_sequence)

local discharger = {
    name = "iron-battery-discharger",
    type = "burner-generator",
	localised_name = {"entity-name.iron-battery-discharger"},
	localised_description = {"entity-description.output-priority", {"entity-description.iron-battery-discharger"}, {"entity-description.output-priority-low"}},
    placeable_by = {item = "iron-battery-discharger", count = 1},
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "iron-battery-discharger"
    },
    order = "z-iron-battery-discharger",
	fast_replaceable_group = "battery-discharger",
	next_upgrade = "steel-battery-discharger",
    icon = DIR.get_icon_path("iron-battery-discharger"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    effectivity = 1,
    energy_source = {
        type = "electric",
        usage_priority = "tertiary",
        drain = "0kW",
    },
	fast_replaceable_group = "battery-discharger",
    max_power_output = "250kW",
    burner = {
        fuel_category = "battery",
        fuel_inventory_size = 1,
        burnt_inventory_size = 1,
        type = "burner",
		light_flicker = {
			minimum_intensity = 0,
			maximum_intensity = 0,
		},
    },
    max_health = standard_health("iron",3),
    dying_explosion = "medium-explosion",
    resistances = standard_resistances("iron"),
    corpse = "medium-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
    animation = {
        layers = {
            DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 0, 0, 320, 192, {1.125,1+battery_y_shift}),
            DIR.get_layer("machines/power/iron-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags),
            DIR.get_layer("machines/power/iron-battery-discharger-working", 30, 6, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-0.5+battery_y_shift}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, glow_sequence),
        }
    },
    idle_animation = {
        layers = {
            DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 0, 0, 320, 192, {1.125,1+battery_y_shift}),
            DIR.get_layer("machines/power/iron-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags),
        }
    },
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/zap-loop.ogg",
            volume = 0.5
        },
		fade_in_ticks = 10,
		fade_out_ticks = 20,
		audible_distance_modifier = 0.75,
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-medium.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    min_perceived_performance = 1,
}

-- active toggle version of batt generator

local active = table.deepcopy(discharger)

active.name = active.name .. "-active"
active.energy_source.usage_priority = "secondary-output"
active.localised_description = {"entity-description.output-priority", {"entity-description.iron-battery-discharger"}, {"entity-description.output-priority-high"}}
active.next_upgrade = "steel-battery-discharger-active"

active.animation = {
	layers = {
            DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 320, 0, 320, 192, {1.125-5,1+battery_y_shift}),
            DIR.get_layer("machines/power/iron-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 192, 0, 192, 192, {-3,0+battery_y_shift}, nil, DIR.general_sprite_flags),
            DIR.get_layer("machines/power/iron-battery-discharger-working", 30, 6, "glow", nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-0.5+battery_y_shift}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, glow_sequence),
	}
}
active.idle_animation = {
	layers = {
            DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 320, 0, 320, 192, {1.125-5,1+battery_y_shift}),
            DIR.get_layer("machines/power/iron-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 192, 0, 192, 192, {-3,0+battery_y_shift}, nil, DIR.general_sprite_flags),
	}
}

-- steel versions of both versions

local adischarger = table.deepcopy(discharger)

adischarger.name = "steel-battery-discharger"
adischarger.localised_name = {"entity-name.steel-battery-discharger"}
adischarger.localised_description = {"entity-description.output-priority", {"entity-description.iron-battery-discharger"}, {"entity-description.output-priority-low"}}
adischarger.icon = DIR.get_icon_path("steel-battery-discharger")
adischarger.placeable_by = {item = "steel-battery-discharger", count = 1}
adischarger.minable.result = "steel-battery-discharger"
adischarger.order = "z-steel-battery-discharger"
adischarger.next_upgrade = nil
adischarger.max_power_output = "1000kW"
adischarger.max_health = standard_health("steel",3)
adischarger.resistances = standard_resistances("steel")
adischarger.animation.layers[2] = DIR.get_layer("machines/power/steel-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags)
adischarger.idle_animation.layers[2] = DIR.get_layer("machines/power/steel-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0+battery_y_shift}, nil, DIR.general_sprite_flags)

local aactive = table.deepcopy(adischarger)

aactive.name = "steel-battery-discharger-active"
aactive.localised_description = {"entity-description.output-priority", {"entity-description.iron-battery-discharger"}, {"entity-description.output-priority-high"}}
aactive.energy_source.usage_priority = "secondary-output"
aactive.animation.layers[1] = DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 320, 0, 320, 192, {1.125-5,1+battery_y_shift})
aactive.animation.layers[2] = DIR.get_layer("machines/power/steel-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 192, 0, 192, 192, {-3,0+battery_y_shift}, nil, DIR.general_sprite_flags)
aactive.idle_animation.layers[1] = DIR.get_layer("machines/power/iron-battery-discharger-shadow", nil, nil, true, seqlen, DIR.anim_speed, 320, 192, 320, 0, 320, 192, {1.125-5,1+battery_y_shift})
aactive.idle_animation.layers[2] = DIR.get_layer("machines/power/steel-battery-discharger-base", nil, nil, false, seqlen, DIR.anim_speed, 192, 192, 192, 0, 192, 192, {-3,0+battery_y_shift}, nil, DIR.general_sprite_flags)

-- icon overlays for entities in upgrade planner

DIR.convert_recipe_icon_to_icons(discharger)
DIR.convert_recipe_icon_to_icons(active)
DIR.convert_recipe_icon_to_icons(adischarger)
DIR.convert_recipe_icon_to_icons(aactive)
DIR.add_icons_to_recipe(
	discharger,
	{{icon = DIR.get_icon_path("low-priority-output-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
	1
)
DIR.add_icons_to_recipe(
	active,
	{{icon = DIR.get_icon_path("high-priority-output-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
	1
)
DIR.add_icons_to_recipe(
	adischarger,
	{{icon = DIR.get_icon_path("low-priority-output-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
	1
)
DIR.add_icons_to_recipe(
	aactive,
	{{icon = DIR.get_icon_path("high-priority-output-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
	1
)

data:extend({discharger, active, adischarger, aactive})


------------------------------------------------------------------------------------------------------------------------------------------------------

-- supermagnet

local sm = table.deepcopy(abattery)

sm.name = "supermagnet"
sm.localised_description = nil
sm.icon = DIR.get_icon_path(sm.name)
sm.placeable_by = {item = sm.name, count = 1}
sm.minable.result = sm.name
sm.order = "zz-supermagnet"
sm.crafting_categories = {"supermagnet"}
sm.next_upgrade = nil
sm.fast_replaceable_group = nil
sm.crafting_speed = 1
sm.energy_usage = "2MW"
sm.max_health = standard_health("chrome",3)
sm.resistances = standard_resistances("chrome")
sm.type = "assembling-machine"
sm.fixed_recipe = "electrum-gem-charged"

sm.fluid_boxes = {
	{
		production_type = "input",
		pipe_covers = DIR.pipe_covers["iron"],
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {-1, -2} }},
		secondary_draw_orders = { north = -1, south = 10 }
	},
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers["iron"],
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {1, -2} }},
		secondary_draw_orders = { north = -1, south = 10 }
	},
	off_when_no_fluid_recipe = false,
}

local function get_direction(filename,y_offset,shadow,x,y,x_offset)
	return DIR.get_layer(filename, nil, nil, shadow, nil, nil, x, y, 0, y*y_offset, x, y, {x_offset,-y_offset*4}, nil, shadow and DIR.general_sprite_flags or nil)
end

sm.animation = {
	north = {
		layers = {
			get_direction("machines/misc/supermagnet-shadow", 0, true, 256, 256, 0.5),
			get_direction("machines/misc/supermagnet-base", 0, false, 192, 256, 0),
		}
	},
	east = {
		layers = {
			get_direction("machines/misc/supermagnet-shadow", 1, true, 256, 256, 0.5),
			get_direction("machines/misc/supermagnet-base", 1, false, 192, 256, 0),
		}
	},
	south = {
		layers = {
			get_direction("machines/misc/supermagnet-shadow", 2, true, 256, 256, 0.5),
			get_direction("machines/misc/supermagnet-base", 2, false, 192, 256, 0),
		}
	},
	west = {
		layers = {
			get_direction("machines/misc/supermagnet-shadow", 3, true, 256, 256, 0.5),
			get_direction("machines/misc/supermagnet-base", 3, false, 192, 256, 0),
		}
	},
}
sm.working_visualisations = {
	{
		animation = DIR.get_layer("machines/misc/supermagnet-working-shadow", 60, 6, true, nil, 1, 128, 96, 0, 0, 128, 96, {2.5,0.25}),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/misc/supermagnet-working", 60, 10, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,-0.5}, nil, DIR.general_sprite_flags),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/misc/supermagnet-glow", 60, 10, "glow", nil, 1, 192, 224, 0, 0, 192, 224, {0,-0.75}, "additive", DIR.general_sprite_flags),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/power/iron-battery-charger-status", 30, 5, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,37/64}, "additive", DIR.general_sprite_flags),
		apply_tint = "status",
		always_draw = true,
	},
}

data:extend({sm})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- large solar array

local pictures = {}
for i=1,16 do
	local layers = {
		DIR.get_layer("machines/power/solar-array-shadow", 1, nil, true, nil, nil, 384, 320, 0, 0, 384, 320, {0.5,0.0}),
	}
	for x = -2,2 do
		table.insert(layers, DIR.get_layer("machines/power/solar-array-base-"..DIR.get_pretend_random_integer(8), 1, nil, false, nil, nil, 64, 352, 0, 0, 64, 352, {x,-0.25}, nil, DIR.general_sprite_flags))
	end
	table.insert(pictures, { layers = layers })
end


data:extend({{
    name = "solar-array",
    type = "solar-panel",
    collision_box = {{-2.4,-2.4},{2.4,2.4}},
    selection_box = {{-2.5,-2.5},{2.5,2.5}},
    corpse = "medium-remnants",
    dying_explosion = "medium-explosion",
    energy_source = {
        type = "electric",
        usage_priority = "solar"
    },
    flags = {
        "placeable-neutral",
        "player-creation"
    },
    icon = DIR.get_icon_path("solar-array"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    max_health = standard_health("steel",4),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "solar-array"
    },
    picture = pictures,
    overlay = nil,
    production = "300kW",
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact
}})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- tweak solar panel

local pictures = {}
for i=1,16 do
	local layers = {
		DIR.get_layer("machines/power/solar-panel-shadow", 1, nil, true, nil, nil, 256, 192, 0, 0, 256, 192, {0.5,0.0}),
	}
	for x = -1,1 do
		table.insert(layers, DIR.get_layer("machines/power/solar-panel-base-"..DIR.get_pretend_random_integer(8), 1, nil, false, nil, nil, 64, 224, 0, 0, 64, 224, {x,-0.25}, nil, DIR.general_sprite_flags))
	end
	table.insert(pictures, { layers = layers })
end

local solar = data.raw["solar-panel"]["solar-panel"]
if solar then
    solar.picture = pictures
    solar.overlay = nil
    solar.production = "75kW"
    solar.icon = DIR.get_icon_path("solar-panel")
    solar.icon_size = DIR.icon_size
    solar.icon_mipmaps = DIR.icon_mipmaps
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- big wooden pole

data:extend({
    {
        type = "electric-pole",
        name = "big-wooden-pole",
        icon = DIR.get_icon_path("big-wooden-pole"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
        minable = {mining_time = DIR.standard_pickup_time, result = "big-wooden-pole"},
        max_health = standard_health("wood",4),
        corpse = "medium-small-remnants",
        resistances = standard_resistances("wood"),
        collision_box = {{-0.65, -0.65}, {0.65, 0.65}},
        selection_box = {{-1, -1}, {1, 1}},
        drawing_box = {{-1, -4}, {1, 1}},
		fast_replaceable_group = "electric-pole",
		next_upgrade = "big-electric-pole",
        maximum_wire_distance = 16,
        supply_area_distance = 2,
        vehicle_impact_sound = DIR.vanilla_sounds.car_wood_impact(0.5),
        pictures =
        {
            layers =
            {
                DIR.get_layer("machines/power/big-wooden-pole-base", 1, 4, false, nil, nil, 128, 384, 0, 0, 128, 384, {0,-2}, nil, nil, nil, 4),
                DIR.get_layer("machines/power/big-wooden-pole-shadow", 1, 1, true, nil, nil, 512, 128, 0, 0, 512, 128, {3,0}, nil, nil, nil, 4),
            }
        },
        connection_points = {
            {
                shadow =
                {
                    copper = util.by_pixel_hr(328,6),
                    red = util.by_pixel_hr(366, 6),
                    green = util.by_pixel_hr(258, 6)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0, -232),
                    red = util.by_pixel_hr(52, -214),
                    green = util.by_pixel_hr(-52, -214)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(328,6),
                    red = util.by_pixel_hr(348, 34),
                    green = util.by_pixel_hr(272, -20)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0, -232),
                    red = util.by_pixel_hr(37, -187),
                    green = util.by_pixel_hr(-37, -241)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(328,6),
                    red = util.by_pixel_hr(311, 45),
                    green = util.by_pixel_hr(311, -30)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0, -232),
                    red = util.by_pixel_hr(0, -176),
                    green = util.by_pixel_hr(0, -250)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(328,6),
                    red = util.by_pixel_hr(348, -20),
                    green = util.by_pixel_hr(272, 34)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0, -238),
                    red = util.by_pixel_hr(37, -241),
                    green = util.by_pixel_hr(-37, -197)
                }
            }
        },
        radius_visualisation_picture =
        {
            filename = "__base__/graphics/entity/small-electric-pole/electric-pole-radius-visualization.png",
            width = 12,
            height = 12,
            priority = "extra-high-no-scale"
        }
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- small bronze pole

data:extend({
    {
        type = "electric-pole",
        name = "small-bronze-pole",
        icon = DIR.get_icon_path("small-bronze-pole"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        flags = {"placeable-neutral", "player-creation", "fast-replaceable-no-build-while-moving"},
        minable = {mining_time = DIR.standard_pickup_time, result = "small-bronze-pole"},
        max_health = standard_health("bronze",1),
        corpse = "small-remnants",
        resistances = standard_resistances("bronze"),
        collision_box = data.raw["electric-pole"]["small-electric-pole"].collision_box,
        selection_box = data.raw["electric-pole"]["small-electric-pole"].selection_box,
        drawing_box = data.raw["electric-pole"]["small-electric-pole"].drawing_box,
		fast_replaceable_group = "electric-pole",
		next_upgrade = nil,
        maximum_wire_distance = 7.5,
        supply_area_distance = 2.5,
		track_coverage_during_build_by_moving = true,
        vehicle_impact_sound = DIR.vanilla_sounds.car_wood_impact(0.5),
        pictures = {
            layers = {
                DIR.get_layer("machines/power/small-bronze-pole-shadow", 1, 1, true, nil, nil, 320, 64, 0, 0, 320, 64, {2,0}, nil, nil, nil, 4),
                DIR.get_layer("machines/power/small-bronze-pole-base", 1, 4, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,-1.5}, nil, nil, nil, 4),
            }
        },
        connection_points = {
            {
                shadow =
                {
                    copper = util.by_pixel_hr(230,2),
                    red = util.by_pixel_hr(252,2),
                    green = util.by_pixel_hr(202,2)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0,-162),
                    red = util.by_pixel_hr(22,-162),
                    green = util.by_pixel_hr(-22,-162)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(230,2),
                    red = util.by_pixel_hr(240,12),
                    green = util.by_pixel_hr(220,-8)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0,-162),
                    red = util.by_pixel_hr(15,-150),
                    green = util.by_pixel_hr(-15,-174)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(230,2),
                    red = util.by_pixel_hr(230,16),
                    green = util.by_pixel_hr(230,-12)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0,-161),
                    red = util.by_pixel_hr(0,-146),
                    green = util.by_pixel_hr(-0,-176)
                }
            },
            {
                shadow =
                {
                    copper = util.by_pixel_hr(230,2),
                    red = util.by_pixel_hr(240,-8),
                    green = util.by_pixel_hr(220,12)
                },
                wire =
                {
                    copper = util.by_pixel_hr(0,-162),
                    red = util.by_pixel_hr(15,-174),
                    green = util.by_pixel_hr(-15,-150)
                }
            }
        },
        radius_visualisation_picture =
        {
            filename = "__base__/graphics/entity/small-electric-pole/electric-pole-radius-visualization.png",
            width = 12,
            height = 12,
            priority = "extra-high-no-scale"
        }
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

local iron_pole = table.deepcopy(data.raw["electric-pole"]["small-bronze-pole"])
iron_pole.name = "small-iron-pole"
iron_pole.icon = DIR.get_icon_path("small-iron-pole")
iron_pole.minable = {mining_time = DIR.standard_pickup_time, result = "small-iron-pole"}
iron_pole.pictures = {
	layers = {
		DIR.get_layer("machines/power/small-bronze-pole-shadow", 1, 1, true, nil, nil, 320, 64, 0, 0, 320, 64, {2,0}, nil, nil, nil, 4),
		DIR.get_layer("machines/power/small-iron-pole-base", 1, 4, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,-1.5}, nil, nil, nil, 4),
	}
}
iron_pole.resistances = standard_resistances("iron")
iron_pole.max_health = standard_health("iron",1)

data:extend({iron_pole})

local steel_pole = table.deepcopy(iron_pole)
steel_pole.name = "medium-electric-pole"
steel_pole.icon = DIR.get_icon_path("medium-steel-pole")
steel_pole.minable = {mining_time = DIR.standard_pickup_time, result = "medium-electric-pole"}
steel_pole.pictures = {
	layers = {
		DIR.get_layer("machines/power/medium-steel-pole-shadow", 1, 1, true, nil, nil, 320, 64, 0, 0, 320, 64, {2,0}, nil, nil, nil, 4),
		DIR.get_layer("machines/power/medium-steel-pole-base", 1, 4, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,-1.5}, nil, nil, nil, 4),
	}
}
steel_pole.resistances = standard_resistances("steel")
steel_pole.max_health = standard_health("steel",1)
steel_pole.maximum_wire_distance = data.raw["electric-pole"]["medium-electric-pole"].maximum_wire_distance
steel_pole.supply_area_distance = data.raw["electric-pole"]["medium-electric-pole"].supply_area_distance

data:extend({steel_pole})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper boiler

data:extend({{
    name = "copper-boiler",
    type = "boiler",
    burning_cooldown = 20,
    collision_box = { {-0.45,-1.45}, {0.45,1.45} },
	selection_box = { {-0.5,-1.5}, {0.5,1.5} },
    corpse = nil, -- no suitable remnants for 1x3?
    energy_consumption = "0.9MW",
    target_temperature = 165,
    energy_source = {
        effectivity = 1,
        emissions_per_minute = DIR.get_standard_emissions(5),
        fuel_category = "chemical",
        fuel_inventory_size = 1,
        smoke = {
            {
                name = "smoke",
                frequency = 8,
                north_position = {-0.3,-0.55},
                south_position = {-0.3,-0.55},
                east_position = {0,-0.8},
                west_position = {0,-0.8},
                starting_frame_deviation = 60,
                starting_vertical_speed = 0,
            }
        },
		light_flicker = {
			color = {0,0,0},
			minimum_intensity = 0.6,
			maximum_intensity = 1.0,
		},
        type = "burner"
    },
    flags = {
        "placeable-neutral",
        "player-creation"
    },
    fluid_box = {
        base_area = 1,
        base_level = -1,
        filter = "water",
        height = 2,
        pipe_connections = {
			{ type="input", position = {0, -2} },
        },
        pipe_covers = DIR.pipe_covers.copper,
        production_type = "input",
    },
    icon = DIR.get_icon_path("copper-boiler"),
    icon_mipmaps = DIR.icon_mipmaps,
    icon_size = DIR.icon_size,
    max_health = standard_health("copper",2),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "copper-boiler"
    },
    mode = "output-to-separate-pipe",
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    output_fluid_box = {
        base_area = 1,
        base_level = 1,
        filter = "steam",
        height = 2,
        pipe_connections = {
			{
                position = {0, 2},
                type = "output"
            }
        },
        pipe_covers = DIR.pipe_covers.steam,
        production_type = "output"
    },
    patch = nil,
    resistances = standard_resistances("copper"),
    structure = {
        north = {
            layers = {
                DIR.get_layer("machines/power/copper-boiler-base-n", 1, 1, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-vertical-shadow", 1, 1, true, nil, nil, 192, 256, 0, 0, 192, 256, {1,0}),
            }
        },
        east = {
            layers = {
                DIR.get_layer("machines/power/copper-boiler-base-e", 1, 1, false, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-horizontal-shadow", 1, 1, true, nil, nil, 256, 128, 0, 0, 256, 128, {0.5,0}),
            }
        },
        south = {
            layers = {
                DIR.get_layer("machines/power/copper-boiler-base-s", 1, 1, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-vertical-shadow", 1, 1, true, nil, nil, 192, 256, 0, 0, 192, 256, {1,0}),
            }
        },
        west = {
            layers = {
                DIR.get_layer("machines/power/copper-boiler-base-w", 1, 1, false, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-horizontal-shadow", 1, 1, true, nil, nil, 256, 128, 0, 0, 256, 128, {0.5,0}),
            }
        },
    },
    fire = {
        north = {
			layers = {
				DIR.get_layer("machines/power/copper-boiler-fire-vertical", 30, 10, "glow", nil, 0.5, 128, 128, 0, 0, 128, 128, {0,0}, "additive"),
				DIR.get_layer("machines/power/copper-boiler-glow-vertical", nil, nil, "light", 30, 0.5, 192, 192, 0, 0, 192, 192, {0,0}, "additive"),
			},
		},
        south = {
			layers = {
				DIR.get_layer("machines/power/copper-boiler-fire-vertical", 30, 10, "glow", nil, 0.5, 128, 128, 0, 0, 128, 128, {0,0}, "additive"),
				DIR.get_layer("machines/power/copper-boiler-glow-vertical", nil, nil, "light", 30, 0.5, 192, 192, 0, 0, 192, 192, {0,0}, "additive"),
			},
		},
        east = {
			layers = {
				DIR.get_layer("machines/power/copper-boiler-fire-horizontal", 30, 10, "glow", nil, 0.5, 128, 128, 0, 0, 128, 128, {0,0}, "additive"),
				DIR.get_layer("machines/power/copper-boiler-glow-horizontal", nil, nil, "light", 30, 0.5, 192, 128, 0, 0, 192, 128, {0,0.5}, "additive"),
			},
		},
        west = {
			layers = {
				DIR.get_layer("machines/power/copper-boiler-fire-horizontal", 30, 10, "glow", nil, 0.5, 128, 128, 0, 0, 128, 128, {0,0}, "additive"),
				DIR.get_layer("machines/power/copper-boiler-glow-horizontal", nil, nil, "light", 30, 0.5, 192, 128, 0, 0, 192, 128, {0,0.5}, "additive"),
			},
		},
    },
    fire_flicker_enabled = true,
    fire_glow = {},
    fire_glow_flicker_enabled = false,
    type = "boiler",
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    water_reflection = nil,
    working_sound = {
        sound = {
            filename = "__base__/sound/boiler.ogg",
            volume = 0.7
        },
		fade_in_ticks = 4,
		fade_out_ticks = 10,
    }
}})


------------------------------------------------------------------------------------------------------------------------------------------------------

-- electric boiler

data:extend({{
    name = "steel-boiler",
    type = "assembling-machine",
	crafting_categories = {"electric-boiler"},
	gui_title_key = "gui-title.boiling",
	crafting_speed = DIR.get_standard_speed(1),
    collision_box = { {-0.45,-1.45}, {0.45,1.45} },
	selection_box = { {-0.5,-1.5}, {0.5,1.5} },
    corpse = nil, -- no suitable remnants for 1x3?
    energy_usage = "1250kW", -- recipes are tuned to 1125kW (to match 900kW at speed 1.25) but we want an extra effiency penalty vs solid fuel boilers
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        drain = "0W",
    },
    flags = {
        "placeable-neutral",
        "player-creation"
    },
	fluid_boxes = {
		{
			production_type = "input",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = -1,
			pipe_connections = {{ type="input", position = {0, -2} }},
			secondary_draw_orders = { north = -1 },
		},
		{
			production_type = "output",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = 1,
			pipe_connections = {{ type="output", position = {0, 2} }},
			secondary_draw_orders = { north = -1 }
		},
		off_when_no_fluid_recipe = false
	},
    icon = DIR.get_icon_path("steel-boiler"),
    icon_mipmaps = DIR.icon_mipmaps,
    icon_size = DIR.icon_size,
    max_health = standard_health("steel",2),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "steel-boiler"
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    resistances = standard_resistances("steel"),
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    water_reflection = nil,
    working_sound = {
        sound = {
            filename = "__base__/sound/boiler.ogg",
            volume = 0.7
        },
		fade_in_ticks = 4,
		fade_out_ticks = 10,
    },
	animation = {
        north = {
            layers = {
                DIR.get_layer("machines/power/electric-boiler-vertical", 1, 1, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-vertical-shadow", 1, 1, true, nil, nil, 192, 256, 0, 0, 192, 256, {1,0}),
            }
        },
        east = {
            layers = {
                DIR.get_layer("machines/power/electric-boiler-horizontal", 1, 1, false, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-horizontal-shadow", 1, 1, true, nil, nil, 256, 128, 0, 0, 256, 128, {0.5,0}),
            }
        },
        south = {
            layers = {
                DIR.get_layer("machines/power/electric-boiler-vertical", 1, 1, false, nil, nil, 64, 256, 0, 0, 64, 256, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-vertical-shadow", 1, 1, true, nil, nil, 192, 256, 0, 0, 192, 256, {1,0}),
            }
        },
        west = {
            layers = {
                DIR.get_layer("machines/power/electric-boiler-horizontal", 1, 1, false, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
                DIR.get_layer("machines/power/copper-boiler-horizontal-shadow", 1, 1, true, nil, nil, 256, 128, 0, 0, 256, 128, {0.5,0}),
            }
        },
	},
	working_visualisations = {
		{
			north_animation = DIR.get_layer("machines/power/electric-boiler-vertical-working", 30, 10, "glow", nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {-0.25,-0.25}, "additive"),
			south_animation = DIR.get_layer("machines/power/electric-boiler-vertical-working", 30, 10, "glow", nil, DIR.anim_speed, 64, 128, 0, 0, 64, 128, {-0.25,-0.25}, "additive"),
			east_animation = DIR.get_layer("machines/power/electric-boiler-horizontal-working", 30, 10, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.25}, "additive"),
			west_animation = DIR.get_layer("machines/power/electric-boiler-horizontal-working", 30, 10, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.25}, "additive"),
			light = {
				intensity = 0.4,
				size = 3,
				shift = {0,0},
			},
			apply_tint = "status",
			always_draw = true,
			north_position = {0.25,-0.25},
			south_position = {0.25,-0.25},
			east_position = {0,0.25},
			west_position = {0,0.25},
		},
	},
	status_colors = standard_status_colours(),
}})

------------------------------------------------------------------------------------------------------------

-- steel gas generator

local gen_max_speed = 1

data:extend({{
    type = "generator",
    name = "petro-generator",
    icon = DIR.get_icon_path("petro-generator"),
    icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps,
    flags = {"placeable-neutral","player-creation"},
    minable = {mining_time = DIR.standard_pickup_time, result = "petro-generator"},
    max_health = standard_health("iron",3),
    corpse = "medium-remnants",
    effectivity = 1,
    resistances = standard_resistances("iron"),
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
	burns_fluid = true,
	scale_fluid_usage = true,
	fluid_usage_per_tick = 2 / 60,
	destroy_non_fuel_fluid = false,
	max_power_output = "800kW",
	maximum_temperature = 100,
    fluid_box = {
      base_area = 1,
      height = 2,
      base_level = -1,
      pipe_covers = DIR.pipe_covers.iron,
      pipe_connections =
      {
        { type = "input-output", position = {0, 2} },
        { type = "input-output", position = {0, -2} }
      },
      production_type = "input-output",
    },
    energy_source = {
      type = "electric",
      usage_priority = "secondary-output",
	  emissions_per_minute = DIR.get_standard_emissions(5),
    },
    horizontal_animation = {
		layers = {
			DIR.get_layer("machines/power/petro-generator-base-shadow-ew", nil, nil, true, 30, gen_max_speed, 256, 192, 0, 0, 256, 192, {0.5,0}),
			DIR.get_layer("machines/power/petro-generator-working-shadow-ew", 30, 6, true, nil, gen_max_speed, 128, 192, 0, 0, 128, 192, {1.5,0}),
			DIR.get_layer("machines/power/petro-generator-base-ew", 30, 6, false, nil, gen_max_speed, 192, 192, 0, 0, 192, 192, {0,0}, nil, DIR.recommended_sprite_flags),
		},
	},
    vertical_animation = {
		layers = {
			DIR.get_layer("machines/power/petro-generator-base-shadow-ns", nil, nil, true, 30, gen_max_speed, 192, 256, 0, 0, 192, 256, {0,0}),
			DIR.get_layer("machines/power/petro-generator-working-shadow-ns", 30, 6, true, nil, gen_max_speed, 128, 192, 0, 0, 128, 192, {1.5,0}),
			DIR.get_layer("machines/power/petro-generator-base-ns", 30, 6, false, nil, gen_max_speed, 192, 256, 0, 0, 192, 256, {0,0}, nil, DIR.recommended_sprite_flags),
		},
    },
    smoke = nil,
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/generator.ogg",
            volume = 0.75
        },
		fade_in_ticks = 5,
		fade_out_ticks = 10,
		match_speed_to_activity = true,
		audible_distance_modifier = 0.75,
		max_sounds_per_type = 3,
    },
    min_perceived_performance = 0.5,
    performance_to_sound_speedup = 0.15,
}})

local description = {"",{"entity-description.petro-generator"},"\n",{"entity-description.accepted-types"}," "}
for _,fluid in pairs(data.raw.fluid) do
	if fluid.fuel_value then table.insert(description,"[img=fluid/"..fluid.name.."] ") end
end
data.raw.generator["petro-generator"].localised_description = description


------------------------------------------------------------------------------------------------------------------------------------------------------
