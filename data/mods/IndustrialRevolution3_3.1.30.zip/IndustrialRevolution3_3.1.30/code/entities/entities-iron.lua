------------------------------------------------------------------------------------------------------------------------------------------------------

-- IRON MACHINES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron template

local speed = 1
local animspeed = DIR.anim_speed / speed
local energy = DIR.get_scaled_energy_usage(speed, DIR.standard_drain)
local iron = {
	source_inventory_size = 1,
	result_inventory_size = 1,
	crafting_speed = DIR.get_standard_speed(speed),
	energy_usage = energy.active,
	energy_source = {
		type = "electric",
		usage_priority = "secondary-input",
		drain = energy.passive,
	},
	allowed_effects = {
		"consumption",
		"speed",
		"pollution",
		"productivity",
	},
	module_specification = {
		module_info_icon_shift = standard_entity_info_module_shift(),
		module_slots = 2
	},
	max_health = standard_health("iron",3),
	dying_explosion = "medium-explosion",
	resistances = standard_resistances("iron"),
	corpse = "medium-remnants",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	collision_box = standard_3x3_collision(),
	selection_box = standard_3x3_selection(),
	working_sound = {
		sound = {
			filename = DIR.base_sound_path.."/furnace.ogg",
			volume = 0.8
		},
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	open_sound = standard_machine_open(),
	close_sound = standard_machine_close(),
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-large.ogg"
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	tile_width = 3,
	tile_height = 3,
	entity_info_icon_shift = standard_entity_info_icon_shift(),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	status_colors = standard_status_colours(),
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron grinder

local iron_grinder = table.deepcopy(iron)
iron_grinder.name = "iron-grinder"
iron_grinder.type = "furnace"
iron_grinder.icon = DIR.get_icon_path("iron-grinder")
iron_grinder.result_inventory_size = 2
iron_grinder.crafting_categories = {"grinding","grinding-2"}
iron_grinder.allowed_effects = {
	"consumption",
	"speed",
	"productivity",
	"pollution",
}
iron_grinder.gui_title_key = "gui-title.grinding"
iron_grinder.animation = {
	layers = {
		DIR.get_layer("machines/grinders/iron-grinder-base", 30, 5, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 30, animspeed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
	}
}
iron_grinder.working_visualisations = {
	{
		animation = standard_assembler_status_glow(),
		light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
	},
}
iron_grinder.placeable_by = {item = "iron-grinder", count = 1}
iron_grinder.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "iron-grinder"
}
iron_grinder.fast_replaceable_group = "grinder"
iron_grinder.next_upgrade = "steel-grinder"
iron_grinder.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
iron_grinder.working_sound.sound.volume = 0.75
iron_grinder.entity_info_icon_shift = standard_grinder_info_icon_shift()
data:extend({iron_grinder})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron mixer

local iron_mixer = table.deepcopy(iron_grinder)
iron_mixer.name = "iron-mixer"
iron_mixer.type = "assembling-machine"
iron_mixer.source_inventory_size = 2
iron_mixer.result_inventory_size = 1
iron_mixer.fluid_boxes = assembler_fluid_boxes()
iron_mixer.entity_info_icon_shift = standard_entity_info_icon_shift()
iron_mixer.icon = DIR.get_icon_path("iron-mixer")
iron_mixer.crafting_categories = {"mixing"}
iron_mixer.gui_title_key = "gui-title.mixing"
iron_mixer.placeable_by = {item = "iron-mixer", count = 1}
iron_mixer.next_upgrade = "steel-mixer"
iron_mixer.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "iron-mixer"
}
iron_mixer.animation = {
	layers = {
		DIR.get_layer("machines/grinders/iron-mixer-base", 60, 10, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 60, 1, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
	}
}
iron_mixer.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
iron_mixer.working_sound.sound.volume = 0.75

data:extend({table.deepcopy(iron_mixer)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron scrapper

local iron_scrapper = table.deepcopy(iron)
iron_scrapper.name = "iron-scrapper"
iron_scrapper.type = "furnace"
iron_scrapper.source_inventory_size = 1
iron_scrapper.result_inventory_size = DIR.max_scrap_types
iron_scrapper.icon = DIR.get_icon_path("iron-scrapper")
iron_scrapper.crafting_categories = {"scrapping"}
iron_scrapper.crafting_speed = DIR.get_standard_speed(1)
iron_scrapper.match_animation_speed_to_activity = false
iron_scrapper.allowed_effects = {
	"consumption",
	"speed",
	"pollution",
}
iron_scrapper.animation = {
	layers = {
		DIR.get_layer("machines/assemblers/iron-scrapper-base", 30, 5, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0-standard_assembler_vertical_shift()}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/assemblers/iron-shadow", nil, nil, true, 30, DIR.anim_speed, 256, 192, 0, 0, 256, 192, {0.5,0-standard_assembler_vertical_shift()}),
	}
}
iron_scrapper.working_visualisations = {
	{
		animation = standard_assembler_status_glow(),
		light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
	},
}
iron_scrapper.placeable_by = {item = "iron-scrapper", count = 1}
iron_scrapper.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "iron-scrapper"
}
iron_scrapper.fast_replaceable_group = "scrapper"
iron_scrapper.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
iron_scrapper.working_sound.sound.volume = 0.75
iron_scrapper.entity_info_icon_shift = standard_grinder_info_icon_shift()
iron_scrapper.show_recipe_icon = false
data:extend({iron_scrapper})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron furnace

speed = 2
energy = DIR.get_scaled_energy_usage(speed, DIR.standard_drain)

local iron_furnace = table.deepcopy(iron)
iron_furnace.name = "electric-furnace"
iron_furnace.type = "furnace"
iron_furnace.crafting_speed = DIR.get_standard_speed(speed)
iron_furnace.energy_source = {
	type = "electric",
	usage_priority = "secondary-input",
	drain = energy.passive,
	emissions_per_minute = DIR.get_standard_emissions(speed),
}
iron_furnace.energy_usage = energy.active
iron_furnace.icon = DIR.get_icon_path("electric-furnace")
iron_furnace.crafting_categories = {
	"smelting","smelting-2","smelting-3"
}
iron_furnace.allowed_effects = {
	"consumption",
	"speed",
	"productivity",
	"pollution",
}
iron_furnace.gui_title_key = "gui-title.smelting"
iron_furnace.placeable_by = {item = "electric-furnace", count = 1}
iron_furnace.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "electric-furnace"
}
iron_furnace.collision_box = standard_furnace_collision()
iron_furnace.fast_replaceable_group = "furnace"
iron_furnace.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/electric-furnace-shadow", nil, nil, true, nil, DIR.anim_speed, 320, 128, 0, 0, 320, 128, {1,0.5}),
		DIR.get_layer("machines/furnaces/electric-furnace-base", nil, nil, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
	}
}
iron_furnace.status_colors = standard_status_colours()
iron_furnace.working_visualisations = {
	{
		animation = DIR.get_layer("machines/furnaces/electric-furnace-working", 60, 15, "glow", nil, 1, 64, 128, 0, 0, 64, 128, {0,-1.5}, "additive", DIR.general_sprite_flags),
		always_draw = false,
		fadeout = true,
		render_layer = "object",
	},
	{
		animation = DIR.get_layer("machines/furnaces/electric-furnace-floor-glow", 30, 5, "light", nil, DIR.animspeed, 192, 128, 0, 0, 192, 128, {0,0.5}, "additive", nil, {1,0.6,0}),
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/furnaces/electric-furnace-status", 30, 5, "glow", nil, DIR.animspeed, 192, 128, 0, 0, 192, 128, {0,-1}, "additive", DIR.general_sprite_flags),
		apply_tint = "status",
		always_draw = true,
		render_layer = "object",
	},
}
iron_furnace.match_animation_speed_to_activity = false
iron_furnace.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.base_sound_path, "electric-furnace")
iron_furnace.entity_info_icon_shift = {0,0}

data.raw.furnace["electric-furnace"] = nil
data:extend({iron_furnace})

-- alloys

local alloying = table.deepcopy(iron_furnace)
local new_name = "electric-alloy-furnace"
alloying.name = new_name
alloying.icon = DIR.get_icon_path("electric-alloy-furnace")
alloying.type = "assembling-machine"
alloying.minable.result = new_name
alloying.placeable_by = { item = new_name, count = 1 }
alloying.gui_title_key = "gui-title.alloying"
alloying.crafting_categories = {"alloying","alloying-2","alloying-3","multi-smelting"}
alloying.animation = {
	layers = {
		DIR.get_layer("machines/furnaces/electric-furnace-shadow", nil, nil, true, nil, DIR.anim_speed, 320, 128, 0, 0, 320, 128, {1,0.5}),
		DIR.get_layer("machines/furnaces/electric-alloy-furnace-base", nil, nil, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,-0.5}, nil, DIR.general_sprite_flags),
	}
}
alloying.next_upgrade = "electric-alloy-furnace"
alloying.fluid_boxes = {
    {
        production_type = "input",
        pipe_picture = DIR.get_furnace_pipe_pictures({0.8,0.8,0.25}, 0, 2),
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 0.5,
        base_level = -1, 
        height = 2,
        pipe_connections = {
			{ type="input-output", position = {-2, 0} },
			{ type="input-output", position = {2, 0} },
		},
        secondary_draw_orders = { north = -1 },
    },
    {
        production_type = "output",
        pipe_picture = DIR.get_furnace_pipe_pictures({0.25,0.2,0.15}, 0, 2),
        pipe_covers = DIR.pipe_covers.iron,
        base_area = 1,
        base_level = 1, 
        pipe_connections = {{ type="output", position = {0, -2} }},
        secondary_draw_orders = { north = -1 },
    },
    off_when_no_fluid_recipe = true,
}

data:extend({alloying})

------------------------------------------------------------------------------------------------------------------------------------------------------
