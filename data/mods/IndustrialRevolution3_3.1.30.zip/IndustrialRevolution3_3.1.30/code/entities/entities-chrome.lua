------------------------------------------------------------------------------------------------------------------------------------------------------

-- chrome template

local speed = 1
local animspeed = DIR.anim_speed/speed

local chrome = {
    crafting_speed = DIR.get_standard_speed(speed),
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
    },
    allowed_effects = {},
    module_specification = nil,
    max_health = standard_health("chrome",3),
	dying_explosion = "medium-explosion",
    resistances = standard_resistances("chrome"),
    corpse = "medium-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
    working_sound = {
        sound = {
            filename = DIR.base_sound_path.."/furnace.ogg",
            volume = 1.0
        },
		fade_in_ticks = 10,
		fade_out_ticks = 30,
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-large.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    tile_width = 3,
    tile_height = 3,
	entity_info_icon_shift = standard_entity_info_icon_shift(),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	status_colors = standard_status_colours(),
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- cubic press

local energy = DIR.get_scaled_energy_usage(12, DIR.standard_drain/2)

local chrome_press = table.deepcopy(chrome)
chrome_press.name = "chrome-press"
chrome_press.type = "assembling-machine"
chrome_press.icon = DIR.get_icon_path("chrome-press")
chrome_press.crafting_categories = {"pressing"}
chrome_press.gui_title_key = "gui-title.pressing"
chrome_press.energy_usage = energy.active
chrome_press.energy_source = {
    type = "electric",
    usage_priority = "secondary-input",
    drain = energy.passive,
}

chrome_press.drawing_box = { {-1.5,-2}, {1.5,1.5} }
chrome_press.animation = {
    layers = {
        DIR.get_layer("machines/misc/chrome-press-shadow", nil, nil, true, nil, animspeed, 320, 192, 0, 0, 320, 192, {1,0}),
        DIR.get_layer("machines/misc/chrome-press-base", nil, nil, false, nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}),
    }
}
chrome_press.working_visualisations = {
    {
        animation = DIR.get_layer("machines/misc/chrome-press-working", 30, 6, "glow", nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, "additive"),
        light = standard_status_light(),
		apply_tint = "status",
		always_draw = true,
    },
}
chrome_press.status_colors = standard_status_colours()
chrome_press.placeable_by = {item = "chrome-press", count = 1}
chrome_press.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "chrome-press"
}
chrome_press.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "hum")
chrome_press.allowed_effects = {
	"consumption",
	"speed",
}
chrome_press.module_specification = {
        module_info_icon_shift = standard_entity_info_module_shift(),
        module_slots = 2
}

data:extend({chrome_press})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- transmat

local map_colour = {1,0.6,0.1}
local transmat = table.deepcopy(chrome)
transmat.name = "chrome-transmat"
transmat.type = "electric-energy-interface"
transmat.localised_description = {
	"entity-description.chrome-transmat",
	{"", string.format("%d", DIR.transmat_cost/1000000), " ", {"si-prefix-symbol-mega"}, {"si-unit-symbol-joule"}},
	{"", string.format("%d", DIR.transmat_charge_rate/1000000), " ", {"si-prefix-symbol-mega"}, {"si-unit-symbol-watt"}},
}
transmat.icon = DIR.get_icon_path("chrome-transmat")
transmat.energy_source = {
	buffer_capacity = DIR.transmat_buffer_joules.."J",
	input_flow_limit = DIR.transmat_charge_rate.."W",
	drain = "25kW",
	type = "electric",
	usage_priority = "secondary-input"
}
transmat.energy_production = nil
transmat.energy_usage = nil
transmat.placeable_by = {item = "chrome-transmat", count = 1}
transmat.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "chrome-transmat"
}
transmat.max_health = standard_health("chrome",4)
transmat.collision_box = {{-1.9,-1.9},{1.9,1.9}}
transmat.selection_box = {{-2,-2},{2,2}}
transmat.collision_mask = { "object-layer", "water-tile", "item-layer"}
transmat.tile_width = 4
transmat.tile_height = 4
transmat.map_color = map_colour
transmat.enemy_map_color = map_colour
transmat.friendly_map_color = map_colour
transmat.corpse = "medium-remnants"

transmat.picture = {
	layers = {
		DIR.get_layer("machines/misc/chrome-transmat-base-shadow", 1, 1, true, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}),
		DIR.get_layer("machines/misc/chrome-transmat-base", 1, 1, false, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}, nil, DIR.recommended_sprite_flags),
	},
}
transmat.render_layer = "transport-belt"

transmat.working_sound = {
	sound = {
		filename = DIR.sound_path.."/energiser.ogg",
		volume = 0.8
	},
	idle_sound = {
		filename = DIR.sound_path.."/energiser.ogg",
		volume = 0.4
	},
	fade_in_ticks = 30,
	fade_out_ticks = 60,
	max_sounds_per_type = 3,
}

table.insert(transmat.flags,"not-rotatable")

data:extend({transmat})

-- animations and misc hackery for transmat

for i = 1,6 do
	data:extend({
		{
			type = "sprite",
			name = "transmat-glow-"..i,
			blend_mode = "additive",
			filename = DIR.entities_path_3.."/machines/misc/chrome-transmat-glow.png",
			width = 256,
			height = 256,
			x = 256 * (i-1),
			priority = "extra-high",
		},
	})
end

DIR.tp_total = 120
DIR.tp_stages = 10

for i=1,DIR.tp_stages do
	local sequence = {}
	for i=1,math.ceil(30/DIR.tp_stages)*(i-1) do table.insert(sequence, 1) end
	for i=1,60 do table.insert(sequence, i) end
	data:extend({
		{
			name = "IR-transmat-particle-"..i,
			type = "optimized-particle",
			life_time = table_size(sequence),
			movement_modifier = 1,
			movement_modifier_when_on_ground = 1,
			vertical_acceleration = 0,
			pictures = {
				sheet = {
					filename = DIR.entities_path_3.."/machines/misc/transmat-particle.png",
					frame_count = 60,
					line_length = 60,
					height = 128,
					variation_count = 1,
					width = 7,
					scale = 0.5,
					blend_mode = "additive",
					animation_speed = 1,
					frame_sequence = sequence,
				}
			},
			render_layer = "higher-object-under",
			render_layer_when_on_ground = "lower-object-above-shadow",
		}
	})
end

local function get_tp_target_effect(i,sparks)
	local tpoffsets = {}
	for i=1,math.ceil(DIR.tp_total/DIR.tp_stages) do
		local r = DIR.get_pretend_random_float(math.pi*2)
		local d = DIR.get_pretend_random_float(1.25)
		table.insert(tpoffsets, {math.cos(r)*d, math.sin(r)*0.707*d})
	end
	return {
		type = "create-particle",
		particle_name = "IR-transmat-particle-"..i,
		initial_height = (sparks == "appear") and 2.25 or 1.25,
		initial_height_deviation = 0.125,
		initial_vertical_speed = (sparks == "appear") and -0.02 or 0.02,
		initial_vertical_speed_deviation = 0.005,
		offsets = tpoffsets,
		repeat_count = 1,
		probability = 1,
		speed_from_center = 0,
		speed_from_center_deviation = 0,
		frame_speed = 1,
		frame_speed_deviation = 0.1,
	}
end

for _,sparks in pairs({"appear","disappear"}) do
	local target_effects = {}
	for i=1,DIR.tp_stages do
		table.insert(target_effects, get_tp_target_effect(i,sparks))
	end
	data:extend({
		{
			name = "transmat-sparks-"..sparks,
			type = "explosion",
			flags = {
				"not-on-map",
				"placeable-off-grid"
			},
			icon = DIR.get_icon_path("chrome-transmat"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			render_layer = "higher-object-under",
			rotate = false,
			animations = {
				{
					animation_speed = 1,
					filename = DIR.entities_path_3.. "/machines/misc/transmat-glow.png",
					blend_mode = "additive",
					frame_count = 30,
					height = 192,
					line_length = 6,
					priority = "extra-high",
					width = 192,
					shift = {0,-0.25},
					scale = 0.5,
				},
			},
            created_effect = {
                type = "direct",
                action_delivery = {
                    type = "instant",
                    target_effects = target_effects,
                }
            },
			sound = {
				filename = DIR.sound_path.."/transmat-beam.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				volume = 0.5,
			},
		}
	})
end

local sequence = {[1]={},[2]={},[3]={}}
for l = 1,3 do
	for i=1,15*(l-1) do table.insert(sequence[l],1) end
	for i=1,30 do table.insert(sequence[l],i) end
	for j=1,10-((l-1)*3) do
		for i=31,40 do table.insert(sequence[l],i) end
	end
	for i=41,70 do table.insert(sequence[l],i) end
	for i=1,15*(l-1) do table.insert(sequence[l],1) end
end

local rings_offset = -1.625
local rings_spacing = -0.75

for _,rings in pairs({"front","back"}) do
	local layers = {
		{
			animation_speed = 1,
			filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-"..rings..".png",
			draw_as_shadow = false,
			frame_count = 70,
			line_length = 10,
			priority = "high",
			width = 256,
			height = 448,
			shift = {0, rings_offset+((rings=="back") and 1 or 0)},
			scale = 0.5,
			frame_sequence = sequence[1],
		},
		{
			animation_speed = 1,
			filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-"..rings..".png",
			draw_as_shadow = false,
			frame_count = 70,
			line_length = 10,
			priority = "high",
			width = 256,
			height = 448,
			shift = {0, rings_offset+rings_spacing+((rings=="back") and 1 or 0)},
			scale = 0.5,
			frame_sequence = sequence[2],
			run_mode = "backward",
		},
		{
			animation_speed = 1,
			filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-"..rings..".png",
			draw_as_shadow = false,
			frame_count = 70,
			line_length = 10,
			priority = "high",
			width = 256,
			height = 448,
			shift = {0, rings_offset+(rings_spacing*2)+((rings=="back") and 1 or 0)},
			scale = 0.5,
			frame_sequence = sequence[3],
		},
	}
	if rings == "front" then
		layers = DIR.append_list({
			{
				animation_speed = 1,
				filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-shadow.png",
				draw_as_shadow = true,
				frame_count = 70,
				height = 192,
				line_length = 7,
				priority = "high",
				width = 576,
				shift = {(rings_offset*-2),0},
				scale = 0.5,
				frame_sequence = sequence[1],
			},
			{
				animation_speed = 1,
				filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-shadow.png",
				draw_as_shadow = true,
				frame_count = 70,
				height = 192,
				line_length = 7,
				priority = "high",
				width = 576,
				shift = {(rings_offset*-2)+(rings_spacing*-1),0},
				scale = 0.5,
				frame_sequence = sequence[2],
			},
			{
				animation_speed = 1,
				filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-rings-shadow.png",
				draw_as_shadow = true,
				frame_count = 70,
				height = 192,
				line_length = 7,
				priority = "high",
				width = 576,
				shift = {(rings_offset*-2)+(rings_spacing*-2),0},
				scale = 0.5,
				frame_sequence = sequence[3],
			}
		}, layers)
	end
	data:extend({
		{
			name = "transmat-rings-"..rings,
			type = "explosion",
			flags = {
				"not-on-map",
				"placeable-off-grid"
			},
			icon = DIR.get_icon_path("chrome-transmat"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			render_layer = (rings == "back") and "object" or "higher-object-under",
			height = 0,
			rotate = false,
			animations = {
				layers = layers,
			},
		}
	})
end

data:extend({
	{
		name = "transmat-base",
		type = "explosion",
		flags = {
			"not-on-map",
			"placeable-off-grid"
		},
		icon = DIR.get_icon_path("chrome-transmat"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		render_layer = "transport-belt-endings",
		height = 0,
		rotate = false,
		animations = {
			{
				animation_speed = 1,
				filename = DIR.entities_path_3.. "/machines/misc/chrome-transmat-base.png",
				draw_as_shadow = false,
				frame_count = 70,
				height = 256,
				line_length = 10,
				priority = "high",
				width = 256,
				shift = {0,0},
				scale = 0.5,
				frame_sequence = sequence[1],
				flags = DIR.recommended_sprite_flags,
			},
		},
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------
