------------------------------------------------------------------------------------------------------------------------------------------------------

-- TARGET MASKS

------------------------------------------------------------------------------------------------------------------------------------------------------

local default_target_masks = data.raw["utility-constants"].default.default_trigger_target_mask_by_type

------------------------------------------------------------------------------------------------------------------------------------------------------

-- stop arc turrets fruitlessly blasting entities that don't move anyway
-- regrettably the best use-case, active defense equipment, doesn't support ignore_target_mask, hey ho
-- see https://forums.factorio.com/viewtopic.php?f=28&t=90486

data:extend({{
	type = "trigger-target-type",
	name = "ir-non-moving"
}})

local entity_types_to_ignore = {"turret","unit-spawner","ammo-turret","electric-turret"}

for _,entity_type in pairs(entity_types_to_ignore) do
	for _,entity in pairs(data.raw[entity_type]) do
		entity.trigger_target_mask = entity.trigger_target_mask or table.deepcopy(default_target_masks[entity_type]) or {"common"}
		table.insert(entity.trigger_target_mask, "ir-non-moving")
		DIR.spam_log("Entity "..entity.name.." given non-moving target mask")
	end
end


------------------------------------------------------------------------------------------------------------------------------------------------------

-- low priority targets (e.g. used by rocket turret to ignore low health units)

data:extend({{
	type = "trigger-target-type",
	name = "ir-low-priority"
}})

for _,entity in pairs(data.raw.unit) do
	if DIR.is_a_low_priority_unit(entity) then
		entity.trigger_target_mask = entity.trigger_target_mask or table.deepcopy(default_target_masks["unit"])	or {"common"}
		table.insert(entity.trigger_target_mask, "ir-low-priority")
		DIR.spam_log("Unit "..entity.name.." given low priority target mask")
		-- log(serpent.line(entity.trigger_target_mask))
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

