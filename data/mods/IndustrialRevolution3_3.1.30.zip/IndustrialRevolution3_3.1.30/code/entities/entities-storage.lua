------------------------------------------------------------------------------------------------------------------------------------------------------

-- STORAGE CONTAINERS and similar

------------------------------------------------------------------------------------------------------------------------------------------------------

-- capacities

local storage_tiers = {
	small = 10,
	medium = 20,
	large = 30,
	very_large = 40,
	wagon = 80,
}

data.raw.container["wooden-chest"].inventory_size = storage_tiers.small
data.raw.container["iron-chest"].inventory_size = storage_tiers.large
data.raw.container["steel-chest"].inventory_size = storage_tiers.very_large
data.raw["logistic-container"]["logistic-chest-active-provider"].inventory_size = storage_tiers.very_large
data.raw["logistic-container"]["logistic-chest-buffer"].inventory_size = storage_tiers.very_large
data.raw["logistic-container"]["logistic-chest-passive-provider"].inventory_size = storage_tiers.very_large
data.raw["logistic-container"]["logistic-chest-requester"].inventory_size = storage_tiers.very_large
data.raw["logistic-container"]["logistic-chest-storage"].inventory_size = storage_tiers.very_large
data.raw["cargo-wagon"]["cargo-wagon"].inventory_size = storage_tiers.wagon

-- default upgrades for vanilla small chests

data.raw.container["wooden-chest"].next_upgrade = "bronze-chest"
data.raw.container["iron-chest"].next_upgrade = "steel-chest"

-- health/resistances for vanilla small chests

data.raw.container["wooden-chest"].max_health = standard_health("wood",2)
data.raw.container["iron-chest"].max_health = standard_health("iron",2)
data.raw.container["steel-chest"].max_health = standard_health("steel",2)
data.raw["logistic-container"]["logistic-chest-active-provider"].max_health = standard_health("steel",2)
data.raw["logistic-container"]["logistic-chest-buffer"].max_health = standard_health("steel",2)
data.raw["logistic-container"]["logistic-chest-passive-provider"].max_health = standard_health("steel",2)
data.raw["logistic-container"]["logistic-chest-requester"].max_health = standard_health("steel",2)
data.raw["logistic-container"]["logistic-chest-storage"].max_health = standard_health("steel",2)

data.raw.container["wooden-chest"].resistances = standard_resistances("wood")
data.raw.container["iron-chest"].resistances = standard_resistances("iron")
data.raw.container["steel-chest"].resistances = standard_resistances("steel")
data.raw["logistic-container"]["logistic-chest-active-provider"].resistances = standard_resistances("steel")
data.raw["logistic-container"]["logistic-chest-buffer"].resistances = standard_resistances("steel")
data.raw["logistic-container"]["logistic-chest-passive-provider"].resistances = standard_resistances("steel")
data.raw["logistic-container"]["logistic-chest-requester"].resistances = standard_resistances("steel")
data.raw["logistic-container"]["logistic-chest-storage"].resistances = standard_resistances("steel")

-- misc

local chest_vertical_offset = 0.25
local pallet_vertical_offset = 0.125

------------------------------------------------------------------------------------------------------------------------------------------------------

-- vanilla chest reskin & inventory type change

local chests = {"iron-chest","steel-chest","wooden-chest","infinity-chest"}

for _,chest in pairs(chests) do
	local ctype = (chest == "infinity-chest") and "infinity-container" or "container"
	if data.raw[ctype][chest] then
		local shadow = (chest == "wooden-chest") and 
			DIR.get_layer("machines/storage/wooden-chest-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.375,-0.25+chest_vertical_offset})
			or
			DIR.get_layer("machines/storage/chest-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.5,-0.25+chest_vertical_offset})
		data.raw[ctype][chest].picture = {
			layers = {
				shadow,		
				DIR.get_layer("machines/storage/"..chest, nil, nil, false, nil, nil, 64, 96, 0, 0, 64, 96, {0,-0.25+chest_vertical_offset}),
			}
		}
		data.raw.item[chest].icons = nil
		data.raw.item[chest].icon = DIR.get_icon_path(chest)
		data.raw.item[chest].icon_size = DIR.icon_size
		data.raw.item[chest].icon_mipmaps = DIR.icon_mipmaps
		data.raw[ctype][chest].icons = nil
		data.raw[ctype][chest].icon = DIR.get_icon_path(chest)
		data.raw[ctype][chest].icon_size = DIR.icon_size
		data.raw[ctype][chest].icon_mipmaps = DIR.icon_mipmaps
		if ctype == "container" then
			data.raw[ctype][chest].inventory_type = "with_filters_and_bar"
		end
	else
		DIR.spam_log("No such container as "..chest, DIR.log_level.warning)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bronze chest

local bronze_chest = {
	name = "bronze-chest",
	type = "container",
	inventory_type = "with_filters_and_bar",
	circuit_connector_sprites = data.raw.container["iron-chest"].circuit_connector_sprites,
	circuit_wire_connection_point = data.raw.container["iron-chest"].circuit_wire_connection_point,
	circuit_wire_max_distance = 9,
	collision_box = standard_small_chest_collision(),
	selection_box = {{-0.5,-0.5}, {0.5,0.5}},
	corpse = "small-remnants",
	fast_replaceable_group = "container",
	flags = {"placeable-neutral","player-creation"},
	icon = DIR.get_icon_path("bronze-chest"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	inventory_size = storage_tiers.medium,
	max_health = standard_health("bronze",2),
	resistances = standard_resistances("bronze"),
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "bronze-chest"
	},
	next_upgrade = "iron-chest",
	open_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-open.ogg",
        volume = 0.5
	},
	close_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-close.ogg",
        volume = 0.5
	},
	picture = {
		layers = {
			DIR.get_layer("machines/storage/bronze-chest", nil, nil, false, nil, nil, 64, 96, 0, 0, 64, 96, {0,-0.25+chest_vertical_offset}),
			DIR.get_layer("machines/storage/chest-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.5,-0.25+chest_vertical_offset}),		
		}
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
}
data:extend({bronze_chest})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- tin chest

local tin_chest = {
	name = "tin-chest",
	type = "container",
	inventory_type = "with_filters_and_bar",
	circuit_connector_sprites = data.raw.container["iron-chest"].circuit_connector_sprites,
	circuit_wire_connection_point = data.raw.container["iron-chest"].circuit_wire_connection_point,
	circuit_wire_max_distance = 9,
	collision_box = standard_small_chest_collision(),
	selection_box = {{-0.5,-0.5}, {0.5,0.5}},
	corpse = "small-remnants",
	fast_replaceable_group = "container",
	flags = {"placeable-neutral","player-creation"},
	icon = DIR.get_icon_path("tin-chest"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	inventory_size = storage_tiers.small,
	max_health = standard_health("tin",2),
	resistances = standard_resistances("tin"),
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "tin-chest"
	},
	next_upgrade = "bronze-chest",
	open_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-open.ogg",
        volume = 0.5
	},
	close_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-close.ogg",
        volume = 0.5
	},
	picture = {
		layers = {
			DIR.get_layer("machines/storage/tin-chest", nil, nil, false, nil, nil, 64, 96, 0, 0, 64, 96, {0,-0.25+chest_vertical_offset}),
			DIR.get_layer("machines/storage/chest-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.5,-0.25+chest_vertical_offset}),		
		}
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
}
data:extend({tin_chest})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- starter chests (not placeable)

local sizes = {
	["small"] = 3,
	["medium"] = 10,
}

for size,slots in pairs(sizes) do
	for i=1,4 do
		local starter = {
			name = "starter-crate-"..size.."-"..i,
			type = "container",
			localised_name = {"entity-name.starter-crate"},
			collision_box = standard_small_chest_collision(),
			selection_box = {{-0.5,-0.5}, {0.5,0.5}},
			collision_mask = {
				"item-layer",
				"object-layer",
				"water-tile",
				"player-layer",
				"resource-layer",
			},
			flags = {"placeable-neutral","placeable-off-grid","player-creation"},
			icon = DIR.get_icon_path("starter-crate"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			inventory_size = slots,
			max_health = standard_health("steel",1),
			minable = {
				mining_time = DIR.standard_pickup_time,
			},
			open_sound = {
				filename = DIR.base_sound_path.."/metallic-chest-open.ogg",
				volume = 0.5
			},
			close_sound = {
				filename = DIR.base_sound_path.."/metallic-chest-close.ogg",
				volume = 0.5
			},
			picture = {
				layers = {
					DIR.get_layer("machines/storage/starter-crate-base", nil, nil, false, nil, 1, 80, 80, 80*(i-1), 0, 80, 80, {-1.25*(i-1),0}),
					DIR.get_layer("machines/storage/starter-crate-shadow", nil, nil, true, nil, 1, 160, 80, 160*(i-1), 0, 160, 80, {0.625+(-2.5*(i-1)),0}),		
				}
			},
			vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
			map_color = {r=1,g=1,b=0},
		}
		data:extend({starter})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bottomless pit

local pit = {
	name = "bottomless-pit",
	type = "infinity-container",
	selection_box = {{-0.5,-0.5}, {0.5,0.5}},
	collision_box = {{-0.25,-0.25}, {0.25,0.25}},
	corpse = "small-remnants",
	flags = {"placeable-neutral","player-creation"},
	icon = DIR.get_icon_path("bottomless-pit"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	inventory_size = 10,
	max_health = standard_health("copper",5),
	minable = {
		mining_time = DIR.standard_pickup_time * 20,
		results = DIR.machines["bottomless-pit"].ingredients,
	},
	open_sound = {
		filename = DIR.base_sound_path.."/machine-open.ogg",
        volume = 0.5
	},
	close_sound = {
		filename = DIR.base_sound_path.."/machine-close.ogg",
        volume = 0.5
	},
	picture = {
		layers = {
			DIR.get_layer("machines/storage/bottomless-pit-base", nil, nil, false, nil, 1, 64, 64, 0, 0, 64, 64, {0,0}),
			DIR.get_layer("machines/storage/bottomless-pit-shadow", nil, nil, true, nil, 1, 96, 64, 0, 0, 96, 64, {0.25,0}),		
		}
	},
	vehicle_impact_sound = DIR.vanilla_sounds.stone_impact,
	enable_inventory_bar = true,
	erase_contents_when_mined = true,
	inventory_type = "with_filters_and_bar",
	gui_mode = "none",
}
data:extend({pit})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- pallets

for _,material in pairs({"wood","tin"}) do
	local sound = (material == "wood") and "wooden" or "metallic"
	local pallet = {
		name = material.."-pallet",
		type = "container",
		inventory_type = "with_filters_and_bar",
		collision_box = standard_small_chest_collision(),
		collision_mask = {
			"item-layer",
			"object-layer",
			"water-tile",
		},
		selection_box = {{-0.5,-0.5}, {0.5,0.5}},
		scale_info_icons = true,
		corpse = "small-remnants",
		fast_replaceable_group = "container",
		flags = {"placeable-neutral","player-creation"},
		icon = DIR.get_icon_path( material.."-pallet"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		inventory_size = (material == "wood") and 1 or 3,
		max_health = standard_health(material,1),
		resistances = standard_resistances(material),
		minable = {
			mining_time = DIR.standard_pickup_time,
			result = material.."-pallet"
		},
		open_sound = {
			filename = DIR.base_sound_path.."/"..sound.."-chest-open.ogg",
			volume = 0.5
		},
		close_sound = {
			filename = DIR.base_sound_path.."/"..sound.."-chest-close.ogg",
			volume = 0.5
		},
		picture = DIR.get_layer("machines/misc/blank", nil, nil, false, nil, nil, 1, 1, 0, 0, 1, 1, {0,0}),
		integration_patch = {
			layers = {
				DIR.get_layer("machines/storage/pallet-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.5,-0.25+pallet_vertical_offset}),		
				DIR.get_layer("machines/storage/"..material.."-pallet", nil, nil, false, nil, nil, 64, 96, 0, 0, 64, 96, {0,-0.25+pallet_vertical_offset}),
			}
		},
		integration_patch_render_layer = "floor-mechanics-under-corpse",
		vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	}
	data:extend({pallet})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- transfer plates

local plates = {
	["transfer-plate"] = 3,
	["transfer-plate-2x2"] = 2,
}

local variant = settings.startup["ir-transfer-plate-style"].value

for name,size in pairs(plates) do

	local sizename = size.."x"..size
	local selection = size/2
	local collision = selection - 0.1
	
	local picture = {
		filename = DIR.entities_path_3.."/machines/storage/transfer-plate-"..sizename.."-"..variant..".png",
		priority = "high",
		shift = {0,0},
		height = size * 64,
		width = size * 64,
		scale = 0.5,
	}
	
	local plate = {
		type = "land-mine",
		name = name,
		localised_description = {"entity-description.transfer-plate"}, -- same for both versions
		icon = DIR.get_icon_path("transfer-plate-"..sizename),
		icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps,
		flags = {"placeable-player", "player-creation"},
		minable = {mining_time = 0.5, result = name},
		mined_sound = DIR.vanilla_sounds.deconstruct_small(1.0),
		max_health = standard_health("copper",2),
		corpse = "small-remnants",
		collision_box = {{-collision,-collision}, {collision,collision}},
		selection_box = {{-selection,-selection}, {selection,selection}},
		picture_safe = picture,
		picture_set = picture,
		picture_set_enemy = picture,
		trigger_radius = (size == 3) and 1.4 or 0.9,
		ammo_category = nil,
		trigger_force = "same",
		force_die_on_attack = false,
		timeout = 30,
		trigger_collision_mask = {"object-layer","player-layer"}, -- updated in data-final-fixes to include heavy picket's custom layer
		action = {
			action_delivery = {
				target_effects = {
					{
						type = "script",
						effect_id = "ir-transfer-plate"
					},
				},
				type = "instant"
			},
			type = "direct"
		},
		radius_visualisation_specification = {
			sprite = {
			  filename = "__core__/graphics/white-square.png",
			  width = 10,
			  height = 10,
			  priority = "extra-high-no-scale",
			  tint = {r=0.125,g=0.4,b=0.5,a=0.5},
			},
			distance = DIR.delivery_plate_radius - ((size == 2) and 0.5 or 0),
		},
		is_military_target = false,
	}

	data:extend({plate})

end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steel storage depot

-- local circuits = circuit_connector_definitions.create (
	-- universal_connector_template,
	-- {
		-- { variation = 26, main_offset = util.by_pixel(9.5,32.5), shadow_offset = util.by_pixel(9.5,32.5), show_shadow = true }
	-- }
-- )

-- local storage_depot = {
	-- name = "steel-storage-depot",
	-- type = "container",
	-- circuit_connector_sprites = circuits.sprites,
	-- circuit_wire_connection_point = circuits.points,
	-- circuit_wire_max_distance = 9,
	-- collision_box = standard_3x3_collision(),
	-- selection_box = standard_3x3_selection(),
	-- corpse = "big-remnants",
	-- fast_replaceable_group = "storage-depot",
	-- flags = {"placeable-neutral","player-creation"},
	-- icon = DIR.get_icon_path("steel-storage-depot"),
	-- icon_size = DIR.icon_size,
	-- inventory_size = 800,
	-- max_health = standard_health("steel",3),
	-- minable = {
		-- mining_time = 0.5,
		-- result = "steel-storage-depot"
	-- },
	-- open_sound = {
		-- filename = "__base__/sound/metallic-chest-open.ogg",
        -- volume = 0.65
	-- },
	-- close_sound = {
		-- filename = "__base__/sound/metallic-chest-close.ogg",
        -- volume = 0.65
	-- },
	-- picture = {
		-- layers = {
			-- DIR.get_layer("machines/storage/steel-storage-depot-base", nil, nil, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,0}),
			-- DIR.get_layer("machines/storage/steel-storage-depot-shadow", nil, nil, true, nil, 1, 320, 192, 0, 0, 320, 192, {1.0,0.25}),		
		-- }
	-- },
	-- vehicle_impact_sound = {
		-- filename = "__base__/sound/car-metal-impact.ogg",
		-- volume = 1
	-- }
-- }
-- data:extend({table.deepcopy(storage_depot)})

-- logistics versions

-- local logistic_depot = table.deepcopy(storage_depot)
-- logistic_depot.type = "logistic-container"
-- logistic_depot.opened_duration = math.ceil(8 / DIR.anim_speed)
-- logistic_depot.icons = { { icon = DIR.get_icon_path("steel-logistics-depot"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps } }
-- logistic_depot.icon = nil
-- logistic_depot.animation = {
	-- layers = {
		-- DIR.get_layer("machines/storage/steel-storage-depot-shadow", nil, nil, true, 8, DIR.anim_speed, 320, 192, 0, 0, 320, 192, {1.0,0.25}),		
		-- DIR.get_layer("machines/storage/steel-logistics-depot-base", nil, nil, false, 8, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0}),
		-- DIR.get_layer("machines/storage/steel-logistics-depot-door", 8, 1, false, nil, DIR.anim_speed, 128, 96, 0, 0, 128, 96, {0,-0.75}),
	-- }
-- }
-- logistic_depot.picture = nil

-- local modes = {
	-- active = DIR.icon_masks["steel-logistics-depot-active"].tint,
	-- passive = DIR.icon_masks["steel-logistics-depot-passive"].tint,
	-- storage = DIR.icon_masks["steel-logistics-depot-storage"].tint,
	-- requester = DIR.icon_masks["steel-logistics-depot-requester"].tint,
	-- buffer = DIR.icon_masks["steel-logistics-depot-buffer"].tint,
-- }

-- local slots = {
	-- storage = 1,
	-- requester = 24,
	-- buffer = 24,
-- }

-- for mode,tint in pairs(modes) do
	-- local instance = table.deepcopy(logistic_depot)
	-- instance.name = "steel-logistics-depot-"..mode
	-- instance.minable.result = "steel-logistics-depot-"..mode
	-- instance.logistic_mode = mode..((mode == "active" or mode == "passive") and "-provider" or "")
	-- instance.max_logistic_slots = slots[mode]
	-- table.insert(instance.animation.layers, DIR.get_layer("machines/storage/steel-logistics-depot-mask", nil, nil, false, 8, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,0}, nil, nil, tint))
	-- table.insert(instance.icons, { icon = DIR.get_icon_path("steel-logistics-depot-mask"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, tint = tint } )
	-- data:extend({table.deepcopy(instance)})
-- end


------------------------------------------------------------------------------------------------------------------------------------------------------
