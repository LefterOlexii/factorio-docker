------------------------------------------------------------------------------------------------------------------------------------------------------

-- FLUID MACHINES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- small tanks

local circuits = circuit_connector_definitions.create (
    universal_connector_template,
    {
        { variation = 27, main_offset = util.by_pixel_hr(21, -38), shadow_offset = util.by_pixel_hr(26, -28), show_shadow = true },
        { variation = 27, main_offset = util.by_pixel_hr(21, -38), shadow_offset = util.by_pixel_hr(26, -28), show_shadow = true },
        { variation = 27, main_offset = util.by_pixel_hr(21, -38), shadow_offset = util.by_pixel_hr(26, -28), show_shadow = true },
        { variation = 27, main_offset = util.by_pixel_hr(21, -38), shadow_offset = util.by_pixel_hr(26, -28), show_shadow = true },
    }
)

local small_tanks = {
	["small-tank"] = "iron",
	["small-tank-steam"] = "steam",
}

local y = 0
for name,material in pairs(small_tanks) do
	local sheets = {
		DIR.get_layer("machines/fluids/small-tank-shadow", nil, nil, true, nil, 1, 224, 128, 0, y*128, 224, 128, {0.75,0-(y*2)}),
		DIR.get_layer("machines/fluids/small-tank-base", nil, nil, false, nil, 1, 128, 160, 0, y*160, 128, 160, {0,-0.25-(y*2.5)}),
	}
	sheets[1].frames = 2
	sheets[2].frames = 2
	y = y + 1

	local filter = (material == "steam") and "steam" or nil
	local description = {
		"entity-description.small-tank",
		filter and {"", "[img=fluid/"..filter.."] ", {"fluid-name."..filter}} or {"entity-description.pipes-all"}
    }

	local resistances = (material == "steam") and standard_resistances("copper") or standard_resistances("iron")

	data:extend({
		{
			name = name,
			type = "storage-tank",
			localised_description = description,
			minable = {
				mining_time = DIR.standard_pickup_time,
				result = name
			},
			circuit_connector_sprites = circuits.sprites,
			circuit_wire_connection_points = circuits.points,
			circuit_wire_max_distance = 9,
			collision_box = {{-0.45,-0.45},{0.45,0.45}},
			selection_box = {{-0.5,-0.5},{0.5,0.5}},
			drawing_box = {{-0.5,-1.5},{0.5,0.5}},
			window_bounding_box = {{-0.2,-0.65},{0.2,-0.2}},
			corpse = "small-remnants",
			fast_replaceable_group = "small-tank",
			flags = {
				"placeable-player",
				"player-creation"
			},
			flow_length_in_ticks = 360,
			fluid_box = {
				base_area = 25,
				pipe_connections = {
					{ position = {0,-1} },
					{ position = {0,1} },
				},
				pipe_covers = DIR.pipe_covers.iron,
				secondary_draw_orders = { north = -1 },
				filter = filter,
			},
			icon = DIR.get_icon_path(name),
			icon_mipmaps = DIR.icon_mipmaps,
			icon_size = DIR.icon_size,
			max_health = standard_health((material == "steam") and "copper" or material,1),
			pictures = {
				picture = {
					sheets = sheets,
				},
				window_background = data.raw["storage-tank"]["storage-tank"].pictures.window_background,
				flow_sprite = data.raw["storage-tank"]["storage-tank"].pictures.flow_sprite,
				gas_flow = data.raw["storage-tank"]["storage-tank"].pictures.gas_flow,
				fluid_background = DIR.get_layer("machines/fluids/fluid-background-narrow", nil, nil, false, nil, nil, 16, 15, 0, 0, 16, 15, {0,0}, nil, nil, nil, nil, nil, nil, 1),
			},
			resistances = resistances,
			two_direction_only = true,
			vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
			scale_info_icons = false,
		}
	})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- gas vent

local vent = {
    name = "iron-gas-vent",
    type = "furnace",
    result_inventory_size = 0,
    source_inventory_size = 0,
    show_recipe_icon = false,
    -- show_recipe_icon_on_map = false,
    icon = DIR.get_icon_path("iron-gas-vent"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    crafting_categories = {"venting"},
    placeable_by = {item = "iron-gas-vent", count = 1},
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "iron-gas-vent"
    },
    fast_replaceable_group = "pipe",
    crafting_speed = DIR.get_standard_speed(1),
    energy_usage = DIR.get_scaled_energy_usage(0.2,0).active,
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        emissions_per_minute = DIR.chemical_pollution_rate,
		drain = "0W",
    },
    max_health = standard_health("iron",2),
    dying_explosion = "explosion",
    resistances = standard_resistances("iron"),
    corpse = "small-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation", "not-upgradable"},
    selection_box = { {-0.5,-0.5}, {0.5,0.5} },
    collision_box = { {-0.49,-0.49}, {0.49,0.49} },
    tile_width = 1,
    tile_height = 1,
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/air-vent.ogg",
            volume = 1,
        },
        fade_in_ticks = 10,
        fade_out_ticks = 30,
    },
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-medium.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    fluid_boxes = {
        {
            base_area = 1,
            base_level = -1,
            production_type = "input",
            pipe_covers = DIR.pipe_covers.iron,
            pipe_connections = {{ type="input", position = {0, -1} }},
            secondary_draw_orders = { north = -1 }
        },
        off_when_no_fluid_recipe = false
    },
    match_animation_speed_to_activity = false,
    animation = {
		north = {
			layers = {
				DIR.get_layer("machines/fluids/gas-vent-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 0, 0, 64, 192, {0,0}),
				DIR.get_layer("machines/fluids/gas-vent-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}),
				DIR.get_layer("machines/fluids/gas-vent-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 0, 160, 96, {0.75,0.25}),
			}
		},
		east = {
			layers = {
				DIR.get_layer("machines/fluids/gas-vent-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 64, 0, 64, 192, {-1,0}),
				DIR.get_layer("machines/fluids/gas-vent-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}),
				DIR.get_layer("machines/fluids/gas-vent-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 96, 160, 96, {0.75,0.25-1.5}),
			}
		},
		south = {
			layers = {
				DIR.get_layer("machines/fluids/gas-vent-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 128, 0, 64, 192, {-2,0}),
				DIR.get_layer("machines/fluids/gas-vent-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}),
				DIR.get_layer("machines/fluids/gas-vent-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 192, 160, 96, {0.75,0.25-3}),
			}
		},
		west = {
			layers = {
				DIR.get_layer("machines/fluids/gas-vent-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 192, 0, 64, 192, {-3,0}),
				DIR.get_layer("machines/fluids/gas-vent-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}),
				DIR.get_layer("machines/fluids/gas-vent-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 288, 160, 96, {0.75,0.25-4.5}),
			}
		},
    },
    status_colors = standard_status_colours(),
    working_visualisations = {
        {
			animation = DIR.get_layer("machines/fluids/gas-vent-status", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.5}, "additive"),
            apply_tint = "status",
            always_draw = true,
        },
        {
            animation = DIR.get_layer("machines/fluids/gas-vent-venting", 60, 10, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0,-120/64}),
            fadeout = true,
            apply_recipe_tint = "primary",
        },
    },
}

data:extend({vent})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- air compressor

local airc = table.deepcopy(vent)
airc.name = "air-compressor"
airc.type = "assembling-machine"
airc.crafting_categories = {"air-compression"}
airc.fixed_recipe = "air-compression"
airc.show_recipe_icon = false
airc.icon = DIR.get_icon_path(airc.name)
airc.placeable_by = {item = airc.name, count = 1}
airc.minable = {
	mining_time = DIR.standard_pickup_time,
	result = airc.name,
}
airc.fluid_boxes = {
	{
		base_area = 10,
		base_level = 1,
		production_type = "output",
		pipe_covers = DIR.pipe_covers.air,
		pipe_connections = {{ type="output", position = {0, -1} }},
		secondary_draw_orders = { north = -1 }
	},
	off_when_no_fluid_recipe = false
}
airc.energy_usage = DIR.get_scaled_energy_usage(0.5,0).active
airc.energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        emissions_per_minute = DIR.standard_cleaning_emissions,
		drain = "0W",
}
airc.allowed_effects = {}
airc.module_specification = nil

airc.animation = {
	north = {
		layers = {
			DIR.get_layer("machines/fluids/air-compressor-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 0, 0, 64, 192, {0,0}),
			DIR.get_layer("machines/fluids/air-compressor-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}, nil, nil, nil, nil, nil, "backward"),
			DIR.get_layer("machines/fluids/air-compressor-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 0, 160, 96, {0.75,0.25}),
		}
	},
	east = {
		layers = {
			DIR.get_layer("machines/fluids/air-compressor-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 64, 0, 64, 192, {-1,0}),
			DIR.get_layer("machines/fluids/air-compressor-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}, nil, nil, nil, nil, nil, "backward"),
			DIR.get_layer("machines/fluids/air-compressor-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 96, 160, 96, {0.75,0.25-1.5}),
		}
	},
	south = {
		layers = {
			DIR.get_layer("machines/fluids/air-compressor-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 128, 0, 64, 192, {-2,0}),
			DIR.get_layer("machines/fluids/air-compressor-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}, nil, nil, nil, nil, nil, "backward"),
			DIR.get_layer("machines/fluids/air-compressor-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 192, 160, 96, {0.75,0.25-3}),
		}
	},
	west = {
		layers = {
			DIR.get_layer("machines/fluids/air-compressor-base", nil, nil, false, 4, DIR.anim_speed, 64, 192, 192, 0, 64, 192, {-3,0}),
			DIR.get_layer("machines/fluids/air-compressor-working", 4, 1, false, nil, DIR.anim_speed, 64, 32, 0, 0, 64, 32, {0,-0.75}, nil, nil, nil, nil, nil, "backward"),
			DIR.get_layer("machines/fluids/air-compressor-shadow", nil, nil, true, 4, DIR.anim_speed, 160, 96, 0, 288, 160, 96, {0.75,0.25-4.5}),
		}
	},
}
airc.working_visualisations = {
	{
		animation = DIR.get_layer("machines/fluids/air-compressor-status", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,-0.5}, "additive"),
		apply_tint = "status",
		always_draw = true,
	},
}

data:extend({airc})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper offshore pump

local pump = table.deepcopy(data.raw["offshore-pump"]["offshore-pump"])

pump.name = "copper-pump"
pump.pumping_speed = 8
pump.icon = DIR.get_icon_path("copper-pump")
pump.icon_size = DIR.icon_size
pump.icon_mipmaps = DIR.icon_mipmaps
pump.minable.result = "copper-pump"

pump.graphics_set = {}
pump.graphics_set.animation = {
    north = {
        layers = {
            DIR.get_layer("machines/fluids/copper-pump-base-south-shadow", 30, 5, true, nil, 0.5, 192, 160, 0, 0, 192, 160, {0.5,-0.25}),
            DIR.get_layer("machines/fluids/copper-pump-base-south", 30, 5, false, nil, 0.5, 128, 160, 0, 0, 128, 160, {0,-0.25}),
        },
    },
    south = {
        layers = {
            DIR.get_layer("machines/fluids/copper-pump-base-north-shadow", 30, 5, true, nil, 0.5, 192, 192, 0, 0, 192, 192, {0.5,0.5}),
            DIR.get_layer("machines/fluids/copper-pump-base-north", 30, 5, false, nil, 0.5, 128, 192, 0, 0, 128, 192, {0,0.5}),
        },
    },
    east = {
        layers = {
            DIR.get_layer("machines/fluids/copper-pump-base-west-shadow", 30, 5, true, nil, 0.5, 192, 128, 0, 0, 192, 128, {1.0,0}),
            DIR.get_layer("machines/fluids/copper-pump-base-west", 30, 5, false, nil, 0.5, 128, 128, 0, 0, 128, 128, {0.5,0}),
        },
    },
    west = {
        layers = {
            DIR.get_layer("machines/fluids/copper-pump-base-east-shadow", 30, 5, true, nil, 0.5, 192, 128, 0, 0, 192, 128, {0,0}),
            DIR.get_layer("machines/fluids/copper-pump-base-east", 30, 5, false, nil, 0.5, 128, 128, 0, 0, 128, 128, {-0.5,0}),
        },
    },
}

pump.water_reflection = {
    orientation_to_variation = true,
    rotate = false,
    pictures = {
        {
            filename = DIR.entities_path_3.."/machines/fluids/copper-pump-reflection.png",
            height = 128,
            priority = "extra-high",
            scale = 1,
            shift = {0,-0.5},
            width = 128,
            x = 0,
        },
        {
            filename = DIR.entities_path_3.."/machines/fluids/copper-pump-reflection.png",
            height = 128,
            priority = "extra-high",
            scale = 1,
            shift = {1,0.25},
            width = 128,
            x = 128,
        },
        {
            filename = DIR.entities_path_3.."/machines/fluids/copper-pump-reflection.png",
            height = 128,
            priority = "extra-high",
            scale = 1,
            shift = {0,1},
            width = 128,
            x = 256,
        },
        {
            filename = DIR.entities_path_3.."/machines/fluids/copper-pump-reflection.png",
            height = 128,
            priority = "extra-high",
            scale = 1,
            shift = {-1,0.25},
            width = 128,
            x = 384,
        },
    },
}

pump.fluid_box.pipe_covers = DIR.pipe_covers.copper

data:extend({pump})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- air purifier

local apvshift = 0.25
local energy = DIR.get_scaled_energy_usage(0.5, 0)

local sequences = {{},{},{},{}}
for i = 1,60 do
	for j = 0,3 do
		local s = (i + j*15)
		s = (s > 60) and (s-60) or s
		table.insert(sequences[j+1], s)
	end
end

data:extend({{
    name = "air-purifier",
    type = "assembling-machine",
    placeable_by = {item = "air-purifier", count = 1},
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "air-purifier"
    },
    crafting_speed = DIR.get_standard_speed(1),
    source_inventory_size = 1,
    result_inventory_size = 0,
    -- show_recipe_icon = false,
    crafting_categories = {"air-purification"},
	fixed_recipe = "air-purification",
	entity_info_icon_shift = {0,0},
    icon = DIR.get_icon_path("air-purifier"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    energy_usage = energy.active,
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        drain = energy.passive,
        emissions_per_minute = DIR.standard_cleaning_emissions,
    },
    allowed_effects = {},
	module_specification = nil,
    max_health = standard_health("iron",3),
    dying_explosion = "medium-explosion",
    resistances = standard_resistances("iron"),
    corpse = "medium-small-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = {{-1.1,-1.0},{1.1,1.0}},
    tile_width = 3,
    tile_height = 3,
    selection_box = standard_3x3_selection(),
    drawing_box = { {-1.5,-1.5}, {1.5,1.5} },
    animation = {
        layers = {
            DIR.get_layer("machines/fluids/air-purifier-shadow", nil, nil, true, nil, nil, 256, 192, 0, 0, 256, 192, {0.5,0+apvshift}),
            DIR.get_layer("machines/fluids/air-purifier-base", nil, nil, false, nil, nil, 192, 224, 0, 0, 192, 224, {0,-0.25+apvshift}),
        }
    },
    status_colors = standard_status_colours(),
    working_visualisations = {
        {
            animation = DIR.get_layer("machines/fluids/air-purifier-glow", 30, 6, "glow", nil, DIR.anim_speed, 96, 96, 0, 0, 96, 96, {0,-0.25+apvshift}, "additive"),
            apply_tint = "status",
            always_draw = true,
        },
        {
            animation = DIR.get_layer("machines/fluids/air-purifier-working", 4, 1, false, nil, DIR.anim_speed, 192, 128, 0, 0, 192, 128, {0,-0.5+apvshift}),
            always_draw = true,
            render_layer = "object",
        },
        {
            animation = DIR.get_layer("machines/fluids/gas-vent-venting", 60, 10, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0.7025, -2.0625-0.25+apvshift}, nil, nil, nil, nil, nil, nil, 0.5, sequences[1]),
            fadeout = true,
            apply_recipe_tint = "primary",
        },
        {
            animation = DIR.get_layer("machines/fluids/gas-vent-venting", 60, 10, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {-0.7025, -2.0625-0.25+apvshift}, nil, nil, nil, nil, nil, nil, 0.5, sequences[3]),
            fadeout = true,
            apply_recipe_tint = "primary",
        },
        {
            animation = DIR.get_layer("machines/fluids/gas-vent-venting", 60, 10, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {0.7025, -1.125-0.25+apvshift}, nil, nil, nil, nil, nil, nil, 0.5, sequences[2]),
            fadeout = true,
            apply_recipe_tint = "primary",
        },
        {
            animation = DIR.get_layer("machines/fluids/gas-vent-venting", 60, 10, false, nil, DIR.anim_speed, 192, 192, 0, 0, 192, 192, {-0.7025, -1.125-0.25+apvshift}, nil, nil, nil, nil, nil, nil, 0.5, sequences[4]),
            fadeout = true,
            apply_recipe_tint = "primary",
        },
    },
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/air-vent.ogg",
            volume = 1
        },
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.core_sound_path.."/deconstruct-medium.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
}})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- aetheric lamp

local lamp = table.deepcopy(data.raw.furnace["iron-gas-vent"])

lamp.name = "copper-aetheric-lamp-end"
lamp.localised_name = {"entity-name.copper-aetheric-lamp"}
lamp.localised_description = {"entity-description.copper-aetheric-lamp"}
lamp.type = "assembling-machine"
lamp.icon = DIR.get_icon_path("copper-aetheric-lamp")
lamp.minable.result = "copper-aetheric-lamp-straight"
lamp.placeable_by = {item = "copper-aetheric-lamp-straight", count = 1}
lamp.animation = {
    north = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-n", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-n", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    east = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-e", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-e", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    south = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-s", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-s", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    west = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-w", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-w", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
}
lamp.working_visualisations = {
    {
		animation = DIR.get_layer("machines/fluids/aetheric-lamp-bulb-on", 30, 10, "glow", nil, 1, 96, 96, 0, 0, 96, 96, {0,-0.5}, "additive-soft"),
		apply_recipe_tint = "primary",
        fadeout = true,
    },
	{
		apply_recipe_tint = "secondary",
		light = {
			color = {1,1,1},
			intensity = 0.75,
			size = 30,
			shift = {0,-0.5},
		},
        fadeout = true,
	},
}
lamp.working_sound = nil
lamp.crafting_speed = DIR.get_standard_speed(1)
lamp.max_health = standard_health("copper",1)
lamp.energy_source = { 
	type = "fluid",
	fluid_box = {
		filter = "steam",
		base_area = 1,
		base_level = -1,
		height = 2,
		production_type = "input-output",
		pipe_connections = {
			{ type="input-output", position = {0,-1} },
		},
		pipe_covers = DIR.pipe_covers.steam,
		secondary_draw_orders = { north = -1 },
	},
	maximum_temperature = 165,
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	light_flicker = standard_zero_light_flicker(),
	render_no_power_icon = false,
}
lamp.energy_usage = "2.5kW"
lamp.crafting_categories = {"glowing"}
lamp.gui_title_key = "gui-title.glowing"
lamp.fluid_boxes = nil
table.insert(lamp.flags, "hide-alt-info")
table.insert(lamp.flags, "not-upgradable")

data:extend({lamp})

local lamp = table.deepcopy(lamp)

lamp.name = "copper-aetheric-lamp-straight"
lamp.minable.result = "copper-aetheric-lamp-straight"
lamp.placeable_by = {item = "copper-aetheric-lamp-straight", count = 1}
lamp.energy_source.fluid_box.pipe_connections = {
	{ type="input-output", position = {0,-1} },
	{ type="input-output", position = {0,1} },
}
lamp.animation = {
    north = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-ns", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-ns", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    east = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-ew", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-ew", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    south = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-ns", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-ns", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
    west = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-ew", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-shadow", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {1,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-ew", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-bulb-off", nil, nil, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,-0.5}),
        }
    },
}

data:extend({lamp})

local range = DIR.glow_recipe_count-1
for hue = 0, range do
	local tint = DIR.hsva2rgba(hue/range,DIR.get_saturation(hue/range,0.75),1)
	local less_tint = DIR.hsva2rgba(hue/range,DIR.get_saturation(hue/range,0.5),1)
	data:extend({{
		type = "recipe",
		name = "aetheric-glow-"..hue,
		localised_name = {"recipe-name.aetheric-glow"},
		order = string.format("%2d", hue == range and 0 or (hue == 0 and range or hue)),
		category = "glowing",
		icons = {
			{ icon = DIR.get_icon_path("aetheric-glow"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, tint = tint },
		},
		subgroup = "ir-glows",
		ingredients = {},
		results = {},
		hide_from_player_crafting = true,
		energy_required = 25000/60,
		allow_decomposition = false,
		hide_from_stats = true,
		enabled = true,
		crafting_machine_tint = { primary = tint, secondary = less_tint },
	}})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- flare stack

-- local speed = 1
-- local animspeed = DIR.anim_speed / speed
-- local energy = DIR.get_scaled_energy_usage(0.2, 0)
-- local stack = {
    -- name = "iron-flare-stack",
    -- type = "furnace",
    -- result_inventory_size = 0,
    -- source_inventory_size = 0,
    -- show_recipe_icon = false,
    -- icon = DIR.get_icon_path("iron-flare-stack"),
    -- icon_size = DIR.icon_size,
	-- icon_mipmaps = DIR.icon_mipmaps,
    -- crafting_categories = {"flaring"},
    -- placeable_by = {item = "iron-flare-stack", count = 1},
    -- minable = {
        -- mining_time = DIR.standard_pickup_time,
        -- result = "iron-flare-stack"
    -- },
    -- fast_replaceable_group = "pipe",
    -- crafting_speed = DIR.get_standard_speed(speed),
    -- energy_usage = energy.active,
    -- energy_source = {
        -- type = "electric",
        -- usage_priority = "secondary-input",
        -- drain = energy.passive,
        -- emissions_per_minute = DIR.chemical_pollution_rate,
    -- },
    -- max_health = standard_health("iron",2),
    -- dying_explosion = "explosion",
    -- resistances = standard_resistances("iron"),
    -- corpse = "small-remnants",
    -- flags = {"placeable-player", "placeable-neutral", "player-creation"},
    -- selection_box = { {-0.5,-0.5}, {0.5,0.5} },
    -- collision_box = { {-0.49,-0.49}, {0.49,0.49} },
    -- tile_width = 1,
    -- tile_height = 1,
    -- working_sound = {
        -- sound = {
            -- filename = DIR.base_sound_path.."/furnace.ogg",
            -- volume = 1.0
        -- }
    -- },
    -- mined_sound = {
        -- filename = DIR.core_sound_path.."/deconstruct-medium.ogg"
    -- },
    -- vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    -- fluid_boxes = {
        -- {
			-- base_area = 10,
            -- base_level = -1,
            -- production_type = "input",
            -- pipe_covers = DIR.pipe_covers.iron,
            -- pipe_connections = {{ type="input", position = {0, -1} }},
            -- secondary_draw_orders = { north = -1 }
        -- },
        -- off_when_no_fluid_recipe = false
    -- },
    -- animation = {
		-- north = {
			-- layers = {
				-- DIR.get_layer("machines/fluids/iron-flare-stack-base", nil, nil, false, nil, nil, 64, 288, 0, 0, 64, 288, {0,-1.25}),
				-- DIR.get_layer("machines/fluids/iron-flare-stack-shadow", nil, nil, true, nil, nil, 384, 96, 0, 0, 384, 96, {2.5,0.25}),
			-- }
		-- },
		-- east = {
			-- layers = {
				-- DIR.get_layer("machines/fluids/iron-flare-stack-base", nil, nil, false, nil, nil, 64, 288, 64, 0, 64, 288, {-1,-1.25}),
				-- DIR.get_layer("machines/fluids/iron-flare-stack-shadow", nil, nil, true, nil, nil, 384, 96, 0, 96, 384, 96, {2.5,-1.25}),
			-- }
		-- },
		-- south = {
			-- layers = {
				-- DIR.get_layer("machines/fluids/iron-flare-stack-base", nil, nil, false, nil, nil, 64, 288, 128, 0, 64, 288, {-2,-1.25}),
				-- DIR.get_layer("machines/fluids/iron-flare-stack-shadow", nil, nil, true, nil, nil, 384, 96, 0, 192, 384, 96, {2.5,-2.75}),
			-- }
		-- },
		-- west = {
			-- layers = {
				-- DIR.get_layer("machines/fluids/iron-flare-stack-base", nil, nil, false, nil, nil, 64, 288, 192, 0, 64, 288, {-3,-1.25}),
				-- DIR.get_layer("machines/fluids/iron-flare-stack-shadow", nil, nil, true, nil, nil, 384, 96, 0, 288, 384, 96, {2.5,-4.25}),
			-- }
		-- },
    -- },
    -- working_visualisations = {
        -- {
			-- animation = DIR.get_layer("machines/fluids/iron-flare-stack-flame", 60, 10, "glow", nil, DIR.anim_speed, 128, 192, 0, 0, 128, 192, {0,-4}, "additive"),
			-- fadeout = true,
			-- constant_speed = true,
        -- },
		-- {
			-- animation = DIR.get_layer("machines/fluids/iron-flare-stack-light", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,-2.5}, "additive", nil, {1.0,0.9,0.7}),
			-- draw_as_light = true,
			-- fadeout = true,
		-- },
    -- },
-- }

-- data:extend({stack})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- cryo tower

local energy = DIR.get_scaled_energy_usage(4, DIR.standard_drain)

local tower = table.deepcopy(vent)
tower.name = "steel-cryo-tower"
tower.type = "assembling-machine"
tower.placeable_by = {item = "steel-cryo-tower", count = 1}
tower.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "steel-cryo-tower"
}
tower.show_recipe_icon = true
tower.source_inventory_size = 0
tower.result_inventory_size = 0
tower.energy_usage = energy.active
tower.energy_source = {
	type = "electric",
	usage_priority = "secondary-input",
	drain = energy.passive,
}
tower.icon = DIR.get_icon_path("steel-cryo-tower")
tower.crafting_categories = {"cryogenics","air-separation"}
tower.show_recipe_icon = true
tower.gui_title_key = "gui-title.cryogenics"
tower.crafting_speed = DIR.get_standard_speed(1)
tower.entity_info_icon_shift = {0,0}
tower.energy_source.emissions_per_minute = nil
tower.match_animation_speed_to_activity = false
tower.allowed_effects = {"consumption","speed"}
tower.module_specification = {
	module_info_icon_shift = standard_entity_info_module_shift(),
	module_slots = 1
}
tower.selection_box = standard_3x3_selection()
tower.collision_box = standard_3x3_collision()

tower.animation = {
	layers = {
		DIR.get_layer("machines/fluids/cryo-tower-base", nil, nil, false, nil, animspeed, 192, 256, 0, 0, 192, 256, {0,0}),
		DIR.get_layer("machines/fluids/cryo-tower-shadow", nil, nil, true, nil, animspeed, 320, 256, 0, 0, 320, 256, {1,0}),
	}
}
tower.status_colors = standard_status_colours()
tower.working_visualisations = {
	{
		animation = DIR.get_layer("machines/fluids/cryo-tower-tint-1", 30, 10, false, nil, 0.5, 128, 160, 0, 0, 128, 160, {0,-0.75}, "additive"),
		apply_recipe_tint = "primary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/cryo-tower-tint-2", 30, 10, false, nil, 0.75, 128, 160, 0, 0, 128, 160, {0,-0.75}, "additive"),
		apply_recipe_tint = "secondary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/cryo-tower-tint-3", 30, 10, false, nil, 1, 128, 160, 0, 0, 128, 160, {0,-0.75}, "additive"),
		apply_recipe_tint = "tertiary",
		fadeout = true,
	},
    {
        animation = DIR.get_layer("machines/fluids/cryo-tower-glow", 30, 6, "glow", nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,0}, "additive"),
		apply_tint = "status",
		always_draw = true,
    },
}

local pp = {
	north = {
		layers = {
			DIR.get_layer("machines/fluids/cryo-tower-pipe-n-shadow", 1, 1, true, nil, nil, 128, 128, 0, 0, 128, 128, {0.25,1}),
			DIR.get_layer("machines/fluids/cryo-tower-pipe-n", 1, 1, false, nil, nil, 96, 128, 0, 0, 96, 128, {0,1}),
		},
	},
	south = {
		layers = {
			DIR.get_layer("machines/fluids/cryo-tower-pipe-s-shadow", 1, 1, true, nil, nil, 128, 128, 0, 0, 128, 128, {0.25,-1}),
			DIR.get_layer("machines/fluids/cryo-tower-pipe-s", 1, 1, false, nil, nil, 96, 128, 0, 0, 96, 128, {0,-1}),
		},
	},
	east = {
		layers = {
			DIR.get_layer("machines/fluids/cryo-tower-pipe-e-shadow", 1, 1, true, nil, nil, 128, 128, 0, 0, 128, 128, {0.25-1,0}),
			DIR.get_layer("machines/fluids/cryo-tower-pipe-e", 1, 1, false, nil, nil, 96, 128, 0, 0, 96, 128, {-1,0}),
		},
	},
	west = {
		layers = {
			DIR.get_layer("machines/fluids/cryo-tower-pipe-w-shadow", 1, 1, true, nil, nil, 128, 128, 0, 0, 128, 128, {0.25+1,0}),
			DIR.get_layer("machines/fluids/cryo-tower-pipe-w", 1, 1, false, nil, nil, 96, 128, 0, 0, 96, 128, {1,0}),
		},
	},
}

tower.fluid_boxes = {
	-- order here is important - output indexes are reserved
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers.iron,
		pipe_picture = pp,
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {-2, 0} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	{
		production_type = "input",
		pipe_covers = DIR.pipe_covers.iron,
		pipe_picture = pp,
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {2, 0} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers.iron,
		pipe_picture = pp,
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {0, -2} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers.iron,
		pipe_picture = pp,
		base_area = 10,
		base_level = 1,
		pipe_connections = {{ type="output", position = {0, 2} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	off_when_no_fluid_recipe = true
}

data:extend({tower})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- ambient heat exchanger / vaporiser

local vaporiser = table.deepcopy(vent)
vaporiser.name = "steel-vaporiser"
vaporiser.type = "furnace"
vaporiser.energy_usage = "1W"
vaporiser.energy_source = {
	type = "void",
	usage_priority = "secondary-input",
}
vaporiser.icon = DIR.get_icon_path("steel-vaporiser")
vaporiser.crafting_categories = {"heating","cooling"}
vaporiser.crafting_speed = DIR.get_standard_speed(1)
vaporiser.show_recipe_icon = true
vaporiser.placeable_by = {item = "steel-vaporiser", count = 1}
vaporiser.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "steel-vaporiser"
}

local ns = {
	layers = {
		DIR.get_layer("machines/fluids/steel-vaporiser-base", 1, 1, false, nil, 1, 64, 192, 0, 0, 64, 192, {0,0}),
		DIR.get_layer("machines/fluids/steel-vaporiser-shadow", 1, 1, true, nil, 1, 192, 128, 0, 0, 192, 128, {1,0}),
	}
}

local ew = {
	layers = {
		DIR.get_layer("machines/fluids/steel-vaporiser-base", 1, 1, false, nil, 1, 64, 192, 64, 0, 64, 192, {-1,0}),
		DIR.get_layer("machines/fluids/steel-vaporiser-shadow", 1, 1, true, nil, 1, 192, 128, 192, 0, 192, 128, {1-3,0}),
	}
}

vaporiser.animation = {
	north = ns,
	south = ns,
	east = ew,
	west = ew,
}

vaporiser.working_visualisations = nil

vaporiser.fluid_boxes = {
	{
		production_type = "output",
		pipe_covers = DIR.pipe_covers_tweaked.iron,
		pipe_picture = nil,
		base_area = 2,
		base_level = 1,
		pipe_connections = {{ type="output", position = {-1.25, 0} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	{
		production_type = "input",
		pipe_covers = DIR.pipe_covers_tweaked.iron,
		pipe_picture = nil,
		base_area = 2,
		base_level = -1,
		pipe_connections = {{ type="input", position = {1.25, 0} }},
		secondary_draw_orders = { north = -2, east = -2, west = -2 }
	},
	off_when_no_fluid_recipe = false
}

data:extend({vaporiser})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- geothermal exchanger

local energy = DIR.get_scaled_energy_usage(0.5, DIR.standard_drain)

local ns = {
    layers = {
        DIR.get_layer("machines/fluids/geothermal-exchanger-shadow-ns", 1, 1, true, nil, DIR.anim_speed, 320, 256, 0, 0, 320, 256, {1,0}),
        DIR.get_layer("machines/fluids/geothermal-exchanger-base-ns", 1, 1, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,0}),
    }
}
local ew = {
    layers = {
        DIR.get_layer("machines/fluids/geothermal-exchanger-shadow-ew", 1, 1, true, nil, DIR.anim_speed, 320, 256, 0, 0, 320, 256, {1,0}),
        DIR.get_layer("machines/fluids/geothermal-exchanger-base-ew", 1, 1, false, nil, DIR.anim_speed, 192, 256, 0, 0, 192, 256, {0,0}),
    }
}
local wns = {
    layers = {
        DIR.get_layer("machines/fluids/geothermal-exchanger-glow-ns", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, "additive"),
    }
}
local wew = {
    layers = {
        DIR.get_layer("machines/fluids/geothermal-exchanger-glow-ew", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {-0.5,-0.5}, "additive"),
    }
}

local x = {
	name = "iron-geothermal-exchanger",
	type = "assembling-machine",
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "iron-geothermal-exchanger",
	},
	icon = DIR.get_icon_path("iron-geothermal-exchanger"),
	icon_mipmaps = DIR.icon_mipmaps,
	icon_size = DIR.icon_size,
	crafting_categories = {"geothermal-exchange"},
	-- fixed_recipe = "geothermal-exchange",
	crafting_speed = DIR.get_standard_speed(1),
	energy_usage = energy.active,
	energy_source = {
		type = "electric",
		usage_priority = "secondary-input",
		drain = energy.passive
	},
	allowed_effects = {
		"consumption",
		"speed",
	},
	module_specification = {
			module_info_icon_shift = standard_entity_info_module_shift(),
			module_slots = 1
	},
	max_health = standard_health("iron",3),
	dying_explosion = "medium-explosion",
	resistances = standard_resistances("iron"),
	corpse = "medium-remnants",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	collision_box = standard_3x3_collision(),
	selection_box = standard_3x3_selection(),
	working_sound = table.deepcopy(data.raw["assembling-machine"]["chemical-plant"].working_sound),
	open_sound = standard_machine_open(),
	close_sound = standard_machine_close(),
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-large.ogg"
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	tile_width = 3,
	tile_height = 3,
	entity_info_icon_shift = {0,-0.25},
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	status_colors = standard_status_colours(),
	animation = {
		north = ns,
		south = ns,
		east = ew,
		west = we,
	},
	working_visualisations = {
		{
			north_animation = wns,
			south_animation = wns,
			east_animation = wew,
			west_animation = wwe,
            apply_tint = "status",
            always_draw = true,
		},
	},
	fluid_boxes = {
		{
			production_type = "output",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = 1, 
			pipe_connections = {{ type="output", position = {1, 2} }},
			secondary_draw_orders = { north = -1 }
		},
		{
			production_type = "output",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = 1, 
			pipe_connections = {{ type="output", position = {1, -2} }},
			secondary_draw_orders = { north = -1 },
		},
		{
			production_type = "input",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = -1, 
			pipe_connections = {{ type="input", position = {-1, 2} }},
			secondary_draw_orders = { north = -1 },
		},
		{
			production_type = "input",
			pipe_covers = DIR.pipe_covers.iron,
			base_area = 2,
			base_level = -1, 
			pipe_connections = {{ type="input", position = {-1, -2} }},
			secondary_draw_orders = { north = -1 },
		},
		off_when_no_fluid_recipe = false,
	}
}

data:extend({x})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- barrelling/unbarrelling - also steam interface

local iron_animation = {
	north = {
		layers = {
			DIR.get_layer("machines/fluids/barrelling-machine-base", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,0}),
			DIR.get_layer("machines/fluids/barrelling-machine-shadow", nil, nil, true, nil, nil, 160, 128, 0, 0, 160, 128, {0.25,0}),
		}
	},
	east = {
		layers = {
			DIR.get_layer("machines/fluids/barrelling-machine-base", nil, nil, false, nil, nil, 64, 128, 64, 0, 64, 128, {-1,0}),
			DIR.get_layer("machines/fluids/barrelling-machine-shadow", nil, nil, true, nil, nil, 160, 128, 0, 128, 160, 128, {0.25,-2}),
		}
	},
	south = {
		layers = {
			DIR.get_layer("machines/fluids/barrelling-machine-base", nil, nil, false, nil, nil, 64, 128, 128, 0, 64, 128, {-2,0}),
			DIR.get_layer("machines/fluids/barrelling-machine-shadow", nil, nil, true, nil, nil, 160, 128, 0, 256, 160, 128, {0.25,-4}),
		}
	},
	west = {
		layers = {
			DIR.get_layer("machines/fluids/barrelling-machine-base", nil, nil, false, nil, nil, 64, 128, 192, 0, 64, 128, {-3,0}),
			DIR.get_layer("machines/fluids/barrelling-machine-shadow", nil, nil, true, nil, nil, 160, 128, 0, 384, 160, 128, {0.25,-6}),
		}
	},
}

local copper_animation = {
    north = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-n", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-n", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/steam-outlet-base", nil, nil, false, nil, nil, 64, 64, 0, 0, 64, 64, {0,-0.25}),
        }
    },
    east = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-e", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-e", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/steam-outlet-base", nil, nil, false, nil, nil, 64, 64, 0, 0, 64, 64, {0,-0.25}),
        }
    },
    south = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-s", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-s", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/steam-outlet-base", nil, nil, false, nil, nil, 64, 64, 0, 0, 64, 64, {0,-0.25}),
        }
    },
    west = {
        layers = {
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-shadow-w", nil, nil, true, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/aetheric-lamp-steam-w", nil, nil, false, nil, nil, 180, 120, 0, 0, 180, 120, {0,0}),
            DIR.get_layer("machines/fluids/steam-outlet-base", nil, nil, false, nil, nil, 64, 64, 0, 0, 64, 64, {0,-0.25}),
        }
    },
}

local copper_working_animation = {
	-- barrel body
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-barrel-metal", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,0}),
		apply_recipe_tint = "primary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-barrel-shadow", nil, nil, true, nil, nil, 128, 128, 0, 0, 128, 128, {1,0}),
		apply_recipe_tint = "primary",
		fadeout = true,
	},
	-- canister body
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-canister-metal", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,0}),
		apply_recipe_tint = "secondary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-canister-shadow", nil, nil, true, nil, nil, 128, 128, 0, 0, 128, 128, {1,0}),
		apply_recipe_tint = "secondary",
		fadeout = true,
	},
	-- steam cell body
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-steam-cell", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,0}),
		apply_recipe_tint = "tertiary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-canister-shadow", nil, nil, true, nil, nil, 128, 128, 0, 0, 128, 128, {1,0}),
		apply_recipe_tint = "tertiary",
		fadeout = true,
	},
	-- iron canister body
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-iron-canister", nil, nil, false, nil, nil, 64, 128, 0, 0, 64, 128, {0,0}),
		apply_recipe_tint = "quaternary",
		fadeout = true,
	},
	{
		animation = DIR.get_layer("machines/fluids/barrelling-machine-canister-shadow", nil, nil, true, nil, nil, 128, 128, 0, 0, 128, 128, {1,0}),
		apply_recipe_tint = "quaternary",
		fadeout = true,
	},
}

local iron_working_animation = table.deepcopy(copper_working_animation)
table.insert(iron_working_animation, {
	animation = DIR.get_layer("machines/fluids/barrelling-machine-working", 30, 6, "glow", nil, DIR.anim_speed, 64, 64, 0, 0, 64, 64, {0,0}, "additive", nil, nil, nil, nil, direction),
	apply_tint = "status",
	always_draw = true,
})

for _,tier in pairs({"","steam-"}) do
-- for _,tier in pairs({""}) do
	for _,prefix in pairs({"barrelling","unbarrelling"}) do
		local direction = (prefix == "barrelling") and "forward" or "backward"
		local ptype = (prefix == "barrelling") and "input" or "output"
		local barreller = table.deepcopy(vent)
		barreller.name = tier .. prefix.."-machine"
		barreller.localised_name = {"entity-name."..tier.."barrelling-machine"}
		barreller.localised_description = {
			"",
			{"entity-description."..tier.."barrelling-machine"},
			"\n[font=default-semibold][color=255,230,192]",
			{"recipe-description.barrelling-mode"},
			"[/color][/font] ",
			{"recipe-description."..prefix}
		}
		barreller.type = "furnace"
		barreller.crafting_categories = (tier == "") and {prefix,"steam-"..prefix} or {"steam-"..prefix}
		barreller.fixed_recipe = nil
		barreller.source_inventory_size = 1
		barreller.result_inventory_size = 1
		barreller.show_recipe_icon = true
		barreller.fast_replaceable_group = tier.."barrelling-machine"
		barreller.icon = DIR.get_icon_path(tier.."barrelling-machine")
		barreller.placeable_by = {item = tier.."barrelling-machine", count = 1} -- both placed by same item, toggled with entity hotkey
		barreller.minable = {
			mining_time = DIR.standard_pickup_time,
			result = tier.."barrelling-machine",
		}
		barreller.fluid_boxes = {
			{
				base_area = 5,
				base_level = (ptype == "input") and -1 or 1,
				production_type = ptype,
				pipe_covers = (tier == "steam-") and DIR.pipe_covers.steam or DIR.pipe_covers.iron,
				pipe_connections = {{ type = ptype, position = {0, -1} }},
				secondary_draw_orders = { north = -1 }
			},
			off_when_no_fluid_recipe = false
		}
		barreller.crafting_speed = DIR.get_standard_speed((tier == "") and 1 or 0.5)
		barreller.energy_usage = DIR.get_scaled_energy_usage(0.5,0).active
		barreller.energy_source = {
			type = (tier == "") and "electric" or "void",
			usage_priority = "secondary-input",
			emissions_per_minute = 0,
			drain = "0W",
		}
		barreller.allowed_effects = (tier == "") and {"consumption","speed"} or {}
		barreller.module_specification = (tier == "") and {
			module_info_icon_shift = {0,0.125},
			module_slots = 1
		} or nil
		barreller.match_animation_speed_to_activity = false
		barreller.animation = (tier == "") and iron_animation or copper_animation
		barreller.working_visualisations = (tier == "") and iron_working_animation or copper_working_animation
		barreller.default_recipe_tint = { primary = {0,0,0,0}, secondary = {0,0,0,0}, tertiary = {0,0,0,0}, quaternary = {0,0,0,0}}
		barreller.working_sound = {
			sound = {
				filename = DIR.base_sound_path.."/pump.ogg",
				volume = 0.5,
			},
			audible_distance_modifier = 0.5,
			max_sounds_per_type = 2
		}
		table.insert(barreller.flags, "not-upgradable")
		data:extend({barreller})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
