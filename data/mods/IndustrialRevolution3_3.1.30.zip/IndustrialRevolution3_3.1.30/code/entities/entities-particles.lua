------------------------------------------------------------------------------------------------------------------------------------------------------

-- shrapnel particles

-- variations per particle material
local particles = {
    copper = 7,
    iron = 7,
    steel = 7,
    bronze = 6,
    gold = 6,
    stone = 3,
    glass = 3,
    wood = 3,
    rubber = 3,
}

for particle,variations in pairs(particles) do
    data:extend({
        DIR.create_IR_particle(particle.."-particle",variations),
        DIR.create_IR_particle_trail(particle.."-particle",variations),
    })
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- mining particles -- moved to terrain-ores

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bot doom particles

local bots = {
	steambot = "construction-robot",
	scatterbot = "combat-robot",
	lampbot = "combat-robot",
}

for bot,bot_type in pairs(bots) do
	local bot_prototype = data.raw[bot_type][bot]
	if not bot_prototype then error("Can't find bot prototype "..bot) end
	local idle = table.deepcopy(bot_prototype.idle.layers and bot_prototype.idle.layers[1] or bot_prototype.idle)
	idle.variation_count = 1
	idle.animation_speed = bot == "lampbot" and 1 or 0.5
	idle.frame_count = idle.direction_count
	local shadow = table.deepcopy(bot_prototype.shadow_idle)
	shadow.variation_count = 1
	shadow.animation_speed = bot == "lampbot" and 1 or 0.5
	shadow.frame_count = shadow.direction_count
	data:extend({
		{
			name = bot.."-death-particle",
			type = "optimized-particle",
			life_time = 900,
			movement_modifier_when_on_ground = 0,
			pictures = {
				sheet = idle,
			},
			shadows = {
				sheet = shadow,
			},
			render_layer = "air-object",
			render_layer_when_on_ground = "corpse",
			ended_in_water_trigger_effect = {
				entity_name = "water-splash",
				type = "create-entity"
			},
			ended_on_ground_trigger_effect = {
				{
					entity_name = bot.."-remnants",
					type = "create-entity"
				},
				{
					sound = {
						{
							filename = "__base__/sound/fight/robot-die-impact-01.ogg",
							volume = 1
						},
						{
							filename = "__base__/sound/fight/robot-die-impact-02.ogg",
							volume = 1
						},
						{
							filename = "__base__/sound/fight/robot-die-impact-03.ogg",
							volume = 1
						}
					},
					type = "play-sound"
				}
			},
		}
	})
end

-- explosion particles + smoke

local colour_y = DIR.laser_colours[settings.startup["ir-laser-colour"].value].index
data:extend({
    {
        name = "IR-spark-particle",
        type = "optimized-particle",
        life_time = 64,
        movement_modifier_when_on_ground = 0,
        pictures = {
            sheet = {
                filename = DIR.particles_path.."/spark-particle.png",
                frame_count = 64,
                line_length = 64,
                height = 16,
                variation_count = 3,
                width = 16,
                scale = 0.25,
                blend_mode = "additive",
				draw_as_glow = true,
            }
        },
        render_layer = "air-object",
        render_layer_when_on_ground = "lower-object-above-shadow",
    },
    {
        name = "IR-emp-spark-particle-1-particle",
        type = "optimized-particle",
        life_time = 32,
        movement_modifier_when_on_ground = 0,
        pictures = {
            sheet = {
                filename = DIR.particles_path.."/spark-particle.png",
                frame_count = 64,
                line_length = 64,
                height = 16,
                variation_count = 1,
                width = 16,
                y = 6 * 16,
                scale = 0.25,
                blend_mode = "additive",
				draw_as_glow = true,
				animation_speed = 2,
            }
        },
        render_layer = "air-object",
        render_layer_when_on_ground = "lower-object-above-shadow",
    },
    {
        name = "IR-emp-spark-particle-2-particle",
        type = "optimized-particle",
        life_time = 32,
        movement_modifier_when_on_ground = 0,
        pictures = {
            sheet = {
                filename = DIR.particles_path.."/spark-particle.png",
                frame_count = 64,
                line_length = 64,
                height = 16,
                variation_count = 1,
                width = 16,
                y = 7 * 16,
                scale = 0.25,
                blend_mode = "additive",
				draw_as_glow = true,
				animation_speed = 2,
            }
        },
        render_layer = "air-object",
        render_layer_when_on_ground = "lower-object-above-shadow",
    },
    {
        name = "IR-particle-smoke",
        type = "trivial-smoke",
        affected_by_wind = false,
        animation = {
            animation_speed = 0.5,
            filename = "__base__/graphics/entity/smoke-fast/smoke-fast.png",
            frame_count = 16,
            height = 50,
            width = 50,
            priority = "high",
            scale = 0.25,
            tint = {
                a = 0.5,
                b = 0.5,
                g = 0.5,
                r = 0.5,
            },
        },
        duration = 150,
        end_scale = 0.05,
        fade_away_duration = 60,
        movement_slow_down_factor = 0.95,
        render_layer = "smoke",
        show_when_smoke_off = true,
        start_scale = 0.25,
    },
})

-- pollution clouds

for size=1,10 do
	data:extend({{
		name = "pollution-cloud-"..size,
		type = "smoke-with-trigger",
		flags = {"not-on-map"},
		show_when_smoke_off = true,
		particle_count = size * 3,
		particle_spread = {size * 0.333, size * 0.333 * 0.707},
		particle_distance_scale_factor = 0.5,
		particle_scale_factor = {1, 0.707},
		particle_duration_variation = 30,
		wave_speed = {0.5 / 80, 0.5 / 60},
		wave_distance = {1, 0.5},
		render_layer = "smoke",
		affected_by_wind = true,
		cyclic = true,
		duration = 60 * (size+1),
		fade_in_duration = 30,
		fade_away_duration = 20 * size,
		spread_duration = 60,
		spread_duration_variation = 30,
		color = {r = 0.2, g = 0.1, b = 0, a = 0.333},
		animation = {
			width = 152,
			height = 120,
			line_length = 5,
			frame_count = 60,
			shift = {-0.5,0.5},
			priority = "high",
			animation_speed = 0.25,
			filename = "__base__/graphics/entity/smoke/smoke.png",
			flags = {"smoke"}
		},
	}})
end

------------------------------------------------------------------------------------------------------------------------------------------------------
