------------------------------------------------------------------------------------------------------------------------------------------------------

-- increase light renderer search distance a la Larger Lamps

local limit = 25
if data.raw["utility-constants"]["default"]["light_renderer_search_distance_limit"] < limit then
	data.raw["utility-constants"]["default"]["light_renderer_search_distance_limit"] = limit
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- IR logos for main menu

local long_logo_shift = {0,-0.125}

local decorative = {
	name = "decorative-logo",
	type = "simple-entity-with-owner",
	render_layer = "transport-belt",
	icon = DIR.get_icon_path("decorative-logo"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	corpse = "small-remnants",
	minable = {
		mining_time = 0.2,
		result = nil,
	},
	placeable_by = { item = "splitter-blocker", count = 1}, -- needed for manifesto simulations
	collision_box = { {-5.95,-1.45}, {5.95,1.45} },
	selection_box = { {-6,-1.5}, {6,1.5} },
	tile_width = 12,
	tile_height = 3,
	max_health = standard_health("bronze",3),
	flags = {"placeable-player", "placeable-neutral", "player-creation", "not-rotatable", "hidden", "not-upgradable", "not-deconstructable"},
	collision_mask = {
		"object-layer",
		"water-tile",
	},
	random_variation_on_create = false,
	pictures = {
		{
			filename = DIR.entities_path_3.."/decorative/ir3-logo-long.png",
			priority = "high",
			shift = long_logo_shift,
			height = 192,
			width = 768,
			scale = 0.5,
		},
		-- {
			-- filename = DIR.entities_path_3.."/decorative/ir3-logo-long-iron.png",
			-- priority = "high",
			-- shift = {0,-0.125},
			-- height = 192,
			-- width = 768,
			-- scale = 0.5,
		-- },
		-- {
			-- filename = DIR.entities_path_3.."/decorative/ir3-logo-long-steel.png",
			-- priority = "high",
			-- shift = {0,-0.125},
			-- height = 192,
			-- width = 768,
			-- scale = 0.5,
		-- },
	},
}

local deadlock = table.deepcopy(decorative)
deadlock.name = "decorative-logo-deadlock989"
deadlock.icon = DIR.get_icon_path("deadlock989")
deadlock.tile_width = 2
deadlock.tile_height = 2
deadlock.collision_box = { {-0.8,-0.8}, {0.8,0.8} }
deadlock.selection_box = { {-1,-1}, {1,1} }
deadlock.pictures = nil
deadlock.picture = {
	filename = DIR.entities_path_3.."/decorative/deadlock989.png",
	priority = "high",
	shift = {0,0},
	height = 128,
	width = 128,
	scale = 0.5,
}

local transmat = table.deepcopy(decorative)
transmat.name = "fake-transmat"
transmat.icon = DIR.get_icon_path("chrome-transmat")
transmat.tile_width = 4
transmat.tile_height = 4
transmat.collision_box = { {-0.5,-0.5}, {0.5,0.5} }
transmat.selection_box = { {-2,-2}, {2,2} }
transmat.pictures = nil
transmat.picture = {
	layers = {
		DIR.get_layer("machines/misc/chrome-transmat-base-shadow", nil, nil, true, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}),
		DIR.get_layer("machines/misc/chrome-transmat-base", nil, nil, false, nil, nil, 256, 256, 0, 0, 256, 256, {0,0}),
	},
}
transmat.minable = nil
transmat.placeable_by = nil
transmat.selectable_in_game = false
transmat.flags = {"not-on-map","placeable-off-grid"}
transmat.corpse = "medium-remnants"
transmat.dying_explosion = "chrome-transmat-explosion" 

local sequence = {}
for i=1,220 do table.insert(sequence,1) end
for i=2,16 do table.insert(sequence,i) end
for i=15,2,-1 do table.insert(sequence,i) end

data:extend({
    decorative,
	deadlock,
	transmat,
	{
		type = "animation",
		name = "transmat-glow-status",
		filename =  DIR.entities_path_3.."/machines/misc/transmat-glow-white.png",
		priority = "extra-high-no-scale",
		width = 256,
		height = 256,
		line_length = 2,
		frame_count = 2,
		animation_speed = 1,
		scale = 0.5,
		blend_mode = "additive-soft",
		draw_as_glow = true,
	},
})

table.insert(data.raw["simple-entity-with-owner"]["decorative-logo"].flags, "placeable-off-grid")
table.insert(data.raw["simple-entity-with-owner"]["decorative-logo-deadlock989"].flags, "placeable-off-grid")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- waterfill

local explosion = table.deepcopy(data.raw.explosion["medium-explosion"])
explosion.name = "waterfill-explosion"
explosion.flags = {"not-on-map","placeable-off-grid"}

data:extend({
	explosion,
	{
		name = "waterfill-explosive",
		type = "simple-entity-with-owner",
		render_layer = "transport-belt",
		icon = DIR.get_icon_path("waterfill-explosive"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		corpse = nil,
		minable = {
			mining_time = 0.2,
			result = "waterfill-explosive",
		},
		max_health = standard_health("iron",1),
		flags = {"placeable-player", "placeable-neutral", "player-creation", "not-rotatable"},
		collision_box = { {-0.3,-0.3}, {0.3,0.3} },
		selection_box = { {-0.5,-0.5}, {0.5,0.5} },
		tile_width = 1,
		tile_height = 1,
		collision_mask = {
			"object-layer",
			"water-tile",
		},
		picture = {
			filename = DIR.entities_path_3.."/decorative/waterfill-explosive-base.png",
			priority = "high",
			shift = {0,0},
			height = 64,
			width = 64,
			scale = 0.5,
		},
		integration_patch = {
			filename = DIR.entities_path_3.."/decorative/waterfill-explosive-shadow.png",
			priority = "high",
			shift = {0.25,0},
			height = 64,
			width = 96,
			scale = 0.5,
			draw_as_shadow = true,
		},
		random_variation_on_create = false,
		render_layer = "object",
	},
	{
		type = "animation",
		name = "waterfill-explosive-glow",
		filename =  DIR.entities_path_3.."/decorative/waterfill-explosive-glow.png",
		priority = "extra-high-no-scale",
		width = 64,
		height = 64,
		line_length = 2,
		frame_count = 2,
		animation_speed = 0.25,
		scale = 0.5,
		draw_as_glow = true,
		blend_mode = "additive",
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- tree beds

for _,planter in pairs(DIR.plantable_trees) do
	local tree_planter = table.deepcopy(deadlock)
	tree_planter.name = "tree-planter-"..planter
	tree_planter.localised_name = {"entity-name." .. ((planter == "ir-rubber-tree") and "tree-planter-rubber-wood" or "tree-planter-wood")}
	tree_planter.localised_description = {"entity-description." .. ((planter == "ir-rubber-tree") and "tree-planter-rubber-wood" or "tree-planter-wood")}
	tree_planter.icon = DIR.get_icon_path((planter == "ir-rubber-tree") and "tree-08-bed" or planter.."-bed")
	tree_planter.render_layer = "floor-mechanics"
	tree_planter.flags = {"placeable-player", "placeable-neutral", "player-creation", "not-rotatable"}
	tree_planter.picture = nil
	tree_planter.pictures = {
		sheet = {
			layers = {
				{
					filename = DIR.entities_path_3.."/decorative/tree-planter-base.png",
					priority = "high",
					shift = {0,0},
					height = 192,
					width = 192,
					scale = 0.5,
					line_length = 4,
					variation_count = 8,
				},
				{
					filename = DIR.entities_path_3.."/decorative/tree-planter-shadow.png",
					priority = "high",
					shift = {0,0},
					height = 192,
					width = 192,
					scale = 0.5,
					line_length = 4,
					variation_count = 8,
					draw_as_shadow = true,
				},
			}
		}
	}
	tree_planter.random_variation_on_create = true
	tree_planter.integration_patch = nil
	tree_planter.max_health = standard_health("copper",3)
	local results = DIR.machines["tree-planter-"..planter] and table.deepcopy(DIR.machines["tree-planter-"..planter].ingredients)
	if results then
		for i,result in ipairs(results) do
			if result[1] ~= "stone-brick" then result[2] = math.min(result[2],4) end
			results[i] = result
		end
	end
	tree_planter.minable = {
		mining_time = 1,
		results = results,
	}
	-- has to be 3x3 because needs to be odd for the tree to be tile-centred, and 1x1 is too small
	tree_planter.collision_box = standard_3x3_collision()
	tree_planter.selection_box = standard_3x3_selection()
	tree_planter.tile_width = 3
	tree_planter.tile_height = 3
	tree_planter.map_color = {0.25,0.25,0.25}

	data:extend({
		tree_planter,
	})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fake labs for simulations

local labs = {"copper-lab","lab","quantum-lab"}

for _,original in pairs(labs) do
	local lab = table.deepcopy(data.raw.lab[original])
	lab.name = "decorative-"..lab.name
	lab.type = "assembling-machine"
	lab.crafting_categories = {"glowing"}
	lab.crafting_speed = DIR.get_standard_speed(2)
	lab.animation = table.deepcopy(lab.on_animation)
	lab.on_animation = nil
	lab.off_animation = nil
	lab.fixed_recipe = "aetheric-glow-1"
	lab.energy_usage = "1W"
	lab.fast_replaceable_group = nil
	lab.next_upgrade = nil
	lab.placeable_by = nil
	lab.minable.result = nil
	lab.module_specification = nil
	lab.show_recipe_icon = false
    lab.show_recipe_icon_on_map = false
	if lab.working_sound and lab.working_sound.sound then lab.working_sound.sound.volume = 0.05 end
	table.insert(lab.flags,"placeable-off-grid")
	if lab.energy_source and lab.energy_source.type == "electric" then lab.energy_source.type = "void" end
	data:extend({lab})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- omg hax

local decorative = {
	name = "static",
	type = "simple-entity-with-owner",
	render_layer = "object",
	icon = DIR.get_icon_path("placeholder"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	minable = {
		mining_time = 0.2,
		result = nil,
	},
	max_health = 9999,
	flags = {"placeable-player", "placeable-neutral", "player-creation", "not-rotatable"},
	collision_box = { {-1.9,-1.9}, {1.9,1.9} },
	selection_box = { {-2,-2}, {2,2} },
	tile_width = 4,
	tile_height = 4,
	collision_mask = {
		"object-layer",
		"water-tile",
	},
	animations = {
		filename = DIR.entities_path_3.."/decorative/static.png",
		priority = "high",
		shift = {0,0},
		height = 256,
		width = 256,
		scale = 0.5,
		frame_count = 8,
		line_length = 4,
		animation_speed = 0.5,
	},
	random_variation_on_create = false,
}

data:extend({decorative})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- twinkle animations

local lengths = {103,139,197,251}

for a=1,4 do

	local sequence = {}
	for i=1,lengths[a] do
		sequence[i] = (i <= 15) and i or 1
	end

	data:extend({
		{
			name = "twinkle-animation-"..a,
			type = "animation",
			animation_speed = 1,
			draw_as_glow = true,
			filename = DIR.entities_path_3.."/decorative/twinkle.png",
			frame_count = 15,
			height = 32,
			width = 32,
			line_length = 5,
			scale = 0.5,
			frame_sequence = sequence,
			blend_mode = "additive-soft",
			draw_as_glow = true,
		},
	})

end

data:extend({
	{
		name = "tree-twinkle",
		type = "explosion",
		animations = {{
			animation_speed = 0.5,
			filename = DIR.entities_path_3.."/decorative/twinkle.png",
			tint = {0.5,1,0.5},
			blend_mode = "additive",
			draw_as_glow = true,
			priority = "high",
			frame_count = 15,
			height = 32,
			width = 32,
			line_length = 5,
			scale = 0.5,
		}},
		flags = {
			"not-on-map",
			"placeable-off-grid"
		},
		render_layer = "air-object",
		rotate = false,
		height = 0
	}
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- letters

-- local letters = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ."
-- for letter in letters:gmatch(".") do 
	-- for _,material in pairs({"steel","bronze"}) do
		-- local l = (letter == ".") and "stop" or letter
		-- local decorative = {
			-- name = material.."-letter-"..l,
			-- localised_name = {"entity-name."..material.."-letter", letter},
			-- type = "simple-entity-with-owner",
			-- render_layer = "transport-belt",
			-- icon = DIR.entities_path_3.."/decorative/letters/"..material.."_"..l..".png",
			-- icon_size = DIR.icon_size,
			-- icon_mipmaps = nil,
			-- corpse = "small-remnants",
			-- minable = {
				-- mining_time = 0.2,
				-- result = nil,
			-- },
			-- collision_box = { {-0.5,-0.5}, {0.5,0.5} },
			-- selection_box = { {-0.5,-0.5}, {0.5,0.5} },
			-- tile_width = 1,
			-- tile_height = 1,
			-- max_health = 50,
			-- flags = {"placeable-player", "placeable-neutral", "player-creation", "not-rotatable", "hidden", "not-upgradable", "not-deconstructable", "placeable-off-grid"},
			-- collision_mask = {
				-- "object-layer",
				-- "water-tile",
			-- },
			-- random_variation_on_create = false,
			-- pictures = {
				-- {
					-- filename = DIR.entities_path_3.."/decorative/letters/"..material.."_"..l..".png",
					-- priority = "high",
					-- shift = nil,
					-- height = 64,
					-- width = 64,
					-- scale = 0.5,
				-- },
			-- },
		-- }
		-- data:extend({decorative})
	-- end
-- end

------------------------------------------------------------------------------------------------------------------------------------------------------
