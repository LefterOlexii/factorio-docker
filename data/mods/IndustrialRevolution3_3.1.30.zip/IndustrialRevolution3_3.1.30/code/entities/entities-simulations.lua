------------------------------------------------------------------------------------------------------------------------------------------------------

-- copies of polluting entities for Manifesto simulations which don't emit
-- would be nice if surfaces had their own advanced map settings but they don't

------------------------------------------------------------------------------------------------------------------------------------------------------

local ptypes = {"boiler","mining-drill","assembling-machine","furnace"}
local copy_list = {}
local used_entities = require("code.data.blueprint-entities")

for _,ptype in pairs(ptypes) do
	copy_list[ptype] = {}
	for _,pt in pairs(data.raw[ptype]) do
		if used_entities[pt.name] and pt.energy_source and pt.energy_source.emissions_per_minute and pt.minable and pt.minable.result then
			copy_list[ptype][pt.name] = true
		end
	end
end

for ptype,names in pairs(copy_list) do
	for p,_ in pairs(names) do
		local c = table.deepcopy(data.raw[ptype][p])
		c.name = c.name.."-simulation"
		c.localised_name = {"entity-name.hidden-entity"}
		c.localised_description = {"entity-description.hidden-entity"}
		c.icons = nil
		c.icon = DIR.get_icon_path("placeholder")
		c.icon_size = DIR.icon_size
		c.icon_mipmaps = DIR.icon_mipmaps
		c.flags = c.flags or {}
		table.insert(c.flags, "not-in-made-in")
		table.insert(c.flags, "hidden")
		table.insert(c.flags, "not-upgradable")
		table.insert(c.flags, "not-deconstructable")
		table.insert(c.flags, "not-in-kill-statistics")
		c.flags = DIR.remove_from_list("placeable-player", c.flags)
		c.energy_source.emissions_per_minute = nil
		c.placeable_by = {item = "splitter-blocker", count = 1}
		c.next_upgrade = nil
		c.fast_replaceable_group = nil
		c.minable.result = nil
		data:extend({c})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- special entities for debugging and the main menu simulation

------------------------------------------------------------------------------------------------------------------------------------------------------

-- cheat chest - bad for performance, only intended for testing purposes

local chest_vertical_offset = 0.25

local container = {
	name = "ir3-linked-filter-chest",
	type = "linked-container",
	collision_box = standard_small_chest_collision(),
	selection_box = {{-0.5,-0.5}, {0.5,0.5}},
	circuit_connector_sprites = data.raw.container["iron-chest"].circuit_connector_sprites,
	circuit_wire_connection_point = data.raw.container["iron-chest"].circuit_wire_connection_point,
	circuit_wire_max_distance = 9,
	fast_replaceable_group = "container",
	flags = {"placeable-neutral","player-creation","hidden"},
	icon = DIR.get_icon_path("special-chest"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	inventory_size = 800,
	inventory_type = "with_filters_and_bar",
	max_health = 9999,
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "ir3-linked-filter-chest"
	},
	open_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-open.ogg",
        volume = 0.5
	},
	close_sound = {
		filename = DIR.base_sound_path.."/metallic-chest-close.ogg",
        volume = 0.5
	},
	picture = {
		layers = {
			DIR.get_layer("machines/storage/special-chest", nil, nil, false, nil, nil, 64, 96, 0, 0, 64, 96, {0,-0.25+chest_vertical_offset}),
			DIR.get_layer("machines/storage/chest-shadow", nil, nil, true, nil, nil, 128, 96, 0, 0, 128, 96, {0.5,-0.25+chest_vertical_offset}),		
		}
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
}

data:extend({container})

-- massive undergrounds since we don't get linked fluidboxes before 1.2

local ugs = {"pipe-to-ground","air-pipe-to-ground","copper-pipe-to-ground","steam-pipe-to-ground"}
for _,ug in pairs(ugs) do
	local e = table.deepcopy(data.raw["pipe-to-ground"][ug])
	e.name = e.name .. "-massive"
	for _,pc in pairs(e.fluid_box.pipe_connections) do
		if pc.max_underground_distance then pc.max_underground_distance = 250 end
	end
	e.icon = data.raw.item[e.name].icon
	e.icons = data.raw.item[e.name].icons
	e.flags = DIR.merge_and_return_unique(e.flags,{"hidden","not-upgradable","not-deconstructable"})
	e.placeable_by = nil
	data:extend({e})
end

-- linked belts that fully look like / have the speed of undergrounds

local belts = {
	["ir3-linked-belt-yellow"] = "underground-belt",
	["ir3-linked-belt-red"] = "fast-underground-belt",
	["ir3-linked-belt-blue"] = "express-underground-belt",
}

for belt,ug in pairs(belts) do
	local e = table.deepcopy(data.raw["linked-belt"]["linked-belt"])
	e.name = belt
	e.structure = table.deepcopy(data.raw["underground-belt"][ug].structure)
	e.speed = data.raw["underground-belt"][ug].speed
	e.belt_animation_set = data.raw["underground-belt"][ug].belt_animation_set
	e.icon = data.raw.item[e.name].icon
	e.icons = data.raw.item[e.name].icons
	e.flags = DIR.merge_and_return_unique(e.flags,{"hidden"})
	data:extend({e})
end

------------------------------------------------------------------------------------------------------------------------------------------------------


------------------------------------------------------------------------------------------------------------------------------------------------------
