------------------------------------------------------------------------------------------------------------------------------------------------------

-- WALLS

------------------------------------------------------------------------------------------------------------------------------------------------------

local original = data.raw.wall["stone-wall"]

-- stone wall resistance buff (explosions)

original.resistances = standard_resistances("stone_impact")

-- "ancient wall"

stone = table.deepcopy(original)
stone.name = "ancient-wall"
stone.minable = {
	mining_time = DIR.standard_pickup_time,
	results = {
		{
			name = "stone",
			type = "item",
			amount_min = 1,
			amount_max = 2,
		},
	},
}
stone.icon = DIR.icon_path.."/64/stone-wall.png"
stone.icon_size = DIR.icon_size
stone.icon_mipmaps = DIR.icon_mipmaps
stone.icons = nil

local yv = {
	corner_left_down = 5,
	corner_right_down = 7,
	ending_left = 1,
	ending_right = 3,
	single = 0,
	straight_horizontal = 2,
	straight_vertical = 4,
	t_up = 6,
}

local function simple_layer(p)
	if not p.filename then error("No filename supplied to template") end
	p.filename = DIR.entities_path_2 .. "/" .. p.filename .. ".png"
	p.height = p.height or 1
	p.width = p.width or 1
	p.scale = p.scale or 0.5
	p.priority = "high"
	return p
end

local pictures = {}

for p,y in pairs(yv) do
	stone.pictures[p] = {
		layers = {
			simple_layer({
				filename = "walls/stone-wall-shadow",
				width = 128, height = 192,
				shift = {0.5,0.5},
				variation_count = 1, line_length = 1, repeat_count = 8,
				y = y * 192,
				draw_as_shadow = true,
			}),
			simple_layer({
				filename = "walls/stone-wall-base",
				width = 64, height = 128,
				variation_count = 8, line_length = 8,
				y = y * 128,
			}),
		}
	}
end

stone.pictures["water_connection_patch"] = {
	sheets = {
		simple_layer({
			filename = "walls/stone-wall-water-patch-shadow",
			width = 176, height = 160,
			shift = {0.5,0.5},
			draw_as_shadow = true,
		}),
		simple_layer({
			filename = "walls/stone-wall-water-patch",
			width = 112, height = 160,
		}),
	}
}
stone.pictures["gate_connection_patch"] = {
	sheets = {
		simple_layer({
			filename = "walls/stone-wall-gate-patch-shadow",
			width = 160, height = 144,
			shift = {0.75,0.375},
			draw_as_shadow = true,
		}),
		simple_layer({
			filename = "walls/stone-wall-gate-patch",
			width = 64, height = 144,
			shift = {0,-0.125}
		}),
	}
}
stone.pictures["filling"] = simple_layer({
			filename = "walls/stone-wall-filling",
			width = 64, height = 96,
			shift = {0,-0.25},
			variation_count = 8, line_length = 8,
})

for _,p in pairs({"wall_diode_red", "wall_diode_green"}) do
	if stone[p] and stone[p].sheet and stone[p].sheet.hr_version then
		stone[p].sheet.hr_version.shift = DIR.get_vector_sum(stone[p].sheet.hr_version.shift or {0,0}, {0,-4/64})
	end
	stone[p].sheet.shift = DIR.get_vector_sum(stone[p].sheet.shift or {0,0}, {0,-4/64})
end

data:extend({stone})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- stone wall cosmetic option

local properties = {
	"icon",
	"icon_size",
	"icon_mipmaps",
	"icons",
	"pictures",
	"wall_diode_green",
	"wall_diode_red",
}

if (settings.startup["ir-stone-wall-style"].value == "on") then
	for _,p in pairs(properties) do
		original[p] = stone[p]
	end
end

data.raw.item["stone-wall"].icon = original.icon
data.raw.item["stone-wall"].icon_size = original.icon_size
data.raw.item["stone-wall"].icon_mipmaps = original.icon_mipmaps
data.raw.item["stone-wall"].icons = original.icons

------------------------------------------------------------------------------------------------------------------------------------------------------

local steel = table.deepcopy(data.raw.wall["stone-wall"])

steel.name = "steel-plate-wall"
steel.corpse = "small-remnants"
steel.icon = DIR.get_icon_path("steel-plate-wall")
steel.icon_size = DIR.icon_size
steel.icon_mipmaps = DIR.icon_mipmaps
steel.max_health = standard_health("steel",4)
steel.resistances = standard_resistances("steel_impact")
steel.minable.result = "steel-plate-wall"
steel.mined_sound.filename = DIR.core_sound_path.."/deconstruct-large.ogg"
steel.vehicle_impact_sound = DIR.vanilla_sounds.generic_impact

steel.pictures = {
	corner_left_down = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 5 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 5 * 128, 64, 128)
		}
	},
	corner_right_down = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 7 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 7 * 128, 64, 128)
		}
	},
	ending_left = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 1 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 1 * 128, 64, 128)
		}
	},
	ending_right = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 3 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 3 * 128, 64, 128)
		}
	},
	single = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 0 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 0 * 128, 64, 128)
		}
	},
	straight_horizontal = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 2 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 2 * 128, 64, 128)
		}
	},
	straight_vertical = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 4 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 4 * 128, 64, 128)
		}
	},
	t_up = {
		layers = {
			DIR.get_layer("walls/steel-plate-wall-shadow", 1, 1, true, 8, nil, 160, 160, 0, 6 * 160, 160, 160),
			DIR.get_layer("walls/steel-plate-wall-base", -8, 8, false, nil, nil, 64, 128, 0, 6 * 128, 64, 128)
		}
	},
	gate_connection_patch = {
		sheets = {
			DIR.get_layer("walls/steel-plate-wall-gate-shadow", nil, nil, true, nil, nil, 128, 128, 0, 0, 128, 128, {0.5,0.5}),
			DIR.get_layer("walls/steel-plate-wall-gate-patch", nil, nil, false, nil, nil, 64, 192, nil, nil, 64, 192),
		},
	},
	water_connection_patch = {
		sheets = {
			DIR.get_layer("walls/steel-plate-wall-water-shadow", nil, nil, true, nil, nil, 192, 160, 0, 0, 192, 160, {0.5,0.75}),
			DIR.get_layer("walls/steel-plate-wall-water-patch", nil, nil, false, nil, nil, 128, 160, 0, 0, 128, 160, {0,-0.25}),
		},
	},
	filling = DIR.get_layer("walls/steel-plate-wall-filler", -8, 8, false, nil, nil, 64, 64, 0, 0, 64, 64),
}

for _,picture in pairs(steel.pictures) do
	if picture.layers then picture.layers[1].shift = {0.75,0.75} end
end

for _,p in pairs({"wall_diode_red", "wall_diode_green"}) do
	if steel[p] and steel[p].sheet and steel[p].sheet.hr_version then
		steel[p].sheet.hr_version.shift = DIR.get_vector_sum(steel[p].sheet.hr_version.shift or {0,0}, {0,-4/64})
	end
	steel[p].sheet.shift = DIR.get_vector_sum(steel[p].sheet.shift or {0,0}, {0,-4/64})
end

data:extend({steel})

data.raw.wall["stone-wall"].next_upgrade = "steel-plate-wall"

------------------------------------------------------------------------------------------------------------------------------------------------------
