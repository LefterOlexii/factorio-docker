------------------------------------------------------------------------------------------------------------------------------------------------------

-- TURRETS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- gun turret

local function turret_dual_projectile_parameters(directions, hoffset, height, distance)
	local p = {}
	local h = height or -0.25
	local d = distance or 1.4
	local root2 = math.sqrt(2)
	for i=1,directions do
		local a = (i-1)/directions
		local r = (a-0.25) * math.pi * 2
		local q = math.pi / 2
		local pa = { a, DIR.get_vector_sum({0,h}, DIR.get_vector_sum({math.cos(r)*d, math.sin(r)*d/root2}, {math.cos(r+q)*hoffset, math.sin(r+q)*hoffset/root2})) }
		table.insert(p, pa)
		local pa = { a, DIR.get_vector_sum({0,h}, DIR.get_vector_sum({math.cos(r)*d, math.sin(r)*d/root2}, {math.cos(r-q)*hoffset, math.sin(r-q)*hoffset/root2})) }
		table.insert(p, pa)
	end
	-- log(serpent.block(p))
	return p
end

local gun_turret = {
    name = "gun-turret",
    type = "ammo-turret",
    alert_when_attacking = true,
    attack_parameters = {
        ammo_category = "bullet",
        cooldown = 6,
        lead_target_for_projectile_speed = DIR.components.magazine.ammo.speed,
        projectile_center = {0,-0.25},
        projectile_creation_distance = 1.4,
		-- projectile_creation_parameters = turret_dual_projectile_parameters(64,1.5),
        range = DIR.components.magazine.ammo.range,
        shell_particle = {
            center = {-0.0625,0},
            creation_distance = -1.925,
            direction_deviation = 0.1,
            name = "shell-particle",
            speed = 0.1,
            speed_deviation = 0.03,
            starting_frame_speed = 0.2,
            starting_frame_speed_deviation = 0.1
        },
        sound = DIR.vanilla_sounds.gun_turret_gunshot,
        type = "projectile"
    },
    attacking_speed = 1/3,
    automated_ammo_count = 10,
    call_for_help_radius = 40,
    close_sound = standard_machine_close(),
    collision_box = DIR.get_box(0.7,0.7),
    corpse = "medium-small-remnants",
    damaged_trigger_effect = nil, -- overwritten by scrap algorithm
    drawing_box = {{-1,-2},{1,1}},
    dying_explosion = nil, -- overwritten by scrap algorithm
    entity_info_icon_shift = standard_2x2_turret_info_icon_shift(),
    fast_replaceable_group = "turret",
    flags = {
        "placeable-player",
        "player-creation"
    },
    icon = nil,
    icon_mipmaps = nil,
    icon_size = nil,
    icons = data.raw.item["gun-turret"].icons,
    inventory_size = 1,
    max_health = standard_health("iron",3),
    minable = {
        mining_time = DIR.standard_pickup_time * 2,
        result = "gun-turret"
    },
    open_sound = standard_machine_open(),
    prepare_range = DIR.components.magazine.ammo.range + 4,
    range = DIR.components.magazine.ammo.range,
    resistances = standard_resistances("iron"),
    rotation_speed = 0.015,
    selection_box = DIR.get_box(1,1),
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    water_reflection = nil, -- meh
    base_picture_render_layer = "object",
    gun_animation_render_layer = "higher-object-under",
    folding_speed = 0.08,
    preparing_speed = 0.08,
    base_picture = {
		layers = {
			DIR.get_layer("machines/turrets/2x2-turret-base-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
			DIR.get_layer("machines/turrets/autogun-turret-base", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, nil, nil, nil),
			DIR.get_layer("machines/turrets/autogun-turret-base-mask", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, {"mask"}, nil, nil, true),
		}
	},
	attacking_animation = {
		layers = {
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-shadow", 4, 3, nil, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-base", 4, 1, nil, false, 3, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-mask", 4, 1, nil, false, 3, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-gun", 4, 3, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
		}
	},
    folded_animation = {
		layers = {
			DIR.get_layer("machines/turrets/autogun-turret-raising-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
			DIR.get_layer("machines/turrets/autogun-turret-raising-base", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
			DIR.get_layer("machines/turrets/autogun-turret-raising-mask", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
			DIR.get_layer("machines/turrets/autogun-turret-raising-gun", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
		}
	},
    folding_animation = {
		layers = {
			DIR.get_layer("machines/turrets/autogun-turret-raising-shadow", 5, 0, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/autogun-turret-raising-base", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/autogun-turret-raising-mask", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true, "backward"),
			DIR.get_layer("machines/turrets/autogun-turret-raising-gun", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4, nil, "backward"),
		}
	},
    prepared_animation = {
		layers = {
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-shadow", 4, 1, nil, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-base", 4, 1, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-mask", 4, 1, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
			DIR.get_multi_layer("machines/turrets/autogun-turret-shooting-gun", 4, 1, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
		}
	},
    preparing_animation = {
		layers = {
			DIR.get_layer("machines/turrets/autogun-turret-raising-shadow", 5, 0, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
			DIR.get_layer("machines/turrets/autogun-turret-raising-base", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
			DIR.get_layer("machines/turrets/autogun-turret-raising-mask", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
			DIR.get_layer("machines/turrets/autogun-turret-raising-gun", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
		}
	},
    folding_sound = DIR.vanilla_sounds.gun_turret_deactivate,
    preparing_sound = DIR.vanilla_sounds.gun_turret_activate,
}

local sounds = {"preparing_sound","folding_sound"}
for _,sound in pairs(sounds) do
	for _,instance in pairs(gun_turret[sound]) do
		if not instance.volume or (instance.volume < 0.35) then instance.volume = 0.35 end
	end
end

data:extend({gun_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- scattergun turret

local scattergun_turret = table.deepcopy(gun_turret)

scattergun_turret.name = "scattergun-turret"
scattergun_turret.minable.result = "scattergun-turret"
scattergun_turret.icon = nil
scattergun_turret.icons = table.deepcopy(data.raw.item["scattergun-turret"].icons)
scattergun_turret.attack_parameters.ammo_category = "shotgun-shell"
scattergun_turret.attack_parameters.range = DIR.components.cartridge.ammo.range
scattergun_turret.attack_parameters.cooldown = DIR.components.cartridge.ammo.cooldown
scattergun_turret.attack_parameters.projectile_center = {0,-0.25}
scattergun_turret.attack_parameters.projectile_creation_distance = 1.5
scattergun_turret.attack_parameters.lead_target_for_projectile_speed = DIR.components.cartridge.ammo.speed
scattergun_turret.max_health = standard_health("copper",3)
scattergun_turret.resistances = standard_resistances("copper")
scattergun_turret.prepare_range = DIR.components.cartridge.ammo.range + 4

scattergun_turret.base_picture = {
    layers = {
		DIR.get_layer("machines/turrets/2x2-turret-base-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
        DIR.get_layer("machines/turrets/scattergun-turret-base", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, nil, nil, nil),
        DIR.get_layer("machines/turrets/scattergun-turret-base-mask", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, {"mask"}, nil, nil, true),
    }
}
scattergun_turret.attacking_animation = {
    layers = {
        DIR.get_layer("machines/turrets/scattergun-turret-shooting-shadow", 1, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/scattergun-turret-shooting", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/scattergun-turret-shooting-mask", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
    }
}
scattergun_turret.prepared_animation = {
    layers = {
        DIR.get_layer("machines/turrets/scattergun-turret-shooting-shadow", 1, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/scattergun-turret-shooting", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/scattergun-turret-shooting-mask", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
    }
}
scattergun_turret.folded_animation = {
    layers = {
        DIR.get_layer("machines/turrets/scattergun-turret-raising-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
        DIR.get_layer("machines/turrets/scattergun-turret-raising", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
        DIR.get_layer("machines/turrets/scattergun-turret-raising-mask", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
    }
}
scattergun_turret.folding_animation = {
    layers = {
        DIR.get_layer("machines/turrets/scattergun-turret-raising-shadow", 5, 0, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4, false, "backward"),
        DIR.get_layer("machines/turrets/scattergun-turret-raising", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4, nil, "backward"),
        DIR.get_layer("machines/turrets/scattergun-turret-raising-mask", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true, "backward"),
    }
}
scattergun_turret.preparing_animation = {
    layers = {
        DIR.get_layer("machines/turrets/scattergun-turret-raising-shadow", 5, 0, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
        DIR.get_layer("machines/turrets/scattergun-turret-raising", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
        DIR.get_layer("machines/turrets/scattergun-turret-raising-mask", 5, 0, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
    }
}
scattergun_turret.attack_parameters.sound = {
    variations = {
		{
			filename = DIR.sound_path.."/shotgun1.ogg",
			volume = 0.5
		},
		{
			filename = DIR.sound_path.."/shotgun2.ogg",
			volume = 0.5
		},
		{
			filename = DIR.sound_path.."/shotgun3.ogg",
			volume = 0.5
		},
	}
}

data:extend({scattergun_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- laser turret

local colour = DIR.laser_colours[settings.startup["ir-laser-colour"].value].rgb
if not colour then colour = {1,0,0,1} end

data:extend({
    {
        name = "laser-turret",
        type = "electric-turret",
        attack_parameters = {
            ammo_type = {
                action = {
                    action_delivery = {
                        beam = "laser-beam",
                        duration = 40,
                        max_length = 24,
                        source_offset = {0,-1.175},
                        type = "beam"
                    },
                    type = "direct"
                },
                category = "laser",
                energy_consumption = "800kJ"
            },
            cooldown = 20,
            damage_modifier = 2,
            range = 24,
            source_direction_count = 64,
            source_offset = {0,-0.9},
            type = "beam",
        },
        call_for_help_radius = 40,
        corpse = "medium-small-remnants",
        collision_box = DIR.get_box(0.7,0.7),
        selection_box = DIR.get_box(1,1),
		damaged_trigger_effect = nil, -- overwritten by scrap algorithm
		drawing_box = {{-1,-2},{1,1}},
        dying_explosion = nil, -- overwritten by scrap algorithm
        energy_source = {
            buffer_capacity = "20MJ",
            drain = "25kW",
            type = "electric",
            usage_priority = "primary-input",
			input_flow_limit = "10MW",
        },
		entity_info_icon_shift = standard_2x2_turret_info_icon_shift(),
        fast_replaceable_group = "turret",
        flags = {
            "placeable-player",
            "placeable-enemy",
            "player-creation"
        },
        folding_speed = 0.05,
        glow_light_intensity = 1,
        icon = nil,
        icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		icons = table.deepcopy(data.raw.item["laser-turret"].icons),
        max_health = standard_health("steel",3),
        minable = {
            mining_time = DIR.standard_pickup_time * 2,
            result = "laser-turret"
        },
        preparing_speed = 0.05,
		prepare_range = 28,
		resistances = standard_resistances("steel"),
        rotation_speed = 0.01,
        vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
		base_picture_render_layer = "object",
		gun_animation_render_layer = "higher-object-under",
        base_picture = {
            layers = {
                DIR.get_layer("machines/turrets/2x2-turret-base-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
                DIR.get_layer("machines/turrets/electric-turret-base", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}),
                DIR.get_layer("machines/turrets/electric-turret-base-mask", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, {"mask"}, nil, nil, true),
            }
        },
        attacking_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-shooting-shadow", 1, 8, true, 20, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
                DIR.get_layer("machines/turrets/laser-turret-shooting", 1, 8, false, 20, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
                DIR.get_layer("machines/turrets/laser-turret-shooting-mask", 1, 8, false, 20, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
            }
        },
        folded_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-raising-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
                DIR.get_layer("machines/turrets/laser-turret-raising", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
                DIR.get_layer("machines/turrets/laser-turret-raising-mask", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
            }
        },
        folding_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-raising-shadow", 8, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4, false, "backward"),
                DIR.get_layer("machines/turrets/laser-turret-raising", 8, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4, nil, "backward"),
                DIR.get_layer("machines/turrets/laser-turret-raising-mask", 8, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true, "backward"),
            }
        },
        prepared_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-shooting-shadow", 1, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 64),
                DIR.get_layer("machines/turrets/laser-turret-shooting", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 64),
                DIR.get_layer("machines/turrets/laser-turret-shooting-mask", 1, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 64, true),
            }
        },
        preparing_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-raising-shadow", 8, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 4),
                DIR.get_layer("machines/turrets/laser-turret-raising", 8, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 4),
                DIR.get_layer("machines/turrets/laser-turret-raising-mask", 8, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 4, true),
            }
        },
        energy_glow_animation = {
            layers = {
                DIR.get_layer("machines/turrets/laser-turret-shooting-glow", 1, 8, "glow", nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}, "additive", {"light"}, colour, 64),
            }
        },
		folding_sound = DIR.vanilla_sounds.laser_turret_deactivate,
		preparing_sound = DIR.vanilla_sounds.laser_turret_activate,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- electric arc turret

data:extend({
    {
      bonus_gui_order = "kb",
      name = "emp-turret",
      type = "ammo-category"
    }
})

local arc_turret = table.deepcopy(data.raw["electric-turret"]["laser-turret"])
local cycle = math.floor(DIR.arc_turret_shooting_speed/60)
local draw = 1000 -- kW

arc_turret.name = "arc-turret"
arc_turret.minable.result = "arc-turret"
arc_turret.icons = table.deepcopy(data.raw.item["arc-turret"].icons)
arc_turret.max_health = standard_health("steel",3)
arc_turret.energy_source = {
	buffer_capacity = "20MJ",
	drain = "25kW",
	type = "electric",
	usage_priority = "primary-input",
	input_flow_limit = "10MW",
}

arc_turret.attack_parameters.source_offset = {0,-0.69375} -- not really relevant now beam is invisible (see projectiles)
arc_turret.attack_parameters.ammo_type.action.action_delivery = {
	type = "beam",
	beam = "emp-beam",
	source_offset = {0,-1.25}, -- ditto
	duration = DIR.arc_turret_shooting_speed,
}
arc_turret.attack_parameters.ammo_type.category = "emp-turret"
arc_turret.attack_parameters.ammo_type.energy_consumption = (cycle*draw).."kJ"
arc_turret.attack_parameters.cooldown = DIR.arc_turret_shooting_speed
arc_turret.attack_parameters.damage_modifier = 0
arc_turret.attack_parameters.range = DIR.arc_turret_max_range
arc_turret.attack_parameters.min_range = DIR.arc_turret_min_range
arc_turret.attack_parameters.health_penalty = -1 -- added 3.1.9, attempting to target fatter mobs
arc_turret.prepare_range = DIR.arc_turret_max_range + 4
arc_turret.ignore_target_mask = {"ir-non-moving"}

arc_turret.preparing_speed = 0.025 -- total guesswork because undocumented
arc_turret.folding_speed = 0.025 -- ditto

arc_turret.attacking_animation = nil
arc_turret.base_picture = {
	layers = {
		DIR.get_layer("machines/turrets/2x2-turret-base-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {0,0}),
        DIR.get_layer("machines/turrets/arc-turret-2-base", 1, 1, false, nil, 0.75, 128, 192, 0, 0, 128, 192, {0,-0.5}),
        DIR.get_layer("machines/turrets/arc-turret-2-base-mask", 1, 1, false, nil, 0.75, 128, 192, 0, 0, 128, 192, {0,-0.5}, nil, {"mask"}, nil, nil, true),
	}
}
arc_turret.prepared_animation = {
    layers = {
        DIR.get_layer("machines/turrets/arc-turret-2-top-shadow", 1, 1, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 1),
        DIR.get_layer("machines/turrets/arc-turret-2-top", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 1),
        DIR.get_layer("machines/turrets/arc-turret-2-top-mask", 1, 1, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 1, true),
    }
}
arc_turret.folded_animation = {
    layers = {
        DIR.get_layer("machines/turrets/arc-turret-2-top-shadow", 1, 1, true, nil, nil, 192, 128, 7*192, 3*128, 192, 128, {1.5-21,-6}, nil, nil, nil, 1),
        DIR.get_layer("machines/turrets/arc-turret-2-top", 1, 1, false, nil, nil, 128, 128, 7*128, 3*128, 128, 128, {-14,-7}, nil, nil, nil, 1),
        DIR.get_layer("machines/turrets/arc-turret-2-top-mask", 1, 1, false, nil, nil, 128, 128, 7*128, 3*128, 128, 128, {-14,-7}, nil, {"mask"}, nil, 1, true),
    }
}
arc_turret.folding_animation = {
    layers = {
        DIR.get_layer("machines/turrets/arc-turret-2-top-shadow", 32, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 1, nil, "forward"),
        DIR.get_layer("machines/turrets/arc-turret-2-top", 32, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 1, nil, "forward"),
        DIR.get_layer("machines/turrets/arc-turret-2-top-mask", 32, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 1, true, "forward"),
    }
}
arc_turret.preparing_animation = {
    layers = {
        DIR.get_layer("machines/turrets/arc-turret-2-top-shadow", 32, 8, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.5,0}, nil, nil, nil, 1, nil, "backward"),
        DIR.get_layer("machines/turrets/arc-turret-2-top", 32, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, nil, nil, 1, nil, "backward"),
        DIR.get_layer("machines/turrets/arc-turret-2-top-mask", 32, 8, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-1}, nil, {"mask"}, nil, 1, true, "backward"),
    }
}
arc_turret.energy_glow_animation = {
	layers = {
		DIR.get_layer("machines/turrets/arc-turret-2-glow", 64, 8, "glow", nil, 0.5, 128, 192, 0, 0, 128, 192, {0,-0.5}, "additive", nil, nil, 1),
	}
}

data:extend({arc_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- photon turret

local photon_properties = {
	torpedo_cost = 10, -- MJ
	buffer = 10, -- MJ
	charge_time = 2, -- seconds, for one torpedo
}

local photon_turret = table.deepcopy(data.raw["electric-turret"]["laser-turret"])

photon_turret.name = "photon-turret"
photon_turret.localised_name = {"entity-name.photon-turret"}
photon_turret.localised_description = {"entity-description.photon-turret"}
photon_turret.minable.result = "photon-turret"
photon_turret.placeable_by = {item = "photon-turret", count = 1}
photon_turret.icons = table.deepcopy(data.raw.item["photon-turret"].icons)
photon_turret.collision_box = standard_3x3_collision()
photon_turret.selection_box = standard_3x3_selection()
photon_turret.tile_width = 3
photon_turret.tile_height = 3
photon_turret.corpse = "medium-remnants"
photon_turret.folding_speed = 4/60
photon_turret.preparing_speed = 4/60
photon_turret.rotation_speed = 0.005
photon_turret.max_health = standard_health("chrome",4)
photon_turret.turret_base_has_direction = true
photon_turret.prepare_range = 64
photon_turret.entity_info_icon_shift = standard_3x3_turret_info_icon_shift()
photon_turret.drawing_box = { {-1.5,-2.5}, {1.5,1.5} }

table.insert(photon_turret.flags, "building-direction-8-way")
table.insert(photon_turret.flags, "not-upgradable")

photon_turret.energy_source = {
    buffer_capacity = photon_properties.buffer .. "MJ",
    drain = "120kW",
    input_flow_limit = (photon_properties.torpedo_cost / photon_properties.charge_time) .. "MW",
    type = "electric",
    usage_priority = "primary-input"
}

photon_turret.attack_parameters = {
    ammo_type = {
        action = {
            action_delivery = {
                projectile = "photon-torpedo",
                type = "projectile",
                starting_speed = 0.5,
                max_range = 60,
                min_range = 12,
                direction_deviation = 0,
                source_effects = {
                    entity_name = "photon-muzzle",
                    type = "create-explosion"
                },
            },
            type = "direct",
        },
        category = "photon-torpedo",
        energy_consumption = photon_properties.torpedo_cost .. "MJ",
        target_type = "entity",
    },
    cooldown = DIR.seconds_to_ticks(photon_properties.charge_time),
    range = 60,
    min_range = 12,
    turn_range = 1/3,
    projectile_center = {0,0},
    projectile_creation_distance = 1.75,
    lead_target_for_projectile_speed = 0.5,
    sound = {
		filename = string.format("%s/%s.ogg", DIR.sound_path, "new-photon"),
		volume = 0.75,
		min_speed = 0.975,
		max_speed = 1.025,
    },
    type = "projectile"
}

photon_turret.base_picture = {
    layers = {
        DIR.get_layer("machines/turrets/photon-turret-base-shadow", 1, 1, true, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}),
        DIR.get_layer("machines/turrets/photon-turret-base", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}),
        DIR.get_layer("machines/turrets/photon-turret-base-mask", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}, nil, {"mask"}, nil, nil, true),
    },
}
photon_turret.attacking_animation = nil
photon_turret.prepared_animation = {
    layers = {
		DIR.get_layer("machines/turrets/photon-turret-shooting-shadow", 1, 8, true, nil, nil, 256, 192, 0, 0, 256, 192, {2,0}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/photon-turret-shooting", 1, 8, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 64),
        DIR.get_layer("machines/turrets/photon-turret-shooting-mask", 1, 8, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 64, true),
        DIR.get_layer("machines/turrets/photon-turret-prepared-glow", 1, 8, "glow", nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, "additive", nil, nil, 64),
    }
}
photon_turret.preparing_animation = {
    layers = {
		DIR.get_layer("machines/turrets/photon-turret-shooting-shadow", 1, 1, true, 4, 1, 256, 192, 0, 0, 256, 192, {2,0}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting", 1, 1, false, 4, 1, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting-mask", 1, 1, false, 4, 1, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 8, true),
        DIR.get_layer("machines/turrets/photon-turret-preparing-glow", 4, 4, "glow", 1, 1, 192, 192, 0, 0, 192, 192, {0,-1}, "additive", nil, nil, 8, nil, "forward"),
    }
}
photon_turret.folded_animation = {
    layers = {
		DIR.get_layer("machines/turrets/photon-turret-shooting-shadow", 1, 1, true, nil, nil, 256, 192, 0, 0, 256, 192, {2,0}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting-mask", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 8, true),
    }
}
photon_turret.folding_animation = {
    layers = {
		DIR.get_layer("machines/turrets/photon-turret-shooting-shadow", 1, 1, true, 4, 1, 256, 192, 0, 0, 256, 192, {2,0}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting", 1, 1, false, 4, 1, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 8),
        DIR.get_layer("machines/turrets/photon-turret-shooting-mask", 1, 1, false, 4, 1, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 8, true),
        DIR.get_layer("machines/turrets/photon-turret-preparing-glow", 4, 4, "glow", 1, 1, 192, 192, 0, 0, 192, 192, {0,-1}, "additive", nil, nil, 8, nil, "backward"),
    }
}
photon_turret.energy_glow_animation = nil

photon_turret.fast_replaceable_group = "large-turret"

data:extend({photon_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- rocket turret

local rtrange = 36
local material = "steel"

local rocket_turret = {
    name = "rocket-turret",
    type = "ammo-turret",
	localised_name = {"entity-name.rocket-turret"},
	localised_description = {"", {"entity-description.rocket-turret"}, "\n", {"entity-description.rocket-turret-ignore", {"entity-description.rocket-turret-low-health", DIR.low_priority_target_health}}},
	ignore_target_mask = {"ir-low-priority"},
    alert_when_attacking = true,
    attack_parameters = {
        ammo_category = "rocket",
        cooldown = 60,
		projectile_creation_parameters = turret_dual_projectile_parameters(64,0.875,-0.25,1.75),
        range = rtrange,
		min_range = 12,
        sound = table.deepcopy(data.raw.gun["rocket-launcher"].sound),
        type = "projectile"
    },
    attacking_speed = 1,
    automated_ammo_count = 20,
    call_for_help_radius = 40,
    close_sound = standard_machine_close(),
    collision_box = standard_3x3_collision(),
    corpse = "medium-remnants",
    damaged_trigger_effect = nil, -- overwritten by scrap algorithm
    drawing_box = photon_turret.drawing_box,
    dying_explosion = nil, -- overwritten by scrap algorithm
    entity_info_icon_shift = standard_3x3_turret_info_icon_shift(),
    fast_replaceable_group = "large-turret",
    flags = {
        "placeable-player",
        "player-creation",
		"not-upgradable"
    },
    icon = nil,
    icon_mipmaps = nil,
    icon_size = nil,
    icons = data.raw.item["rocket-turret"].icons,
    inventory_size = 1,
    max_health = standard_health(material,4),
    minable = {
        mining_time = DIR.standard_pickup_time * 2,
        result = "rocket-turret"
    },
    open_sound = standard_machine_open(),
	placeable_by = {item = "rocket-turret", count = 1},
    prepare_range = rtrange + 2,
    resistances = standard_resistances(material),
    rotation_speed = 0.005,
    selection_box = standard_3x3_selection(),
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    water_reflection = nil, -- meh
    base_picture_render_layer = "object",
    gun_animation_render_layer = "higher-object-under",
    folding_speed = 0.05,
    preparing_speed = 0.05,
	base_picture = {
		layers = {
			DIR.get_layer("machines/turrets/photon-turret-base-shadow", 1, 1, true, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}),
			DIR.get_layer("machines/turrets/rocket-turret-base", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}),
			DIR.get_layer("machines/turrets/rocket-turret-base-mask", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,0}, nil, {"mask"}, nil, nil, true),
		},
	},
	attacking_animation = nil,
	prepared_animation = {
		layers = {
			DIR.get_layer("machines/turrets/rocket-turret-shooting-shadow", 1, 8, true, nil, nil, 224, 160, 0, 0, 224, 160, {1.75,0.25}, nil, nil, nil, 64),
			DIR.get_layer("machines/turrets/rocket-turret-shooting", 1, 8, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 64),
			DIR.get_layer("machines/turrets/rocket-turret-shooting-mask", 1, 8, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 64, true),
			DIR.get_layer("machines/turrets/rocket-turret-shooting-glow", 1, 8, "light", nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 64),
		}
	},
	folded_animation = {
		layers = {
			DIR.get_layer("machines/turrets/rocket-turret-raising-shadow", 1, 1, true, nil, nil, 224, 160, 0, 0, 224, 160, {1.75,0.25}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-mask", 1, 1, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 4, true, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-glow", 1, 1, "light", nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, true, "backward"),
		}
	},
	folding_animation = {
		layers = {
			DIR.get_layer("machines/turrets/rocket-turret-raising-shadow", 8, 0, true, nil, nil, 224, 160, 0, 0, 224, 160, {1.75,0.25}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising", 8, 0, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, false, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-mask", 8, 0, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 4, true, "backward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-glow", 8, 0, "light", nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, true, "backward"),
		}
	},
	preparing_animation = {
		layers = {
			DIR.get_layer("machines/turrets/rocket-turret-raising-shadow", 8, 0, true, nil, nil, 224, 160, 0, 0, 224, 160, {1.75,0.25}, nil, nil, nil, 4, false, "forward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising", 8, 0, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, false, "forward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-mask", 8, 0, false, nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, {"mask"}, nil, 4, true, "forward"),
			DIR.get_layer("machines/turrets/rocket-turret-raising-glow", 8, 0, "light", nil, nil, 192, 192, 0, 0, 192, 192, {0,-1}, nil, nil, nil, 4, true, "forward"),
		}
	},
    folding_sound = DIR.vanilla_sounds.gun_turret_deactivate,
    preparing_sound = DIR.vanilla_sounds.gun_turret_activate,
}

data:extend({rocket_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- turret colours

local turrets = {"scattergun-turret","gun-turret","laser-turret","arc-turret","photon-turret","rocket-turret"}
local runtime = settings.startup["ir-turret-runtime"].value

for _,turret in pairs(turrets) do
	-- convert runtime tints on actual turrets if option is set
	local prototype = data.raw["ammo-turret"][turret] or data.raw["electric-turret"][turret]
	if runtime ~= "runtime" then
		local animations = {prototype.base_picture, prototype.preparing_animation, prototype.prepared_animation, prototype.folding_animation, prototype.folded_animation, prototype.attacking_animation, prototype.energy_glow_animation}
		for _,animation in pairs(animations) do
			if animation and animation.layers then
				for _,layer in pairs(animation.layers) do
					if layer.apply_runtime_tint then
						if (runtime == "predefined") and DIR.machines[turret] and DIR.machines[turret].icon_masks then
							layer.apply_runtime_tint = nil
							layer.tint = DIR.machines[turret].icon_masks.tint
						elseif DIR.hues[runtime] then 
							layer.apply_runtime_tint = nil
							layer.tint = DIR.hsva2rgba(DIR.hues[runtime],DIR.get_saturation(DIR.hues[runtime]),1,0.5)
						end
					end
				end
			end
		end
	end
	-- fake turret animations for documentation
	local animations = {prototype.base_picture, prototype.prepared_animation, prototype.energy_glow_animation}
	local c = 1
	for _,animation in pairs(animations) do
		if animation and animation.layers then
			for _,layer in pairs(animation.layers) do
				local a = table.deepcopy(layer)
				a.name = turret .."-".. c
				a.type = "animation"
				a.animation_speed = 0.5
				if a.direction_count and a.direction_count > 1 then a.frame_count = a.direction_count end
				if a.apply_runtime_tint and DIR.machines[turret] and DIR.machines[turret].icon_masks then
					a.apply_runtime_tint = nil
					a.tint = DIR.machines[turret].icon_masks.tint
				end
				data:extend({a})
				c = c + 1
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- narrow arc version of photon turret - after mask tinting settings

local narrow_photon = table.deepcopy(data.raw["electric-turret"]["photon-turret"])
narrow_photon.attack_parameters.turn_range = 1/6
narrow_photon.name = narrow_photon.name .. "-narrow"
narrow_photon.energy_source.drain = "60kW"
table.insert(narrow_photon.icons, { icon = DIR.get_icon_path("narrow-angle"), icon_size = DIR.icon_size, scale = 0.25, shift = {-8,8}, icon_mipmaps = DIR.icon_mipmaps})

data:extend({narrow_photon})

-- non-ignoring version of rocket turret

local ni_rocket_turret = table.deepcopy(rocket_turret)
ni_rocket_turret.name = "rocket-turret-all"
ni_rocket_turret.localised_description = {"", {"entity-description.rocket-turret"}, "\n", {"entity-description.rocket-turret-ignore", {"entity-description.rocket-turret-none"}}}
ni_rocket_turret.ignore_target_mask = nil
table.insert(ni_rocket_turret.icons, { icon = DIR.base_icons_path.."/signal/signal_everything.png" , icon_size = 64, scale = 0.25, shift = {-8,8}, icon_mipmaps = 4})

data:extend({ni_rocket_turret})

------------------------------------------------------------------------------------------------------------------------------------------------------
