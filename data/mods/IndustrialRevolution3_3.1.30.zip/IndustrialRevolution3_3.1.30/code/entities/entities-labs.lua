------------------------------------------------------------------------------------------------------------------------------------------------------

-- LABS

------------------------------------------------------------------------------------------------------------------------------------------------------

local packs = {
	["copper-lab"] = {"automation-science-pack","logistic-science-pack"},
	["lab"] = {},
	["quantum-lab"] = {},
}

for _,component in pairs({"analysis","special-analysis"}) do
	for _,material in pairs(DIR.components[component].materials) do
		local name = DIR.get_item_name(material,component)
		if component == "special-analysis" then
			if DIR.components[component].project_info and DIR.components[component].project_info[material] and DIR.components[component].project_info[material].do_not_identify then
				table.insert(packs["lab"], name)
				table.insert(packs["quantum-lab"], name)
			end
		else
			if material ~= "hydrogen" then table.insert(packs["lab"], name) end
			table.insert(packs["quantum-lab"], name)
		end
	end
end

local descriptions = {}
for lab,packs in pairs(packs) do
	local d = {""} 
	for _,pack in pairs(packs) do
		table.insert(d, "[img=item/" .. pack .. "]")
	end
	descriptions[lab] = {"entity-description."..lab, {"entity-description.lab-inputs"}, d}
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- vanilla lab

local speed = 2
local anim_speed = 0.5

data.raw.lab["lab"].fast_replaceable_group = "lab"
data.raw.lab["lab"].order = "a"

data.raw.lab["lab"].researching_speed = speed
local energy = DIR.get_scaled_energy_usage(speed, DIR.standard_drain)
data.raw.lab["lab"].energy_source = {
	type = "electric",
	usage_priority = "secondary-input",
	drain = energy.passive,
}
data.raw.lab["lab"].energy_usage = energy.active

data.raw.lab["lab"].icon = DIR.get_icon_path("lab")
data.raw.lab["lab"].icon_size = DIR.icon_size
data.raw.lab["lab"].icon_mipmaps = DIR.icon_mipmaps

data.raw.lab["lab"].off_animation = {
	layers = {
		DIR.get_layer("machines/labs/electric-lab-shadow", 1, nil, true, 60, anim_speed, 320, 192, 0, 0, 320, 192, {1,0}),
		DIR.get_layer("machines/labs/electric-lab-base", 1, nil, false, 60, anim_speed, 192, 228, 0, 0, 192, 228, {0,-0.25}, nil, DIR.general_sprite_flags),
	}
}
data.raw.lab["lab"].on_animation = {
	layers = {
		DIR.get_layer("machines/labs/electric-lab-shadow", 1, nil, true, 60, anim_speed, 320, 192, 0, 0, 320, 192, {1,0}),
		DIR.get_layer("machines/labs/electric-lab-base", 1, nil, false, 60, anim_speed, 192, 228, 0, 0, 192, 228, {0,-0.25}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/labs/electric-lab-working", 60, 10, "glow", nil, anim_speed, 192, 228, 0, 0, 192, 228, {0,-0.25}, "additive-soft", DIR.general_sprite_flags),		
	}
}
data.raw.lab["lab"].working_sound = {
	sound = {
		filename = DIR.sound_path.."/lab1.ogg",
		volume = 0.5
	},
	max_sounds_per_type = 3,
	fade_in_ticks = 10,
	fade_out_ticks = 30,
}

data.raw.lab["lab"].inputs = packs["lab"]
data.raw.lab["lab"].localised_description = descriptions["lab"]

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper lab

local speed = 1
local energy = DIR.get_scaled_energy_usage(speed, 0)
local lab = {
    name = "copper-lab",
    type = "lab",
	localised_description = descriptions["copper-lab"], 
	order = "b", -- because we want electric lab to define bonus effect icon, item/recipes are ordered differently
    collision_box = {{-1.2, -1.2}, {1.2,1.2}},
    corpse = "medium-remnants",
	dying_explosion = "medium-explosion",
	energy_source = {
		type = "fluid",
		fluid_box = {
			filter = "steam",
			base_area = 1,
			base_level = -1,
			height = 2,
			production_type = "input-output",
			pipe_connections = {
				{ type="input-output", position = {-2, 0} },
				{ type="input-output", position = {0, 2} },
				{ type="input-output", position = {2, 0} },
				{ type="input-output", position = {0, -2} },
			},
			pipe_covers = DIR.pipe_covers.steam,
			secondary_draw_orders = { north = -1 },
		},
		maximum_temperature = 165,
		scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
		light_flicker = standard_zero_light_flicker(),
		-- smoke = {
			-- copper_steam({-0.875,-0.975},{-0.875,-0.975},2,0),
			-- copper_steam({0.875,-0.975},{0.875,-0.975},2,0.25),
		-- },
	},
	allowed_effects = {},
    energy_usage = energy.active,
    fast_replaceable_group = "lab",
	next_upgrade = "lab",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    icon = DIR.get_icon_path("copper-lab"),
    icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
    inputs = packs["copper-lab"],
    max_health = standard_health("copper",3),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "copper-lab"
    },
	placeable_by = {item = "copper-lab", count = 1},
    off_animation = {
        layers = {
			DIR.get_layer("machines/misc/bronze-telescope-shadow-base", nil, nil, true, 64, 0.5, 256, 256, 0, 0, 256, 256, {0.5,0}),
            DIR.get_layer("machines/labs/copper-lab-shadow-working", 64, 8, true, nil, 0.5, 256, 160, 0, 0, 256, 160, {1.5,0.25}),
			DIR.get_layer("machines/labs/copper-lab-base", nil,nil, false, 64, 0.5, 192, 256, 0, 0, 192, 256, {0,0}, nil, DIR.general_sprite_flags),
            DIR.get_layer("machines/labs/copper-lab-working", 64, 8, false, nil, 0.5, 192, 192, 0, 0, 192, 192, {0,-0.5}, nil, DIR.general_sprite_flags),
        }
    },
    on_animation = {
        layers = {
			DIR.get_layer("machines/misc/bronze-telescope-shadow-base", nil, nil, true, 64, 0.5, 256, 256, 0, 0, 256, 256, {0.5,0}),
            DIR.get_layer("machines/labs/copper-lab-shadow-working", 64, 8, true, nil, 0.5, 256, 160, 0, 0, 256, 160, {1.5,0.25}),
			DIR.get_layer("machines/labs/copper-lab-base", nil,nil, false, 64, 0.5, 192, 256, 0, 0, 192, 256, {0,0}, nil, DIR.general_sprite_flags),
            DIR.get_layer("machines/labs/copper-lab-working", 64, 8, false, nil, 0.5, 192, 192, 0, 0, 192, 192, {0,-0.5}, nil, DIR.general_sprite_flags),
        }
    },
    researching_speed = speed,
	resistances = standard_resistances("iron"),
    selection_box = {{-1.5,-1.5}, {1.5,1.5}},
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/clock.ogg",
            volume = 0.5
        },
		max_sounds_per_type = 3,
		fade_in_ticks = 10,
		fade_out_ticks = 30,
    }
}

data:extend({lab})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- quantum lab

local glow_sequence = {}
for i=1,6 do
	for j=1,10 do table.insert(glow_sequence, i) end
end

local speed = 8
local anim_speed = 0.5
local energy = DIR.get_scaled_energy_usage(6, DIR.standard_drain)
local lab = {
    name = "quantum-lab",
    type = "lab",
	localised_description = descriptions["quantum-lab"], 
	order = "c",
    collision_box = {{-3.25,-3.25}, {3.25,3.25}},
    selection_box = {{-3.5,-3.5}, {3.5,3.5}},
	drawing_box = { {-3.5,-4.5}, {3.5,3.5} },
    corpse = "medium-remnants",
    dying_explosion = "big-artillery-explosion",
    energy_source = {
        type = "electric",
        usage_priority = "secondary-input",
        drain = energy.passive,
    },
    energy_usage = energy.active,
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    icon = DIR.get_icon_path("quantum-lab"),
    icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
    inputs = packs["quantum-lab"],
    max_health = standard_health("chrome",5),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "quantum-lab"
    },
    module_specification = {
        max_entity_info_module_icon_rows = 1,
        max_entity_info_module_icons_per_row = 4,
        module_info_icon_shift = { 0, 2 },
        module_slots = 3
    },
    off_animation = {
        layers = {
			DIR.get_layer("machines/labs/quantum-lab-base-shadow", 1, nil, true, 60, anim_speed, 512, 448, 0, 0, 512, 448, {0.5,0}),
            DIR.get_layer("machines/labs/quantum-lab-rings-shadow", 60, 10, true, nil, anim_speed, 256, 320, 0, 0, 256, 320, {2.5,0}),
			DIR.get_layer("machines/labs/quantum-lab-base-top", 1, nil, false, 60, anim_speed, 448, 256, 0, 0, 448, 256, {0,-2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-base-bottom", 1, nil, false, 60, anim_speed, 448, 192, 0, 0, 448, 192, {0,2.0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-rings", 60, 10, false, nil, anim_speed, 448, 384, 0, 0, 448, 384, {0,-0.5}, nil, DIR.general_sprite_flags),
        }
    },
    on_animation = {
		layers = {
			DIR.get_layer("machines/labs/quantum-lab-base-shadow", 1, nil, true, 60, anim_speed, 512, 448, 0, 0, 512, 448, {0.5,0}),
            DIR.get_layer("machines/labs/quantum-lab-rings-shadow", 60, 10, true, nil, anim_speed, 256, 320, 0, 0, 256, 320, {2.5,0}),
			DIR.get_layer("machines/labs/quantum-lab-base-top", 1, nil, false, 60, anim_speed, 448, 256, 0, 0, 448, 256, {0,-2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-base-bottom", 1, nil, false, 60, anim_speed, 448, 192, 0, 0, 448, 192, {0,2.0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-rings", 60, 10, false, nil, anim_speed, 448, 384, 0, 0, 448, 384, {0,-0.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-rings-glow", 60, 10, "glow", nil, anim_speed, 448, 384, 0, 0, 448, 384, {0,-0.5}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/labs/quantum-lab-lights", 6, 1, "glow", nil, anim_speed, 448, 128, 0, 0, 448, 128, {0,2.5}, "additive", DIR.general_sprite_flags, nil, nil, nil, nil, 0.5, glow_sequence),		
		}
    },
    researching_speed = speed,
	resistances = standard_resistances("chrome"),
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/quantum.ogg",
            volume = 0.9
        },
		max_sounds_per_type = 3,
		fade_in_ticks = 10,
		fade_out_ticks = 30,
    },
}
data:extend({lab})
