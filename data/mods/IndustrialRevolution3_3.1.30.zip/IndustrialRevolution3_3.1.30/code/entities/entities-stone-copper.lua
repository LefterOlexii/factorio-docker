------------------------------------------------------------------------------------------------------------------------------------------------------

-- STONE AND COPPER MACHINES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- stone template

local speed = 1
local animspeed = 1
local energy = DIR.get_scaled_energy_usage(speed, 0)
local stone = {
	source_inventory_size = 1,
	result_inventory_size = 1,
    crafting_speed = DIR.get_standard_speed(speed),
    energy_source = {
        effectivity = 1,
        emissions_per_minute = DIR.get_standard_emissions(speed),
        fuel_category = "chemical",
        fuel_inventory_size = 1,
        smoke = {
            {
                frequency = 10,
                name = "smoke",
                position = {
                    0,
                    -1.25
                },
                starting_frame_deviation = 60,
                starting_vertical_speed = 0.08
            },
        },
        type = "burner",
		light_flicker = standard_zero_light_flicker(),
    },
	dying_explosion = "medium-explosion",
    energy_usage = energy.active,
    max_health = standard_health("copper",3),
    resistances = standard_resistances("stone"),
    corpse = "medium-remnants",
    flags = {"placeable-player", "placeable-neutral", "player-creation"},
    collision_box = standard_3x3_collision(),
    selection_box = standard_3x3_selection(),
    working_sound = {
        sound = {
            filename = DIR.base_sound_path.."/furnace.ogg",
            volume = 1.0
        },
		fade_in_ticks = 5,
		fade_out_ticks = 30,
    },
    open_sound = standard_machine_open(),
    close_sound = standard_machine_close(),
    mined_sound = {
        filename = DIR.base_sound_path.."/deconstruct-bricks.ogg"
    },
    vehicle_impact_sound = DIR.vanilla_sounds.car_stone_impact,
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	entity_info_icon_shift = {0,-0.1},
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- stone furnace

local v_tweak = 9/64

local stone_furnace = table.deepcopy(stone)
stone_furnace.name = "stone-furnace"
stone_furnace.type = "furnace"
stone_furnace.icon = DIR.get_icon_path("stone-furnace")
stone_furnace.crafting_categories = {"smelting"}
stone_furnace.gui_title_key = "gui-title.smelting"
stone_furnace.animation = {
    layers = {
        DIR.get_layer("machines/furnaces/stone-furnace-base", nil, nil, false, nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5+v_tweak}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/furnaces/stone-furnace-shadow", nil, nil, true, nil, animspeed, 320, 128, 0, 0, 320, 128, {1.0,0.5+v_tweak}),
    }
}
stone_furnace.working_visualisations = {
    {
        animation = DIR.get_layer("machines/furnaces/stone-furnace-working", 30, 6, "glow", nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5}, "additive", DIR.general_sprite_flags),
		fadeout = true,
    },
	{
		animation = DIR.get_layer("machines/furnaces/stone-furnace-floor-glow", nil, nil, "light", nil, animspeed, 192, 128, 0, 0, 192, 128, {0,1.5+v_tweak}, "additive", nil, {1,0.45,0}),
		light = {intensity = 0.5, size = 4, shift = {0,0.75}, color = {1,0.45,0}},
		fadeout = true,
		effect = "flicker",
	},
}
stone_furnace.collision_box = standard_furnace_collision()
stone_furnace.match_animation_speed_to_activity = false
stone_furnace.fast_replaceable_group = "furnace"
stone_furnace.next_upgrade = "bronze-furnace"
stone_furnace.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "stone-furnace"
}
stone_furnace.placeable_by = {item = "stone-furnace", count = 1}
data:extend({table.deepcopy(stone_furnace)})

-- alloys

local alloying = table.deepcopy(stone_furnace)
local new_name = "stone-alloy-furnace"
alloying.name = new_name
alloying.icon = DIR.get_icon_path("stone-alloy-furnace")
alloying.type = "assembling-machine"
alloying.minable.result = new_name
alloying.placeable_by = { item = new_name, count = 1 }
alloying.gui_title_key = "gui-title.alloying"
alloying.crafting_categories = {"alloying"}
alloying.animation = {
    layers = {
        DIR.get_layer("machines/furnaces/stone-alloy-furnace-base", nil, nil, false, nil, animspeed, 192, 256, 0, 0, 192, 256, {0,-0.5+v_tweak}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/furnaces/stone-alloy-furnace-shadow", nil, nil, true, nil, animspeed, 320, 128, 0, 0, 320, 128, {1.0,0.5+v_tweak}),
    }
}
alloying.next_upgrade = "bronze-alloy-furnace"

data:extend({alloying})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper grinder

local copper_grinder = table.deepcopy(stone)
copper_grinder.name = "copper-grinder"
copper_grinder.type = "furnace"
copper_grinder.source_inventory_size = 1
copper_grinder.result_inventory_size = 2
copper_grinder.energy_source = {
	type = "fluid",
	fluid_box = standard_copper_energy_fluid_box(),
	maximum_temperature = 165,
	light_flicker = standard_zero_light_flicker(),
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	smoke = standard_copper_steam(),
}	
copper_grinder.icon = DIR.get_icon_path("copper-grinder")
copper_grinder.icon_size = DIR.icon_size
copper_grinder.icon_mipmaps = DIR.icon_mipmaps
copper_grinder.crafting_categories = {"grinding"}
copper_grinder.gui_title_key = "gui-title.grinding"
copper_grinder.animation = {
	layers = {
		DIR.get_layer("machines/grinders/copper-grinder-base", 30, 5, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0}, nil, DIR.general_sprite_flags),
		DIR.get_layer("machines/assemblers/copper-shadow", nil, nil, true, 30, animspeed, 256, 192, 0, 0, 256, 192, {0.5,0}),
	}
}
copper_grinder.fast_replaceable_group = "grinder"
copper_grinder.placeable_by = {item = "copper-grinder", count = 1}
copper_grinder.next_upgrade = "iron-grinder"
copper_grinder.minable = {
	mining_time = DIR.standard_pickup_time,
	result = "copper-grinder"
}
copper_grinder.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
copper_grinder.working_sound.sound.volume = 0.75
copper_grinder.vehicle_impact_sound = DIR.vanilla_sounds.generic_impact
copper_grinder.entity_info_icon_shift = standard_grinder_info_icon_shift()
copper_grinder.resistances = standard_resistances("copper")
data:extend({table.deepcopy(copper_grinder)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper mixer

-- local copper_mixer = table.deepcopy(copper_grinder)
-- copper_mixer.name = "copper-mixer"
-- copper_mixer.type = "assembling-machine"
-- copper_mixer.source_inventory_size = 2
-- copper_mixer.result_inventory_size = 1
-- copper_mixer.fluid_boxes = assembler_fluid_boxes("copper")
-- copper_mixer.entity_info_icon_shift = standard_entity_info_icon_shift()
-- copper_mixer.icon = DIR.get_icon_path("copper-mixer")
-- copper_mixer.crafting_categories = {"mixing"}
-- copper_mixer.gui_title_key = "gui-title.mixing"
-- copper_mixer.placeable_by = {item = "copper-mixer", count = 1}
-- copper_mixer.next_upgrade = "iron-mixer"
-- copper_mixer.minable = {
	-- mining_time = DIR.standard_pickup_time,
	-- result = "copper-mixer"
-- }
-- copper_mixer.animation = {
	-- layers = {
		-- DIR.get_layer("machines/grinders/copper-mixer-base", 60, 10, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0}, nil, DIR.general_sprite_flags),
		-- DIR.get_layer("machines/assemblers/copper-shadow", nil, nil, true, 60, animspeed, 256, 192, 0, 0, 256, 192, {0.5,0}),
	-- }
-- }
-- copper_mixer.working_sound.sound.filename = string.format("%s/%s.ogg", DIR.sound_path, "grinder")
-- copper_mixer.working_sound.sound.volume = 0.75

-- data:extend({table.deepcopy(copper_mixer)})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- charcoal kiln

local stone_kiln = table.deepcopy(stone)
stone_kiln.name = "stone-charcoal-kiln"
stone_kiln.type = "furnace"
local energy = DIR.get_scaled_energy_usage(0.2, 0)
stone_kiln.energy_usage = energy.active
stone_kiln.energy_source = {
	emissions_per_minute = math.ceil(DIR.get_standard_emissions(speed/3)),
	type = "void",
	light_flicker = standard_zero_light_flicker(),
}
stone_kiln.source_inventory_size = 1
stone_kiln.result_inventory_size = 1
stone_kiln.icon = DIR.get_icon_path("stone-charcoal-kiln")
stone_kiln.crafting_categories = {"charcoal-kiln"}
stone_kiln.animation = {
    layers = {
        DIR.get_layer("machines/furnaces/stone-charcoal-kiln-base", nil, nil, false, nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0}, nil, DIR.general_sprite_flags),
        DIR.get_layer("machines/furnaces/stone-charcoal-kiln-shadow", nil, nil, true, nil, animspeed, 320, 192, 0, 0, 320, 192, {1,0}),
    }
}
stone_kiln.working_visualisations = {
    {
        animation = DIR.get_layer("machines/furnaces/stone-charcoal-kiln-working", 30, 6, "glow", nil, animspeed, 192, 192, 0, 0, 192, 192, {0,0}, "additive", DIR.general_sprite_flags),
		fadeout = true,
    },
	{
		animation = DIR.get_layer("machines/furnaces/stone-charcoal-kiln-floor-glow", 30, 5, "light", nil, animspeed, 192, 128, 0, 0, 192, 128, {0,1.5+(10/64)}, "additive", nil, {1,0.45,0}),
		light = {intensity = 0.5, size = 4, shift = {0,0.75}, color = {1,0.45,0}},
		fadeout = true,
		-- effect = "flicker",
	},
}
stone_kiln.minable = {
    mining_time = DIR.standard_pickup_time,
    result = "stone-charcoal-kiln"
}
stone_kiln.placeable_by = {item = "stone-charcoal-kiln", count = 1}
-- stone_kiln.show_recipe_icon = false

data:extend({table.deepcopy(stone_kiln)})

------------------------------------------------------------------------------------------------------------------------------------------------------
