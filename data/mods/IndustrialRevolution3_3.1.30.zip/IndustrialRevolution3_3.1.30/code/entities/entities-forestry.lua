------------------------------------------------------------------------------------------------------------------------------------------------------

-- FORESTRY

------------------------------------------------------------------------------------------------------------------------------------------------------

-- template

local forestry_dome_vertical_offset = -1
local forestry_working_glow_vertical_offset = -54/64

local forestry = {
	name = "bronze-forestry",
	type = "assembling-machine",
	source_inventory_size = 0,
	result_inventory_size = 1,
	crafting_speed = DIR.get_standard_speed(0.5),
	dying_explosion = "medium-explosion",
	icon = DIR.get_icon_path("bronze-forestry"),
	placeable_by = {item = "bronze-forestry", count = 1},
	fast_replaceable_group = "forestry",
	next_upgrade = "iron-forestry",
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "bronze-forestry",
	},
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	entity_info_icon_shift = {0,-0.5},
	crafting_categories = {"forestry"},
	allow_copy_paste = false,
	energy_source = {
		effectivity = 1,
		emissions_per_minute = DIR.get_standard_emissions(-12),
		type = "void",
		light_flicker = standard_zero_light_flicker(),
	},
	energy_usage = "1W",
	fluid_boxes = {
        {
            production_type = "input",
			filter = "water",
            pipe_covers = DIR.pipe_covers.copper,
            base_area = 10,
            base_level = -1,
            pipe_connections = {{ type="input", position = {0, -2} }},
            secondary_draw_orders = { north = -1 }
        },
		off_when_no_fluid_recipe = false,
	},
	max_health = standard_health("bronze",3),
	resistances = standard_resistances("bronze"),
	corpse = "medium-remnants",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	collision_box = standard_3x3_collision(),
	selection_box = standard_3x3_selection(),
	animation = {
		north = {
			layers = {
				DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 0, 384, 256, {1,0}),
				DIR.get_layer("machines/forestry/bronze-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 0, 256, 256, {0,0}),
				DIR.get_layer("machines/forestry/bronze-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
			}	
		},
		east = {
			layers = {
				DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 256, 384, 256, {1,-4}),
				DIR.get_layer("machines/forestry/bronze-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 256, 256, 256, {0,-4}),
				DIR.get_layer("machines/forestry/bronze-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
			}	
		},
		south = {
			layers = {
				DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 512, 384, 256, {1,-8}),
				DIR.get_layer("machines/forestry/bronze-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 512, 256, 256, {0,-8}),
				DIR.get_layer("machines/forestry/bronze-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
			}	
		},
		west = {
			layers = {
				DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 768, 384, 256, {1,-12}),
				DIR.get_layer("machines/forestry/bronze-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 768, 256, 256, {0,-12}),
				DIR.get_layer("machines/forestry/bronze-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
			}	
		},
	},
	match_animation_speed_to_activity = false,
	working_visualisations = {
		{
			animation = DIR.get_layer("machines/forestry/forestry-glow", 30, 6, "glow", nil, 0.5, 192, 192, 0, 0, 192, 192, {0,forestry_working_glow_vertical_offset}, "additive-soft", nil, nil, nil, nil, "forward-then-backward"),
			-- draw_as_glow = true,
			fadeout = true,
		},
	},
	working_sound = {
		sound = {
			filename = DIR.sound_path .. "/birds.ogg",
			volume = 1.0
		},
		fade_in_ticks = 60,
		fade_out_ticks = 60,
	},
	open_sound = standard_machine_open(),
	close_sound = standard_machine_close(),
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-large.ogg"
	},
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,

}

-- bronze forestry

data:extend({forestry})

-- iron forestry

forestry = table.deepcopy(forestry)
forestry.name = "iron-forestry"
forestry.icon = DIR.get_icon_path(forestry.name)
forestry.placeable_by = {item = forestry.name, count = 1}
forestry.minable.result = forestry.name
forestry.next_upgrade = "chrome-forestry"
forestry.energy_source = {
	type = "electric",
	usage_priority = "secondary-input",
	drain = "0W",
	emissions_per_minute = DIR.get_standard_emissions(-12),
}
forestry.fluid_boxes = {
	{
		production_type = "input",
		filter = "water",
		pipe_covers = DIR.pipe_covers.iron,
		base_area = 10,
		base_level = -1,
		pipe_connections = {{ type="input", position = {0, -2} }},
		secondary_draw_orders = { north = -1 }
	},
	off_when_no_fluid_recipe = false,
}
forestry.energy_usage = "20kW"
forestry.crafting_speed = DIR.get_standard_speed(1)
forestry.max_health = standard_health("iron",3)
forestry.resistances = standard_resistances("iron")
forestry.animation = {
	north = {
		layers = {
			DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 0, 384, 256, {1,0}),
			DIR.get_layer("machines/forestry/iron-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 0, 256, 256, {0,0}),
			DIR.get_layer("machines/forestry/iron-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	east = {
		layers = {
			DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 256, 384, 256, {1,-4}),
			DIR.get_layer("machines/forestry/iron-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 256, 256, 256, {0,-4}),
			DIR.get_layer("machines/forestry/iron-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	south = {
		layers = {
			DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 512, 384, 256, {1,-8}),
			DIR.get_layer("machines/forestry/iron-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 512, 256, 256, {0,-8}),
			DIR.get_layer("machines/forestry/iron-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	west = {
		layers = {
			DIR.get_layer("machines/forestry/forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 768, 384, 256, {1,-12}),
			DIR.get_layer("machines/forestry/iron-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 768, 256, 256, {0,-12}),
			DIR.get_layer("machines/forestry/iron-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
}

local lightpatch = mods["DeadlockLargerLamp"] and "__DeadlockLargerLamp__/graphics/entities/light.png" or (DIR.entities_path_3.."/machines/misc/larger-light.png")

forestry.working_visualisations = {
	{
		animation = DIR.get_layer("machines/forestry/forestry-glow", 30, 6, "glow", nil, 0.5, 192, 192, 0, 0, 192, 192, {0,forestry_working_glow_vertical_offset}, "additive-soft", nil, nil, nil, nil, "forward-then-backward"),
		-- draw_as_glow = true,
		fadeout = true,
		light = {
			color = {1,1,0.95},
			intensity = 0.666,
			size = 60,
			type = "oriented",
			picture = { filename = lightpatch, width = 256, height = 256, scale = 0.125 },
		},
	},
}

data:extend({forestry})

-- chrome forestry

forestry = table.deepcopy(forestry)
forestry.name = "chrome-forestry"
forestry.crafting_categories = {"forestry-advanced"}
forestry.icon = DIR.get_icon_path(forestry.name)
forestry.placeable_by = {item = forestry.name, count = 1}
forestry.minable.result = forestry.name
forestry.next_upgrade = nil
forestry.energy_source = {
	type = "electric",
	usage_priority = "secondary-input",
	drain = "0W",
	emissions_per_minute = DIR.get_standard_emissions(-12),
}
forestry.fluid_boxes = {
	{
		production_type = "input",
		filter = "liquid-fertiliser",
		pipe_covers = DIR.pipe_covers.iron,
		base_area = 10,
		base_level = -1,
		pipe_connections = {
			{ type="input", position = {1, -2} },
		},
		secondary_draw_orders = { north = -1 }
	},
	{
		production_type = "input",
		filter = "carbon-gas",
		pipe_covers = DIR.pipe_covers.iron,
		base_area = 10,
		base_level = -1,
		pipe_connections = {
			{ type="input", position = {-1, -2} },
		},
		secondary_draw_orders = { north = -1 }
	},
	{
		production_type = "output",
		filter = "oxygen-gas",
		pipe_covers = DIR.pipe_covers.iron,
		base_area = 10,
		base_level = 1,
		pipe_connections = {
			{ type="output", position = {0, 2} }
		},
		secondary_draw_orders = { north = -1 }
	},
	off_when_no_fluid_recipe = false,
}
forestry.energy_usage = "30kW"
forestry.crafting_speed = DIR.get_standard_speed(1)
forestry.max_health = standard_health("chrome",3)
forestry.resistances = standard_resistances("chrome")
forestry.animation = {
	north = {
		layers = {
			DIR.get_layer("machines/forestry/chrome-forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 0, 384, 256, {1,0}),
			DIR.get_layer("machines/forestry/chrome-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 0, 256, 256, {0,0}),
			DIR.get_layer("machines/forestry/chrome-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	east = {
		layers = {
			DIR.get_layer("machines/forestry/chrome-forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 256, 384, 256, {1,-4}),
			DIR.get_layer("machines/forestry/chrome-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 256, 256, 256, {0,-4}),
			DIR.get_layer("machines/forestry/chrome-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	south = {
		layers = {
			DIR.get_layer("machines/forestry/chrome-forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 512, 384, 256, {1,-8}),
			DIR.get_layer("machines/forestry/chrome-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 512, 256, 256, {0,-8}),
			DIR.get_layer("machines/forestry/chrome-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
	west = {
		layers = {
			DIR.get_layer("machines/forestry/chrome-forestry-shadow", 1, 1, true, nil, 1, 384, 256, 0, 768, 384, 256, {1,-12}),
			DIR.get_layer("machines/forestry/chrome-forestry-feet", 1, 1, false, nil, 1, 256, 256, 0, 768, 256, 256, {0,-12}),
			DIR.get_layer("machines/forestry/chrome-forestry-dome", 1, 1, false, nil, 1, 192, 192, 0, 0, 192, 192, {0,forestry_dome_vertical_offset}),
		}	
	},
}

data:extend({forestry})

------------------------------------------------------------------------------------------------------------------------------------------------------
