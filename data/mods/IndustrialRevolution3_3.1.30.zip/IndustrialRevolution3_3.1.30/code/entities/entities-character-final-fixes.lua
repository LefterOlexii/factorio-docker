------------------------------------------------------------------------------------------------------------------------------------------------------

-- Late pass on player characters

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Allow some other categories to be handcrafted, if character can use default crafting category

for _,character in pairs(data.raw.character) do
	if DIR.is_value_in_list(character.crafting_categories, "crafting") then
		character.crafting_categories = DIR.merge_and_return_unique(character.crafting_categories, {"crafting-small","module-loading"})
		DIR.spam_log("Character "..character.name.." given IR3 crafting categories")
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
