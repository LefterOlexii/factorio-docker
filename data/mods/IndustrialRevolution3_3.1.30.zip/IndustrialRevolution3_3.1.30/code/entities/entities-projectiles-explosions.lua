------------------------------------------------------------------------------------------------------------------------------------------------------

-- PROJECTILES AND EXPLOSIONS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- overwrite laser beam

local colour_y = DIR.laser_colours[settings.startup["ir-laser-colour"].value].index

local beam_speed = 0.5
local beam = {
	filename = DIR.projectiles_path .. "/laser-body.png",
	flags = {"trilinear-filtering"},
	line_length = 16,
	width = 64,
	height = 16,
	frame_count = 16,
	scale = 0.5,
	animation_speed = beam_speed,
	blend_mode = "additive",
	run_mode = "forward-then-backward",
	draw_as_glow = true,
	y = colour_y * 16,
}

data:extend({
	{
		type = "beam",
		name = "laser-beam",
		flags = {"not-on-map"},
		width = 0.5,
		damage_interval = 20,
		random_target_offset = true,
		action_triggered_automatically = false,
		action = {
			type = "direct",
			action_delivery = {
				type = "instant",
				target_effects = {
					{
						type = "damage",
						damage = {amount = 10, type = "laser"}
					},
					-- DIR.particle_effect("IR-laser-spark", 4, 0.2, 0),
				}
			}
		},
		head = beam,
		tail = beam,
		body = {beam},
		ending = {
			filename = DIR.projectiles_path .. "/laser-end.png",
			flags = {"trilinear-filtering"},
			line_length = 8,
			width = 64,
			height = 64,
			frame_count = 8,
			scale = 0.5,
			animation_speed = beam_speed,
			blend_mode = "additive",
			draw_as_glow = true,
			y = colour_y * 64,
			repeat_count = 4,
		},
		ground_light_animations = {
			head = {
				filename = "__base__/graphics/entity/laser-turret/laser-ground-light-head.png",
				line_length = 1,
				width = 256,
				height = 256,
				repeat_count = 32,
				scale = 0.5,
				shift = util.by_pixel(-32, 0),
				animation_speed = beam_speed,
				tint = DIR.multiply_colour(DIR.laser_colours[settings.startup["ir-laser-colour"].value].rgb, 0.5)
			},
			tail = {
				filename = "__base__/graphics/entity/laser-turret/laser-ground-light-tail.png",
				line_length = 1,
				width = 256,
				height = 256,
				repeat_count = 32,
				scale = 0.5,
				shift = util.by_pixel(32, 0),
				animation_speed = beam_speed,
				tint = DIR.multiply_colour(DIR.laser_colours[settings.startup["ir-laser-colour"].value].rgb, 0.5)
			},
			body = {
				filename = "__base__/graphics/entity/laser-turret/laser-ground-light-body.png",
				line_length = 1,
				width = 64,
				height = 256,
				repeat_count = 32,
				scale = 0.5,
				animation_speed = beam_speed,
				tint = DIR.multiply_colour(DIR.laser_colours[settings.startup["ir-laser-colour"].value].rgb, 0.5)
			}
		},
		working_sound = {
			sound = { filename = DIR.sound_path .. "/new-phaser-loop.ogg" },
			apparent_volume = 1,
			fade_in_ticks = 3,
			fade_out_ticks = 30
		}
	}
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- EMP beam
-- 2.2.4 - we use an invisible beam and not a direct effect because electric turret glow animation requires a beam with duration
-- actual beam visuals are via rendering api in the scripted effect

local emp_beam = {
    name = "emp-beam",
    type = "beam",
    flags = {"not-on-map"},
    width = 0.5,
    damage_interval = DIR.arc_turret_shooting_speed,
    random_target_offset = false,
    action_triggered_automatically = false,
    action = {
        {
            action_delivery = {
                target_effects = {
                    {
                        type = "create-sticker",
                        sticker = "emp-sticker"
                    },
                },
                type = "instant"
            },
            radius = DIR.arc_turret_jump_distance,
            type = "area"
        },
        {
            action_delivery = {
                target_effects = {
                    {
                        type = "script",
                        effect_id = "ir-emp-direct"
                    },
                    DIR.particle_effect("IR-emp-spark-particle-1", 15, 0.1, 0.5),
                    DIR.particle_effect("IR-emp-spark-particle-2", 15, 0.1, 0.5)
                },
                type = "instant"
            },
            type = "direct"
        }
    },
    head = standard_blank_sprite(64,1),
    tail = standard_blank_sprite(64,1),
    body = standard_blank_sprite(64,1),
    ground_light_animations = nil,
	working_sound = {
		sound = {
			filename = DIR.sound_path .. "/zap-loop.ogg",
			volume = 0.333,
		},
		fade_in_ticks = 3,
		fade_out_ticks = 10,
	}
}

data:extend({emp_beam})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- EMP sticker and animations

local sequence = {}
for i=1,16 do table.insert(sequence,1) end
for i=1,32 do table.insert(sequence,i) end

data:extend(
    {
        {
            name = "emp-sticker",
            type = "sticker",
            duration_in_ticks = DIR.arc_turret_shooting_speed,
            target_movement_modifier = 0.05,
            flags = {"not-on-map"},
			animation = {
				animation_speed = 1,
				blend_mode = "additive-soft",
				draw_as_glow = true,
				filename = DIR.projectiles_path .. "/emp-sticker.png",
				frame_count = 16,
				height = 64,
				line_length = 4,
				scale = 0.5,
				shift = {0,-1.5},
				width = 64,
			},
			stickers_per_square_meter = 1,
        },
    }
)

for variant = 0,7 do
	local x = 0
	local xg = 0
	for _,width in pairs({8,12,16}) do
		data:extend({
			{
				name = "lightning-"..width.."-"..(variant+1),
				type = "sprite",
				draw_as_glow = true,
				filename = DIR.projectiles_path .. "/lightning.png",
				priority = "extra-high",
				height = 256,
				width = width*64,
				scale = 0.5,
				blend_mode = "additive",
				flags = {"trilinear-filtering"},
				x = x,
				y = 256 * variant
			},
			{
				name = "lightning-ground-"..width.."-"..(variant+1),
				type = "sprite",
				draw_as_light = true,
				filename = DIR.projectiles_path .. "/lightning-ground.png",
				priority = "extra-high",
				height = 320,
				width = (width+1)*64,
				scale = 0.5,
				flags = {"trilinear-filtering"},
				x = xg,
				y = 320 * variant
			}
		})
		x = x + (width*64)
		xg = xg + (width+1)*64
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- "photon torpedo"

data:extend(
    {
        {
            type = "ammo-category",
            name = "photon-torpedo",
            bonus_gui_order = "kc"
        }
    }
)

data:extend(
    {
        {
            name = "photon-torpedo",
            type = "projectile",
            acceleration = 0,
            max_speed = 0.5,
            height = 1,
            hit_at_collision_position = true,
            action = {
                action_delivery = {
                    target_effects = {
                        {
                            entity_name = "photon-hit",
                            type = "create-entity"
                        },
                        {
                            entity_name = "photon-shock",
                            type = "create-entity"
                        },
                        {
                            damage = {
                                amount = 180,
                                type = "laser"
                            },
                            type = "damage"
                        },
                        {
                            check_buildability = true,
                            entity_name = "small-scorchmark",
                            type = "create-entity"
                        },
                        {
                            action = {
                                action_delivery = {
                                    target_effects = {
                                        {
                                            damage = {
                                                amount = 240,
                                                type = "explosion"
                                            },
                                            type = "damage"
                                        },
                                        {
                                            entity_name = "explosion",
                                            type = "create-entity"
                                        }
                                    },
                                    type = "instant"
                                },
                                radius = 4,
                                type = "area"
                            },
                            type = "nested-result"
                        }
                    },
                    type = "instant"
                },
                type = "direct"
            },
            animation = {
                layers = {
                    {
                        filename = DIR.projectiles_path .. "/photon.png",
                        blend_mode = "additive",
                        frame_count = 16,
                        line_length = 4,
                        height = 128,
                        priority = "high",
                        width = 128,
                        scale = 0.5,
                        draw_as_glow = true
                    }
                }
            },
            rotatable = false,
            light = {
                intensity = 1 / 3,
                size = 1,
                add_perspective = false,
                type = "oriented",
                picture = {
                    filename = DIR.projectiles_path .. "/photon-light.png",
                    blend_mode = "additive",
                    height = 90,
                    priority = "high",
                    width = 128,
                    scale = 0.5,
                    draw_as_glow = true
                }
            },
            collision_box = {{-0.5, -0.5}, {0.5, 0.5}},
            direction_only = true,
            flags = {"not-on-map"},
            force_condition = "not-same"
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- explosions

data:extend(
    {
        {
            name = "photon-hit",
            animations = {
                {
                    animation_speed = 1,
                    filename = DIR.projectiles_path .. "/photon-hit.png",
                    blend_mode = "additive",
                    frame_count = 64,
                    height = 128,
                    line_length = 8,
                    priority = "high",
                    width = 128,
                    scale = 0.5,
					draw_as_glow = true,
                },
            },
            flags = {
                "not-on-map",
                "placeable-off-grid"
            },
            light = {
                color = {
                    b = 0.25,
                    g = 0.5,
                    r = 1
                },
                intensity = 1,
                size = 10,
                add_perspective = true
            },
            sound = {
                aggregation = {
                    max_count = 1,
                    remove = true
                },
                variations = {
                    {
                        filename = DIR.base_sound_path .. "/fight/large-explosion-1.ogg",
                        volume = 0.8
                    },
                    {
                        filename = DIR.base_sound_path .. "/fight/large-explosion-2.ogg",
                        volume = 0.8
                    }
                }
            },
            created_effect = {
                type = "direct",
                action_delivery = {
                    type = "instant",
                    target_effects = {
                        DIR.particle_effect("IR-spark", 50, 0.1, 0.5)
                    }
                }
            },
            type = "explosion"
        },
        {
            name = "photon-shock",
            type = "explosion",
            flags = {
                "not-on-map",
                "placeable-off-grid"
            },
            rotate = false,
            animations = {
                {
                    animation_speed = 1,
                    filename = DIR.projectiles_path .. "/shock.png",
                    blend_mode = "additive",
                    frame_count = 16,
                    height = 256,
                    line_length = 4,
                    priority = "high",
                    width = 256,
                    scale = 1,
                    tint = {1.0, 0.75, 0.5},
					draw_as_glow = true,
                }
            }
        },
        {
            name = "emp-shock",
            type = "explosion",
            flags = {
                "not-on-map",
                "placeable-off-grid"
            },
            rotate = false,
			height = 0, -- position set by script
            animations = {
                {
                    animation_speed = 1,
                    filename = DIR.projectiles_path .. "/shock.png",
                    blend_mode = "additive",
                    frame_count = 16,
                    height = 256,
                    line_length = 4,
                    priority = "high",
                    width = 256,
                    scale = 1,
                    tint = DIR.hsva2rgba(0.55, 0.5, 0.5, 0.5),
					draw_as_glow = true,
                }
            },
            light = {
                color = {0.5, 0.9, 1.0},
                intensity = 1,
                size = 10,
                add_perspective = true
            }
        },
        {
            name = "photon-muzzle",
            type = "explosion",
            animations = {
                {
                    animation_speed = 0.5,
                    filename = DIR.projectiles_path .. "/photon-muzzle.png",
                    blend_mode = "additive",
                    frame_count = 8,
                    height = 64,
                    line_length = 8,
                    priority = "high",
                    width = 64,
                    scale = 0.5
                }
            },
            flags = {
                "not-on-map",
                "placeable-off-grid"
            },
			render_layer = "object",
            rotate = true
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------

for _,suffix in pairs({"","wood","solid","body"}) do
	data:extend({
		{
			name = (suffix == "") and "fetchport-projectile" or "fetchport-projectile-"..suffix,
			type = "projectile",
			acceleration = 0.01,
			turning_speed_increases_exponentially_with_projectile_speed = true,
			max_speed = 1,
			height = 0,
			hit_at_collision_position = false,
			rotatable = false,
			collision_box = {{-0.125, -0.125}, {0.125, 0.125}},
			direction_only = false,
			flags = {"not-on-map"},
			hit_collision_mask = {"player-layer"},
			force_condition = "same",
			action = (suffix ~= "") and {
				type = "direct",
                action_delivery = {
					type = "instant",
                    target_effects = {
						type = "play-sound",
						sound = {
							variations = {
								{
									filename = DIR.sound_path.."/"..suffix.."-impact-1.ogg",
									min_speed = 0.975,
									max_speed = 1.025,
									audible_distance_modifier = 0.5,
									volume = (suffix == "body") and 1 or 0.75
								},
								{
									filename = DIR.sound_path.."/"..suffix.."-impact-2.ogg",
									min_speed = 0.975,
									max_speed = 1.025,
									audible_distance_modifier = 0.5,
									volume = (suffix == "body") and 1 or 0.75
								},
								{
									filename = DIR.sound_path.."/"..suffix.."-impact-3.ogg",
									min_speed = 0.975,
									max_speed = 1.025,
									audible_distance_modifier = 0.5,
									volume = (suffix == "body") and 1 or 0.75
								},
							},
						},
						play_on_target_position = true,
					},
				},
			} or nil,
		}
	})
end

data:extend({
	{
		type = "sprite",
		name = "flying-item-shadow",
		filename = DIR.icon_path.."/32/flying-item-shadow.png",
		priority = "extra-high",
		width = 32,
		height = 16,
		scale = 1,
		draw_as_shadow = true,
	},
})

for _,affix in pairs({"entity","tile"}) do

	data:extend({
	  {
		type = "artillery-projectile",
		name = "itemcannon-projectile-"..affix,
		flags = {"not-on-map"},
		reveal_map = false,
		map_color = {r=1, g=1, b=0},
		rotatable = false,
		picture = nil,
		shadow =
		{
		  filename = DIR.icon_path.."/32/flying-item-shadow.png",
		  width = 32,
		  height = 16,
		  scale = 0.5
		},
		chart_picture = nil,
		action =
		{
		  type = "direct",
		  action_delivery =
		  {
			type = "instant",
			target_effects =
			{
				{
					type = "script",
					effect_id = "ir-itemcannon-projectile-"..affix,
				},
			}
		  }
		},
		height_from_ground = 4
	  },
	})

end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- zero-fireball explosions
data:extend({
	{
		name = "ir-smoke-explosion",
		type = "explosion",
		subgroup = "ir-explosions",
		animations = {
			{
				filename = "__base__/graphics/entity/smoke-fast/smoke-fast.png",
				priority = "high",
				width = 50,
				height = 50,
				frame_count = 16,
				animation_speed = 0.5,
				scale = 1,
				tint = {0.85,0.85,0.85},
			  }
		},
		smoke = "light-smoke",
		smoke_count = 3,
		smoke_slow_down_factor = 0.5,
		flags = {
			"not-on-map",
			"placeable-off-grid"
		},
		render_layer = "object",
		sound = DIR.vanilla_sounds.small_explosion(1)
	}
})
  
------------------------------------------------------------------------------------------------------------------------------------------------------
