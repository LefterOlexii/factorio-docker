------------------------------------------------------------------------------------------------------------------------------------------------------

-- DRILLS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper drill

local speed = DIR.basic_drill_speed
local energy = DIR.get_scaled_energy_usage(6, 0)

local drillbase = DIR.get_layer("machines/drills/copper-drill-base", 60, 10, false, nil, 0.5, 192, 256, 0, 0, 192, 256, {0,-0.25}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward")
local drillworking = DIR.get_layer("machines/drills/copper-drill-working", 60, 20, "glow", nil, 0.5, 64, 128, 0, 0, 64, 128, {0,-1.25}, "additive", DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward")
local drillshadow = DIR.get_layer("machines/drills/copper-drill-shadow", 60, 6, true, nil, 0.5, 320, 192, 0, 0, 320, 192, {1,0.25}, nil, nil, nil, nil, nil, "forward-then-backward")

local drill = {
	name = "burner-mining-drill",
	type = "mining-drill",
	icons = data.raw.item["burner-mining-drill"].icons,
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "burner-mining-drill"
	},
	graphics_set = {
		working_visualisations = {
			{
				animation = DIR.get_layer("machines/drills/copper-drill-underlay-rail", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
				always_draw = true,
				render_layer = "lower-object-above-shadow",
			},
			{
				north_animation = {
					layers = {
						DIR.get_layer("machines/drills/iron-drill-underlay-north-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
						DIR.get_layer("machines/drills/copper-drill-underlay-north", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
						drillshadow,
						drillbase,
					},
				},
				east_animation = {
					layers = {
						DIR.get_layer("machines/drills/iron-drill-underlay-east-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
						DIR.get_layer("machines/drills/copper-drill-underlay-east", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
						drillshadow,
						drillbase,
					},
				},
				south_animation = {
					layers = {
						DIR.get_layer("machines/drills/iron-drill-underlay-south-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
						DIR.get_layer("machines/drills/copper-drill-underlay-south", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
						drillshadow,
						drillbase,
					},
				},
				west_animation = {
					layers = {
						DIR.get_layer("machines/drills/iron-drill-underlay-west-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
						DIR.get_layer("machines/drills/copper-drill-underlay-west", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
						drillshadow,
						drillbase,
					},
				},
				always_draw = true,
				render_layer = "object",
			},
			{
				animation = drillworking,
				align_to_waypoint = false,
				-- draw_as_light = true,
				fadeout = true,
			},
		},
	},
	allowed_effects = {},
	base_render_layer = "object",
	circuit_connector_sprites = nil,
	circuit_wire_connection_points = nil,
	circuit_wire_max_distance = nil, --9
	dying_explosion = "medium-explosion",
	collision_box = { {-2.4,-2.4}, {2.4,2.4} },
	selection_box = { {-2.5,-2.5}, {2.5,2.5} },
	-- drawing_box = { {-1.5,-2.5}, {1.5,1.5} },
	corpse = "medium-remnants",
	energy_source = {
		effectivity = 1,
		emissions_per_minute = DIR.get_standard_emissions(speed*4),
		fuel_category = "chemical",
		fuel_inventory_size = 1,
		smoke = {
		  {
			deviation = {0.1, 0.1},
			frequency = 3,
			name = "smoke",
			north_position = {0,-1.65},
			east_position = {0,-1.65},
			south_position = {0,-1.65},
			west_position = {0,-1.65},
		  }
		},
		type = "burner",
		light_flicker = standard_zero_light_flicker(),
	},
	energy_usage = energy.active,
	fast_replaceable_group = "mining-drill",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	max_health = standard_health("copper",5),
	mining_speed = speed,
	monitor_visualization_tint = {
		r = 78,
		g = 173,
		b = 255,
	},
	radius_visualisation_picture = {
		filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
		height = 10,
		width = 10
	},
	resource_categories = {"basic-solid"},
	resource_searching_radius = 3.49,
	resistances = standard_resistances("copper"),
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	working_sound = {
		sound = {
		  filename = DIR.base_sound_path.."/burner-mining-drill.ogg",
		  volume = 0.8
		},
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	vector_to_place_result = {0, -2.85},
}

data:extend({drill})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steam drill

local energy = DIR.get_scaled_energy_usage(2, 0) -- one copper boiler can run 3 drills

local drill = table.deepcopy(drill)
drill.name = "steam-drill"
drill.minable.result = "steam-drill"
drill.energy_usage = energy.active
drill.icons = data.raw.item["steam-drill"].icons,
table.remove(drill.graphics_set.working_visualisations) -- steam doesn't glow

drill.energy_source = {
	type = "fluid",
	emissions_per_minute = DIR.get_standard_emissions(speed*4),
	fluid_box = {
        filter = "steam",
        base_area = 1,
        base_level = -1,
        height = 2,
        production_type = "input-output",
        pipe_connections = {
            { type="input-output", position = {3, 0} },
            { type="input-output", position = {-3, 0} },
        },
        pipe_picture = {
			north = {
				layers = {
					DIR.get_layer("machines/drills/steam-drill-connectors-base", nil, nil, false, nil, nil, 120, 120, 152, 0, 384, 384, {0,3}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/steam-drill-connectors-shadow", nil, nil, true, nil, nil, 120, 120, 132, 0, 384, 384, {0.5,3}),
				},
			},
			south = {
				layers = {
					DIR.get_layer("machines/drills/steam-drill-connectors-base", nil, nil, false, nil, nil, 120, 120, 152, 264, 384, 384, {0,-3}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/steam-drill-connectors-shadow", nil, nil, true, nil, nil, 120, 120, 132, 264, 384, 384, {0.5,-3}),
				},
			},
			east = {
				layers = {
					DIR.get_layer("machines/drills/steam-drill-connectors-base", nil, nil, false, nil, nil, 160, 80, 224, 152, 384, 384, {-3,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/steam-drill-connectors-shadow", nil, nil, true, nil, nil, 160, 80, 224, 152, 384, 384, {-3+0.5,0}),
				},
			},
			west = {
				layers = {
					DIR.get_layer("machines/drills/steam-drill-connectors-base", nil, nil, false, nil, nil, 160, 80, 0, 152, 384, 384, {3,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/steam-drill-connectors-shadow", nil, nil, true, nil, nil, 160, 80, 0, 152, 384, 384, {3+0.5,0}),
				},
			},
		},
        pipe_covers = DIR.pipe_covers.steam,
        secondary_draw_order = -1,
    },
	maximum_temperature = 165,
	scale_fluid_usage = DIR.scale_steam_machine_fluid_usage,
	light_flicker = standard_zero_light_flicker(),
	smoke = {
	  {
		deviation = {0.1, 0.1},
		frequency = 3,
		name = "smoke",
		north_position = {0,-1.65},
		east_position = {0,-1.65},
		south_position = {0,-1.65},
		west_position = {0,-1.65},
	  }
	},
}

data:extend({drill})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- electric (iron) drill

local speed = DIR.basic_drill_speed * 2
local energy = DIR.get_scaled_energy_usage(4, 0)
local circuits = circuit_connector_definitions.create (
    universal_connector_template,
    {
		{ variation = 4, main_offset = util.by_pixel_hr(-10, -162), shadow_offset = util.by_pixel_hr(0, -152), show_shadow = true },
		{ variation = 2, main_offset = util.by_pixel_hr(154, -5), shadow_offset = util.by_pixel_hr(164, 5), show_shadow = true },
		{ variation = 0, main_offset = util.by_pixel_hr(10, 142), shadow_offset = util.by_pixel_hr(20, 152), show_shadow = true },
		{ variation = 6, main_offset = util.by_pixel_hr(-154, 5), shadow_offset = util.by_pixel_hr(-144, 15), show_shadow = true },
	}
)

local graphics_set = {
	working_visualisations = {
		{
			animation = DIR.get_layer("machines/drills/iron-drill-underlay-rail", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
			always_draw = true,
			render_layer = "lower-object-above-shadow",
		},
		{
			north_animation = {
				layers = {
					DIR.get_layer("machines/drills/iron-drill-underlay-north-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
					DIR.get_layer("machines/drills/iron-drill-underlay-north", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/iron-drill-shadow", 60, 6, true, nil, 0.5, 384, 224, 0, 0, 384, 224, {1,0}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/iron-drill-base", 60, 10, false, nil, 0.5, 256, 256, 0, 0, 256, 256, {0,-0.75}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			east_animation = {
				layers = {
					DIR.get_layer("machines/drills/iron-drill-underlay-east-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
					DIR.get_layer("machines/drills/iron-drill-underlay-east", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/iron-drill-shadow", 60, 6, true, nil, 0.5, 384, 224, 0, 0, 384, 224, {1,0}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/iron-drill-base", 60, 10, false, nil, 0.5, 256, 256, 0, 0, 256, 256, {0,-0.75}, nil, nil, nil, nil, nil, "forward-then-backward"),
				},
			},
			south_animation = {
				layers = {
					DIR.get_layer("machines/drills/iron-drill-underlay-south-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
					DIR.get_layer("machines/drills/iron-drill-underlay-south", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/iron-drill-shadow", 60, 6, true, nil, 0.5, 384, 224, 0, 0, 384, 224, {1,0}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/iron-drill-base", 60, 10, false, nil, 0.5, 256, 256, 0, 0, 256, 256, {0,-0.75}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			west_animation = {
				layers = {
					DIR.get_layer("machines/drills/iron-drill-underlay-west-shadow", 1, 1, true, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}),
					DIR.get_layer("machines/drills/iron-drill-underlay-west", 1, 1, false, 120, 0.5, 384, 384, 0, 0, 384, 384, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/iron-drill-shadow", 60, 6, true, nil, 0.5, 384, 224, 0, 0, 384, 224, {1,0}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/iron-drill-base", 60, 10, false, nil, 0.5, 256, 256, 0, 0, 256, 256, {0,-0.75}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			always_draw = true,
			render_layer = "object",
		},
		{
			align_to_waypoint = false,
			animation = DIR.get_layer("machines/drills/iron-drill-working", 120, 10, "glow", nil, 0.5, 128, 160, 0, 0, 128, 160, {0,-0.25}, "additive-soft", DIR.general_sprite_flags),
			apply_tint = "status",
			always_draw = true,
		},
	},
	status_colors = standard_status_colours(),
}

local wet_mining_graphics_set = table.deepcopy(graphics_set)

table.insert(wet_mining_graphics_set.working_visualisations,
{
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-patch-north-shadow", nil, nil, true, 120, 0.5, 448, 384, 0, 0, 448, 384, {0.5,0}),
			DIR.get_layer("machines/drills/iron-drill-connector-south", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-east", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-west", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {-1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-se", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {1.5,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-sw", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {-1.5,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-shadow-se", 60, 10, false, nil, 0.5, 64, 128, 0, 0, 64, 128, {2,1}, nil, nil, nil, nil, nil, "forward-then-backward"),
		}
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-patch-east-shadow", nil, nil, true, 120, 0.5, 448, 384, 0, 0, 448, 384, {0.5,0}),
			DIR.get_layer("machines/drills/iron-drill-connector-north", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-south", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-west", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {-1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-nw", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {-1.5,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-sw", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {-1.5,1.5}, nil, DIR.general_sprite_flags),
		}
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-patch-south-shadow", nil, nil, true, 120, 0.5, 448, 384, 0, 0, 448, 384, {0.5,0}),
			DIR.get_layer("machines/drills/iron-drill-connector-north", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-east", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-west", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {-1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-ne", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {1.5,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-nw", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {-1.5,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-shadow-ne", 60, 10, false, nil, 0.5, 64, 128, 0, 0, 64, 128, {2,-1}, nil, nil, nil, nil, nil, "forward-then-backward"),
		}
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-patch-west-shadow", nil, nil, true, 120, 0.5, 448, 384, 0, 0, 448, 384, {0.5,0}),
			DIR.get_layer("machines/drills/iron-drill-connector-north", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-south", nil, nil, false, 120, 0.5, 80, 192, 0, 0, 80, 192, {0,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-connector-east", nil, nil, false, 120, 0.5, 192, 80, 0, 0, 192, 80, {1.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-ne", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {1.5,-1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-se", nil, nil, false, 120, 0.5, 192, 192, 0, 0, 192, 192, {1.5,1.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-pipes-shadow-ne", 60, 10, false, nil, 0.5, 64, 128, 0, 0, 64, 128, {2,-1}, nil, nil, nil, nil, nil, "forward-then-backward"),
			DIR.get_layer("machines/drills/iron-drill-pipes-shadow-se", 60, 10, false, nil, 0.5, 64, 128, 0, 0, 64, 128, {2,1}, nil, nil, nil, nil, nil, "forward-then-backward"),
		}
	},
	always_draw = true,
	secondary_draw_order = -50,
})

table.insert(wet_mining_graphics_set.working_visualisations, {
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	always_draw = true,
	apply_tint = "input-fluid-base-color",
})
            
table.insert(wet_mining_graphics_set.working_visualisations, {
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive", DIR.general_sprite_flags),
		},
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive", DIR.general_sprite_flags),
		},
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-2.0,0}, "additive", DIR.general_sprite_flags),
		},
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-2.0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {2.0,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,2.0}, "additive", DIR.general_sprite_flags),
		},
	},
	always_draw = true,
	apply_tint = "input-fluid-flow-color",
})

local drill = {
	name = "electric-mining-drill",
	type = "mining-drill",
	icon = DIR.get_icon_path("electric-mining-drill"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "electric-mining-drill"
	},
	allowed_effects = {
        "consumption",
        "speed",
		"productivity",
        "pollution"
	},
	module_specification = {
		module_info_icon_shift = {0,1.25},
		module_slots = 2
	},
	graphics_set = graphics_set,
	wet_mining_graphics_set = wet_mining_graphics_set,
	input_fluid_box = {
        base_area = 1,
        base_level = -1,
        height = 2,
        pipe_connections = {
			{ position = { -3, 0 } },
			{ position = { 3, 0 } },
			{ position = { 0, 3 } },
        },
        pipe_covers = DIR.pipe_covers.iron,
		production_type = "input-output",
	},
	base_render_layer = "object",
	circuit_connector_sprites = circuits.sprites,
	circuit_wire_connection_points = circuits.points,
	circuit_wire_max_distance = default_circuit_wire_max_distance,
	collision_box = { {-2.4,-2.4}, {2.4,2.4} },
	selection_box = { {-2.5,-2.5}, {2.5,2.5} },
	corpse = "medium-remnants",
	dying_explosion = "medium-explosion",
	energy_source = {
		emissions_per_minute = DIR.get_standard_emissions(speed*4),
		usage_priority = "secondary-input",
		drain = energy.passive,
		type = "electric"
	},
	energy_usage = energy.active,
	fast_replaceable_group = "mining-drill",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	max_health = standard_health("iron",5),
	mining_speed = speed,
	monitor_visualization_tint = {
		r = 78,
		g = 173,
		b = 255,
	},
	radius_visualisation_picture = {
		filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
		height = 10,
		width = 10
	},
	resource_categories = {"basic-solid"},
	resource_searching_radius = 4.49,
	resistances = standard_resistances("iron"),
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	working_sound = {
		sound = {
		  filename = DIR.base_sound_path.."/electric-mining-drill.ogg",
		  volume = 0.8
		},
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	vector_to_place_result = {0, -2.85},
}

data:extend({drill})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- chrome drill

local speed = DIR.basic_drill_speed * 3
local energy = DIR.get_scaled_energy_usage(5, 0)
local circuits = circuit_connector_definitions.create (
    universal_connector_template,
    {
		{ variation = 4, main_offset = util.by_pixel_hr(-10, -226), shadow_offset = util.by_pixel_hr(0, -216), show_shadow = true },
		{ variation = 2, main_offset = util.by_pixel_hr(218, -5), shadow_offset = util.by_pixel_hr(228, 5), show_shadow = true },
		{ variation = 0, main_offset = util.by_pixel_hr(10, 206), shadow_offset = util.by_pixel_hr(20, 196), show_shadow = true },
		{ variation = 6, main_offset = util.by_pixel_hr(-218, 5), shadow_offset = util.by_pixel_hr(-208, 15), show_shadow = true },
	}
)

local graphics_set = {
	working_visualisations = {
		{
			animation = DIR.get_layer("machines/drills/chrome-drill-underlay-rail", 1, 1, false, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}, nil, DIR.general_sprite_flags),
			always_draw = true,
			render_layer = "lower-object-above-shadow",
		},
		{
			north_animation = {
				layers = {
					DIR.get_layer("machines/drills/chrome-drill-underlay-north-shadow", nil, nil, true, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}),
					DIR.get_layer("machines/drills/chrome-drill-underlay-north", nil, nil, false, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/chrome-drill-shadow", 60, 6, true, nil, 0.5, 544, 288, 0, 0, 544, 288, {1.25,0.25}, nil, nil, nil, nil, nil, "forward-then-backward"),	
					DIR.get_layer("machines/drills/chrome-drill-base", 60, 10, false, nil, 0.5, 320, 384, 0, 0, 320, 384, {0,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			east_animation = {
				layers = {
					DIR.get_layer("machines/drills/chrome-drill-underlay-east-shadow", nil, nil, true, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}),
					DIR.get_layer("machines/drills/chrome-drill-underlay-east", nil, nil, false, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/chrome-drill-shadow", 60, 6, true, nil, 0.5, 544, 288, 0, 0, 544, 288, {1.25,0.25}, nil, nil, nil, nil, nil, "forward-then-backward"),	
					DIR.get_layer("machines/drills/chrome-drill-base", 60, 10, false, nil, 0.5, 320, 384, 0, 0, 320, 384, {0,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			south_animation = {
				layers = {
					DIR.get_layer("machines/drills/chrome-drill-underlay-south-shadow", nil, nil, true, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}),
					DIR.get_layer("machines/drills/chrome-drill-underlay-south", nil, nil, false, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/chrome-drill-shadow", 60, 6, true, nil, 0.5, 544, 288, 0, 0, 544, 288, {1.25,0.25}, nil, nil, nil, nil, nil, "forward-then-backward"),	
					DIR.get_layer("machines/drills/chrome-drill-base", 60, 10, false, nil, 0.5, 320, 384, 0, 0, 320, 384, {0,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			west_animation = {
				layers = {
					DIR.get_layer("machines/drills/chrome-drill-underlay-west-shadow", nil, nil, true, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}),
					DIR.get_layer("machines/drills/chrome-drill-underlay-west", nil, nil, false, 120, 0.5, 512, 512, 0, 0, 512, 512, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/chrome-drill-shadow", 60, 6, true, nil, 0.5, 544, 288, 0, 0, 544, 288, {1.25,0.25}, nil, nil, nil, nil, nil, "forward-then-backward"),	
					DIR.get_layer("machines/drills/chrome-drill-base", 60, 10, false, nil, 0.5, 320, 384, 0, 0, 320, 384, {0,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				},
			},
			always_draw = true,
			render_layer = "object",
		},
		{
			align_to_waypoint = false,
			animation = DIR.get_layer("machines/drills/chrome-drill-working", 120, 10, "glow", nil, 0.5, 256, 224, 0, 0, 256, 224, {0,-0.25}, "additive-soft", DIR.general_sprite_flags),
			apply_tint = "status",
			always_draw = true,
		},
	},
	status_colors = standard_status_colours(),
}

local wet_mining_graphics_set = table.deepcopy(graphics_set)

table.insert(wet_mining_graphics_set.working_visualisations,
{
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/chrome-drill-patch-north-shadow", nil, nil, true, 120, nil, 544, 512, 0, 0, 544, 512, {0.25,0}),
			DIR.get_layer("machines/drills/chrome-drill-connector-south", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-east", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-west", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {-2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-se", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {2,2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-sw", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {-2,2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-shadow-se", 60, 10, false, nil, 0.5, 64, 192, 0, 0, 64, 192, {3,1.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
		},
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/chrome-drill-patch-east-shadow", nil, nil, true, 120, nil, 544, 512, 0, 0, 544, 512, {0.25,0}),
			DIR.get_layer("machines/drills/chrome-drill-connector-north", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,-2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-south", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-west", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {-2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-nw", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {-2,-2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-sw", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {-2,2}, nil, DIR.general_sprite_flags),
		},
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/chrome-drill-patch-south-shadow", nil, nil, true, 120, nil, 544, 512, 0, 0, 544, 512, {0.25,0}),
			DIR.get_layer("machines/drills/chrome-drill-connector-north", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,-2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-east", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-west", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {-2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-ne", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {2,-2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-nw", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {-2,-2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-shadow-ne", 60, 10, false, nil, 0.5, 64, 192, 0, 0, 64, 192, {3,-1.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
		},
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/chrome-drill-patch-west-shadow", nil, nil, true, 120, nil, 544, 512, 0, 0, 544, 512, {0.25,0}),
			DIR.get_layer("machines/drills/chrome-drill-connector-north", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,-2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-south", nil, nil, false, 120, 0.5, 128, 192, 0, 0, 128, 192, {0,2.5}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-connector-east", nil, nil, false, 120, 0.5, 192, 128, 0, 0, 192, 128, {2.5,0}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-ne", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {2,-2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-se", nil, nil, false, 120, 0.5, 256, 256, 0, 0, 256, 256, {2,2}, nil, DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/chrome-drill-pipes-shadow-ne", 60, 10, false, nil, 0.5, 64, 192, 0, 0, 64, 192, {3,-1.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
			DIR.get_layer("machines/drills/chrome-drill-pipes-shadow-se", 60, 10, false, nil, 0.5, 64, 192, 0, 0, 64, 192, {3,1.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
		},
	},
	always_draw = true,
	secondary_draw_order = -50,
})

table.insert(wet_mining_graphics_set.working_visualisations, {
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-base-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive-soft", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-base-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive-soft", DIR.general_sprite_flags),
		},
	},
	always_draw = true,
	apply_tint = "input-fluid-base-color",
})
            
table.insert(wet_mining_graphics_set.working_visualisations, {
	north_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive", DIR.general_sprite_flags),
		},
	},
	east_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive", DIR.general_sprite_flags),
		},
	},
	south_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-w", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {-3,0}, "additive", DIR.general_sprite_flags),
		},
	},
	west_animation = {
		layers = {
			DIR.get_layer("machines/drills/iron-drill-window-flow-n", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,-3}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-e", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {3,0}, "additive", DIR.general_sprite_flags),
			DIR.get_layer("machines/drills/iron-drill-window-flow-s", nil, nil, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,3}, "additive", DIR.general_sprite_flags),
		},
	},
	always_draw = true,
	apply_tint = "input-fluid-flow-color",
})


local drill = {
	name = "chrome-drill",
	type = "mining-drill",
	icon = DIR.get_icon_path("chrome-drill"),
	icon_size = DIR.icon_size,
	icon_mipmaps = DIR.icon_mipmaps,
	minable = {
		mining_time = DIR.standard_pickup_time,
		result = "chrome-drill"
	},
	allowed_effects = {
        "consumption",
        "speed",
		"productivity",
        "pollution"
	},
	module_specification = {
		module_info_icon_shift = {0,1.5},
		module_slots = 2
	},
	graphics_set = graphics_set,
	wet_mining_graphics_set = wet_mining_graphics_set,
	input_fluid_box = {
        base_area = 1,
        base_level = -1,
        height = 2,
        pipe_connections = {
			{ position = { -4, 0 } },
			{ position = { 4, 0 } },
			{ position = { 0, 4 } },
        },
        pipe_covers = DIR.pipe_covers.iron,
		production_type = "input-output",
	},
	base_render_layer = "object",
	circuit_connector_sprites = circuits.sprites,
	circuit_wire_connection_points = circuits.points,
	circuit_wire_max_distance = default_circuit_wire_max_distance,
	collision_box = { {-3.4,-3.4}, {3.4,3.4} },
	corpse = "medium-remnants",
	dying_explosion = "medium-explosion",
	energy_source = {
		emissions_per_minute = DIR.get_standard_emissions(speed*4),
		usage_priority = "secondary-input",
		drain = energy.passive,
		type = "electric"
	},
	energy_usage = energy.active,
	fast_replaceable_group = "mining-drill",
	flags = {"placeable-player", "placeable-neutral", "player-creation"},
	max_health = standard_health("chrome",5),
	mining_speed = speed,
	monitor_visualization_tint = {
		r = 78,
		g = 173,
		b = 255,
	},
	radius_visualisation_picture = {
		filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
		height = 10,
		width = 10
	},
	resource_categories = {"basic-solid"},
	resource_searching_radius = 5.49,
	resistances = standard_resistances("chrome"),
	selection_box = { {-3.5,-3.5}, {3.5,3.5} },
	vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
	working_sound = {
		sound = {
		  filename = DIR.sound_path.."/heavy-drill.ogg",
		  volume = 1
		},
		fade_in_ticks = 10,
		fade_out_ticks = 30,
	},
	vector_to_place_result = {0, -3.85},
}

data:extend({drill})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- derricks

local circuits = circuit_connector_definitions.create (
    universal_connector_template,
    {
		{ variation = 7, main_offset = util.by_pixel_hr(-31, -82), shadow_offset = util.by_pixel_hr(-21, -72), show_shadow = true },
		{ variation = 7, main_offset = util.by_pixel_hr(-31, -82), shadow_offset = util.by_pixel_hr(-21, -72), show_shadow = true },
		{ variation = 7, main_offset = util.by_pixel_hr(-31, -82), shadow_offset = util.by_pixel_hr(-21, -72), show_shadow = true },
		{ variation = 7, main_offset = util.by_pixel_hr(-31, -82), shadow_offset = util.by_pixel_hr(-21, -72), show_shadow = true },
	}
)

for _,material in pairs({"copper","steel"}) do
	local graphics_set = {
		animation = {
			north = {
				layers = {
					DIR.get_layer("machines/drills/derrick-base-shadow", 1, 1, true, 120, DIR.anim_speed, 384, 256, 0, 0, 384, 256, {1.5,0.5}),
					DIR.get_layer("machines/drills/derrick-working-shadow", 60, 6, true, nil, DIR.anim_speed, 256, 128, 0, 0, 256, 128, {1.5,0.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/"..material.."-derrick-base", 1, 1, false, 120, DIR.anim_speed, 192, 320, 0, 0, 192, 320, {0,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/"..material.."-derrick-working", 60, 10, false, nil, DIR.anim_speed, 128, 256, 0, 0, 128, 256, {0.5,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				}
			},
			east = {
				layers = {
					DIR.get_layer("machines/drills/derrick-base-shadow", 1, 1, true, 120, DIR.anim_speed, 384, 256, 384, 0, 384, 256, {1.5-6,0.5}),
					DIR.get_layer("machines/drills/derrick-working-shadow", 60, 6, true, nil, DIR.anim_speed, 256, 128, 0, 0, 256, 128, {1.5,0.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/"..material.."-derrick-base", 1, 1, false, 120, DIR.anim_speed, 192, 320, 192, 0, 192, 320, {-3,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/"..material.."-derrick-working", 60, 10, false, nil, DIR.anim_speed, 128, 256, 0, 0, 128, 256, {0.5,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				}
			},
			south = {
				layers = {
					DIR.get_layer("machines/drills/derrick-base-shadow", 1, 1, true, 120, DIR.anim_speed, 384, 256, 768, 0, 384, 256, {1.5-12,0.5}),
					DIR.get_layer("machines/drills/derrick-working-shadow", 60, 6, true, nil, DIR.anim_speed, 256, 128, 0, 0, 256, 128, {1.5,0.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/"..material.."-derrick-base", 1, 1, false, 120, DIR.anim_speed, 192, 320, 384, 0, 192, 320, {-6,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/"..material.."-derrick-working", 60, 10, false, nil, DIR.anim_speed, 128, 256, 0, 0, 128, 256, {0.5,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				}
			},
			west = {
				layers = {
					DIR.get_layer("machines/drills/derrick-base-shadow", 1, 1, true, 120, DIR.anim_speed, 384, 256, 1152, 0, 384, 256, {1.5-18,0.5}),
					DIR.get_layer("machines/drills/derrick-working-shadow", 60, 6, true, nil, DIR.anim_speed, 256, 128, 0, 0, 256, 128, {1.5,0.5}, nil, nil, nil, nil, nil, "forward-then-backward"),
					DIR.get_layer("machines/drills/"..material.."-derrick-base", 1, 1, false, 120, DIR.anim_speed, 192, 320, 576, 0, 192, 320, {-9,0}, nil, DIR.general_sprite_flags),
					DIR.get_layer("machines/drills/"..material.."-derrick-working", 60, 10, false, nil, DIR.anim_speed, 128, 256, 0, 0, 128, 256, {0.5,-0.5}, nil, DIR.general_sprite_flags, nil, nil, nil, "forward-then-backward"),
				}
			},
		},	
		working_visualisations = (material ~= "copper") and {
			{
				animation = DIR.get_layer("machines/drills/"..material.."-derrick-working-glow", 30, 6, "glow", nil, 0.5, 64, 64, 0, 0, 64, 64, {-1,-0.5}, "additive-soft", DIR.general_sprite_flags),
				align_to_waypoint = false,
				always_draw = true,
				apply_tint = "status",
				light = {
					intensity = 0.333,
					size = 1.5,
					shift = {-1,0.75},
				},
			},
		} or nil,
		status_colors = standard_status_colours(),
	}

	local name = material.."-derrick"
	local speed = 1
	local energy = DIR.get_scaled_energy_usage(0.5, 0)

	local drill = {
		name = name,
		type = "mining-drill",
		icon = DIR.get_icon_path(name),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		minable = {
			mining_time = DIR.standard_pickup_time,
			result = name,
		},
		circuit_connector_sprites = (material ~= "copper") and circuits.sprites or nil,
		circuit_wire_connection_points = (material ~= "copper") and circuits.points or nil,
		circuit_wire_max_distance = (material ~= "copper") and default_circuit_wire_max_distance or nil,
		graphics_set = graphics_set,
		output_fluid_box = {
			base_area = 10,
			base_level = 1,
			pipe_connections = {
				{ 
					position = { 0, -2 },
					type = "output",
				},
			},
			pipe_covers = DIR.pipe_covers.iron,
		},
		base_render_layer = "object",
		corpse = "medium-remnants",
		energy_source = (material == "copper") and {
			usage_priority = "secondary-input",
			type = "void"
		} or {
			emissions_per_minute = DIR.get_standard_emissions(1),
			usage_priority = "secondary-input",
			drain = energy.passive,
			type = "electric"
		},
		energy_usage = (material == "copper") and "1W" or energy.active,
		module_specification = (material ~= "copper") and {
			module_info_icon_shift = {0,0.75},
			module_slots = 2
		} or nil,
		allowed_effects = (material ~= "copper") and {
			"consumption",
			"speed",
			"productivity",
			"pollution"
		} or {},
		fast_replaceable_group = "derrick",
		flags = {"placeable-player", "placeable-neutral", "player-creation"},
		max_health = standard_health(material,3),
		mining_speed = 1,
		resource_categories = (material == "copper") and {"ir-steam"} or {"ir-gas","ir-steam"},
		resource_searching_radius = 0.49,
		resistances = standard_resistances(material),
		collision_box = standard_3x3_collision(),
		selection_box = standard_3x3_selection(),
		vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
		working_sound = table.deepcopy(data.raw["mining-drill"]["pumpjack"].working_sound),
		vector_to_place_result = {0, 0},
		-- monitor_visualization_tint = {
			-- r = 78,
			-- g = 173,
			-- b = 255,
		-- },
		-- radius_visualisation_picture = {
			-- filename = "__base__/graphics/entity/electric-mining-drill/electric-mining-drill-radius-visualization.png",
			-- height = 10,
			-- width = 10
		-- },
	}

	data:extend({drill})

end


------------------------------------------------------------------------------------------------------------------------------------------------------
