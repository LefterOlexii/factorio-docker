------------------------------------------------------------------------------------------------------------------------------------------------------

-- try, for the love of God, to very roughly match inserter speeds to IR's standard crafting times

-- burner inserter

data.raw.inserter["burner-inserter"].allow_burner_leech = true
data.raw.inserter["burner-inserter"].extension_speed = DIR.standard_inserter_extension
data.raw.inserter["burner-inserter"].rotation_speed = DIR.standard_inserter_rotation
data.raw.inserter["burner-inserter"].energy_per_rotation = "10kJ"
data.raw.inserter["burner-inserter"].energy_per_movement = "10kJ"
data.raw.inserter["burner-inserter"].energy_source.light_flicker = standard_zero_light_flicker()
data.raw.inserter["burner-inserter"].circuit_connector_sprites = nil
data.raw.inserter["burner-inserter"].circuit_wire_connection_points = nil
data.raw.inserter["burner-inserter"].circuit_wire_max_distance = nil
data.raw.inserter["burner-inserter"].localised_description = {"entity-description.burner-inserter"}

-- yellow inserter

data.raw.inserter["inserter"].extension_speed = DIR.standard_inserter_extension
data.raw.inserter["inserter"].rotation_speed = DIR.standard_inserter_rotation

-- red inserter

data.raw.inserter["long-handed-inserter"].extension_speed = DIR.standard_inserter_extension
data.raw.inserter["long-handed-inserter"].rotation_speed = DIR.standard_inserter_rotation

-- blue inserter

data.raw.inserter["fast-inserter"].extension_speed = DIR.standard_inserter_extension * 2
data.raw.inserter["fast-inserter"].rotation_speed = DIR.standard_inserter_rotation * 2

-- purple inserter

data.raw.inserter["filter-inserter"].extension_speed = DIR.standard_inserter_extension * 2
data.raw.inserter["filter-inserter"].rotation_speed = DIR.standard_inserter_rotation * 2

-- green inserter

data.raw.inserter["stack-inserter"].extension_speed = DIR.standard_inserter_extension * 2
data.raw.inserter["stack-inserter"].rotation_speed = DIR.standard_inserter_rotation * 2

-- white inserter

data.raw.inserter["stack-filter-inserter"].extension_speed = DIR.standard_inserter_extension * 2
data.raw.inserter["stack-filter-inserter"].rotation_speed = DIR.standard_inserter_rotation * 2

-- put vanilla filter inserters into same upgrade group

data.raw.inserter["filter-inserter"].fast_replaceable_group = "filter-inserter"
data.raw.inserter["filter-inserter"].next_upgrade = "stack-filter-inserter"
data.raw.inserter["stack-filter-inserter"].fast_replaceable_group = "filter-inserter"
data.raw.inserter["stack-filter-inserter"].filter_count = 5

------------------------------------------------------------------------------------------------------------------------------------------------------

-- steam inserter

local inserter = table.deepcopy(data.raw.inserter["burner-inserter"])

inserter.name = "steam-inserter"
inserter.localised_description = {"entity-description.steam-inserter"}
inserter.minable.result = "steam-inserter"
inserter.fast_replaceable_group = "pipe"
inserter.icon = DIR.get_icon_path("steam-inserter")
inserter.icon_size = DIR.icon_size
inserter.icon_mipmaps = DIR.icon_mipmaps
inserter.selection_box = { {-0.5,-0.5}, {0.5,0.5} }
inserter.collision_box = { {-0.49,-0.49}, {0.49,0.49} }
inserter.energy_source = {
	type = "fluid",
	fluid_box = {
		filter = "steam",
		base_area = 1,
		base_level = -1,
		height = 2,
		production_type = "input-output",
		pipe_connections = {
			{ type="input-output", position = {1, 0} },
			{ type="input-output", position = {-1, 0} },
		},
		pipe_covers = DIR.pipe_covers.steam,
	},
	maximum_temperature = 165,
	fluid_usage_per_tick = 0.0186666666666667, -- ughhhhh
	light_flicker = standard_zero_light_flicker(),
}	
table.insert(inserter.flags, "hide-alt-info")
table.insert(inserter.flags, "not-upgradable")

-- we have to use integration_patch instead of the proper platform sprite because of shadow issues (has specifiable render layer)
inserter.platform_picture = standard_blank_sprite()

local function wacky_inserter_integration_patch_shenanigans(x_offset)
	return {
		{
			filename = DIR.entities_path_2.."/inserters/steam-inserter-platform.png",
			height = 120,
			width = 180,
			priority = "extra-high",
			scale = 0.5,
			x = x_offset,
		},
		{
			filename = DIR.entities_path_2.."/inserters/steam-inserter-shadow.png",
			height = 120,
			width = 180,
			priority = "extra-high",
			scale = 0.5,
			draw_as_shadow = true,
			x = x_offset,
		},	
	}
end

inserter.integration_patch = {
    -- turns out that inserter platform_picture and integration_patch give sheets opposing directions, sigh
    -- specify each direction manually instead rather than make the sprite sheet different to every other inserter
	south = {
		layers = wacky_inserter_integration_patch_shenanigans(0),
	},
	west = {
		layers = wacky_inserter_integration_patch_shenanigans(180),
	},
	north = {
		layers = wacky_inserter_integration_patch_shenanigans(360),
	},
	east = {
		layers = wacky_inserter_integration_patch_shenanigans(540),
	},
}
inserter.integration_patch_render_layer = "object"

data:extend({inserter})

-------------------------------------------------------------------------------------

-- orange filter inserter

local inserter = table.deepcopy(data.raw.inserter["inserter"])
inserter.name = "slow-filter-inserter"
inserter.icon = DIR.get_icon_path("slow-filter-inserter")
inserter.icon_size = DIR.icon_size
inserter.icon_mipmaps = DIR.icon_mipmaps
inserter.filter_count = 5
inserter.fast_replaceable_group = "filter-inserter"
inserter.next_upgrade = "filter-inserter"
inserter.minable.result = "slow-filter-inserter"

inserter.platform_picture = {
    sheet = {
        filename = DIR.entities_path_2.."/inserters/hr-orange-inserter-platform.png",
        height = 79,
        priority = "extra-high",
        scale = 0.5,
        shift = {
            0.046875,
            0.203125
        },
		width = 105
    }
}
inserter.hand_base_picture = {
    filename = DIR.entities_path_2.."/inserters/hr-orange-inserter-hand-base.png",
    height = 136,
    priority = "extra-high",
    scale = 0.25,
    width = 32
}
inserter.hand_closed_picture = {
    filename = DIR.entities_path_2.."/inserters/hr-orange-inserter-hand-closed.png",
    height = 164,
    priority = "extra-high",
    scale = 0.25,
    width = 72
}
inserter.hand_open_picture = {
    filename = DIR.entities_path_2.."/inserters/hr-orange-inserter-hand-open.png",
    height = 164,
    priority = "extra-high",
    scale = 0.25,
    width = 72
}

data:extend({inserter})

-------------------------------------------------------------------------------------

-- long steam inserter

local inserter = table.deepcopy(data.raw.inserter["steam-inserter"])

inserter.name = "long-handed-steam-inserter"
inserter.energy_per_rotation = "15kJ"
inserter.energy_per_movement = "15kJ"
inserter.energy_source.fluid_usage_per_tick = inserter.energy_source.fluid_usage_per_tick * 1.5
inserter.insert_position = data.raw.inserter["long-handed-inserter"].insert_position
inserter.pickup_position = data.raw.inserter["long-handed-inserter"].pickup_position
inserter.extension_speed = data.raw.inserter["long-handed-inserter"].extension_speed
inserter.rotation_speed = data.raw.inserter["long-handed-inserter"].rotation_speed
inserter.minable.result = "long-handed-steam-inserter"
inserter.hand_size = 1.5
inserter.icon = DIR.get_icon_path("long-handed-steam-inserter")
inserter.icon_size = DIR.icon_size
inserter.icon_mipmaps = DIR.icon_mipmaps
inserter.hand_base_picture = data.raw.inserter["slow-filter-inserter"].hand_base_picture
inserter.hand_closed_picture = data.raw.inserter["slow-filter-inserter"].hand_closed_picture
inserter.hand_open_picture = data.raw.inserter["slow-filter-inserter"].hand_open_picture

data:extend({inserter})

-------------------------------------------------------------------------------------

-- update vanilla icons

DIR.replace_item_icon("inserter")
DIR.replace_item_icon("filter-inserter")
DIR.replace_item_icon("fast-inserter")
DIR.replace_item_icon("long-handed-inserter")
DIR.replace_item_icon("burner-inserter")
DIR.replace_item_icon("stack-inserter")
DIR.replace_item_icon("stack-filter-inserter")

-------------------------------------------------------------------------------------

-- add type / power source overlays to icons

if (settings.startup["ir-inserter-overlays"].value == "on") then
	for _,inserter in pairs(data.raw.inserter) do
		local type_icon = inserter.filter_count and DIR.get_icon_path("electronic-circuit") or ((inserter.hand_size and inserter.hand_size > 1) and DIR.get_icon_path("long-handed")) or nil
		local burner_icon = inserter.energy_source.type == "burner" and DIR.get_icon_path("heating-overlay") or nil
		local steam_icon = inserter.energy_source.type == "fluid" and inserter.energy_source.fluid_box and inserter.energy_source.fluid_box.filter == "steam" and DIR.get_icon_path("steam") or nil
		local item = data.raw.item[inserter.name]
		if item ~= nil and ((type_icon ~= nil) or (burner_icon ~= nil) or (steam_icon ~= nil)) then
			if not item.icons then
				item.icons = {{icon = item.icon, icon_size = item.icon_size, icon_mipmaps = DIR.icon_mipmaps}}
				item.icon = nil
			end
			if burner_icon ~= nil then
				table.insert(item.icons,{icon = burner_icon, icon_size = DIR.icon_size, scale = 0.25, shift = {-8,8}, icon_mipmaps = DIR.icon_mipmaps})
			end
			if steam_icon ~= nil then
				table.insert(item.icons,{icon = steam_icon, icon_size = DIR.icon_size, scale = 0.25, shift = {-8,8}, icon_mipmaps = DIR.icon_mipmaps})
			end
			if type_icon ~= nil then
				table.insert(item.icons,{icon = type_icon, icon_size = DIR.icon_size, scale = 0.25, shift = {-8,8}, icon_mipmaps = DIR.icon_mipmaps})
			end
			inserter.icons = item.icons
		end
	end
end

-------------------------------------------------------------------------------------
