------------------------------------------------------------------------------------------------------------------------------------------------------

-- MISC TWEAKS TO VANILLA ENTITIES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- belt map colours

if settings.startup["ir-belt-map-colours"].value == "coloured" then
	local colours = {
		[1] = {
			hue = 0.111,
			entities = {
				["transport-belt"] = "transport-belt",
				["underground-belt"] = "underground-belt",
				["splitter"] = "splitter",
			},
		},
		[2] = {
			hue = 0,
			entities = {
				["transport-belt"] = "fast-transport-belt",
				["underground-belt"] = "fast-underground-belt",
				["splitter"] = "fast-splitter",
			},
		},
		[3] = {
			hue = 0.54,
			entities = {
				["transport-belt"] = "express-transport-belt",
				["underground-belt"] = "express-underground-belt",
				["splitter"] = "express-splitter",
			},
		},
	}
	local saturations = {
		["transport-belt"] = 0.5,
		["underground-belt"] = 0.5,
		["splitter"] = 0.75,
	}
	local values = {
		["transport-belt"] = 0.75,
		["underground-belt"] = 0.45,
		["splitter"] = 0.9,
	}
	for _,beltdata in pairs(colours) do
		for entitytype,entityname in pairs(beltdata.entities) do
			data.raw[entitytype][entityname].map_color = DIR.hsva2rgba(beltdata.hue,saturations[entitytype],values[entitytype])
		end
	end
end

-- wire reach and health buff for large steel pylons

if data.raw["electric-pole"]["big-electric-pole"] then
	data.raw["electric-pole"]["big-electric-pole"].maximum_wire_distance = 32
	data.raw["electric-pole"]["big-electric-pole"].max_health = standard_health("steel",2)
	data.raw["electric-pole"]["big-electric-pole"].fast_replaceable_group = "electric-pole"
end

-- other power pole tweaks

if data.raw["electric-pole"]["substation"] then
	data.raw["electric-pole"]["substation"].max_health = standard_health("chrome",2)
end

if data.raw["electric-pole"]["small-electric-pole"] then
	data.raw["electric-pole"]["small-electric-pole"].max_health = standard_health("wood",1)
end

-- roboport range buff

if data.raw["roboport"]["roboport"] then
	data.raw.roboport.roboport.logistics_radius = 32
	data.raw.roboport.roboport.construction_radius = 96
	data.raw.roboport.roboport.max_health = standard_health("steel",4)
	data.raw.roboport.roboport.energy_source.buffer_capacity = "60MJ"
	data.raw.roboport.roboport.energy_source.input_flow_limit = "10MW"
	data.raw.roboport.roboport.recharge_minimum = "30MJ"
	local offsets = {}
	local stations = 8
	local d = 1.75
	for i=1,stations do
		local a = math.pi * 2 * ((i/stations) + (1/(stations*2)))
		table.insert(offsets, {math.cos(a) * d, math.sin(a) * d * 0.707})
	end
	data.raw.roboport.roboport.charging_offsets = offsets
end

-- accumulator buff

if data.raw["accumulator"]["accumulator"] then
	data.raw.accumulator.accumulator.energy_source = {
		buffer_capacity = "60MJ",
		input_flow_limit = "1MW",
		output_flow_limit = "1MW",
		type = "electric",
		usage_priority = "tertiary"
	}
	data.raw.accumulator.accumulator.max_health = standard_health("steel",2)
end

-- oil refinery working vis & adjust oil processing energy costs

if data.raw["assembling-machine"]["oil-refinery"] then
    data.raw["assembling-machine"]["oil-refinery"].energy_usage = DIR.get_scaled_energy_usage(DIR.refinery_power, DIR.standard_drain).active
    data.raw["assembling-machine"]["oil-refinery"].energy_source.drain = DIR.get_scaled_energy_usage(DIR.refinery_power, DIR.standard_drain).passive
    data.raw["assembling-machine"]["oil-refinery"].energy_source.emissions_per_minute = DIR.chemical_pollution_rate / 2
    data.raw["assembling-machine"]["oil-refinery"].gui_title_key = "gui-title.refinery"
    data.raw["assembling-machine"]["oil-refinery"].crafting_speed = DIR.get_standard_speed(1)
	data.raw["assembling-machine"]["oil-refinery"].max_health = standard_health("iron",5)
	data.raw["assembling-machine"]["oil-refinery"].working_visualisations[1].animation = 
		DIR.get_layer("machines/fluids/flare-stack-flame", 60, 10, "glow", nil, DIR.anim_speed, 128, 192, 0, 0, 128, 192, {1/32,-1}, "additive")
end

if data.raw["assembling-machine"]["chemical-plant"] then
    data.raw["assembling-machine"]["chemical-plant"].energy_usage = DIR.get_scaled_energy_usage(DIR.chemplant_power, DIR.standard_drain).active
    data.raw["assembling-machine"]["chemical-plant"].energy_source.drain = DIR.get_scaled_energy_usage(DIR.chemplant_power, DIR.standard_drain).passive
    data.raw["assembling-machine"]["chemical-plant"].energy_source.emissions_per_minute = DIR.chemical_pollution_rate / 4
    data.raw["assembling-machine"]["chemical-plant"].gui_title_key = "gui-title.chemistry"
    data.raw["assembling-machine"]["chemical-plant"].crafting_speed = DIR.get_standard_speed(1)
	data.raw["assembling-machine"]["chemical-plant"].max_health = standard_health("iron",3)
end

-- other entities left with vanilla power consumption and/or pollution

if data.raw["mining-drill"]["pumpjack"] then
    data.raw["mining-drill"]["pumpjack"].energy_usage = DIR.get_scaled_energy_usage(1, 0).active
    data.raw["mining-drill"]["pumpjack"].energy_source.drain = nil
    data.raw["mining-drill"]["pumpjack"].energy_source.emissions_per_minute = DIR.get_standard_emissions(1)
	data.raw["mining-drill"]["pumpjack"].max_health = standard_health("iron",2)
end

if data.raw["beacon"]["beacon"] then
    data.raw["beacon"]["beacon"].energy_usage = DIR.get_scaled_energy_usage(4, 0).active
	data.raw["beacon"]["beacon"].max_health = standard_health("chrome",3)
end

if data.raw["boiler"]["boiler"] then
    data.raw["boiler"]["boiler"].energy_source.emissions_per_minute = DIR.get_standard_emissions(10)
	data.raw["boiler"]["boiler"].max_health = standard_health("iron",3)
end

if data.raw["assembling-machine"]["centrifuge"] then
    data.raw["assembling-machine"]["centrifuge"].energy_usage = DIR.get_scaled_energy_usage(3, DIR.standard_drain).active
    data.raw["assembling-machine"]["centrifuge"].energy_source.drain = DIR.get_scaled_energy_usage(3, DIR.standard_drain).passive
    data.raw["assembling-machine"]["centrifuge"].energy_source.emissions_per_minute = nil
    data.raw["assembling-machine"]["centrifuge"].max_health = standard_health("steel",3)
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fix derpy tile boundary-clipped pipe connections (IR pipes aren't composed that way)
-- apply the north pipe cover permanently to main animations

-- storage tanks

local function get_north_pipe_cover_offset(x,y)
	local covers = pipecoverspictures()
	if covers.north and covers.north.layers and table_size(covers.north.layers) == 2 then
		covers.north.layers[1].shift = {x,y}
		covers.north.layers[1].hr_version.shift = {x,y}
		covers.north.layers[2].shift = {x,y}
		covers.north.layers[2].hr_version.shift = {x,y}
		return covers.north.layers
	else
		DIR.spam_log("Couldn't parse vanilla pipe cover pictures", DIR.log_level.warning)
		return {}
	end
end

if data.raw["storage-tank"]["storage-tank"] and data.raw["storage-tank"]["storage-tank"].pictures then

	local ew = {
		{
			filename = "__base__/graphics/entity/storage-tank/storage-tank.png",
			height = 108,
			hr_version = {
				filename = "__base__/graphics/entity/storage-tank/hr-storage-tank.png",
				height = 215,
				priority = "extra-high",
				scale = 0.5,
				shift = {
					-0.0078125,
					0.1171875
				},
				width = 219,
				x = 219,
			},
			priority = "extra-high",
			shift = {
				0,
				0.125
			},
			width = 110,
			x = 110,
		},
		{
			draw_as_shadow = true,
			filename = "__base__/graphics/entity/storage-tank/storage-tank-shadow.png",
			height = 77,
			hr_version = {
				draw_as_shadow = true,
				filename = "__base__/graphics/entity/storage-tank/hr-storage-tank-shadow.png",
				height = 153,
				priority = "extra-high",
				scale = 0.5,
				shift = {
					0.9296875,
					0.6953125
				},
				width = 291,
				x = 291,
			},
			priority = "extra-high",
			shift = {
				0.9375,
				0.703125
			},
			width = 146,
			x = 146
		}
	}

	local ns = table.deepcopy(ew)
	ns[1].x = nil
	ns[1].hr_version.x = nil
	ns[2].x = nil
	ns[2].hr_version.x = nil

	for _,layer in pairs(get_north_pipe_cover_offset(-1,-2)) do
		table.insert(ns,1,layer)
	end
	for _,layer in pairs(get_north_pipe_cover_offset(1,-2)) do
		table.insert(ew,1,layer)
	end

	data.raw["storage-tank"]["storage-tank"].pictures.picture = {
		north = { layers = ns },
		east = { layers = ew },
		south = { layers = ns },
		west = { layers = ew },
	}
	
end

-- pumps

if data.raw["pump"]["pump"] then

	local pumps = {"north","south"}
	for _,pump in pairs(pumps) do
		local copy = table.deepcopy(data.raw["pump"]["pump"].animations[pump])
		data.raw["pump"]["pump"].animations[pump] = { layers = get_north_pipe_cover_offset(0,-1.5) }
		for _,layer in pairs(data.raw["pump"]["pump"].animations[pump].layers) do
			layer.repeat_count = 32
			layer.hr_version.repeat_count = 32
		end
		table.insert(data.raw["pump"]["pump"].animations[pump].layers, copy)
	end
	
end

-- oil refinery

if data.raw["assembling-machine"]["oil-refinery"] then

	local layers = data.raw["assembling-machine"]["oil-refinery"].animation.north.layers
	layers = DIR.append_list(layers,get_north_pipe_cover_offset(-2,-3))
	layers = DIR.append_list(layers,get_north_pipe_cover_offset(0,-3))
	layers = DIR.append_list(layers,get_north_pipe_cover_offset(2,-3))
	layers = data.raw["assembling-machine"]["oil-refinery"].animation.south.layers
	layers = DIR.append_list(layers,get_north_pipe_cover_offset(-1,-3))
	layers = DIR.append_list(layers,get_north_pipe_cover_offset(1,-3))
	
end

-- flamethrower turret

local fturret = data.raw["fluid-turret"]["flamethrower-turret"]

if fturret then

	local dirs = {
		["east"] = {-1,-1.5},
		["west"] = {1,-1.5}
	}
	for dir,vector in pairs(dirs) do
		if fturret.base_picture[dir] and fturret.base_picture[dir].layers then
			for _,layer in pairs(get_north_pipe_cover_offset(vector[1],vector[2])) do
				table.insert(fturret.base_picture[dir].layers, layer)
			end
		end
	end
	fturret.gun_animation_render_layer = "object"
	fturret.gun_animation_secondary_draw_order = 2
	fturret.base_picture_render_layer = "object"
	fturret.base_picture_secondary_draw_order = 1
	fturret.fluid_box.render_layer = "object"
	
	table.insert(fturret.attack_parameters.fluids, 2, {type = "bitumen-fluid"})
	
end

-- vanilla boiler

local b = data.raw["boiler"]["boiler"]

if b then
	b.structure.north.layers = DIR.append_list(get_north_pipe_cover_offset(0,-1.5),b.structure.north.layers)
	b.structure.east.layers = DIR.append_list(get_north_pipe_cover_offset(-0.5,-2),b.structure.east.layers)
	b.structure.west.layers = DIR.append_list(get_north_pipe_cover_offset(0.5,-2),b.structure.west.layers)
end


------------------------------------------------------------------------------------------------------------------------------------------------------
