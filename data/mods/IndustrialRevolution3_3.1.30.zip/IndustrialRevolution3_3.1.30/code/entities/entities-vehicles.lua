------------------------------------------------------------------------------------------------------------------------------------------------------

-- VEHICLES

local default_vehicle_fuel_categories = {"steam-cell","canister","barrel","battery"}

local movement_triggers = require("__base__/prototypes/entity/movement-triggers")
local monowheel_movement_triggers = table.deepcopy(movement_triggers.car)

local offsets = { {0.125,0.25},{-0.125,0.25},{0.125,-0.25},{-0.125,-0.25}, }
for _,tile in pairs(monowheel_movement_triggers) do
    if tile.actions then
        for _,action in pairs(tile.actions) do
            if action.offsets then action.offsets = offsets end
        end
    elseif tile.offsets then
        tile.offsets = offsets
    end
end

local function get_light_cone(x,y,z)
    return {
        color = {r = 0.92, g = 0.77, b = 0.3},
        intensity = 0.75,
        minimum_darkness = 0.3,
        picture = {
            filename = "__core__/graphics/light-cone.png",
            flags = {"light"},
            height = 200,
            priority = "extra-high",
            scale = 2,
            width = 200
        },
        shift = {x,y},
        size = 2,
        type = "oriented",
        rotation_shift = z,
    }
end

local function get_vehicle_light_cones(x,y)
    return {
        get_light_cone(x,y),
        get_light_cone(-x,y),
    }
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- vanilla locomotives, cars, tanks accept batteries and canisters

local vehicles = {
    locomotive = "locomotive",
    car = "car",
    tank = "car",
}

for name,vehicle in pairs(vehicles) do
    local prototype = data.raw[vehicle][name]
    if prototype and prototype.burner then
        prototype.burner.fuel_category = nil
        prototype.burner.fuel_categories = default_vehicle_fuel_categories
        prototype.burner.burnt_inventory_size = prototype.burner.fuel_inventory_size
    end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- monowheel

local voffset = -0.75

local smoke = {}
local toffset = 0

for i = 0,2 do
    table.insert(smoke, {
        deviation = {0.125,0.125},
        frequency = 30,
        offset = toffset,
        name = "car-smoke",
        position = {-0.25, 1.5 - (i*0.125)},
        height = 1.1 - (i*0.2),
        starting_frame = 0,
        starting_frame_deviation = 60
    })
    toffset = toffset + 1/12
    table.insert(smoke, {
        deviation = {0.125,0.125},
        frequency = 30,
        offset = toffset,
        name = "car-smoke",
        position = {0.25,1.5 - (i*0.125)},
        height = 1.1 - (i*0.2),
        starting_frame = 0,
        starting_frame_deviation = 60
    })
    toffset = toffset + 1/12
end

local monowheel = {
    name = "monowheel",
    type = "car",
    alert_icon_shift = {0,voffset},
    animation = {
        layers = {
            DIR.get_multi_layer("vehicles/monowheel-shadow", 8, 1, 1, true, 3, 8, 256, 160, 0, 0, 256, 160, {1.5,voffset+0.75}, nil, nil, nil, 64, false),
            DIR.get_multi_layer("vehicles/monowheel-base", 8, 1, 1, false, 3, 8, 192, 192, 0, 0, 192, 192, {0,voffset}, nil, DIR.recommended_sprite_flags, nil, 64, false),
            DIR.get_multi_layer("vehicles/monowheel-tracks", 8, 3, 3, false, nil, 8, 192, 192, 0, 0, 192, 192, {0,voffset}, nil, DIR.recommended_sprite_flags, nil, 64, false),
        },
    },
    light_animation = DIR.get_multi_layer("vehicles/monowheel-glow", 8, 1, 1, "glow", 3, 8, 192, 192, 0, 0, 192, 192, {0,voffset}, "additive", DIR.recommended_sprite_flags, nil, 64, false),
    braking_power = "100kW",
    burner = {
        effectivity = 1,
        fuel_categories = default_vehicle_fuel_categories,
        fuel_inventory_size = 1,
        burnt_inventory_size = 1,
        smoke = smoke,
    },
    collision_box = DIR.get_box(0.7,1),
    consumption = "125kW",
    corpse = "medium-small-remnants",
    crash_trigger = data.raw.car.car.crash_trigger,
    dying_explosion = "medium-explosion",
    effectivity = 0.75,
    energy_per_hit_point = 1,
    flags = {
        "placeable-neutral",
        "player-creation",
        "placeable-off-grid",
        "not-flammable"
    },
    friction = 0.00175,
    icon = DIR.get_icon_path("monowheel"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    inventory_size = 20,
    light = get_vehicle_light_cones(0.5,-13),
    max_health = standard_health("copper",3),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "monowheel"
    },
    mined_sound = data.raw.car.car.mined_sound,
    open_sound = data.raw.car.car.open_sound,
    close_sound = data.raw.car.car.close_sound,
    placeable_by = {item = "monowheel", count = 1},
    render_layer = "object",
    resistances = standard_resistances("copper"),
    rotation_speed = 0.01,
    selection_box = DIR.get_box(0.7,1),
    sound_minimum_speed = 0.2,
    sound_no_fuel = data.raw.car.car.sound_no_fuel,
    stop_trigger = data.raw.car.car.stop_trigger,
    stop_trigger_speed = 0.2,
    tank_driving = false,
    track_particle_triggers = monowheel_movement_triggers,
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    weight = 800,
    working_sound = data.raw.car.car.working_sound,
}

data:extend({monowheel})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- heavy roller

local voffset = -0.25
local roller_movement_triggers = table.deepcopy(movement_triggers.tank)

for _,tile in pairs(roller_movement_triggers) do
    if tile.actions then
        for _,action in pairs(tile.actions) do
            if action.offsets then
                for k,offset in pairs(action.offsets) do
                    action.offsets[k] = {offset[1]*1.125,offset[2]}
                end
            end
        end
    elseif tile.offsets then
        for k,offset in pairs(tile.offsets) do
            tile.offsets[k] = {offset[1]*1.125,offset[2]}
        end
    end
end


local smoke = {}
local toffset = 0

for i = 0,2 do
    table.insert(smoke, {
        deviation = {0.125,0.125},
        frequency = 20,
        offset = toffset,
        name = "car-smoke",
        position = {-0.65, 0 - (i*0.2)},
        height = 1 - (i*0.05),
        starting_frame = 0,
        starting_frame_deviation = 60
    })
    toffset = toffset + 1/6
    table.insert(smoke, {
        deviation = {0.125,0.125},
        frequency = 20,
        offset = toffset,
        name = "car-smoke",
        position = {0.65, 0 - (i*0.2)},
        height = 1 - (i*0.05),
        starting_frame = 0,
        starting_frame_deviation = 60
    })
    toffset = toffset + 1/6
end

local roller = {
    name = "heavy-roller",
    type = "car",
    alert_icon_shift = {0,voffset},
    animation = {
        layers = {
            DIR.get_multi_layer("vehicles/heavy-roller-shadow", 8, 1, 1, true, 3, 8, 384, 256, 0, 0, 384, 256, {1,voffset+0.5}, nil, nil, nil, 64, false),
            DIR.get_multi_layer("vehicles/heavy-roller-base", 8, 1, 1, false, 3, 8, 256, 256, 0, 0, 256, 256, {0,voffset}, nil, DIR.recommended_sprite_flags, nil, 64, false),
            DIR.get_multi_layer("vehicles/heavy-roller-tracks", 8, 3, 3, false, nil, 8, 256, 256, 0, 0, 256, 256, {0,voffset}, nil, DIR.recommended_sprite_flags, nil, 64, false),
        },
    },
    light_animation = DIR.get_multi_layer("vehicles/heavy-roller-glow", 8, 1, 1, "glow", 3, 8, 256, 256, 0, 0, 256, 256, {0,voffset}, "additive", DIR.recommended_sprite_flags, nil, 64, false),
    braking_power = "600kW",
    burner = {
        effectivity = 1,
        fuel_categories = default_vehicle_fuel_categories,
        fuel_inventory_size = 1,
        burnt_inventory_size = 1,
        smoke = smoke,
    },
    collision_box = DIR.get_box(1.05,1.45),
    selection_box = DIR.get_box(1.1,1.5),
    drawing_box = DIR.get_box(1.25,1.75),
    consumption = "300kW",
    corpse = "medium-remnants",
    crash_trigger = data.raw.car.tank.crash_trigger,
    dying_explosion = "medium-explosion",
    effectivity = 0.9,
    energy_per_hit_point = 1,
    equipment_grid = "IR-vehicle-equipment-grid-platform",
    flags = {
        "placeable-neutral",
        "player-creation",
        "placeable-off-grid",
        "not-flammable"
    },
    friction = 0.002,
    has_belt_immunity = true,
    terrain_friction_modifier = 0.2,
    icon = DIR.get_icon_path("heavy-roller"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    immune_to_tree_impacts = true,
    immune_to_rock_impacts = true,
    inventory_size = 80,
    light = get_vehicle_light_cones(0.8,-14),
    max_health = standard_health("bronze",4),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "heavy-roller"
    },
    mined_sound = data.raw.car.tank.mined_sound,
    open_sound = data.raw.car.tank.open_sound,
    close_sound = data.raw.car.tank.close_sound,
    placeable_by = {item = "heavy-roller", count = 1},
    render_layer = "object",
    resistances = standard_resistances("bronze"),
    rotation_speed = 0.0035,
    sound_minimum_speed = 0.1,
    sound_scaling_ratio = 0.8,
    sound_no_fuel = data.raw.car.tank.sound_no_fuel,
    stop_trigger = data.raw.car.tank.stop_trigger,
    stop_trigger_speed = 0.1,
    tank_driving = true,
    track_particle_triggers = roller_movement_triggers,
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    weight = 12500,
    working_sound = data.raw.car.tank.working_sound,
}

data:extend({roller})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- heavy picket

local voffset = -0.75
local vheight = 1.25

local smoke = {{
    deviation = {0.125,0.125},
    frequency = 20,
    offset = toffset,
    name = "car-smoke",
    position = {0, 2.0},
    height = 0.75 ,
    starting_frame = 0,
    starting_frame_deviation = 60
}}

local picket_movement_triggers = table.deepcopy(roller_movement_triggers)

local particles = {
    ["water"] = "water-lower-particle",
    ["water-green"] = "green-water-lower-particle",
    ["deepwater"] = "deep-water-lower-particle",
    ["deepwater-green"] = "deep-green-water-lower-particle",
}

for t,p in pairs(particles) do
    if data.raw.tile[t] and data.raw["optimized-particle"][p] then
        table.insert(picket_movement_triggers, {
            tiles = { t },
            type = "create-particle",
            repeat_count = 5,
            particle_name = p,
            initial_height = 0.2,
            speed_from_center = 0.01,
            speed_from_center_deviation = 0.05,
            initial_vertical_speed = 0.02,
            offsets = {
                {0.75, 1},
                {-0.75,1},
                {0.75, -1},
                {-0.75,-1}
            },
            offset_deviation = {{-0.2, -0.2}, {0.2, 0.2}},
            rotate_offsets = true
        })
    else
        DIR.spam_log("Couldn't set up movement trigger for tile "..t, DIR.log_level_warning)
    end
end

local picket = {
    name = "heavy-picket",
    type = "car",
    alert_icon_shift = {0,voffset},
    animation = {
        layers = {
            DIR.get_layer("vehicles/picket-shadow", 1, 8, true, nil, nil, 448, 256, 0, 0, 448, 256, {1+vheight,voffset+vheight}, nil, nil, nil, 64, false),
            DIR.get_layer("vehicles/picket-base", 1, 8, false, nil, nil, 320, 320, 0, 0, 320, 320, {0,voffset}, nil, DIR.recommended_sprite_flags, nil, 64, false),
            DIR.get_layer("vehicles/picket-running-green", 1, 8, "glow", nil, nil, 320, 320, 0, 0, 320, 320, {0,voffset}, "additive", nil, nil, 64, false),
            DIR.get_layer("vehicles/picket-running-red", 1, 8, "glow", nil, nil, 320, 320, 0, 0, 320, 320, {0,voffset}, "additive", nil, nil, 64, false),
        },
    },
    light_animation = DIR.get_layer("vehicles/picket-lamps", 1, 8, "glow", nil, nil, 320, 320, 0, 0, 320, 320, {0,voffset}, "additive", DIR.recommended_sprite_flags, nil, 64, false),
    light = get_vehicle_light_cones(1,-14.5),
    water_reflection = {
        orientation_to_variation = false,
        rotate = true,
        pictures = {
            {
                filename = DIR.entities_path_2.."/vehicles/picket-reflection.png",
                priority = "extra-high",
                scale = 1,
                shift = {0,0.5},
                width = 160,
                height = 160,
                x = 0,
            },
        },
    },
    braking_power = "1500kW",
    burner = {
        effectivity = 1,
        fuel_categories = {"battery"},
        fuel_inventory_size = 3,
        burnt_inventory_size = 3,
        smoke = smoke,
    },
    collision_mask = {}, -- updated in data-final-fixes
    collision_box = DIR.get_box(1.25,2.35),
    selection_box = DIR.get_box(1.25,2.35),
    drawing_box = DIR.get_box(1.25,2.35,0,-0.5),
    consumption = "500kW",
    corpse = "medium-remnants",
    crash_trigger = data.raw.car.car.crash_trigger,
    dying_explosion = "medium-explosion",
    effectivity = 1,
    energy_per_hit_point = 1,
    equipment_grid = "IR-vehicle-equipment-grid-platform-picket",
    flags = {
        "placeable-neutral",
        "player-creation",
        "placeable-off-grid",
        "not-flammable"
    },
    friction = 0.00125,
    terrain_friction_modifier = 0,
    has_belt_immunity = true,
    icon = DIR.get_icon_path("heavy-picket"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    immune_to_tree_impacts = true,
    immune_to_rock_impacts = true,
    inventory_size = 100,
    max_health = standard_health("chrome",5),
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "heavy-picket"
    },
    open_sound = data.raw.car.tank.open_sound,
    close_sound = data.raw.car.tank.close_sound,
    mined_sound = data.raw.car.tank.mined_sound,
    placeable_by = {item = "heavy-picket", count = 1},
    render_layer = "object",
    resistances = standard_resistances("chrome"),
    rotation_speed = 0.005,
    sound_minimum_speed = 0.2,
    sound_scaling_ratio = 0.3,
    sound_no_fuel = data.raw.car.car.sound_no_fuel,
    -- stop_trigger = nil,
    -- stop_trigger_speed = 0.2,
    tank_driving = true,
    track_particle_triggers = picket_movement_triggers,
    vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
    weight = 12500,
    working_sound = {
        sound = {
            filename = DIR.sound_path.."/picket.ogg",
            volume = 1
        },
        fade_in_ticks = 20,
        fade_out_ticks = 60,
        match_speed_to_activity = true,
    },
	-- guns = {"heavy-picket-launcher"}
}

data:extend({picket})

-- data:extend({
  -- {
    -- type = "gun",
    -- name = "heavy-picket-launcher",
    -- icon = "__base__/graphics/icons/tank-cannon.png",
    -- icon_size = 64, icon_mipmaps = 4,
    -- flags = {"hidden"},
    -- subgroup = "gun",
    -- order = "z[tank]-z[hplauncher]",
    -- attack_parameters = {
      -- type = "projectile",
      -- ammo_category = "drone",
      -- cooldown = 5.625*60,
      -- movement_slow_down_factor = 0,
      -- projectile_creation_distance = 1.6,
      -- projectile_center = {0,0},
      -- range = 25,
      -- sound = sounds.tank_gunshot
    -- },
    -- stack_size = 1
  -- },
-- })

------------------------------------------------------------------------------------------------------------------------------------------------------
