------------------------------------------------------------------------------------------------------------------------------------------------------

local pipe_sprites = {
    straight_horizontal = {"h"},
    straight_horizontal_window = {"hw"},
    straight_vertical = {"v"},
    straight_vertical_window = {"vw"},
    straight_vertical_single = {"vs"},
    ending_left = {"ee"},
    ending_right = {"ew"},
    ending_up = {"es"},
    ending_down = {"en"},
    corner_up_right = {"ne"},
    corner_up_left = {"nw"},
    corner_down_right = {"se"},
    corner_down_left = {"sw"},
    t_right = {"te"},
    t_left = {"tw"},
    t_up = {"tn"},
    t_down = {"ts"},
    cross = {"x"},
    horizontal_window_background = {"hb"},
    vertical_window_background = {"vb"},
}

local ug_sprites = {
    up = {"un"},
    down = {"us"},
    left = {"uw"},
    right = {"ue"},
}

local ugs_sprites = {
    up = {"uns"},
    down = {"uss"},
    left = {"uws"},
    right = {"ues"},
}

local pipes = {
    copper = {
        max_health = standard_health("copper",1),
        max_underground_distance = 10,
        filter = "water",
        resistances = standard_resistances("copper"),
    },
    steam = {
        max_health = standard_health("copper",1),
        max_underground_distance = 10,
        filter = "steam",
        resistances = standard_resistances("copper"),
    },
    iron = {
        max_health = standard_health("iron",1),
        max_underground_distance = 15,
        resistances = standard_resistances("iron"),
    },
    air = {
        max_health = standard_health("iron",1),
        max_underground_distance = 10,
        filter = "air-gas",
        resistances = standard_resistances("iron"),
    },
}

------------------------------------------------------------------------------------------------------------------------------------------------------

local pipe_pictures_original = {
    fluid_background = table.deepcopy(data.raw.pipe.pipe.pictures["fluid_background"]),
    gas_flow = table.deepcopy(data.raw.pipe.pipe.pictures["gas_flow"]),
    high_temperature_flow = table.deepcopy(data.raw.pipe.pipe.pictures["high_temperature_flow"]),
    low_temperature_flow = table.deepcopy(data.raw.pipe.pipe.pictures["low_temperature_flow"]),
    middle_temperature_flow = table.deepcopy(data.raw.pipe.pipe.pictures["middle_temperature_flow"]),
}

local function valve_sheet(material,shadow,direction,shadow_direction)
	return {
		layers = {
			{
				filename = DIR.entities_path_2.."/pipes/valve-"..material.."-"..direction..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5
			},
			{
				filename = DIR.entities_path_2.."/pipes/valve-"..shadow.."-"..shadow_direction..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5,
				draw_as_shadow = true,
			},
		}
	}
end

for material,pipedata in pairs(pipes) do
    local name = (material == "iron") and "pipe" or material.."-pipe"
    local shadow = (material == "steam" or material == "air") and "steam-shadow" or "shadow"
    local pipe_pictures = {
        fluid_background = pipe_pictures_original.fluid_background,
        gas_flow = pipe_pictures_original.gas_flow,
        high_temperature_flow = pipe_pictures_original.high_temperature_flow,
        low_temperature_flow = pipe_pictures_original.low_temperature_flow,
        middle_temperature_flow = pipe_pictures_original.middle_temperature_flow,
    }
	-- 3.1.0 - because of fluid-powered loaders and their VERY fussy render layer arrangements,
	-- we have to chop the bottom part of pipes that intrudes into the tile below into a lower render layer, in the loader/ug "front patch" styley
	-- unfortunately we can't actually draw the patch, only do the chop, but luckily it seems to work anyway
	-- only applies to vw, vs, x, tw, te, ts, sw, se, en - list defined in globals
    for spritelist,sprites in pairs(pipe_sprites) do
        pipe_pictures[spritelist] = { layers = {} }
        for _,sprite in pairs(sprites) do
            table.insert(pipe_pictures[spritelist].layers, {
                filename = DIR.entities_path_2.."/pipes/pipe-"..material.."-"..sprite..".png",
                priority = "extra-high",
                width = 180,
                height = DIR.patchable_pipe_sprites[sprite] or 120,
				shift = DIR.patchable_pipe_sprites[sprite] and {0,((120-DIR.patchable_pipe_sprites[sprite])/-128)} or {0,0},
                scale = 0.5,
            })
            if not string.find(spritelist,"background") then
                table.insert(pipe_pictures[spritelist].layers, {
                    filename = DIR.entities_path_2.."/pipes/pipe-"..shadow.."-"..sprite..".png",
                    priority = "extra-high",
                    width = 180,
                    height = 120,
                    scale = 0.5,
                    draw_as_shadow = true,
                })
            end
        end
    end
    local ug_pictures = {}
    for spritelist,sprites in pairs(ug_sprites) do
		ug_pictures[spritelist] = { layers = {} }
		for _,sprite in pairs(sprites) do
			table.insert(ug_pictures[spritelist].layers, {
				filename = DIR.entities_path_2.."/pipes/pipe-"..material.."-"..sprite..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5
			})
			table.insert(ug_pictures[spritelist].layers, {
				filename = DIR.entities_path_2.."/pipes/pipe-"..shadow.."-"..sprite..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5,
				draw_as_shadow = true,
			})
		end
    end
    local ugs_pictures = {}
    for spritelist,sprites in pairs(ugs_sprites) do
		ugs_pictures[spritelist] = { layers = {} }
		for _,sprite in pairs(sprites) do
			table.insert(ugs_pictures[spritelist].layers, {
				filename = DIR.entities_path_2.."/pipes/pipe-"..material.."-"..sprite..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5
			})
			table.insert(ugs_pictures[spritelist].layers, {
				filename = DIR.entities_path_2.."/pipes/pipe-"..shadow.."-"..sprite..".png",
				priority = "extra-high",
				width = 180,
				height = 120,
				scale = 0.5,
				draw_as_shadow = true,
			})
		end
    end

    local description = {
        "entity-description.pipes",
        pipedata.filter and {"", "[img=fluid/"..pipedata.filter.."] ", {"fluid-name."..pipedata.filter}} or {"entity-description.pipes-all"}
    }

    local working_sound = {
        fade_in_ticks = 4,
        fade_out_ticks = 60,
        audible_distance_modifier = 0.3,
        match_volume_to_activity = true,
		use_doppler_shift = false,
        sound = {
            {
                filename = DIR.base_sound_path.."/pipe.ogg",
                volume = 0.45
            }
        }
    }

    -- pipe
	if not pipedata.underground_only then
		data:extend({{
			name = name,
			localised_description = description,
			type = "pipe",
			collision_box = {{-0.29,-0.29},{0.29,0.29}},
			corpse = "small-remnants",
			damaged_trigger_effect = nil, -- added later
			dying_explosion = "pipe-explosion",
			fast_replaceable_group = "pipe",
			flags = {
				"placeable-neutral",
				"player-creation",
				"fast-replaceable-no-build-while-moving"
			},
			fluid_box = {
				base_area = pipedata.base_area or 1,
				filter = pipedata.filter,
				maximum_temperature = pipedata.maximum_temperature,
				pipe_connections = {
					{ position = {0,-1} },
					{ position = {1,0} },
					{ position = {0,1} },
					{ position = {-1,0} },
				},
			},
			icon = DIR.get_icon_path(name),
			icon_mipmaps = DIR.icon_mipmaps,
			icon_size = DIR.icon_size,
			max_health = pipedata.max_health or 100,
			minable = {
				mining_time = DIR.standard_pickup_time,
				result = name
			},
			pictures = table.deepcopy(pipe_pictures),
			resistances = pipedata.resistances,
			selection_box = {{-0.5,-0.5},{0.5,0.5}},
			vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
			working_sound = (material ~= "steam") and working_sound or nil,
			horizontal_window_bounding_box = {{-0.25, -0.3125}, {0.25, 0}},
			vertical_window_bounding_box = {{-0.25,-0.5}, {0.25, 0.25}},
		}})
	end

    -- undergrounds
    name = (material == "iron") and "pipe-to-ground" or material.."-pipe-to-ground"
	for version,length in pairs({
		[name.."-short"] = 5,
		[name] = (pipedata.max_underground_distance or 10),
	}) do
		data:extend({{
			name = version,
			localised_description = description,
			type = "pipe-to-ground",
			collision_box = {{-0.29,-0.29},{0.29,0.2}}, -- not a typo
			corpse = "small-remnants",
			damaged_trigger_effect = nil, -- added later
			dying_explosion = "pipe-explosion",
			fast_replaceable_group = "pipe",
			flags = {
				"placeable-neutral",
				"player-creation",
				"fast-replaceable-no-build-while-moving"
			},
			fluid_box = {
				base_area = pipedata.base_area or 1,
				filter = pipedata.filter,
				maximum_temperature = pipedata.maximum_temperature,
				pipe_connections = {
					{ position = {0,-1} },
					{ position = {0,1}, max_underground_distance = length },
				},
				pipe_covers = DIR.pipe_covers[material],
			},
			icon = DIR.get_icon_path(version),
			icon_mipmaps = DIR.icon_mipmaps,
			icon_size = DIR.icon_size,
			max_health = pipedata.max_health or 100,
			minable = {
				mining_time = DIR.standard_pickup_time,
				result = version
			},
			pictures = table.deepcopy((length==5) and ugs_pictures or ug_pictures),
			resistances = pipedata.resistances,
			selection_box = {{-0.5,-0.5},{0.5,0.5}},
			vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
			working_sound = (material ~= "steam") and working_sound or nil,
		}})
	end
	
	-- valve
	if not pipedata.underground_only then
		if pipedata.valve ~= false then
			name = (material == "iron") and "valve" or material.."-valve"
			local circuits = circuit_connector_definitions.create (
				universal_connector_template,
				{
					{ variation = 2, main_offset = util.by_pixel_hr(0, 3), shadow_offset = util.by_pixel_hr(5, 3-10), show_shadow = true },
					{ variation = 26, main_offset = util.by_pixel_hr(0, 8), shadow_offset = util.by_pixel_hr(5, 8-10), show_shadow = true },
					{ variation = 2, main_offset = util.by_pixel_hr(0, 3), shadow_offset = util.by_pixel_hr(5, 3-10), show_shadow = true },
					{ variation = 26, main_offset = util.by_pixel_hr(0, 8), shadow_offset = util.by_pixel_hr(5, 8-10), show_shadow = true },
				}
			)
			local template = {
				name = name,
				type = "storage-tank",
				localised_description = {"",{"entity-description.valve"},"\n",description},
				circuit_connector_sprites = circuits.sprites,
				circuit_wire_connection_points = circuits.points,
				circuit_wire_max_distance = 9,
				minable = {
					mining_time = DIR.standard_pickup_time,
					result = name,
				},
				collision_box = {{-0.29,-0.29},{0.29,0.29}},
				selection_box = {{-0.5,-0.5},{0.5,0.5}},
				window_bounding_box = {{0,0},{0,0}},
				corpse = "small-remnants",
				fast_replaceable_group = "pipe",
				flags = {
					"placeable-player",
					"player-creation",
					"hide-alt-info" -- icon is badly placed for 1x1 tanks, seemingly hardcoded
				},
				fluid_box = {
					base_area = pipedata.base_area or 1,
					filter = pipedata.filter,
					maximum_temperature = pipedata.maximum_temperature,
					pipe_connections = {
						{ position = {0,-1}, type = "output" },
						{ position = {0,1}, type = "input" },
					},
					pipe_covers = DIR.pipe_covers[material],
					secondary_draw_orders = { north = -1 }
				},
				icon_mipmaps = DIR.icon_mipmaps,
				icon_size = DIR.icon_size,
				max_health = pipedata.max_health or 100,
				pictures = {
					window_background = standard_blank_sprite(),
					flow_sprite = standard_blank_sprite(),
					gas_flow = standard_blank_sprite(),
					fluid_background = standard_blank_sprite(),
				},
				resistances = pipedata.resistances,
				flow_length_in_ticks = 1,
				two_direction_only = false,
				vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
				working_sound = nil, -- valves have to be silent because tanks don't support activity
			}
			local versions = {
				[""] = "",
				["overflow"] = "o",
				["underflow"] = "u",
			}
			local levels = {
				["overflow"] = 0.8,
				["underflow"] = -0.2,
			}
			for version,suffix in pairs(versions) do
				local v = table.deepcopy(template)
				v.placeable_by = {item = v.name, count = 1}
				v.name = (version == "") and v.name or v.name.."-"..version
				v.pictures.picture = {
					north = valve_sheet(material,shadow,"n"..suffix,"n"),
					east = valve_sheet(material,shadow,"e"..suffix,"e"),
					south = valve_sheet(material,shadow,"s"..suffix,"s"),
					west = valve_sheet(material,shadow,"w"..suffix,"w"),
				}
				v.fluid_box.base_level = levels[version]
				v.icon = DIR.get_icon_path(v.name)
				data:extend({v})
			end
		end
	end
	
end

------------------------------------------------------------------------------------------------------------------------------------------------------
