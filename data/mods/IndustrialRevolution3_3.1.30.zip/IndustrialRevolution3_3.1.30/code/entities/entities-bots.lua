------------------------------------------------------------------------------------------------------------------------------------------------------

-- BOTS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- buff vanilla bots

local default_speed = 0.075

data.raw["construction-robot"]["construction-robot"].speed = default_speed
data.raw["construction-robot"]["construction-robot"].speed_multiplier_when_out_of_energy = 0.25
data.raw["construction-robot"]["construction-robot"].max_payload_size = 5
data.raw["logistic-robot"]["logistic-robot"].speed = default_speed
data.raw["logistic-robot"]["logistic-robot"].speed_multiplier_when_out_of_energy = 0.25

-- the "real" deconstruct sound now played via on_robot_mined_entity
data.raw["utility-sounds"]["default"]["deconstruct_robot"] = {
    {
      filename = DIR.sound_path.."/silence.ogg",
      volume = 0
    }
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- switch vanilla defender bot to physical projectiles

local ammo_material = DIR.materials["iron"]
local ammo_component = DIR.components["magazine"]

data.raw["combat-robot"]["defender"].attack_parameters.ammo_type = DIR.get_ammo_type(
    ammo_component.ammo.projectile_type or "bullet",
    ammo_material.base_damage,
    ammo_component.ammo.range or 18,
    ammo_component.ammo.speed or 1,
    (ammo_component.ammo.use_pellets and ammo_material.pellets) or 1,
    ammo_component.ammo.deviation or 0,
    ammo_component.ammo.category or "bullet",
    ammo_material.hue,
    ammo_material.saturation
)
data.raw["combat-robot"]["defender"].attack_parameters.range = ammo_component.ammo.range
data.raw["combat-robot"]["defender"].attack_parameters.cooldown = ammo_component.ammo.cooldown * 2

------------------------------------------------------------------------------------------------------------------------------------------------------

-- clockwork punkbot

local bot_power_move = "2.5kJ"
local bot_power_tick = "0.025kJ"
local bot_power_battery = "0.75MJ"

local function construction_sparks(voffset)
	return {
		filename = DIR.projectiles_path.."/construction-sparks.png",
		draw_as_glow = true,
		width = 64,
		height = 64,
		frame_count = 32,
		line_length = 8,
		shift = {0,voffset},
		animation_speed = 0.5,
		scale = 0.5,
		blend_mode = "additive",
	}
end

data.raw["construction-robot"]["construction-robot"].sparks = construction_sparks(0.125)

local steambot = {
    name = "steambot",
    type = "construction-robot",
    cargo_centered = {0,0},
    collision_box = {{0,0},{0,0}},
    selection_box = {{-0.5,-1.5},{0.5,-0.5}},
    construction_vector = {0.3,0.22},
    draw_cargo = true,
    dying_trigger_effect = {
        {
            initial_height = 1.8,
            initial_vertical_speed = 0,
            frame_speed = 1,
            frame_speed_deviation = 0.5,
            speed_from_center = 0,
            speed_from_center_deviation = 0.2,
            offset_deviation = {{-0.01, -0.01},{0.01, 0.01}},
            offsets = {{0, 0.5}},
            particle_name = "steambot-death-particle",
            repeat_count = 1,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            type = "create-particle"
        },
        {
            type = "play-sound",
            sound = {
                { filename = "__base__/sound/fight/robot-die-whoosh-01.ogg", volume = 0.5 },
                { filename = "__base__/sound/fight/robot-die-whoosh-02.ogg", volume = 0.5 },
                { filename = "__base__/sound/fight/robot-die-whoosh-03.ogg", volume = 0.5 },
            },
        },
    },
    energy_per_move = bot_power_move,
    energy_per_tick = bot_power_tick,
    flags = {
        "placeable-player",
        "player-creation",
        "placeable-off-grid",
        "not-on-map",
		"hidden" -- to prevent it showing in bonus gui
    },
    icon = DIR.get_icon_path("steambot"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    idle = DIR.get_layer("bots/steambot-idle", 1, 8, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, nil, nil, nil, 64),
    in_motion = DIR.get_layer("bots/steambot-moving", 1, 8, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, nil, nil, nil, 64),
    working = {
		layers = {
			DIR.get_layer("bots/steambot-idle", 1, 8, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, nil, nil, nil, 64),
			DIR.get_layer("bots/steambot-glow", 1, 8, "glow", nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, "additive", nil, nil, 64),
		}
	},
    shadow_idle = DIR.get_layer("bots/steambot-idle-shadow", 1, 8, true, nil, nil, 128, 64, 0, 0, 128, 64, {1.0,0.6}, nil, nil, nil, 64),
    shadow_in_motion = DIR.get_layer("bots/steambot-moving-shadow", 1, 8, true, nil, nil, 128, 64, 0, 0, 128, 64, {1.0,0.6}, nil, nil, nil, 64),
    shadow_working = DIR.get_layer("bots/steambot-idle-shadow", 1, 8, true, nil, nil, 128, 64, 0, 0, 128, 64, {1.0,0.6}, nil, nil, nil, 64),
    max_energy = bot_power_battery,
    max_health = standard_health("copper",1),
    max_payload_size = 5,
    max_to_charge = 0.95,
    min_to_charge = 0.2,
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "steambot"
    },
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-robot.ogg"
	},
	repairing_sound = data.raw["construction-robot"]["construction-robot"].repairing_sound,
    resistances = standard_fireproof(),
    smoke = nil,
    sparks = construction_sparks(0.125),
    speed = default_speed,
    speed_multiplier_when_out_of_energy = 0.25,
    max_speed = default_speed, -- stops bot from benefitting from movement speed research
    transfer_distance = 0.5,
    working_sound = {
        max_sounds_per_type = 3,
        sound = {
            {
                filename = DIR.sound_path.."/ticktock.ogg",
                volume = 0.333
            },
        },
        fade_in_ticks = 10,
        fade_out_ticks = 30,
    },
}

data:extend({steambot})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- remnants

local bots = {
	["steambot"] = {"copper","copper"},
	["scatterbot"] = {"bronze","copper"},
	["lampbot"] = {"iron","glass"},
}

for bot,materials in pairs(bots) do
	local particles = {}
	for _,material in pairs(materials) do
		table.insert(particles,DIR.particle_effect(material,math.floor(8,0.2,0.1)))
	end
	local animation = {}
	for i=0,3 do
		table.insert(animation, {
			direction_count = 1,
			filename = DIR.entities_path_2.."/bots/"..bot.."-remnants.png",
			frame_count = 1,
			height = 128,
			line_length = 1,
			width = 128,
			scale = 0.5,
			variation_count = 1,
			shift = {0.25,0},
			y = i * 128,
		})
	end
	local remnants = {
		animation = animation,
		created_effect = {
			type = "direct",
			action_delivery = {
				type = "instant",
				target_effects = particles,
			},
		},
		collision_box = DIR.get_box(0.4,0.4),
		final_render_layer = "remnants",
		flags = {
			"placeable-neutral",
			"not-on-map"
		},
		icon = DIR.get_icon_path(bot),
		icon_mipmaps = 4,
		icon_size = 64,
		name = bot.."-remnants",
		order = "d[remnants]-z",
		remove_on_tile_placement = false,
		selectable_in_game = false,
		selection_box = DIR.get_box(0.5,0.5),
		subgroup = "remnants",
		time_before_removed = DIR.seconds_to_ticks(120),
		type = "corpse"
	}
	data:extend({remnants})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- bronze scatterbot

local ammo_material = DIR.materials["bronze"]
local ammo_component = DIR.components["cartridge"]

local scatterbot = {
    alert_when_damaged = false,
    attack_parameters = {
        ammo_type = DIR.get_ammo_type(
            ammo_component.ammo.projectile_type or "bullet",
            ammo_material.base_damage,
            ammo_component.ammo.range or 18,
            ammo_component.ammo.speed or 1,
            (ammo_component.ammo.use_pellets and ammo_material.pellets) or 1,
            ammo_component.ammo.deviation or 0,
            ammo_component.ammo.category or "bullet",
            ammo_material.hue,
            ammo_material.saturation
        ),
        cooldown = ammo_component.ammo.cooldown * 2,
        projectile_center = {0,0},
        projectile_creation_distance = 1,
        range = ammo_component.ammo.range,
        sound = {
            variations = {
                {
                    filename = DIR.sound_path.."/shotgun1.ogg",
                    volume = 0.5
                },
                {
                    filename = DIR.sound_path.."/shotgun2.ogg",
                    volume = 0.5
                },
                {
                    filename = DIR.sound_path.."/shotgun3.ogg",
                    volume = 0.5
                },
            }
        },
        type = "projectile",
    },
    dying_trigger_effect = {
        {
            frame_speed = 1,
            frame_speed_deviation = 0.5,
            initial_height = 1.8,
            initial_vertical_speed = 0,
            offset_deviation = {{-0.01, -0.01},{0.01, 0.01}},
            offsets = {{0, 0.5}},
            particle_name = "scatterbot-death-particle",
            repeat_count = 1,
            speed_from_center = 0,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            speed_from_center_deviation = 0.2,
            type = "create-particle",
        },
        {
            type = "play-sound",
            sound = {
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-01.ogg", volume = 0.5
                },
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-02.ogg", volume = 0.5
                },
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-03.ogg", volume = 0.5
                }
            }
        },
    },
    destroy_action = {
        type = "direct",
        action_delivery = {
            type = "instant",
            source_effects = {
                frame_speed = 0.5,
                frame_speed_deviation = 0.5,
                initial_height = 1.8,
                initial_vertical_speed = 0,
                offset_deviation = {{-0.01, -0.01},{0.01, 0.01}},
                offsets = {{0, 0.5}},
                particle_name = "scatterbot-death-particle",
                speed_from_center = 0,
                speed_from_center_deviation = 0.1,
                type = "create-particle",
            }
        }
    },
    collision_box = {{0,0},{0,0}},
    selection_box = {{-0.5,-1.5},{0.5,-0.5}},
    flags = {
        "placeable-player",
        "player-creation",
        "placeable-off-grid",
        "not-on-map",
        "not-repairable"
    },
    follows_player = true,
    friction = 0.01,
    icon = DIR.get_icon_path("scatterbot"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    idle = DIR.get_layer("bots/scatterbot-base", 1, 16, false, nil, nil, 128, 128, 0, 0, 128, 128, {0,0}, nil, nil, nil, 16),
    in_motion = DIR.get_layer("bots/scatterbot-base", 1, 16, false, nil, nil, 128, 128, 0, 128, 128, 128, {0,-2}, nil, nil, nil, 16),
    shadow_idle = DIR.get_layer("bots/scatterbot-shadow", 1, 16, true, nil, nil, 192, 128, 0, 0, 192, 128, {1.0,0.6}, nil, nil, nil, 16),
    shadow_in_motion = DIR.get_layer("bots/scatterbot-shadow", 1, 16, true, nil, nil, 192, 128, 0, 128, 192, 128, {1.0,-1.4}, nil, nil, nil, 16),
    max_health = standard_health("bronze",1),
    name = "scatterbot",
    order = "e-a",
    resistances = standard_resistances("bronze"),
    speed = 0.0025,
    max_speed = 0.0025,
    range_from_player = 6,
    time_to_live = 1800,
    type = "combat-robot",
    working_sound = {
        max_sounds_per_type = 3,
        sound = {
            {
                filename = DIR.sound_path.."/ticktock.ogg",
                volume = 0.5
            },
        },
        fade_in_ticks = 10,
        fade_out_ticks = 30,
    },
}

data:extend({scatterbot})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- lampbot - a bot that is also a lamp

data:extend({
	{
		type = "ammo-category",
		name = "lightbeam",
		bonus_gui_order = "z-z",
	},
})

local lampbot = {
    alert_when_damaged = false,
    attack_parameters = {type="beam", range = 0, cooldown = 99999, ammo_type = {category = "lightbeam"}},
    dying_trigger_effect = {
        {
            frame_speed = 1,
            frame_speed_deviation = 0.5,
            initial_height = 1.8,
            initial_vertical_speed = 0,
            offset_deviation = {{-0.01, -0.01},{0.01, 0.01}},
            offsets = {{0, 0.5}},
            particle_name = "lampbot-death-particle",
            repeat_count = 1,
            speed_from_center = 0,
            speed_from_center = 0.08,
            speed_from_center_deviation = 0.15,
            speed_from_center_deviation = 0.2,
            type = "create-particle",
        },
        {
            type = "play-sound",
            sound = {
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-01.ogg", volume = 0.5
                },
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-02.ogg", volume = 0.5
                },
                {
                    filename = "__base__/sound/fight/robot-die-whoosh-03.ogg", volume = 0.5
                }
            }
        },
    },
    destroy_action = {
        type = "direct",
        action_delivery = {
            type = "instant",
            source_effects = {
                frame_speed = 0.5,
                frame_speed_deviation = 0.5,
                initial_height = 1.8,
                initial_vertical_speed = 0,
                offset_deviation = {{-0.01, -0.01},{0.01, 0.01}},
                offsets = {{0, 0.5}},
                particle_name = "lampbot-death-particle",
                speed_from_center = 0,
                speed_from_center_deviation = 0.1,
                type = "create-particle",
            }
        }
    },
    collision_box = {{0,0},{0,0}},
    selection_box = {{-0.5,-1.5},{0.5,-0.5}},
    flags = {
        "placeable-player",
        "player-creation",
        "placeable-off-grid",
        "not-on-map",
        "not-repairable"
    },
    follows_player = false,
    friction = 1000,
    icon = DIR.get_icon_path("lampbot"),
    icon_size = DIR.icon_size,
    icon_mipmaps = DIR.icon_mipmaps,
    idle = {
		layers = {
			DIR.get_layer("bots/lampbot-base", 1, 8, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, nil, nil, nil, 64),
			DIR.get_layer("bots/lampbot-glow", 1, 8, "light", nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, "additive", nil, nil, 64),
		},
	},
    in_motion = {
		layers = {
			DIR.get_layer("bots/lampbot-base", 1, 8, false, nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, nil, nil, nil, 64),
			DIR.get_layer("bots/lampbot-glow", 1, 8, "light", nil, nil, 96, 96, 0, 0, 96, 96, {0,0}, "additive", nil, nil, 64),
		},
	},
    shadow_idle = DIR.get_layer("bots/lampbot-shadow", 1, 8, true, nil, nil, 128, 96, 0, 0, 128, 96, {1.0,0.6}, nil, nil, nil, 64),
    shadow_in_motion = DIR.get_layer("bots/lampbot-shadow", 1, 8, true, nil, nil, 128, 96, 0, 0, 128, 96, {1.0,0.6}, nil, nil, nil, 64),
    max_health = standard_health("iron",1),
    name = "lampbot",
    order = "b",
    resistances = standard_resistances("iron"),
    speed = 0,
    max_speed = 0,
    range_from_player = nil,
    time_to_live = 60000,
    type = "combat-robot",
    working_sound = nil,
	light = {
		color = {r = 0.92, g = 0.77, b = 0.3},
		intensity = 0.85,
		minimum_darkness = 0.2,
		picture = {
			filename = "__core__/graphics/light-cone.png",
			flags = {"light"},
			height = 200,
			priority = "extra-high",
			scale = 2,
			width = 200
		},
		shift = {0,-13},
		size = 2,
		type = "oriented",
		rotation_shift = 0,
	},
    minable = {
        mining_time = DIR.standard_pickup_time,
        result = "lampbot-capsule"
    },
	mined_sound = {
		filename = DIR.core_sound_path.."/deconstruct-robot.ogg"
	},
}

data:extend({lampbot})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- make all robots fire-proof

for _,p in pairs(data.raw["combat-robot"]) do
	p.resistances = standard_fireproof(p.resistances)
end

for _,p in pairs(data.raw["construction-robot"]) do
	p.resistances = standard_fireproof(p.resistances)
end

for _,p in pairs(data.raw["logistic-robot"]) do
	p.resistances = standard_fireproof(p.resistances)
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- 2x2 robotower

local anim_speed = 1/30
local circuits = circuit_connector_definitions.create (
    universal_connector_template,
    {{ variation = 18, main_offset = util.by_pixel(0, -14), shadow_offset = util.by_pixel(10, -4), show_shadow = true }}
)

data:extend({
    {
        name = "robotower",
        minable = {
            mining_time = DIR.standard_pickup_time,
            result = "robotower"
        },
        base = {
            layers = {
                DIR.get_layer("machines/misc/robotower-base", 1, 1, false, nil, nil, 128, 192, 0, 0, 128, 192, {0,-0.5}),
                DIR.get_layer("machines/misc/robotower-shadow", 1, 1, true, nil, nil, 256, 192, 0, 0, 256, 192, {1,0.5}),
            },
        },
        base_animation = DIR.get_layer("machines/misc/robotower-lights", 16, 16, "glow", nil, anim_speed, 64, 96, 0, 0, 64, 96, {0,0.25}),
        base_patch = standard_blank_sprite(),
        door_animation_down = DIR.get_layer("machines/misc/robotower-door-down", 16, 16, false, nil, nil, 96, 48, 0, 0, 96, 48, {0,-0.625}),
        door_animation_up = DIR.get_layer("machines/misc/robotower-door-up", 16, 16, false, nil, nil, 96, 48, 0, 0, 96, 48, {0,-1.375}),
        charge_approach_distance = 4,
        charging_offsets = {{-0.85,-0.5},{0.85,-0.5}},
        spawn_and_station_height = 0.5,
        stationing_offset = {0,-0.5},
        circuit_connector_sprites = circuits.sprites,
        circuit_wire_connection_point = circuits.points,
        circuit_wire_max_distance = 9,
        robots_shrink_when_entering_and_exiting = true,
        close_door_trigger_effect = {
            {
                sound = {
                    filename = DIR.base_sound_path.."/roboport-door.ogg",
                    volume = 0.75
                },
                type = "play-sound"
            }
        },
        collision_box = {{-0.95,-0.95},{0.95,0.95}},
        selection_box = {{-1,-1},{1,1}},
        logistics_radius = 16,
        construction_radius = 48,
        corpse = "medium-small-remnants",
        default_available_construction_output_signal = {
            name = "signal-Z",
            type = "virtual"
        },
        default_available_logistic_output_signal = {
            name = "signal-X",
            type = "virtual"
        },
        default_total_construction_output_signal = {
            name = "signal-T",
            type = "virtual"
        },
        default_total_logistic_output_signal = {
            name = "signal-Y",
            type = "virtual"
        },
        draw_construction_radius_visualization = true,
        draw_logistic_radius_visualization = true,
        dying_explosion = "medium-explosion",
        energy_source = {
            buffer_capacity = "20MJ",
            input_flow_limit = "2.5MW",
            type = "electric",
            usage_priority = "secondary-input"
        },
        energy_usage = "20kW",
        charging_energy = "1MW",
        flags = {
            "placeable-player",
            "player-creation"
        },
        icon = DIR.get_icon_path("robotower"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        material_slots_count = 2,
        max_health = standard_health("steel",2),
        recharge_minimum = "10MJ",
        recharging_animation = {
            animation_speed = 0.5,
            filename = "__base__/graphics/entity/roboport/roboport-recharging.png",
            frame_count = 16,
            height = 35,
            priority = "high",
            scale = 1.5,
            width = 37
        },
        recharging_light = {
            color = {
                b = 1,
                g = 0.75,
                r = 0.75
            },
            intensity = 0.4,
            size = 5
        },
        request_to_open_door_timeout = 15,
        resistances = standard_resistances("steel"),
        robot_slots_count = 2,
        type = "roboport",
        vehicle_impact_sound = DIR.vanilla_sounds.generic_impact,
        working_sound = data.raw.roboport.roboport.working_sound,
        open_door_trigger_effect = data.raw.roboport.roboport.open_door_trigger_effect,
        close_door_trigger_effect = data.raw.roboport.roboport.close_door_trigger_effect,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------
