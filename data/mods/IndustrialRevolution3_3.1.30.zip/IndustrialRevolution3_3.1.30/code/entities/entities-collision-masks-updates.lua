------------------------------------------------------------------------------------------------------------------------------------------------------

-- Late pass on collision masks

------------------------------------------------------------------------------------------------------------------------------------------------------

-- special layer for heavy picket / things that can cross water but still collide with objects
local collision_mask_util = require("__core__.lualib.collision-mask-util")
DIR.water_crossable_layer = collision_mask_util.get_first_unused_layer()

-- set up heavy picket

data.raw.car["heavy-picket"].collision_mask = {DIR.water_crossable_layer}

-- set up land-mines
-- primarily for heavy pickets triggering transfer plates, but may as well do all mines in case some other mod is also using them for shenanigans
-- can't use utils because those deal with regular collision mask, not trigger

for _,prototype in pairs(data.raw["land-mine"]) do
	prototype.trigger_collision_mask = DIR.merge_and_return_unique(prototype.trigger_collision_mask or {"item-layer", "object-layer", "player-layer", "water-tile"}, {DIR.water_crossable_layer})
end

-- set up everything else

local prototypes = collision_mask_util.collect_prototypes_with_layer("player-layer")
for _,prototype in pairs(prototypes) do
	if prototype.type ~= "tile" then
		prototype.collision_mask = DIR.merge_and_return_unique(collision_mask_util.get_mask(prototype), {DIR.water_crossable_layer})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
