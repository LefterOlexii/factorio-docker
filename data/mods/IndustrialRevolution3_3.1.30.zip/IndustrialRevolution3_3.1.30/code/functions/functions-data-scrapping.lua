------------------------------------------------------------------------------------------------------------------------------------------------------

-- SCRAPPING

------------------------------------------------------------------------------------------------------------------------------------------------------

function DIR.get_item_count_in_recipe_ingredients(recipe,item)
	local root = recipe.normal or recipe
	if not root.ingredients then return 0 end
	for _,ingredient in pairs(root.ingredients) do
		local name = ingredient.name or ingredient[1]
		local amount = ingredient.amount or ingredient[2]
		if name == item and type(amount) == "number" then return amount end
	end
	return 0
end

function DIR.is_recipe_one_item_result(recipe)
	local root = recipe.normal or recipe
	if root.result then return true end
	if root.results then
		local count = 0
		for _,result in pairs(root.results) do
			if result.type ~= "fluid" or not DIR.scrapping_ignored_fluids[result.name] then count = count + 1 end
		end
		if count == 1 then return true end
	end
	return false
end

function DIR.get_first_item_result(recipe)
	local root = recipe.normal or recipe
	if root.result then return {type = "item", name = root.result, amount = root.result_count or 1} end
	if root.results then
		for _,result in pairs(root.results) do
			if result.type ~= "fluid" then 
				if result.type == nil then return {type = "item", name = result[1], amount = result[2] or 1}
				elseif result.amount == nil then return {type = "item", name = result.name, amount = 1}
				else return result end
			end
		end
	end
	return nil
end

function DIR.is_a_crafting_recipe(recipe)
	if recipe.category == nil then return true end
	for _,category in pairs(DIR.scrapping_categories) do
		if string.find(recipe.category,category) then return true end
	end
	return false
end

function DIR.calculate_scraps(item_data, scraptable, count)
	-- check for loop just in case some bonkers situation has arisen with impossible recipe chains
	if not count then count = 1 else count = count + 1 end
	if count > 100 then
		error("\n\nIR3: Scrap calculator got stuck in a loop while trying to process item "..item_data.item..".\n\nMost likely cause: another mod has created a cyclical chain of crafting recipes without setting allow_as_intermediate or allow_intermediates to false for at least one recipe in the chain.")
	end
	-- search all recipes for this item and build up the scrap table
	local scrapqueue = {}
	for recipe_name,name in pairs(DIR.scrappable_recipes) do
		local recipe = data.raw.recipe[recipe_name]
		local value = DIR.get_item_count_in_recipe_ingredients(recipe,item_data.item)
		if value > 0 then
			value = (value / DIR.get_first_item_result(recipe).amount) * item_data.base_value
			if not scraptable[name] then scraptable[name] = {} end
			if not scraptable[name][item_data.base_item] then scraptable[name][item_data.base_item] = 0 end
			scraptable[name][item_data.base_item] = scraptable[name][item_data.base_item] + value
			local scrapdata = {item = name, base_value = value, base_item = item_data.base_item }
			scrapqueue[name .. ":" .. item_data.base_item] = scrapdata
		end
	end
	for _,scrapdata in pairs(scrapqueue) do
		DIR.calculate_scraps(scrapdata, scraptable, count)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
