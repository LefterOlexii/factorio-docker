------------------------------------------------------------------------------------------------------------------------------------------------------

-- ENTITIES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Work out belts-of-coal-per-machine and return as pair of KW strings

function DIR.get_scaled_energy_usage(speed, drain_ratio)
	drain_ratio = drain_ratio or 0
	local total = (DIR.belt_energy_value / (DIR.machines_per_belt * DIR.clusters_per_energy_belt * DIR.smelting_to_crafting_ratio)) * speed
	return {
		active = tostring(total * (1-drain_ratio)) .. "MW",
		passive = drain_ratio and (tostring(total * (drain_ratio)) .. "MW") or nil,
		total_as_numeric_MW = total,
	}
end

function DIR.get_standard_emissions(speed)
	return DIR.nice_round(speed * 3, 1)
end

function DIR.get_spilled_pollution_value(amount)
	return (amount/DIR.voiding_per_cycle) * DIR.chemical_pollution_rate * (DIR.standard_voiding_time/60)
end

function DIR.get_standard_speed(multiplier)
	return (1/DIR.machine_to_belt_ratio) * multiplier
end

-- nightmare fuel

function DIR.wild_stab_at_entity_by_name(entity_name)
	if not entity_name then return nil end
	-- ugh, like, a world of ugh
	for _,class in pairs(data.raw) do
		-- jesus christ make it stop
		if class ~= "land-mine" then
			for _,candidate in pairs(class) do
				-- max_health isn't mandatory but it's explicitly set for everything we care about
				if candidate.name == entity_name and candidate.selection_box and candidate.max_health then return candidate end
			end
		end
	end
	return nil
end

-- 2.4.0: when we broke out graphics into packs, paths suddenly got much more complex. 
-- look up the mod which now owns each folder

function DIR.get_sprites_path_from_name(name)
	for substring,path in pairs(DIR.sprite_paths_lookup) do
		if string.find(name,substring.."/",1,true) then return path end
	end
	error("Could not identify mod/folder for sprite "..name)
end

-- sprite definitions for animation layers etc.

function DIR.get_sprite_def(name, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, scale, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, sequence, sprite_path) 
	local variation_count = nil
	if frame_count and frame_count < 0 then
		variation_count = math.abs(frame_count)
		frame_count = nil
	end
	if shadow == true then shadow = "shadow" elseif shadow == false then shadow = nil end
	return {
		draw_as_shadow = (shadow == "shadow"),
		draw_as_light = (shadow == "light"),
		draw_as_glow = (shadow == "glow"),
		filename = string.format("%s/%s.png", sprite_path or DIR.get_sprites_path_from_name(name), name),
		blend_mode = blend_mode,
		animation_speed = animation_speed,
		repeat_count = repeat_count,
		frame_count = frame_count,
		direction_count = direction_count,
		line_length = line_length,
		height = height,
		width = width,
		x = x,
		y = y,
		scale = scale,
		shift = shift,
		tint = tint,
		apply_runtime_tint = apply_runtime_tint,
		run_mode = run_mode,
		priority = "high",
		flags = flags,
		variation_count = variation_count,
		frame_sequence = sequence,
	}
end

function DIR.get_multi_sprite_def(name, files, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, scale, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, sequence, sprite_path) 
	local stripes = {}
	for i=1,files do
		table.insert(stripes, { filename = string.format("%s/%s-%d.png", sprite_path or DIR.get_sprites_path_from_name(name), name, i), width_in_frames = frame_count, height_in_frames = direction_count / files })
	end
	if shadow == true then shadow = "shadow" elseif shadow == false then shadow = nil end
	return {
		draw_as_shadow = (shadow == "shadow"),
		draw_as_light = (shadow == "light"),
		draw_as_glow = (shadow == "glow"),
		stripes = stripes, 
		blend_mode = blend_mode,
		animation_speed = animation_speed,
		repeat_count = repeat_count,
		frame_count = frame_count,
		direction_count = direction_count,
		line_length = line_length,
		height = height,
		width = width,
		x = x,
		y = y,
		scale = scale,
		shift = shift,
		tint = tint,
		apply_runtime_tint = apply_runtime_tint,
		run_mode = run_mode,
		priority = "high",
		flags = flags,
		max_advance = 1, -- caps vehicle wheel animation
	}
end

function DIR.offset(shift1, shift2)
	return ({shift1[1]-shift2[1], shift1[2]-shift2[2]})
end

function DIR.shift_calc(x,y,tw,th,w,h)
	return {((tw/2) - (x + (w/2)))/64, ((th/2) - (y + (h/2)))/64}
end

function DIR.get_layer(name, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, tw, th, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, scale, sequence, sprite_path) 
	if shift then shift = DIR.offset(shift, DIR.shift_calc(x,y,tw,th,width,height)) end
	return DIR.get_sprite_def(name, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, scale or 0.5, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, sequence, sprite_path)
end

function DIR.get_multi_layer(name, files, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, tw, th, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, sequence, sprite_path) 
	if shift then shift = DIR.offset(shift, DIR.shift_calc(x,y,tw,th,width,height)) end
	return DIR.get_multi_sprite_def(name, files, frame_count, line_length, shadow, repeat_count, animation_speed, width, height, x, y, 0.5, shift, blend_mode, flags, tint, direction_count, apply_runtime_tint, run_mode, sequence, sprite_path)
end

function DIR.tiles(n) return n*64 end

function DIR.get_box(x,y,dx,dy)
	dx = dx or 0
	dy = dy or 0
	return {{-x+dx,-y+dy},{x+dx,y+dy}}
end

function DIR.autoplace_pass()
	local resources = {}
	for _,r in pairs(data.raw.resource) do
		if r.autoplace and r.autoplace.control and r.autoplace.control ~= "" then resources[r.autoplace.control] = true end
	end
	for _,a in pairs(data.raw["autoplace-control"]) do
		if a.category == "resource" and not resources[a.name] then data.raw["autoplace-control"][a.name] = nil end
	end
	for _,presets in pairs(data.raw["map-gen-presets"]) do
		for _,preset in pairs(presets) do
			if preset.basic_settings and preset.basic_settings.autoplace_controls then
				for i,a in pairs(preset.basic_settings.autoplace_controls) do
					if not resources[i] then preset.basic_settings.autoplace_controls[i] = nil end
				end
			end
		end
	end
end

function DIR.get_crafting_tints_from_hue(hue,saturation,alpha)
	return {
		primary = DIR.hsva2rgba(hue, DIR.get_saturation(hue,saturation), 1, alpha or 1), -- tier/material colour, often overridden later by metallic tint
		secondary = DIR.hsva2rgba(hue, DIR.get_saturation(hue,saturation), 1, alpha or 1), -- same but never overridden
		tertiary = DIR.hsva2rgba(hue, DIR.get_saturation(hue,saturation), 0.75, alpha or 1), -- darker colour
		quaternary = DIR.hsva2rgba(hue, DIR.get_saturation(hue,saturation)/2, 1, alpha or 1),	-- pastel colour
	}
end

function DIR.get_crafting_tints_from_hues(saturation,h1,h2,h3,h4,v1,v2)
	return {
		primary = DIR.hsva2rgba(h1, DIR.get_saturation(h1,saturation), v1), 
		secondary = DIR.hsva2rgba(h2, DIR.get_saturation(h2,saturation), v2), 
		tertiary = DIR.hsva2rgba(h3, DIR.get_saturation(h3,saturation), v1), 
		quaternary = DIR.hsva2rgba(h4, DIR.get_saturation(h4,saturation), v2),	
	}
end

local function check_connections(connections, ctype, name)
	if connections == nil or table_size(connections) == 0 then
		DIR.spam_log("Entity "..name.." has a fluid box without pipe connections", DIR.log_level.warning)
		return
	end
	for _,c in pairs(connections) do
		if (c.type ~= "input-output") and (c.type ~= ctype) then
			DIR.spam_log("Entity "..name.." has a pipe connection type that doesn't match production type", DIR.log_level.warning)
		end
	end
end

local function check_fluidbox(box,name)
	if type(box) == "table" then
		if box.base_level then
			if box.production_type == "output" then
				if box.base_level < 0 then DIR.spam_log("Entity "..name.." has an output fluid box with negative base level", DIR.log_level.warning) end
				check_connections(box.pipe_connections, box.production_type, name)
			elseif box.production_type == "input" then
				if box.base_level > 0 then DIR.spam_log("Entity "..name.." has an input fluid box with positive base level", DIR.log_level.warning) end
				check_connections(box.pipe_connections, box.production_type, name)
			elseif box.production_type == "input-output" then
				if box.base_level > 0 then DIR.spam_log("Entity "..name.." has an input-output fluid box with positive base level", DIR.log_level.warning) end
				if box.height == nil then DIR.spam_log("Entity "..name.." has an input-output fluid box with no height", DIR.log_level.warning) end
				check_connections(box.pipe_connections, box.production_type, name)
			else
				DIR.spam_log("Entity "..name.." has an illegal fluid box production type", DIR.log_level.warning)
			end
		else
			DIR.spam_log("Entity "..name.." doesn't have a fluid box base level", DIR.log_level.warning)
		end
	end
end

function DIR.final_entities_pass()
	-- add coke to everything that burns chemical (but not vice versa)
	for _,ptype in pairs(data.raw) do
		for _,p in pairs(ptype) do
			local b = (p.energy_source and p.energy_source.type == "burner") and p.energy_source or p.burner
			if b then
				if (DIR.list_contains(b.fuel_categories,"chemical") or (b.fuel_category == "chemical")) then
					if b.fuel_categories then
						b.fuel_categories = DIR.merge_and_return_unique(b.fuel_categories, {"coke"})
					elseif b.fuel_category then
						b.fuel_categories = {"chemical","coke"}
						b.fuel_category = nil
					end
				end
			end
		end
	end
	-- warn about wonky fluidbox settings
	for _,ptype in pairs(data.raw) do
		for _,p in pairs(ptype) do
			if p.fluid_boxes then for _,b in pairs(p.fluid_boxes) do check_fluidbox(b,p.name) end end
			if p.energy_source and p.energy_source.fluid_box then check_fluidbox(p.energy_source.fluid_box,p.name) end
		end
	end
	-- we don't allow third parties to delete this mod's tiles - rude
	local tile_components = {"crushed","covering"}
	for _, component in pairs(tile_components) do
		if DIR.components[component].tile_walking_speed then
			for material, speed in pairs(DIR.components[component].tile_walking_speed) do
				if not data.raw.tile[DIR.get_item_name(material,component)] then
					error("\n\n"..DIR.IR..": A custom tile created and required by IR3 has been deleted by another mod. Try reducing the number of mods installed or adjust other mod settings before activating IR3.\n")
				end
			end
		end
	end
	-- check on collision mask/box shenanigans - too many third party mods change properties which the upgrade/fast-replace system is hyper-sensitive about
	for ptype,collection in pairs(DIR.entity_upgrade_properties_checklist) do
		for rentity,entities in pairs(collection) do
			local reference_entity = data.raw[ptype][rentity]
			if reference_entity then
				for _,centity in pairs(entities) do
					local comparison_entity = data.raw[ptype][centity]
					if comparison_entity then
						if not DIR.string_lists_have_same_members(comparison_entity.collision_mask, reference_entity.collision_mask) then
							comparison_entity.collision_mask = reference_entity.collision_mask
							DIR.spam_log("Enforcing collision_mask from "..rentity.." on "..centity, DIR.log_level.warning)
						end
						if comparison_entity.fast_replaceable_group ~= reference_entity.fast_replaceable_group then
							comparison_entity.fast_replaceable_group = reference_entity.fast_replaceable_group
							DIR.spam_log("Enforcing fast_replaceable_group from "..rentity.." on "..centity, DIR.log_level.warning)
						end
						if not DIR.boxes_are_equivalent(comparison_entity.collision_box, reference_entity.collision_box) then
							comparison_entity.collision_box = reference_entity.collision_box
							DIR.spam_log("Enforcing collision_box from "..rentity.." on "..centity, DIR.log_level.warning)
						end
					else
						DIR.spam_log("No such upgrade-sensitive entity as "..ptype.."/"..centity, DIR.log_level.warning)
					end
				end
			else
				DIR.spam_log("No such upgrade-sensitive reference entity as "..ptype.."/"..rentity, DIR.log_level.warning)
			end
		end
	end
	-- audit module compatibility
	-- for _,ptype in pairs({"furnace","assembling-machine"}) do
		-- for _,m in pairs(data.raw[ptype]) do
			-- if ((m.allowed_effects == nil) or (table_size(m.allowed_effects) == 0)) and m.module_specification ~= nil then
				-- DIR.spam_log("Entity "..m.name.." ("..ptype..") allows module effects but has no module specs", DIR.log_level.warning)
			-- end
			-- if not DIR.list_contains(m.flags, "hidden") and m.module_specification == nil and m.energy_source and m.energy_source.type == "electric" then
				-- DIR.spam_log("Electric entity "..m.name.." ("..ptype..") has no module specs", DIR.log_level.warning)
			-- end
		-- end
	-- end
	-- audit steam fuel sources
	-- for pn,pt in pairs(data.raw) do
		-- for name,ptype in pairs(pt) do
			-- if ptype.energy_source and ptype.energy_source.type == "fluid" and ptype.energy_source.fluid_box and ptype.energy_source.fluid_box.filter == "steam" then
				-- DIR.spam_log("Steam entity: "..name, DIR.log_level.warning)
			-- end
		-- end
	-- end
    -- audit fluid box sizes
	-- for _,ptype in pairs({"furnace"}) do
		-- for _,p in pairs(data.raw[ptype]) do
			-- if p.fluid_boxes then
				-- for _,b in pairs(p.fluid_boxes) do
					-- if type(b) == "table" then
						-- local capacity = math.abs((b.base_area or 1) * (b.height or 1))
						-- if capacity > 1 then
							-- DIR.spam_log("Entity "..p.name.." ("..ptype..") has "..b.production_type.." fluid box size "..capacity*100, DIR.log_level.warning)
						-- end
					-- end
				-- end
			-- end
		-- end
	-- end
end

function DIR.is_a_low_priority_unit(entity)
	return entity and entity.max_health and (entity.max_health < DIR.low_priority_target_health) and entity.name ~= "compilatron"
end

------------------------------------------------------------------------------------------------------------------------------------------------------
