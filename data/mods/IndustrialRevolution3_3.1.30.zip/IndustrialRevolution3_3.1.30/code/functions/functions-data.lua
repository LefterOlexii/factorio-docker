------------------------------------------------------------------------------------------------------------------------------------------------------

-- DATA STAGE FUNCTIONS

------------------------------------------------------------------------------------------------------------------------------------------------------

require(DIR.IR_path.."/code/functions/functions-data-maths")
require(DIR.IR_path.."/code/functions/functions-data-entities")
require(DIR.IR_path.."/code/functions/functions-data-technology")
require(DIR.IR_path.."/code/functions/functions-data-items-recipes")
require(DIR.IR_path.."/code/functions/functions-data-icons")
require(DIR.IR_path.."/code/functions/functions-data-ammo")
require(DIR.IR_path.."/code/functions/functions-data-particles")
require(DIR.IR_path.."/code/functions/functions-data-scrapping")
require(DIR.IR_path.."/code/functions/functions-data-log")

------------------------------------------------------------------------------------------------------------------------------------------------------
