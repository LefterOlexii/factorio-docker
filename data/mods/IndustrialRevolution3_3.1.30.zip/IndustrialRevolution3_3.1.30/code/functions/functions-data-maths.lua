--------------------------------------------------------------------------------------------------------------------------------------------------------

-- MATHS

--------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.random_index = 0
DIR.random = require(DIR.IR_path.."/code/data/random")

function DIR.get_pretend_random_integer(m)
	DIR.random_index = (DIR.random_index >= #DIR.random) and 1 or (DIR.random_index + 1)
	return math.ceil(DIR.random[DIR.random_index] * m)
end

function DIR.get_pretend_random_float(m)
	DIR.random_index = (DIR.random_index >= #DIR.random) and 1 or (DIR.random_index + 1)
	return DIR.random[DIR.random_index] * m
end

function DIR.nice_round(num, decimals)
  local mult = 10^(decimals or 0)
  return math.floor(num * mult + 0.5) / mult
end

function DIR.linear_transform(x,a,b,c,d)
	return (x-a)/(b-a)*(d-c)+c
end

function DIR.multiply_vector(v,f)
	if not v.x then v.x = v[1] end
	if not v.y then v.y = v[2] end
    return { x = v.x * f, y = v.y * f }
end

function DIR.get_vector_sum(v1,v2)
    if not v1 or not v2 then return nil end
	if v1.x or v1.y or v2.x or v2.y then
		return { x= (v1.x or v1[1]) + (v2.x or v2[1]), y = (v1.y or v1[2]) + (v2.y or v2[2]) }
	else
		return { (v1.x or v1[1]) + (v2.x or v2[1]), (v1.y or v1[2]) + (v2.y or v2[2]) }
	end
	-- if not v1.x then v1.x = v1[1] end
	-- if not v1.y then v1.y = v1[2] end
	-- if not v2.x then v2.x = v2[1] end
	-- if not v2.y then v2.y = v2[2] end
    -- return { x = v1.x + v2.x, y = v1.y + v2.y}
end

function DIR.vectors_are_equal(v1,v2)
	return (v1.x == v2.x) and (v1.y == v2.y)
end

function DIR.get_vector_difference(v1,v2)
    if not v1 or not v2 then return nil end
    return { x = v1.x - v2.x, y = v1.y - v2.y}
end

function DIR.get_vector_difference_normal(v1,v2)
	local diff = DIR.get_vector_difference(v1,v2)
	local dist = DIR.get_distance(v1,v2)
	if dist == 0 then return {0,0} end
	return {x=diff.x/dist, y=diff.y/dist}
end

function DIR.get_vector_midpoint(v1,v2)
	return DIR.multiply_vector(DIR.get_vector_sum(v1,v2), 0.5)
end

function DIR.get_distance_squared(v1,v2)
	local diff = DIR.get_vector_difference(v1,v2)
	return (diff.x ^ 2) + (diff.y ^ 2)
end

function DIR.get_distance(v1,v2)
	return math.sqrt(DIR.get_distance_squared(v1,v2))
end

function DIR.list_contains(list,target)
    if not list then return false end
    for _,v in pairs(list) do
        if v == target then return true end
    end
    return false
end

function DIR.append_list(t1, t2)
    if not t1 then t1 = {} end
    if not t2 then t2 = {} end
    for k,v in pairs(t2) do
        table.insert(t1,v)
    end
    return t1
end

function DIR.remove_from_list(item, list)
	local new = {}
	for _,v in pairs(list) do
		if v ~= item then table.insert(new,v) end
	end
	return new
end

function DIR.values_to_keys(t)
    if t == nil then return nil end
    local t2 = {}
    for _,v in pairs(t) do t2[v] = true end
    return t2
end

function DIR.keys_to_values(t)
    if t == nil then return nil end
    local t2 = {}
    for k,_ in pairs(t) do table.insert(t2,k) end
    return t2
end

function DIR.unique_values_only(t)
	return DIR.keys_to_values(DIR.values_to_keys(t))
end

function DIR.merge_and_return_unique(t1,t2)
	t1 = DIR.append_list(t1, t2)
	return DIR.unique_values_only(t1)
end

function DIR.merge_keys(t1,t2)
    if not t2 then return t1 end
    if not t1 then return t2 end
    for k,v in pairs(t2) do
        t1[k] = v
    end
    return t1
end

function DIR.serialise(t)
    if t == nil then return nil end
    return table.concat(t, ", ")
end

function DIR.is_value_in_list(t, value)
    if not t or not value then return false end
    for k,v in pairs(t) do
        if value == v then return true end
    end
    return false
end

function DIR.clamp(val, mini, maxi)
    return math.min(math.max(val, mini), maxi)
end

function DIR.multiply_colour(colour, factor)
    if not colour.r then colour.r = colour[1] or 0 end
    if not colour.g then colour.g = colour[2] or 0 end
    if not colour.b then colour.b = colour[3] or 0 end
    if not colour.a then colour.a = colour[4] or 1 end
    return {r=colour.r*factor, g=colour.g*factor, b=colour.b*factor, a=colour.a}
end

function DIR.get_premultiplied_colour(color,factor)
	factor = factor or 1
	local a = color.a or 1
	return DIR.multiply_colour(color, a * factor)
end

function DIR.seconds_to_ticks(s)
    return math.floor(s * 60)
end

function DIR.hsva2rgba(h, s, v, a)
	if a == nil then a = 1 end
    local r, g, b
    local i = math.floor(h * 6);
    local f = h * 6 - i;
    local p = v * (1 - s);
    local q = v * (1 - f * s);
    local t = v * (1 - (1 - f) * s);
    i = i % 6
    if i == 0 then r, g, b = v, t, p
    elseif i == 1 then r, g, b = q, v, p
    elseif i == 2 then r, g, b = p, v, t
    elseif i == 3 then r, g, b = p, q, v
    elseif i == 4 then r, g, b = t, p, v
    elseif i == 5 then r, g, b = v, p, q
    end
    return { r = r, g = g, b = b, a = a }
end

function DIR.rgba2hsva(r, g, b, a)
  local max, min = math.max(r, g, b), math.min(r, g, b)
  local h, s, v
  v = max

  local d = max - min
  if max == 0 then s = 0 else s = d / max end

  if max == min then
    h = 0 -- achromatic
  else
    if max == r then
    h = (g - b) / d
    if g < b then h = h + 6 end
    elseif max == g then h = (b - r) / d + 2
    elseif max == b then h = (r - g) / d + 4
    end
    h = h / 6
  end

  return {h = h, s = s, v = v, a = a}
end

function DIR.get_saturation(hue,saturation)
	if saturation == nil then return 1 end
	if hue > 0 then return saturation end
	return 0
end

-- 3.0.5: re-adapted from the weird version in util.format_number
function DIR.format_number_to_units(amount, units)
	units = units or ""
	local suffix = ""
	local suffix_list = {
		["P"] = 10^15,
		["T"] = 10^12,
		["G"] = 10^9,
		["M"] = 10^6,
		["k"] = 10^3
	}
	for letter, limit in pairs (suffix_list) do
		if math.abs(amount) >= limit then
			amount = amount/limit
			suffix = letter
			break
		end
	end
	local formatted, k = amount
	while true do
		formatted, k = string.gsub(formatted, "^(-?%d+)(%d%d%d)", '%1,%2')
		if (k==0) then break end
	end
	return formatted..suffix..units
end

local function serialise_bbox(box)
	local lx = box.left_top and box.left_top.x or box[1][1] or box[1].x
	local ly = box.left_top and box.left_top.y or box[1][2] or box[1].y
	local rx = box.right_bottom and box.right_bottom.x or box[2][1] or box[2].x
	local ry = box.right_bottom and box.right_bottom.y or box[2][2] or box[2].y
	if not lx or not ly or not rx or not ry then error("Bad bounding box") end
	return {lx,ly,rx,ry}
end

function DIR.get_area_of_bounding_box(boundingbox)
	local nbox = serialise_bbox(boundingbox)
	return math.abs(nbox[1]-nbox[3]) * math.abs(nbox[2]-nbox[4])
end

function DIR.boxes_are_equivalent(b1,b2)
	if b1 == nil or b2 == nil then return (b1 == b2) end
	local b1n = serialise_bbox(b1)
	local b2n = serialise_bbox(b2)
	for k,v in ipairs(b1n) do
		if b2n[k] ~= v then return false end
	end
	return true
end

function DIR.splitstring(s, delimiter)
    result = {};
    for match in (s..delimiter):gmatch("(.-)"..delimiter) do
        table.insert(result, match);
    end
    return result;
end

function DIR.pairs_by_sorted_keys(t, f)
	local a = {}
	for n in pairs(t) do table.insert(a, n) end
		table.sort(a, f)
		local i = 0 
		local iter = function()
		i = i + 1
		if a[i] == nil then return nil
		else return a[i], t[a[i]]
		end
	end
	return iter
end

function DIR.divide_vector(v,f)
	return {v[1]/f, v[2]/f}
end

function DIR.get_theta_radians(p1,p2)
    return math.atan2(p2.y-p1.y, p2.x-p1.x)
end

function DIR.get_theta(e1,e2)
    return (math.atan2(e2.y-e1.y, e2.x-e1.x) / (math.pi*2))
end

function DIR.get_facing_away(e1,e2)
    return DIR.get_theta(e1.position,e2.position) - 0.25
end

function DIR.escape(str)
    return str:gsub("[%(%)%.%%%+%-%*%?%[%]%^%$]", function(c) return "%" .. c end)
end

function DIR.escaped_gsub(str,old,new)
	return string.gsub(str, DIR.escape(old), new)
end

-- function DIR.parse_version_number(mod_version)
	-- if mod_version == nil then return nil end
	-- local major, minor, patch = string.match(mod_version, "(%d+)%.(%d+)%.(%d+)")
	-- return {major = major or 0, minor = minor or 0, patch = patch or 0}
-- end

-- function DIR.versions_are_similar(mv1,mv2,tolerance)
	-- tolerance = tolerance or 3
	-- local v1 = DIR.parse_version_number(mv1)
	-- local v2 = DIR.parse_version_number(mv2)
	-- return (v1.major == v2.major) and (v1.minor == v2.minor) and (math.abs(tonumber(v1.patch)-tonumber(v2.patch)) <= tolerance)
-- end

function DIR.string_lists_have_same_members(l1,l2)
	if l1 == nil or l2 == nil then return (l1 == l2) end
	local a1 = DIR.values_to_keys(l1)
	local a2 = DIR.values_to_keys(l2)
	for k,v in pairs(a1) do
		if a2[k] ~= v then return false end
	end
	return true
end

------------------------------------------------------------------------------------------------------------------------------------------------------
