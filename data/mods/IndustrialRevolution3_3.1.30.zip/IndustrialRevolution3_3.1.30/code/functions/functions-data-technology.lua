------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY

------------------------------------------------------------------------------------------------------------------------------------------------------

-- flags for the flag king on his flag throne

function DIR.is_an_ignored_recipe(name)
	local recipe = data.raw.recipe[name]
	return recipe and recipe.IR_tech_rebuild_ignore
end

function DIR.is_an_ignored_ingredient_provider(name)
	local recipe = data.raw.recipe[name]
	-- if recipe then log(serpent.block(recipe)) end
	return recipe and recipe.IR_tech_rebuild_ignore_as_provider
end

function DIR.is_an_ignored_technology(name)
	local tech = data.raw.technology[name]
	return tech and tech.IR_tech_rebuild_ignore
end

-- does a tech unlock any recipes?

function DIR.does_tech_unlock_recipes(tech)
	if not tech.effects then return false end
	for _,effect in pairs(tech.effects) do
		if effect.type == "unlock-recipe" then return true end
	end
	return false
end

-- create a bare-bones new tech

function DIR.add_new_minimal_tech(tech_name, icon, icon_source, unlocks, prerequisites, bonus_effects, rebuild_ignore)
    if icon_source == false then
		icon = DIR.get_icon_path(icon, DIR.high_icon_size)
	elseif icon_source == true then
		icon = string.format("__base__/graphics/technology/%s.png", icon)
	else 
		icon = DIR.get_icon_path(icon, DIR.high_icon_size, icon_source)
	end
    local effects = {}
    if unlocks then
        for _,unlock in pairs(unlocks) do
            table.insert(effects, {
                type = "unlock-recipe",
                recipe = unlock
            })
        end
    end
    if bonus_effects then
        for _,effect in pairs(bonus_effects) do
            table.insert(effects, effect)
        end
    end
    data.raw.technology[tech_name] = nil
    data:extend {{
        type = "technology",
        name = tech_name,
        enabled = true,
        icon = icon,
        icon_size = vanilla_icon and DIR.vanilla_tech_icon_size or DIR.high_icon_size,
		icon_mipmaps = vanilla_icon and DIR.vanilla_tech_icon_mipmaps or DIR.high_icon_mipmaps,
        unit = {
            count = 999,
            time = 60,
            ingredients = {{"automation-science-pack", 1}},
        },
        prerequisites = prerequisites,
        effects = effects,
        upgrade = false,
		IR_native = true, -- so we know that this is native
		IR_tech_rebuild_ignore = rebuild_ignore, -- added 2.2.0 for IR2G
    }}
    return data.raw.technology[tech_name]
end

-- add a machine masked icon to a tech

function DIR.add_machine_mask_to_tech(tech, machine, icon_path, tint)
	if not tech.icons then
		tech.icon = nil
		tech.icon_size = nil
		tech.icons = {
			{ icon = DIR.machines[machine] and DIR.get_icon_path(DIR.machines[machine].icon_masks.base, DIR.high_icon_size, icon_path) or DIR.get_icon_path(machine, DIR.high_icon_size, icon_path), icon_size = DIR.high_icon_size, icon_mipmaps = DIR.high_icon_mipmaps },
			{ icon = DIR.machines[machine] and DIR.get_icon_path(DIR.machines[machine].icon_masks.mask, DIR.high_icon_size, icon_path) or DIR.get_icon_path(machine.."-mask", DIR.high_icon_size, icon_path), DIR.high_icon_size, icon_path, icon_size = DIR.high_icon_size, icon_mipmaps = DIR.high_icon_mipmaps, tint = tint or DIR.machines[machine].icon_masks.tint },
		}
	else
		table.insert(tech.icons, 2,
			{ icon = DIR.machines[machine] and DIR.get_icon_path(DIR.machines[machine].icon_masks.mask, DIR.high_icon_size, icon_path) or DIR.get_icon_path(machine.."-mask", DIR.high_icon_size, icon_path), icon_size = DIR.high_icon_size, icon_mipmaps = DIR.high_icon_mipmaps, tint = tint or DIR.machines[machine].icon_masks.tint }
		)
	end
end

-- return the first tech you find that unlocks a recipe

function DIR.find_tech_that_unlocks(recipe)
    for _,tech in pairs(data.raw.technology) do
        if tech.enabled ~= false and tech.effects then
            for _,effect in pairs(tech.effects) do
                if effect.recipe == recipe then return tech end
            end
        end
    end
    return nil
end

-- return a list of tech names that have this tech as prereq

function DIR.find_techs_with_prereq(prereq)
	-- this gets called a LOT during science recosting, so cache it
	DIR.cached_techs_with_prereq = DIR.cached_techs_with_prereq or {}
	if DIR.cached_techs_with_prereq[prereq] then return DIR.cached_techs_with_prereq[prereq] end
    local techs = {}
    for _,tech in pairs(data.raw.technology) do
        if tech.enabled ~= false and tech.prerequisites and DIR.is_value_in_list(tech.prerequisites, prereq) then table.insert(techs, tech.name) end
    end
	DIR.cached_techs_with_prereq[prereq] = techs
    return techs
end

-- add recipe unlock to tech

function DIR.add_unlock_to_tech(tech,recipe,index)
    local t = data.raw.technology[tech]
    if not t then
		DIR.spam_log("Asked to add unlock to non-existent tech "..tech, DIR.log_level.error)
		return
	end
    if not t.effects then t.effects = {} end
    if not index then table.insert(t.effects, {type = "unlock-recipe", recipe = recipe})
    else table.insert(t.effects, index, {type = "unlock-recipe", recipe = recipe}) end
end

-- strip recipe unlock from tech

function DIR.remove_unlock_from_tech(tech, recipe)
    local t = data.raw.technology[tech]
    if t and t.effects then 
		for k,effect in pairs(t.effects) do
			if effect.recipe == recipe then
				t.effects[k] = nil
			end
		end
	end
end

-- remove all effects in a tech

function DIR.remove_all_effects_from_tech(tech)
    local t = data.raw.technology[tech]
    if t then t.effects = {} end
end

-- remove all barrel recipes from a tech

function DIR.remove_all_barrels_from_tech(tech)
    local t = data.raw.technology[tech]
    if not t or not t.effects then return end
    local copy = {}
    for _,effect in pairs(t.effects) do
        if effect.recipe and not string.find(effect.recipe,"%-barrel$") then table.insert(copy,effect) end
    end
    t.effects = copy
end

-- does tech have a specific prereq

function DIR.get_tech_has_prereq(tech_name, prereq)
	if data.raw.technology[tech_name] or not data.raw.technology[tech_name].prerequisites then return false end
	for _,p in pairs(data.raw.technology[tech_name].prerequisites) do
		if p == prereq then return true end
	end
	return false
end

-- add a new prereq to a tech

function DIR.add_prereq_to_tech(tech_name, prereq)
    if not data.raw.technology[tech_name] then
		DIR.spam_log("Asked to add prereqs to non-existent tech: "..tech_name, DIR.log_level.error)
		return
	end
    if not data.raw.technology[tech_name].prerequisites then data.raw.technology[tech_name].prerequisites = {} end
	if not DIR.get_tech_has_prereq(tech_name, prereq) then table.insert(data.raw.technology[tech_name].prerequisites, prereq) end
end

-- override all prereqs in a tech

function DIR.replace_all_prereqs(tech, prereq)
    data.raw.technology[tech].prerequisites = prereq
end

-- remove a specific prereq from a tech

function DIR.remove_prereq_from_tech(tech, prereq)
    if not data.raw.technology[tech] or not data.raw.technology[tech].prerequisites then return end
    local t = {}
    for _,v in pairs(data.raw.technology[tech].prerequisites) do
        if v ~= prereq then table.insert(t,v) end
    end
    data.raw.technology[tech].prerequisites = t
end

-- disable a tech - also remove it as a prereq from all other techs

function DIR.disable_technology(tech)
    local techp = data.raw.technology[tech]
	if techp then
		techp.enabled = false
		techp.hidden = true
		techp.prerequisites = nil
		for _,rawtech in pairs(data.raw.technology) do
			DIR.remove_prereq_from_tech(rawtech.name, techp)
		end
	else
		DIR.spam_log("Asked to disable non-existent tech "..tech)
	end
end

-- function DIR.enable_technology(tech)
    -- tech = data.raw.technology[tech]
    -- tech.enabled = true
    -- tech.hidden = false
-- end

-- add a science pack ingredient to a tech

function DIR.add_pack_to_tech(pack, tech_name)
    local tech = data.raw.technology[tech_name]
    if not tech then error("Asked to add science pack to non-existent tech: "..tech_name) end
    if not tech.unit.ingredients then tech.unit.ingredients = {} end
    -- make sure it's not already there
    if not DIR.get_tech_has_pack(tech,pack) then 
		table.insert(tech.unit.ingredients, { pack, 1 } )
	end
end

-- add a science pack ingredient to a tech (optional) and all its "children" (mandatory)
-- assumes that cycles have already been identified and aborted from

function DIR.recursive_add_pack_to_tech(pack, tech_name, add_to_original)
	DIR.recursive_pack_cache = DIR.recursive_pack_cache or {} 
	DIR.recursive_pack_cache[pack] = DIR.recursive_pack_cache[pack] or {}
	if DIR.recursive_pack_cache[pack][tech_name] then return end
    if add_to_original then
		DIR.add_pack_to_tech(pack, tech_name)
		DIR.recursive_pack_cache[pack][tech_name] = true
	end
    local children = DIR.find_techs_with_prereq(tech_name)
    for _,child in pairs(children) do
        DIR.recursive_add_pack_to_tech(pack, child, true)
    end
end

-- check if a tech uses a pack

function DIR.get_tech_has_pack(tech,pack)
	if tech.unit and tech.unit.ingredients then
		for _,ingredient in pairs(tech.unit.ingredients) do
			if (ingredient.name == pack) or (ingredient[1] == pack) then return true end
		end
	end
	return false
end

-- return list of unlocked recipes for a tech

function DIR.get_tech_recipe_unlocks(tech)
	local list = {}
	for _,effect in pairs(data.raw.technology[tech].effects) do
		if effect.type == "unlock-recipe" then table.insert(list,effect.recipe) end
	end
	return table_size(list) == 0 and {"none"} or DIR.serialise(list)
end

function DIR.get_tech_unlocks_recipe(tech,recipe)
	local tech = data.raw.technology[tech]
	if not tech or not tech.effects then return false end
	for _,effect in pairs(tech.effects) do
		if effect.type == "unlock-recipe" and effect.recipe == recipe then return true end
	end
	return false
end

-- recursively search techs for ancestors and populate the cache

function DIR.get_ancestors_of_tech(tech_name, chain)
    local proto = data.raw.technology[tech_name]
    if not proto or not proto.prerequisites or proto.enabled == false then return nil end

	-- we may have trodden this road before
    if DIR.ancestors[tech_name] then return DIR.ancestors[tech_name] end

	-- build up list of names
	if not chain then chain = {tech_name}
	elseif DIR.is_value_in_list(chain,tech_name) then
		-- we're in a cycle. abort, abort
		table.insert(chain,tech_name)
		local message = "\n\nGuru meditation error: IR3 has detected a cyclical dependency in the technology tree.\nProbable cause: a vanilla or IR3 recipe/technology has been changed so that recipe A depends on item B but recipe B depends on item A.\n\n"
		local found = false
		for _,name in pairs(chain) do
			if name == tech_name then found = true end
			if found then
				message = message..name.." [" .. DIR.serialise(data.raw.technology[name].prerequisites) .. "] ("..DIR.get_tech_recipe_unlocks(name)..")".."\n"
			end
		end
		error(message,0)
	else table.insert(chain,tech_name) end

	-- flip prereqs list into keys
    local ancestors = DIR.values_to_keys(proto.prerequisites)
	
	-- for each prereq, merge in their ancestors' prereqs, recursively
    for prerequisite,_ in pairs(DIR.values_to_keys(proto.prerequisites)) do
        ancestors = DIR.merge_keys(ancestors, DIR.get_ancestors_of_tech(prerequisite, chain))
    end
	
	-- cache this result so we don't have to do the same thing over and over
    DIR.ancestors[tech_name] = ancestors
    return ancestors
end

-- is this tech fair game for the tech tree generator?

function DIR.is_tech_rebuildable(tech)
	return (tech.enabled ~= false) and (tech.IR_native or DIR.vanilla_techs[DIR.strip_numeric_suffix(tech.name)])
end

-- icon overlay
function DIR.add_tech_icon_overlay(tech, icon_path, icon_shift)
	local t = data.raw.technology[tech]
	if not t then error("add_tech_icon_overlay given non-existent tech "..tech) end
	if t.icons == nil then
		if not t.icon then error("add_tech_icon_overlay given tech with missing icon "..tech) end
		t.icons = {
			{
				icon = t.icon,
				icon_size = t.icon_size or DIR.high_icon_size, icon_mipmaps = t.icon_mipmaps or DIR.high_icon_mipmaps,
			}
		}
		t.icon = nil
		t.icon_size = nil
		t.icon_mipmaps = nil
	end
	table.insert(t.icons, {
		icon = icon_path, icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, shift = icon_shift or {96,96},
	})
end

------------------------------------------------------------------------------------------------------------------------------------------------------
