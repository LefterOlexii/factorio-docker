------------------------------------------------------------------------------------------------------------------------------------------------------

-- ITEMS AND RECIPES

------------------------------------------------------------------------------------------------------------------------------------------------------

function DIR.count_ingredients_by_type(ingredients,itype)
	local count = 0
	for _,ingredient in pairs(ingredients) do 
		if ingredient.type == itype then count = count + 1 end
	end
	return count
end

function DIR.get_belt_brightness_variation_pictures(icon_name,icon_size,icon_mipmaps,icon_path)
	local pictures = {}
	for i=1-DIR.belt_brightness_variation,1,DIR.belt_brightness_variation/DIR.belt_brightness_variation_steps do
		table.insert(pictures, {
			filename = DIR.get_icon_path(icon_name,icon_size,icon_path),
			size = icon_size,
			scale = 16 / icon_size,
			mipmap_count = icon_mipmaps,
			tint = {i,i,i}
		})
	end
	return pictures
end

function DIR.generate_system_item(material,component,variant,icon_path)

	local componentdata = DIR.components[component]
	if not componentdata then error("generate_system_item: no component data for "..component) end
	local materialdata = DIR.materials[material]
	if not materialdata then error("generate_system_item: component "..component.." specifies non-existent material "..material) end

	-- ITEM
	local name = DIR.get_item_name(material, component) .. (variant and "-"..variant or "")
	local item = {}
	item.type = componentdata.type
	item.name = name
	item.stack_size = (componentdata.stack_size_exceptions and componentdata.stack_size_exceptions[material]) or componentdata.stack_size or 100
	item.ir_component = true -- flag for detection later, discarded at end of data stage
	local icon_name = componentdata.icon or name
	-- icon - does it have belt variants?
	local variations = componentdata.belt_variation_exceptions and componentdata.belt_variation_exceptions[material] or componentdata.belt_variations
	if variations and variations > 1 and componentdata.rotate_icon_variants and componentdata.rotate_icon_variants[material] then
		-- as of 2.0.1 components can opt in to icon variant rotation again
		if DIR.belt_variant_count[component] == nil or DIR.belt_variant_count[component] > variations then DIR.belt_variant_count[component] = 1 end
		if DIR.belt_variant_count[component] > 1 then icon_name = icon_name .. "-" .. DIR.belt_variant_count[component] end
		DIR.belt_variant_count[component] = DIR.belt_variant_count[component] + 1
	end
	if componentdata.use_vanilla_icons and componentdata.use_vanilla_icons[material] then
		item.icon = DIR.base_icons_path.."/"..icon_name..".png" 
		item.icon_size = 64
		item.icon_mipmaps = 4
	else
		item.icon = DIR.get_icon_path(icon_name,DIR.icon_size,icon_path) 
		item.icon_size = DIR.icon_size
		item.icon_mipmaps = DIR.icon_mipmaps
	end
	-- belt variations
	if variations and variations > 1 then
		item.pictures = {}
		for i=1,variations do
			local variant_name, filename
			if (componentdata.use_vanilla_icons and componentdata.use_vanilla_icons[material]) then
				variant_name = (i == 1) and item.name or item.name.."-"..(i-1)
				filename = DIR.base_icons_path.."/"..variant_name..".png"
			else
				variant_name = (i == 1) and item.name or item.name.."-"..i
				filename = DIR.get_icon_path(variant_name,DIR.icon_size,icon_path)
			end
			if componentdata.belt_variation_lights and componentdata.belt_variation_lights[material] then
				table.insert(item.pictures, {
					layers = {
						{
							filename = filename,
							size = DIR.icon_size,
							scale = 16 / DIR.icon_size,
							mipmap_count = DIR.icon_mipmaps,
						},
						{
							filename = filename,
							size = DIR.icon_size,
							scale = 16 / DIR.icon_size,
							mipmap_count = DIR.icon_mipmaps,
							draw_as_light = true,
							flags = {"light"},
							blend_mode = "additive",
							tint = {0.4,0.4,0.4,0.4},
						},
					},
				})
			else
				table.insert(item.pictures, {
					filename = filename,
					size = DIR.icon_size,
					scale = 16 / DIR.icon_size,
					mipmap_count = DIR.icon_mipmaps,
				})
			end
		end
	elseif (settings.startup["ir-belt-brightness-variation"].value == "on") and componentdata.brightness_variations then
		item.pictures = DIR.get_belt_brightness_variation_pictures(icon_name,DIR.icon_size,DIR.icon_mipmaps,icon_path)
	end
	-- crafting category - this is a recipe thing but needed for item subgroups as well
	-- does this component deviate from default crafting method?
	local item_category = (componentdata.crafting_category_exceptions and componentdata.crafting_category_exceptions[material]) or componentdata.category or "crafting"
	-- is it a tiered crafting category?
	if DIR.is_value_in_list(DIR.tiered_categories, item_category) then
		local tier = (componentdata.tier_override and componentdata.tier_override[material]) or (materialdata.tiers and materialdata.tiers[item_category]) or 1
		if tier > 1 then item_category = item_category .. "-" .. tier end
	end
	-- subgroups
	local recipe_subgroup = (componentdata.subgroup_exceptions and componentdata.subgroup_exceptions[material]) or componentdata.subgroup or component
	if recipe_subgroup == "material" and not exception then
		recipe_subgroup = componentdata.tabgroup.."-"..material
	end
	local item_exception = componentdata.item_subgroup_exceptions and componentdata.item_subgroup_exceptions[material]
	item.subgroup = item_exception or componentdata.item_subgroup or recipe_subgroup
	-- order
	local component_order = (componentdata.item_order_exceptions and componentdata.item_order_exceptions[material]) or (componentdata.order_exceptions and componentdata.order_exceptions[material]) or componentdata.item_order or componentdata.order
	item.order = componentdata.do_not_append_item_material_order and component_order or string.format("%s-%s", component_order, materialdata.order)
	-- fuels
	if componentdata.fuel_values and componentdata.fuel_values[material] then
		item.fuel_value = string.format("%gMJ", DIR.base_energy_unit * componentdata.fuel_values[material].multiplier)
		local emissions_property = (componentdata.type == "fluid") and "emissions_multiplier" or "fuel_emissions_multiplier" -- ffs
		item[emissions_property] = componentdata.fuel_values[material].emissions_multiplier
		if componentdata.type == "item" then item.fuel_category = componentdata.fuel_values[material].category or "chemical" end
		item.fuel_acceleration_multiplier = componentdata.fuel_values[material].fuel_acceleration_multiplier
		item.fuel_top_speed_multiplier = componentdata.fuel_values[material].fuel_top_speed_multiplier
	end
	-- ammo
	if componentdata.type == "ammo" then
		if not materialdata.base_damage or not componentdata.ammo then
			error("Error: ammo given material "..material.." which doesn't define ammo properties")
		end
		item.ammo_type = DIR.get_ammo_type(
			componentdata.ammo.projectile_type or "bullet",
			materialdata.base_damage,
			componentdata.ammo.range or 18,
			componentdata.ammo.speed or 1,
			(componentdata.ammo.use_pellets and materialdata.pellets) or 1,
			componentdata.ammo.deviation or 0,
			componentdata.ammo.category or "bullet",
			materialdata.hue,
			materialdata.saturation
		)
		item.magazine_size = componentdata.ammo.size or 10
		item.reload_time = componentdata.ammo.reload
	end
	-- repair tools
	if componentdata.type == "repair-tool" then
		if not materialdata.repair_durability then error("Error: repair tool given material "..material.." which doesn't define durability") end
		item.durability = materialdata.repair_durability
		item.speed = materialdata.repair_speed or 1
		item.localised_description = {"item-description.repair-tool"}
	end
	-- science
	if componentdata.type == "tool" then
		item.durability = 1
		item.durability_description_key = "description.science-pack-remaining-amount-key"
		item.durability_description_value = "description.science-pack-remaining-amount-value"
		item.localised_name = {"item-name."..name}
	end
	-- fluids
	if componentdata.type == "fluid" then
		local hot = (component == "molten")
		local hue = componentdata.fluid_hue_exceptions and componentdata.fluid_hue_exceptions[material] or materialdata.hue or 0
		local saturation = (hot and 1) or (componentdata.fluid_saturation_exceptions and componentdata.fluid_saturation_exceptions[material]) or DIR.get_saturation(hue, materialdata.saturation)
		item.base_color = DIR.hsva2rgba(hot and DIR.hues.orange or hue, saturation, materialdata.value or 1)
		item.flow_color = DIR.hsva2rgba(hue, saturation*0.5, 1)
		item.default_temperature = hot and 1000 or 15
		item.gas_temperature = componentdata.gas_temperature or 100
		item.auto_barrel = componentdata.auto_barrel and (materialdata.auto_barrel == nil or materialdata.auto_barrel == true) and (componentdata.auto_barrel_exceptions == nil or componentdata.auto_barrel_exceptions[material])
		-- override any energy-related properties here per material
		if componentdata.fluid_temperature_properties and componentdata.fluid_temperature_properties[material] then
			for property,value in pairs(componentdata.fluid_temperature_properties[material]) do
				item[property] = value
			end
		end
		-- add voided pollution penalty description?
		-- local pollution = materialdata.emissions_multiplier or 1
		-- item.localised_description = {"fluid-description.emissions-multiplier", pollution * 100}
	end
	-- done:
	if componentdata.no_item and componentdata.no_item[material] then
		DIR.spam_log("generate_system_item: skipping "..item.type.." "..item.name.." as directed", DIR.log_level.debug)
	else
		data:extend({item})
		DIR.spam_log("generate_system_item: created "..item.type.." "..item.name, DIR.log_level.debug)
		-- assign spill emissions
		if componentdata.type == "fluid" then
			local spille = componentdata.spill_emissions or DIR.materials[material].emissions_multiplier or 0
			if spille > 0 then DIR.set_fluid_spill_multiplier(name,spille) end
		end
	end
	
	-- RECIPE
	-- what is this component made from? is this specific material-component combo a special case?
	local made_from = (componentdata.made_from_exceptions and componentdata.made_from_exceptions[material]) or componentdata.made_from
	-- some components are never crafted e.g. ores, weird aliases like uranium
	if made_from and (componentdata.no_recipe == nil or componentdata.no_recipe[material] ~= true) then
		-- loop through all the source components for this item 
		local default_item_category = item_category
		for source,ratio in pairs(made_from) do
			if not DIR.components[source] then error("Item "..name.." specifies non-existing component source") end		
			if not ratio.amount or not ratio.result then error("Item "..name.." has badly specified source components") end
			-- source specifies a category override? 
			if componentdata.material_category_exceptions and componentdata.material_category_exceptions[material] and componentdata.material_category_exceptions[material][source] then
				item_category = componentdata.material_category_exceptions[material][source]
			elseif componentdata.source_category_exceptions and componentdata.source_category_exceptions[source] then
				item_category = componentdata.source_category_exceptions[source]
			else
				item_category = default_item_category
			end
			-- name of the recipe? if it has multiple sources, it gets a unique name, otherwise same name as result item - unless component specifies special unique root
			-- this also automatically flags the recipe as a non-provider (IR 2.2.0)
			local recipe_name = name
			local ignore_as_provider = false
			if not (componentdata.no_affix and componentdata.no_affix[source]) and table_size(made_from) > 1 then
				recipe_name = name.."-from-"..source
				ignore_as_provider = true
			end
			-- crafting time - component speed, multiplied by material speed, optionally multiplied by number of outputs
			local base_speed = 
				(componentdata.specific_speed_override and componentdata.specific_speed_override[recipe_name]) or
				(componentdata.speed_exceptions_from_source and componentdata.speed_exceptions_from_source[source]) or
				(componentdata.speed_exceptions and componentdata.speed_exceptions[material]) or
				componentdata.speed or
				DIR.standard_crafting_time
			local craft_time = base_speed * (materialdata.speed_multiplier or 1.0) * (componentdata.scale_speed and ratio.result or 1)
			-- order
			local order = string.format("%s-%s-%s", (componentdata.order_exceptions and componentdata.order_exceptions[material]) or componentdata.order, materialdata.order, DIR.components[source].order)
			-- if the source components exist, then make the recipe
			if DIR.is_value_in_list(DIR.components[source].materials, material) or (componentdata.ignore_missing_sources and componentdata.ignore_missing_sources[material]) then 

				local source_name = DIR.get_item_name(material, source)

				-- primary ingredients
				local ingredients = {}
				if source ~= component then
					if ratio.amount > 0 then
						if DIR.components[source].type == "fluid" then
							table.insert(ingredients, {type = "fluid", name = source_name, amount = ratio.amount})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {type = "item", name = source_name, amount = ratio.amount})
						end
					end
				end

				-- secondary ingredients
				if componentdata.made_from_secondary and not (componentdata.made_from_exceptions and componentdata.made_from_exceptions[material]) then
					for secondary_comp, amount in pairs(componentdata.made_from_secondary) do
						if (DIR.components[secondary_comp] and DIR.components[secondary_comp].type == "fluid") or data.raw.fluid[secondary_comp] then
							table.insert(ingredients, {type = "fluid", name = secondary_comp, amount = amount, catalyst_amount = (secondary_comp == "water") and amount or nil})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {type = "item", name = DIR.get_item_name(material, secondary_comp), amount = amount})
						end
					end
				end

				-- tertiary ingredients, per mat-comp combo
				if componentdata.made_from_tertiary and componentdata.made_from_tertiary[material] and not DIR.components[source].block_tertiary_ingredients then
					for tertiary_comp, amount in pairs(componentdata.made_from_tertiary[material]) do
						if data.raw.fluid[tertiary_comp] or string.find(tertiary_comp,"fluid") or string.find(tertiary_comp,"gas") or string.find(tertiary_comp,"molten") or string.find(tertiary_comp,"acid") then
							table.insert(ingredients, {type = "fluid", name = tertiary_comp, amount = amount})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {type = "item", name = tertiary_comp, amount = amount})
						end
					end
				elseif componentdata.made_from_quaternary and componentdata.made_from_quaternary[source] and componentdata.made_from_quaternary[source][material] and not DIR.components[source].block_tertiary_ingredients then
					-- quaternary ingredients, per source, per material, overridden by tertiary
					for tertiary_comp, amount in pairs(componentdata.made_from_quaternary[source][material]) do
						if data.raw.fluid[tertiary_comp] or string.find(tertiary_comp,"fluid") or string.find(tertiary_comp,"gas") or string.find(tertiary_comp,"molten") then
							tertiary_comp = string.gsub(tertiary_comp, ":fluid", "")
							table.insert(ingredients, {
								type = "fluid",
								name = tertiary_comp,
								amount = amount,
								catalyst_amount = componentdata.quaternary_catalyst_amounts and componentdata.quaternary_catalyst_amounts[tertiary_comp] or nil,
							})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {
								type = "item",
								name = tertiary_comp,
								amount = amount,
								catalyst_amount = componentdata.quaternary_catalyst_amounts and componentdata.quaternary_catalyst_amounts[tertiary_comp] or nil
							})
						end
					end
				end

				-- category extra ingredients
				if componentdata.made_from_category and componentdata.made_from_category[item_category] and not DIR.components[source].block_tertiary_ingredients then
					for ingredient, amount in pairs(componentdata.made_from_category[item_category]) do
						if data.raw.fluid[ingredient] or string.find(ingredient,"fluid") or string.find(ingredient,"gas") then
							table.insert(ingredients, {type = "fluid", name = ingredient, amount = amount, minimum_temperature = componentdata.made_from_category_minimum_temperature, maximum_temperature = componentdata.made_from_category_maximum_temperature})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {type = "item", name = ingredient, amount = amount})
						end
					end
				end
				
				-- specific ingredients, per recipe
				if componentdata.made_from_specific and componentdata.made_from_specific[recipe_name] then
					for specific_comp, amount in pairs(componentdata.made_from_specific[recipe_name]) do
						if data.raw.fluid[specific_comp] or string.find(specific_comp,"fluid") then
							table.insert(ingredients, {type = "fluid", name = specific_comp, amount = amount})
							if item_category == "crafting" then item_category = "crafting-with-fluid" end
						else
							table.insert(ingredients, {type = "item", name = specific_comp, amount = amount})
						end
					end
				end

				-- emissions_multiplier
				local emissions = nil
				if componentdata.specific_emissions_multiplier and componentdata.specific_emissions_multiplier[recipe_name] ~= nil then
					emissions = componentdata.specific_emissions_multiplier[recipe_name]
				else
					emissions = componentdata.source_emissions_multiplier and componentdata.source_emissions_multiplier[source] 
				end

				-- specific components are all unlocked by one tech
				local forced_unlock = componentdata.mass_unlock_technology or DIR.components[source].mass_unlock_technology

				-- Create the recipe

				DIR.spam_log("generate_system_item: created recipe "..recipe_name, DIR.log_level.debug)
				local recipe_order = (componentdata.ignore_category_order_prefix and (componentdata.ignore_category_order_prefix[material] ~= true)) and DIR.category_orders[DIR.strip_numeric_suffix(item_category)] and DIR.category_orders[DIR.strip_numeric_suffix(item_category)].."-"..order or order
				local new_recipe = DIR.generate_recipe(
					recipe_name,
					name,
					icon_name,
					material,
					component,
					item_category,
					recipe_order,
					ratio.result,
					ingredients,
					craft_time,
					DIR.can_craft_at_start(material, component, source),
					(componentdata.subgroup_source_exceptions and componentdata.subgroup_source_exceptions[source])
						or (recipe_subgroup == "source" and componentdata.tabgroup.."-"..source)
						or (recipe_subgroup == "material" and componentdata.tabgroup.."-"..material)
						or recipe_subgroup,
					emissions,
					forced_unlock,
					icon_path,
					ignore_as_provider,
					(componentdata.source_hide_from_player_crafting and componentdata.source_hide_from_player_crafting[source] and componentdata.source_hide_from_player_crafting[source][material]) or (componentdata.material_hide_from_player_crafting and componentdata.material_hide_from_player_crafting[material])
				)
				-- scrapping override
				new_recipe.IR_not_scrappable = componentdata.not_scrappable
				-- category results
				local category_results = componentdata.category_results_secondary and componentdata.category_results_secondary[DIR.strip_numeric_suffix(item_category)]
				if category_results then table.insert(new_recipe.results, category_results) end
				-- probabilistic bonus byproducts
				if not DIR.components[source].block_tertiary_ingredients then
					-- material-based bonuses block source-based bonuses
					local multi_icons = (componentdata.bonus_results_icon_ignore ~= true)
					if componentdata.bonus_results and componentdata.bonus_results[material] then
						DIR.add_probability_to_recipe(new_recipe, item, component, componentdata.bonus_results[material], multi_icons)
						if componentdata.mark_bonus_results_as_non_provider then new_recipe.IR_tech_rebuild_ignore_as_provider = true end
					elseif componentdata.bonus_results_from_source and componentdata.bonus_results_from_source[source] then
						DIR.add_probability_to_recipe(new_recipe, item, component, componentdata.bonus_results_from_source[source], multi_icons)
						if componentdata.mark_bonus_results_as_non_provider then new_recipe.IR_tech_rebuild_ignore_as_provider = true end
					elseif componentdata.bonus_results_from_specific_source and componentdata.bonus_results_from_specific_source[DIR.get_item_name(material, source)] then
						DIR.add_probability_to_recipe(new_recipe, item, component, componentdata.bonus_results_from_specific_source[DIR.get_item_name(material, source)], multi_icons)
						if componentdata.mark_bonus_results_as_non_provider then new_recipe.IR_tech_rebuild_ignore_as_provider = true end
					elseif category_results and not componentdata.category_results_icon_ignore then
						DIR.convert_recipe_icon_to_icons(new_recipe)
						DIR.add_icons_to_recipe(new_recipe, {{icon = DIR.get_icon_path(category_results.name,DIR.icon_size,icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, 1)
					end
				end
				-- overlay icon per category or per source
				if DIR.category_overlays[DIR.strip_numeric_suffix(item_category)] then
					DIR.convert_recipe_icon_to_icons(new_recipe)
					DIR.add_icons_to_recipe(new_recipe,{{icon = DIR.get_icon_path(DIR.category_overlays[DIR.strip_numeric_suffix(item_category)],DIR.icon_size,icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
				elseif componentdata.always_show_source_overlay and componentdata.always_show_source_overlay[source] then
					DIR.convert_recipe_icon_to_icons(new_recipe)
					DIR.add_icons_to_recipe(new_recipe,{{icon = DIR.get_icon_path(DIR.get_item_name(material,source),DIR.icon_size,icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
				else
				-- Components with multiple sources get distinguishing layered ingredient icons
					if componentdata.strict_ingredient_overlay and componentdata.strict_ingredient_overlay[material] and componentdata.strict_ingredient_overlay[material][source] then
						DIR.convert_recipe_icon_to_icons(new_recipe)
						DIR.add_icons_to_recipe(new_recipe,{{icon = DIR.get_icon_path(componentdata.strict_ingredient_overlay[material][source]), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
					else
						local really_force_overlay = (componentdata.force_overlay_for_material and componentdata.force_overlay_for_material[material])
						if ((componentdata.show_non_source_ingredients or table_size(made_from) > 1) and not (componentdata.no_overlay and componentdata.no_overlay[source]))
							or really_force_overlay	
						then
							if really_force_overlay or componentdata.show_non_source_ingredients or not materialdata.alloy or source ~= component then
								local overlay_name = DIR.get_item_name(material, source)
								DIR.add_ingredient_icons_to_recipe(new_recipe, (not really_force_overlay and DIR.is_value_in_list(componentdata.ignore_source_overlay,source)) and overlay_name or "", icon_path)
							end
						end
					end
				end
				
				-- Add to productivity list
				local is_productive = componentdata.productivity_material_exceptions and componentdata.productivity_material_exceptions[material]
				if is_productive == nil then is_productive = componentdata.productivity_source_exceptions and componentdata.productivity_source_exceptions[source] end
				if is_productive == nil then is_productive = componentdata.productivity end
				if is_productive then table.insert(DIR.productivity_limitation,recipe_name) end
				
				-- if the recipe only has one fluid input, then force the fluidbox_index, to stop all of the inputs pulling the same fluid
				DIR.fix_generated_recipe_fluidbox_indices(new_recipe)
				
				-- duplication e.g. advanced washing
				if componentdata.duplications then
					for _, duplication in pairs(componentdata.duplications) do
						if ((DIR.strip_numeric_suffix(item_category) == duplication.category) or DIR.list_contains(duplication.categories,DIR.strip_numeric_suffix(item_category)))
							and ((duplication.materials == nil) or duplication.materials[material]) and ((duplication.ignore_sources == nil) or not duplication.ignore_sources[source])
						then
							local duplicate = table.deepcopy(new_recipe)
							duplicate.name = duplicate.name .. "-" .. duplication.affix
							duplicate.category = duplicate.category or "crafting"
							local new_category = duplication.affix and (duplication.affix .. "-" .. duplicate.category) or duplicate.category
							new_category = duplication.replace_category and duplication.replace_category or new_category
							if duplication.strip_numeric_suffix then new_category = DIR.strip_numeric_suffix(new_category) end
							if duplication.subgroup then duplicate.subgroup = duplication.subgroup end
							-- remove an ingredient?
							if duplication.remove_ingredient then
								for k,v in pairs(duplicate.ingredients) do
									if v[1] == duplication.remove_ingredient or v.name == duplication.remove_ingredient then
										duplicate.ingredients[k] = nil
									end
								end
							end
							-- replace specific ingredients in a proportion?
							if duplication.replace_ingredients or duplication.replace_source then
								for old,new in pairs(duplication.replace_ingredients or duplication.replace_source) do
									if duplication.replace_source then 
										old = DIR.get_item_name(material,old)
										new = DIR.get_item_name(material,new)
									end
									for _,ingredient in pairs(duplicate.ingredients) do
										if ingredient.name == old then
											ingredient.name = new
											ingredient.maximum_temperature = duplication.maximum_temperature
											ingredient.minimum_temperature = duplication.minimum_temperature
											if duplication.replace_ingredients_multiplier and ingredient.amount then
												ingredient.amount = ingredient.amount * duplication.replace_ingredients_multiplier
											end
											if duplication.replace_ingredients_type then
												ingredient.type = duplication.replace_ingredients_type
											end
										end
									end
									if duplicate.icons then
										for _,icon in pairs(duplicate.icons) do
											icon.icon = DIR.escaped_gsub(icon.icon, old, new)
											if DIR.category_overlays[DIR.strip_numeric_suffix(item_category)] and DIR.category_overlays[new_category] then
												icon.icon = DIR.escaped_gsub(icon.icon, DIR.category_overlays[DIR.strip_numeric_suffix(item_category)], DIR.category_overlays[new_category])
											end
										end
									end
									if duplication.add_icon_overlay then
										DIR.convert_recipe_icon_to_icons(duplicate)
										DIR.add_icons_to_recipe(duplicate,{{icon = DIR.get_icon_path(duplication.add_icon_overlay), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)					
									end
								end
							end
							-- add a new ingredient to all?
							if duplication.add_ingredient then
								table.insert(duplicate.ingredients, duplication.add_ingredient)
								if not duplication.replace_ingredients then
									duplicate.icon = DIR.get_icon_path(icon_name)
									DIR.add_icons_to_recipe(duplicate,{{icon = DIR.get_icon_path(duplication.add_ingredient.name), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1, 8.5)
								end
							end
							if duplication.add_ingredients then
								for _,ingredient in pairs(duplication.add_ingredients) do
									table.insert(duplicate.ingredients, ingredient)
								end
								duplicate.icon = DIR.get_icon_path(icon_name)
								DIR.add_ingredient_icons_to_recipe(duplicate, nil, icon_path)
							end
							-- add a new result to all?
							if duplication.add_result then
								table.insert(duplicate.results, duplication.add_result)
								DIR.add_result_icons_to_recipe(duplicate, false, name, icon_path)
							end
							if duplication.add_results then
								for _,add_r in pairs(duplication.add_results) do
									table.insert(duplicate.results, add_r)
								end
								DIR.add_result_icons_to_recipe(duplicate, false, name, icon_path)
							end
							-- adjust bonus result chances?
							if componentdata.bonus_results and componentdata.bonus_results[material] then
								for key,result in pairs(duplicate.results) do
									if result.name == name and duplication.result_multiplier then
										result.amount = result.amount * duplication.result_multiplier
									elseif result.name == name and duplication.result_probability > 0 then
										result.probability = duplication.result_probability
										result.amount_min = nil
										result.amount_max = nil
										result.amount = 1
									elseif result.name == name and duplication.result_probability == 0 then
										duplicate.results[key] = nil
										duplicate.main_product = nil
									elseif duplication.byproduct_probability_multiplier then
										for bonus,probability in pairs(componentdata.bonus_results[material]) do
											if result.name == bonus then 
												result.probability = probability * duplication.byproduct_probability_multiplier
											end
										end
									end
								end
							end
							-- multiply resources?
							if duplication.resource_multiplier then
								if not duplication.resource_multiplier_results_only then
									for _,ingredient in pairs(duplicate.ingredients) do
										ingredient.amount = ingredient.amount * duplication.resource_multiplier
									end
								end
								for _,result in pairs(duplicate.results) do
									result.amount = result.amount * duplication.resource_multiplier
								end
							end
							-- speed multiplier?
							if duplication.speed_multiplier and duplicate.energy_required then
								duplicate.energy_required = duplicate.energy_required * duplication.speed_multiplier
							end
							-- change category and other details
							if duplicate.localised_name and type(duplicate.localised_name) == "table" and duplicate.localised_name[1] == "recipe-name."..DIR.strip_numeric_suffix(duplicate.category) then
								duplicate.localised_name[1] = "recipe-name."..DIR.strip_numeric_suffix(new_category)
							end
							duplicate.category = new_category
							duplicate.emissions_multiplier = (duplicate.emissions_multiplier or 1) * (duplication.emissions_multiplier or 1)
							duplicate.order = DIR.category_orders[new_category] and DIR.category_orders[new_category].."-"..duplicate.order or duplicate.order
							duplicate.order = duplication.order_prefix and duplication.order_prefix.."-"..duplicate.order or duplicate.order
							duplicate.hide_from_player_crafting = duplication.hide_from_player_crafting
							if duplication.enabled ~= nil then duplicate.enabled = duplication.enabled end
							DIR.fix_generated_recipe_fluidbox_indices(duplicate)

							-- IR 3.0.0 - duplicated recipes are automatically marked as non-providers
							duplicate.IR_tech_rebuild_ignore_as_provider = true
							-- make it
							data:extend({table.deepcopy(duplicate)})
							if is_productive and (duplication.productivity ~= false) then 
								table.insert(DIR.productivity_limitation,duplicate.name)
							end
							DIR.spam_log("generate_system_item: created duplicated recipe "..duplicate.name, DIR.log_level.debug)
						end
					end
				end
			end
		end
	else
		DIR.spam_log("generate_system_item: no recipe for "..name)
	end
end

function DIR.fix_generated_recipe_fluidbox_indices(new_recipe)
	local indices = DIR.force_fluidbox_index_by_category[DIR.strip_numeric_suffix(new_recipe.category)] 
	if indices and new_recipe.ingredients and new_recipe.results then
		for _,list in pairs({new_recipe.ingredients, new_recipe.results}) do
			local count = DIR.count_ingredients_by_type(list,"fluid")
			if count > #indices then
				error("Recipe "..new_recipe.name.." is set up to force fluidbox index for up to "..#indices.." ingredients/results but has unexpected "..count)
			end
			if count > 0 then
				local c = 1
				for i,ingredient in pairs(list) do
					if ingredient.type == "fluid" then
						ingredient.fluidbox_index = indices[count][c]
						c = c + 1
					end
				end
			end
		end
	end
end

-- create a new generated basic item recipe

function DIR.generate_recipe(name, result, icon_name, material, component, category, order, result_count, ingredients, energy, enabled, subgroup, emissions, forced_unlock, icon_path, ignore_as_provider, hide_from_player)
    local recipe = {}
    recipe.type = "recipe"
    recipe.name = name
	recipe.IR_recipe = true
	if ignore_as_provider == true then 
		recipe.IR_tech_rebuild_ignore_as_provider = true
		DIR.spam_log("Recipe "..name.." was marked as a non-provider")
	end
	local materialdata = DIR.materials[material]
	local componentdata = DIR.components[component]
	if result_count == math.floor(result_count) then
		recipe.results = { { name = result, type = (componentdata.type == "fluid") and "fluid" or "item", amount = result_count } }
	else
		recipe.results = { { name = result, type = (componentdata.type == "fluid") and "fluid" or "item", amount_min = math.floor(result_count), amount_max = math.ceil(result_count) } }
	end
	recipe.show_amount_in_title = false
	recipe.always_show_products = true
	recipe.subgroup = subgroup
    recipe.enabled = enabled
    recipe.category = category
    recipe.order = order
    recipe.ingredients = ingredients
    recipe.energy_required = energy
	recipe.emissions_multiplier = emissions
	if componentdata.do_not_decompose_exceptions and componentdata.do_not_decompose_exceptions[material] then
		recipe.allow_decomposition = false
	elseif recipe.do_not_decompose then
		recipe.allow_decomposition = false
	end
	if componentdata.use_vanilla_icons and componentdata.use_vanilla_icons[material] then
		recipe.icon = DIR.base_icons_path.."/"..icon_name..".png" 
		recipe.icon_size = 64
		recipe.icon_mipmaps = 4
	else
		recipe.icon = DIR.get_icon_path(icon_name,DIR.icon_size,icon_path)
		recipe.icon_size = DIR.icon_size
		recipe.icon_mipmaps = DIR.icon_mipmaps
	end
	recipe.IR_component = component
	recipe.hidden = componentdata.hidden
	recipe.hide_from_player_crafting = hide_from_player
	if componentdata.allow_as_intermediate and componentdata.allow_as_intermediate[material] ~= nil then recipe.allow_as_intermediate = componentdata.allow_as_intermediate[material] end

	-- locale
	local main_ingredient = ingredients[1] and ingredients[1].name
	if componentdata.recipe_locale_name_exceptions and componentdata.recipe_locale_name_exceptions[material] then
		recipe.localised_name = {componentdata.recipe_locale_name_exceptions[material]}
	elseif DIR.strip_numeric_suffix(category) == "smelting" then
		recipe.localised_name = {"recipe-name.smelting", {componentdata.type.."-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "alloying" or DIR.strip_numeric_suffix(category) == "molten-alloying" or DIR.strip_numeric_suffix(category) == "blast-alloying" then
		recipe.localised_name = {"recipe-name.alloying", {componentdata.type.."-name."..result}}
	elseif DIR.strip_numeric_suffix(category) == "blast-smelting" or DIR.strip_numeric_suffix(category) == "blast-multi-smelting" then
		recipe.localised_name = {"recipe-name.blast-smelting", {componentdata.type.."-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "grinding" and component ~= "powder" then
		recipe.localised_name = {"recipe-name."..DIR.strip_numeric_suffix(category), {componentdata.type.."-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "washing" or DIR.strip_numeric_suffix(category) == "advanced-washing" then
		recipe.localised_name = {"recipe-name."..category, {componentdata.type.."-name."..material}}
	elseif DIR.strip_numeric_suffix(category) == "chemistry" and component ~= "plating-solution" and componentdata.type ~= "tool" then
		recipe.localised_name = {"recipe-name.chemistry", {componentdata.type.."-name."..result}}
	elseif DIR.strip_numeric_suffix(category) == "melting" or DIR.strip_numeric_suffix(category) == "melting-with-gas" then
		recipe.localised_name = {"recipe-name.melting", {"item-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "cryogenics" then
		recipe.localised_name = {"recipe-name.liquefaction", {"fluid-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "cooling" then
		recipe.localised_name = {"recipe-name.cooling", {"fluid-name."..main_ingredient}}
	elseif DIR.strip_numeric_suffix(category) == "heating" then
		recipe.localised_name = {"recipe-name.warming", {"fluid-name."..main_ingredient}}
	else
		recipe.localised_name = nil
	end
	if componentdata.localised_description then
		recipe.localised_description = componentdata.localised_description
	end
	
    -- tints
	if componentdata.crafting_tint_override and componentdata.crafting_tint_override[material] then
		recipe.crafting_machine_tint = componentdata.crafting_tint_override[material]
	else
		if category == "chemistry" or category == "electroplating" then
			recipe.crafting_machine_tint = DIR.get_crafting_tints_from_hue(materialdata.hue, materialdata.saturation or DIR.get_saturation(materialdata.hue))
		elseif category == "cryogenics" then
			local hue = materialdata.hue
			local saturation = materialdata.saturation or DIR.get_saturation(materialdata.hue)
			recipe.crafting_machine_tint = {
				primary = DIR.hsva2rgba(hue-0.03, DIR.get_saturation(hue,saturation), 0.8, 0.25),
				secondary = DIR.hsva2rgba(hue, DIR.get_saturation(hue,saturation), 1, 0.25),
				tertiary = DIR.hsva2rgba(hue+0.03, DIR.get_saturation(hue,saturation), 0.8, 0.25),
			}
		else
			local tier = (componentdata.tier_override and componentdata.tier_override[material]) or (materialdata.tiers and materialdata.tiers[category]) or materialdata.default_tier or 1
			recipe.crafting_machine_tint = DIR.get_crafting_tints_from_hue(DIR.tier_hues[tier],DIR.get_saturation(DIR.tier_hues[tier]))
			if materialdata.rgba then recipe.crafting_machine_tint.primary = materialdata.rgba end
		end
	end

    data:extend({recipe})
	
    return data.raw.recipe[name]
	
end

-- probability byproducts

function DIR.add_probability_to_recipe(recipe, item, component, bonus_results, generate_multi_icons, result_probability, byproduct_probability_multiplier)
	if bonus_results == nil or not next(bonus_results) then return end
	if not byproduct_probability_multiplier then byproduct_probability_multiplier = 1 end
	if not result_probability then result_probability = 1 end
	local results = (result_probability > 0) and table.deepcopy(recipe.results) or {}
	if result_probability > 0 then
		for k,v in pairs(results) do
			if v.type == "item" then
				if result_probability < 1 then
					results[k].probability = result_probability
					results[k].amount = 1
					results[k].amount_min = nil
					results[k].amount_max = nil
				end
			end
		end
	end
	for bonus_item,probability in pairs(bonus_results) do
		local final_probability = probability * byproduct_probability_multiplier
		local item_type = (data.raw.fluid[bonus_item] or string.find(bonus_item,"gas") or string.find(bonus_item,"fluid")) and "fluid" or "item"
		if final_probability < 1 then 
			table.insert(results, { name = bonus_item, type = item_type, amount = 1, probability = final_probability })
		elseif final_probability == math.floor(final_probability) then
			table.insert(results, { name = bonus_item, type = item_type, amount = final_probability, temperature = (bonus_item=="steam") and 165 or nil })
		else
			table.insert(results, { name = bonus_item, type = item_type, amount_min = math.floor(final_probability), amount_max = math.ceil(final_probability) ,temperature = (bonus_item=="steam") and 165 or nil })
		end
	end
	recipe.results = results
	recipe.result = nil
	recipe.result_count = nil
	recipe.main_product = results[1].name
	if generate_multi_icons and table_size(results) > 1 then
		DIR.add_result_icons_to_recipe(recipe, false, nil, icon_path)
	end
end

-- generate name from mat-comp combo - check overrides

function DIR.get_item_name(material, component)
	return DIR.components[component] and DIR.components[component].name_overrides and DIR.components[component].name_overrides[material] or string.format("%s-%s", material, component)
end

-- can I craft it at game start?

function DIR.can_craft_at_start(material, component, source)
	if source then
		if DIR.components[source].start_exceptions and DIR.components[source].start_exceptions[material] ~= nil then
			return DIR.components[source].start_exceptions[material]
		end
		if not DIR.components[source].start then return false end
	end
	if DIR.materials[material].start then
		if DIR.components[component].start_exceptions and DIR.components[component].start_exceptions[material] ~= nil then
			return DIR.components[component].start_exceptions[material]
		end
		if DIR.components[component].start then return true end
	end
	return false
end

-- move an item to a different subgroup

function DIR.change_item_subgroup(name, subgroup)
	if not data.raw.item[name] and not data.raw.capsule[name] and not data.raw.gun[name] then
		error("Asked to change subgroup for non-existent item "..name)
		return
	end
	if data.raw.item[name] then data.raw.item[name].subgroup = subgroup end
	if data.raw.capsule[name] then data.raw.capsule[name].subgroup = subgroup end
	if data.raw.gun[name] then data.raw.gun[name].subgroup = subgroup end
end

-- change item crafting tab order

function DIR.change_item_order(name, order)
	local item = data.raw.item[name] or data.raw.capsule[name] or data.raw.gun[name] or data.raw.ammo[name]
	if not item then
		error("Asked to change order for non-existent item/gun/ammo/capsule "..name)
		return
	end
	item.order = order
end

function DIR.change_recipe_order(name, order)
	if not data.raw.recipe[name] then
		error("Asked to change order for non-existent recipe "..name)
		return
	end
	data.raw.recipe[name].order = order
end

function DIR.change_item_and_recipe_order(name, order)
	DIR.change_item_order(name, order)
	DIR.change_recipe_order(name, order)
end

-- move a recipe to a different subgroup

function DIR.change_recipe_subgroup(name, subgroup)
	if not data.raw.recipe[name] then
		error("Asked to change subgroup for non-existent item "..name)
		return
	end
	data.raw.recipe[name].subgroup = subgroup
end

function DIR.change_item_and_recipe_subgroup(name,subgroup)
	DIR.change_item_subgroup(name,subgroup)
	DIR.change_recipe_subgroup(name,subgroup)
end

-- change a recipe's crafting category

function DIR.change_recipe_category(name, category)
	if not data.raw.recipe[name] then
		error("Asked to change category for non-existent recipe "..name)
		return
	end
	data.raw.recipe[name].category = category
end

function DIR.get_item_of_any_type(name)
	for _,type in pairs({"item","module","tool","repair-tool","ammo","capsule","gun","rail-planner","armor","item-with-entity-data","blueprint","blueprint-book","upgrade-item","deconstruction-item"}) do
		if data.raw[type][name] then return data.raw[type][name] end
	end
	return nil
end

function DIR.add_new_machine(machine,machinedata,icon_path)
	if DIR.machine_count == nil then DIR.machine_count = 1 end
	local icons = nil
	if machinedata.icon_masks then
		icons = {
			{ icon = DIR.get_icon_path(machinedata.icon_masks.base, DIR.icon_size, icon_path or DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps }, 
			{ icon = DIR.get_icon_path(machinedata.icon_masks.mask, DIR.icon_size, icon_path or DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, tint = machinedata.icon_masks.tint }, 
		}
	elseif machinedata.use_vanilla_icon then
		icons = {
			{ icon = DIR.base_icons_path.."/"..(machinedata.icon or machine)..".png", icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		}
	elseif machinedata.icons then
		icons = {}
		scale = 1
		for _,icon in pairs(machinedata.icons) do
			table.insert(icons, {icon = DIR.get_icon_path(icon, DIR.icon_size, icon_path or DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, scale = scale})
			-- scale = 0.75
		end
	else
		icons = { 
			{ icon = DIR.get_icon_path(machinedata.icon or machine, DIR.icon_size, icon_path or DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		}
	end
	
	data:extend({
		{
			type = machinedata.type or "item",
			name = machine,
			localised_name = machinedata.localised_name,
			localised_description = machinedata.localised_description,
			order = machinedata.order or string.format("machine-%03d", DIR.machine_count),
			subgroup = machinedata.subgroup,
			stack_size = machinedata.stack_size or 50,
			icons = icons,
			place_result = machinedata.place or machine,
			ir_machine = true,
			flags = machinedata.hidden and {"hidden"} or nil,
			icon_tintable = machinedata.icon_tintable and DIR.get_icon_path(machinedata.icon_tintable, DIR.icon_size, icon_path) or nil,
			icon_tintable_mask = machinedata.icon_tintable_mask and DIR.get_icon_path(machinedata.icon_tintable_mask, DIR.icon_size, icon_path) or nil,
			icon_size = machinedata.icon_tintable and machinedata.icon_masks and DIR.icon_size or nil,
			icon_mipmaps = machinedata.icon_tintable and machinedata.icon_masks and DIR.icon_mipmaps or nil,
		},
		{
			type = "recipe",
			name = machine,
			order = machinedata.order or string.format("machine-%03d", DIR.machine_count),
			subgroup = machinedata.subgroup,
			result = machine,
			result_count = machinedata.count or 1,
			category = machinedata.category or "crafting",
			enabled = machinedata.enabled,
			ingredients = machinedata.ingredients,
			energy_required = (machinedata.time or 4) * DIR.standard_crafting_time,
			always_show_products = true,
			show_amount_in_title = false,
			hidden = machinedata.hidden,
		}
	})
	if machinedata.icon_overlay or machinedata.result_overlay then
		-- DIR.convert_recipe_icon_to_icons(data.raw.item[machine])
		DIR.add_icons_to_recipe(
			data.raw.item[machine],
			{{icon = DIR.get_icon_path(machinedata.icon_overlay or machinedata.result_overlay), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
			machinedata.icon_overlay and -1 or 1
		)
	elseif machinedata.category and DIR.category_overlays[DIR.strip_numeric_suffix(machinedata.category)] then
		-- local recipe = data.raw.recipe[machine]
		-- recipe.icon = icon
		-- recipe.icon_size = DIR.icon_size
		-- recipe.icon_mipmaps = DIR.icon_mipmaps
		-- recipe.icons = icons
		-- DIR.convert_recipe_icon_to_icons(recipe)
		-- DIR.add_icons_to_recipe(recipe,{{icon = DIR.get_icon_path(DIR.category_overlays[DIR.strip_numeric_suffix(machinedata.category)],DIR.icon_size,DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)					
	end
	DIR.machine_count = DIR.machine_count + 1
end

function DIR.recipe_has_ingredient(recipe,target)
	local root = recipe.ingredients or (recipe.normal and recipe.normal.ingredients)
	if root and not recipe.redundant and not DIR.is_an_ignored_recipe(recipe.name) then
		for _,ingredient in pairs(root) do
			local name = ingredient.name or ingredient[1]
			if name == target then return true end
		end
	end
	return false
end

function DIR.count_recipes_with_ingredient(target)
	local count = 0
	for _,recipe in pairs(data.raw.recipe) do
		if DIR.recipe_has_ingredient(recipe,target) then count = count + 1 end
	end
	return count
end

-- scan all recipes for items which are never used, recursively
function DIR.redundancy_scan()
	DIR.spam_log("Starting redundancy scan",DIR.log_level.milestone)
	local items = {}
	for component,componentdata in pairs(DIR.components) do
		if componentdata.type == "item" and componentdata.materials and not componentdata.skip_scan then
			for _,material in pairs(componentdata.materials) do
				items[DIR.get_item_name(material,component)] = true
			end
		end
	end
	for count = 1, 100 do
		local found = false
		DIR.spam_log("Redundancy scan pass "..count.." ...")
		for target,_ in pairs(items) do
			local count = DIR.count_recipes_with_ingredient(target)
			if count == 0 then
				found = true
				items[target] = nil
				local recipe = data.raw.recipe[target]
				if recipe then 
					DIR.spam_log("Hiding recipe for redundant item: "..target, DIR.log_level.warning)
					recipe.redundant = true
					if recipe.icon then
						recipe.icons = { { icon = recipe.icon, icon_size = recipe.icon_size, icon_mipmaps = recipe.icon_mipmaps } }
						recipe.icon = nil
						recipe.icon_size = nil
					end
					table.insert(recipe.icons, { icon = DIR.get_icon_path("signal-warning",DIR.icon_size), icon_size = DIR.icon_size, scale = 0.25, shift = {-8,-8}, icon_mipmaps = DIR.icon_mipmaps })
					recipe.localised_description = {"recipe-description.redundant"}
					recipe.hidden = true
					local item = data.raw.item[target]
					item.flags = {"hidden"}
				end
			end
		end
		if not found then 
			for target,_ in pairs(items) do
				local recipe = data.raw.recipe[target]
				if recipe and not recipe.redundant then 
					local count = DIR.count_recipes_with_ingredient(target)
					if count < 2 then DIR.spam_log("Item "..target.." is only used in "..count.." recipe(s).", DIR.log_level.warning) end
				end
			end
			return
		end
	end
	DIR.spam_log("Redundancy scan complete",DIR.log_level.milestone)
end

-- see what regularly co-occurs with what else
function DIR.collocation_scan(minimum,maximum)
	DIR.spam_log("Starting collocation scan",DIR.log_level.milestone)
	local blob = {}
	local rcount = {}
	for _,recipe in pairs(data.raw.recipe) do
		if not recipe.hidden then
			local ingredients = recipe.normal and recipe.normal.ingredients or recipe.ingredients
			if not ingredients then
				DIR.spam_log("Recipe "..recipe.name.." has no ingredients?", DIR.log_level.warning)
			else
				local icount = table_size(ingredients)
				if icount >= minimum and icount <= maximum then
					for k,ing in pairs(ingredients) do
						local item = ing.name or ing[1]
						rcount[item] = (rcount[item] or 0) + 1
						for k2,ing2 in pairs(ingredients) do
							if k ~= k2 then
								local item2 = ing2.name or ing2[1]
								blob[item] = blob[item] or {}
								blob[item][item2] = blob[item][item2] or 0
								blob[item][item2] = blob[item][item2] + 1
							end
						end
					end
				end
			end
		end
	end
	for item,items in pairs(blob) do
		for ing,count in pairs(items) do
			local total = blob[item][ing]
			local ratio = total / rcount[item]
			if (ratio >= 0.66 and total >= 3) or (ratio >= 0.5 and total >= 6) then
				local range = (minimum == maximum) and minimum or minimum.."-"..maximum
				DIR.spam_log(range.." ingredients: in "..total.." recipes ("..math.floor(ratio*100).."%) "..item.." <- "..ing, DIR.log_level.warning)
			end
		end
	end
	DIR.spam_log("Collocation scan complete",DIR.log_level.milestone)
end

-- search through a set of ingredients and replace matches, returns true if any replacements made
function DIR.replace_ingredients(ingredients, from, to)
    local found = false
    for _,ingredient in pairs(ingredients) do
        if ingredient.name == from then
            ingredient.name = to
            found = true
        elseif ingredient[1] == from then
            ingredient[1] = to
            found = true
        end
    end
    return found
end

-- in a recipe, replace any matching ingredient 
function DIR.replace_ingredient_in_recipe(recipe, old, new)
    local found = false
	local r = data.raw.recipe[recipe]
	if not r then
		DIR.spam_log("Asked to replace ingredient in non-existent recipe "..recipe, DIR.log_level.warning)
		return
	end
	local roots = {r, r.normal, r.expensive}
	for _,root in pairs(roots) do
		if root and root.ingredients then 
			for i,ingredient in pairs(root.ingredients) do
				if ingredient.name == old or ingredient[1] == old then
					root.ingredients[i] = new
					found = true
				end
			end
		end
	end
    return found
end


-- replace any target ingredients in all recipes
function DIR.replace_all_ingredients(from, to)
    for _,recipe in pairs(data.raw.recipe) do
        local found = false
        if recipe.ingredients then found = replace_ingredients(recipe.ingredients, from, to) end
        if recipe.normal and recipe.normal.ingredients then found = replace_ingredients(recipe.normal.ingredients, from, to) end
        if recipe.expensive and recipe.expensive.ingredients then found = replace_ingredients(recipe.expensive.ingredients, from, to) end
    end
end

function DIR.multiply_ingredients(root, factor)
	if not root then return nil end
	local ingredients = table.deepcopy(root)
	for _,i in pairs(ingredients) do
		if i.amount then i.amount = i.amount * factor
		else i[2] = i[2] * factor end
	end
	return ingredients
end

function DIR.multiply_results(results, factor)
	if not results then return nil end
	results = table.deepcopy(results)
	for _,r in pairs(results) do
		if r.amount then r.amount = r.amount * factor
		else r[2] = r[2] * factor end
	end
	return results
end

-- disable a recipe
function DIR.disable_recipe(recipe, state)
	if not data.raw.recipe[recipe] then error("Asked to disable non-existent recipe "..recipe) end
	if not state then state = false end
	if data.raw.recipe[recipe].normal then
		data.raw.recipe[recipe].normal.enabled = state
		data.raw.recipe[recipe].expensive.enabled = state
	else
		data.raw.recipe[recipe].enabled = state
	end
end

-- set single-result recipe count
function DIR.set_recipe_result_count(recipe, count)
   if not data.raw.recipe[recipe] then return end
   if data.raw.recipe[recipe].normal then
      data.raw.recipe[recipe].normal.result_count = count
      data.raw.recipe[recipe].expensive.result_count = count
   else
      data.raw.recipe[recipe].result_count = count
   end
end

-- disabled named recipes
function DIR.disable_recipes(recipelist)
    for _,recipe in pairs(recipelist) do
		DIR.disable_recipe(recipe)
    end
end

function DIR.hide_recipes(recipelist)
    for _,recipe in pairs(recipelist) do
		data.raw.recipe[recipe].hidden = true
    end
end

-- enable named recipes
function DIR.enable_recipes(recipelist)
    for _,recipe in pairs(recipelist) do
		DIR.disable_recipe(recipe, true)
    end
end

function DIR.strip_numeric_suffix(category)
	category = category or "crafting"
	return string.gsub(category, "-%d+$", "")
end

function DIR.pull_numbers_from_string(text)
	local s = ""
	string.gsub(text, "%d+", function(n) s = s..n end)
	return s
end

function DIR.hide_items(itemlist)
    for _,item in pairs(itemlist) do
		-- hide the item and recipe
		local itemtypes = {"item","ammo","repair-tool","gun"}
		local found = false
		for _,itemtype in pairs(itemtypes) do
			if data.raw[itemtype][item] then
				data.raw[itemtype][item].flags = {"hidden","hide-from-bonus-gui","hide-from-fuel-tooltip"}
				found = true
				break
			end
		end
		if not found then error("Couldn't locate item "..item.." for hiding") end
		-- if this item places an entity, remove its next_upgrade
		local result = data.raw.item[item] and data.raw.item[item].place_result
		if result then
			for _,prototype in pairs(data.raw) do
				if prototype[result] and prototype[result].next_upgrade ~= nil then
					prototype[result].next_upgrade = nil
				end
			end
		end
		-- if there's a recipe with the same name, hide it too
		if data.raw.recipe[item] then data.raw.recipe[item].hidden = true end
    end
end

-- replace a recipe's ingredients with a new set
function DIR.replace_recipe_ingredients(recipename, ingredients, result_count, category, ctime, result)
	if not result_count then result_count = 1 end
	local recipe = data.raw.recipe[recipename]
	if not recipe then return end
	local root = recipe.normal and {recipe.normal,recipe.expensive} or {recipe}
	for _,r in pairs(root) do
		r.results = nil
		r.ingredients = ingredients
		r.result = result or recipename
		r.result_count = result_count
		if ctime then r.energy_required = ctime
		elseif r.energy_required == nil then r.energy_required = DIR.default_crafting_speed end
		r.energy_required = r.energy_required * DIR.standard_crafting_time
	end
	if category then recipe.category = category end
end

function DIR.get_crafting_ratio(ratio)
	if not ratio then return nil end
	return {from = ratio[1], to = ratio[2]}
end

function DIR.get_number_of_sources(component)
	return table_size(DIR.made_from[component])
end

function DIR.recipe_shows_products(recipename)
	local recipe = data.raw.recipe[recipename]
	if recipe then
		local roots = {recipe, recipe.normal, recipe.expensive}
		for _,root in pairs(roots) do
			if root and type(root) == "table" then
				root.always_show_products = true
				root.show_amount_in_title = false
			end
		end
	else
		DIR.spam_log("Asked to show products for non-existent recipe "..recipename, DIR.log_level.warning)
	end
end

function DIR.final_recipes_pass()
	local subgroups = {}
	for _,subgroup in pairs(data.raw["item-subgroup"]) do
		if DIR.is_value_in_list(DIR.hidden_item_groups,subgroup.group) then subgroups[subgroup.name] = true end
	end
	for _,recipe in pairs(data.raw.recipe) do
		-- difficulty stuff
		local for_fucks_sake = recipe.normal and {recipe.normal,recipe.expensive} or {recipe}
		for _,root in pairs(for_fucks_sake) do
			if root then
				-- hate this layout for recipe tooltips, make it go away
				if root.result and root.result_count and root.result_count > 1 then
					DIR.recipe_shows_products(recipe.name)
				end
			end
		end
		-- hide specific tabs
		if subgroups[recipe.subgroup] then recipe.hide_from_player_crafting = true end
		-- validate allow_decomposition
		-- if (recipe.allow_decomposition == false) and data.raw.character.character then
			-- local cat = recipe.category or "crafting"
			-- if DIR.list_contains(data.raw.character.character.crafting_categories, cat) then
				-- DIR.spam_log("Recipe "..recipe.name.." is handcraftable but does not allow decomposition", DIR.log_level.warning)
			-- end
		-- end
	end
	-- break apart annoying item subgroups that have width+1 items
	-- only attack recipe subgroups that start with "ir-"
	local subgroups = {}
	for _,subgroup in pairs(data.raw["item-subgroup"]) do
		subgroups[subgroup.name] = 0
	end
	for _,recipe in pairs(data.raw.recipe) do
		if recipe.subgroup and (string.find(recipe.subgroup, "^ir%-") or DIR.long_subgroups[recipe.subgroup]) and subgroups[recipe.subgroup] and not recipe.hidden and not recipe.hide_from_player_crafting then
			subgroups[recipe.subgroup] = subgroups[recipe.subgroup] + 1
		end
	end
	for subgroup,count in pairs(subgroups) do
		if count > DIR.slot_row_count and count < DIR.slot_row_count * 2 then
			-- get all the recipes with this subgroup by order
			local recipes_ordered = {}
			for _,recipe in pairs(data.raw.recipe) do
				if recipe.subgroup == subgroup and not recipe.hidden and not recipe.hide_from_player_crafting then
					table.insert(recipes_ordered, recipe.name)
				end
			end
			table.sort(recipes_ordered, function(a,b) return (data.raw.recipe[a].order or "") < (data.raw.recipe[b].order or "") end)
			data:extend({{
				type = "item-subgroup",
				name = subgroup.."-2",
				group = data.raw["item-subgroup"][subgroup].group,
				order = data.raw["item-subgroup"][subgroup].order .. "2",
			}})
			local number = 1
			for _,recipe in pairs(recipes_ordered) do
				if number > math.ceil(count/2) then data.raw.recipe[recipe].subgroup = subgroup.."-2" end
				number = number + 1
			end
		end
	end
	-- check for productivity limitation issues
	-- build a list of categories used by limitation recipes
	local categories = {}
	for  _,recipe in pairs(DIR.productivity_limitation) do
		local p = data.raw.recipe[recipe]
		if p then
			categories[p.category or "crafting"] = 0
		else
			DIR.spam_log("Recipe "..recipe.." is listed in productivity limitation but does not exist", DIR.log_level.warning)
		end
	end
	-- count how many machines can run that recipe and do actually support productivity
	local types = {"furnace","assembling-machine","rocket-silo"}
	for _,t in pairs(types) do
		for _,p in pairs(data.raw[t]) do
			local pcategories = DIR.values_to_keys(p.crafting_categories)
			local peffects = DIR.values_to_keys(p.allowed_effects)
			for category,_ in pairs(categories) do
				if pcategories and pcategories[category] then
					if peffects and peffects["productivity"] and p.module_specification and p.module_specification.module_slots and p.module_specification.module_slots > 0 then
						categories[category] = categories[category] + 1
					end
				end
			end
		end
	end
	for category,count in pairs(categories) do
		if count == 0 then DIR.spam_log("Crafting category "..category.." has productivity recipes but no compatible machines") end
	end
	-- test assembling machine productivity support
	local machines = {"assembling-machine-1","assembling-machine-2","assembling-machine-3"}
	local categories = {}
	for _,m in pairs(machines) do
		local e = data.raw["assembling-machine"][m]
		if e then
			for _,c in pairs(e.crafting_categories) do
				categories[c] = true
			end
		end
	end
	local precipes = DIR.values_to_keys(DIR.productivity_limitation)
	for _,recipe in pairs(data.raw.recipe) do
		if recipe.category and categories[recipe.category] and precipes[recipe.name] then
			DIR.spam_log("Recipe "..recipe.name.." has productivity enabled and is an assembling machine recipe")
		end
	end
	-- hunt for empty crafting categories
	for category,_ in pairs(data.raw["recipe-category"]) do
		if not DIR.get_any_recipe_has_category(category) then
			DIR.spam_log("Crafting category "..category.." has no recipes")
		end
	end
	-- test for unlockable recipes
	local unlocked = {}
	for _,tech in pairs(data.raw.technology) do
		if tech.effects then
			for _,effect in pairs(tech.effects) do
				if effect.type == "unlock-recipe" then unlocked[effect.recipe] = true end
			end
		end
	end
	for _,recipe in pairs(data.raw.recipe) do
		local root = recipe.normal and recipe.normal or recipe
		if root.enabled == false and not unlocked[recipe.name] then
			DIR.spam_log("Recipe "..recipe.name.." is locked but has no tech unlock")
		end
	end
end

function DIR.validate_kits()
	local starter_kits = require("code.data.kits")
	for age,items in pairs(starter_kits.kits) do
		for name,count in pairs(items) do
			local found = false
			for _,itemtype in pairs(DIR.all_the_item_types) do
				if data.raw[itemtype][name] then
					found = true
					break
				end
			end
			if not found then error("\n\nStarter kit "..age.." contains non-existent item "..name..".") end
		end
	end
	for age,techs in pairs(starter_kits.tech) do
		for _,tech in pairs(techs) do
			if not data.raw.technology[tech] then error("\n\nStarter kit "..age.." contains non-existent technology "..tech..".") end
		end
	end
end

function DIR.get_any_recipe_has_category(category)
	for _,r in pairs(data.raw.recipe) do
		if r.category == category then return true end
	end
	return false
end

-- function DIR.get_crafting_machines_with_category(category)
	-- local machines = {}
	-- for _,ptype in pairs({"assembling-machine","furnace"}) do
		-- for _,machine in pairs(data.raw[ptype]) do
			-- if machine.crafting_categories and DIR.is_value_in_list(machine.crafting_categories, category) and not DIR.is_value_in_list(machine.flags,"hidden") then
				-- machines[machine.name] = ptype
			-- end
		-- end
	-- end
	-- return machines
-- end

-- function DIR.get_container_localised_description(category)
	-- local machines = DIR.get_crafting_machines_with_category(category)
	-- local list = {""}
	-- for m,mtype in pairs(machines) do
		-- local p = data.raw[mtype][m]
		-- if p and p.crafting_categories and DIR.list_contains(p.crafting_categories, category) then
			-- if table_size(list) > 1 then table.insert(list, "\n") end
			-- table.insert(list, "[img=entity/" .. m .. "] ")
			-- table.insert(list, p.localised_name or {"entity-name." .. m})
		-- end
	-- end
	-- return (table_size(list) > 1) and {"item-description.container-description", list} or nil
-- end

function DIR.set_fluid_spill_multiplier(fluid,emissions)
	local f = data.raw.fluid[fluid]
	if not f then error("DIR.set_fluid_spill_emissions() called on non-existent fluid "..fluid) end
	if (emissions == nil) or (emissions < 0) then error("DIR.set_fluid_spill_emissions(): emissions cannot be less than 0 or nil ("..fluid..")") end
	local i = data.raw.item[fluid.."-spill-data"]
	if i then
		i.fuel_emissions_multiplier = emissions
	else
		data:extend({{
			name = fluid.."-spill-data",
			localised_name = {"item-name.fluid-spill-data", {"fluid-name."..fluid}},
			type = "item",
			icon = f.icon,
			icon_size = f.icon_size,
			icon_mipmaps = f.icon_mipmaps,
			icons = f.icons,
			fuel_emissions_multiplier = emissions,
			fuel_value = "1J",
			fuel_category = "fluid-spill",
			flags = {"hidden", "hide-from-fuel-tooltip"},
			stack_size = 1
		}})
	end
end

function DIR.get_fluid_spill_multiplier(fluid)
	local f = data.raw.fluid[fluid]
	if not f then error("DIR.get_fluid_spill_emissions() called on non-existent fluid "..fluid) end
	local i = data.raw.item[fluid.."-spill-data"]
	return i and i.fuel_emissions_multiplier or 0
end

------------------------------------------------------------------------------------------------------------------------------------------------------
