------------------------------------------------------------------------------------------------------------------------------------------------------

-- LOG

------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.log_level = {
	debug = 1,
	warning = 2,
	error = 3,
	milestone = 4,
	notice = 5,
}

DIR.log_prefix = {
	[DIR.log_level.debug] = "debug: ",
	[DIR.log_level.warning] = "WARNING: ",
	[DIR.log_level.error] = "ERROR: ",
	[DIR.log_level.milestone] = "MILESTONE: ",
	[DIR.log_level.notice] = "NOTICE: ",
}

function DIR.spam_log(message, level)
	if not level then level = DIR.log_level.debug end
	if DIR.log[level] then log(DIR.IR_short..": "..DIR.log_prefix[level]..message) end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
