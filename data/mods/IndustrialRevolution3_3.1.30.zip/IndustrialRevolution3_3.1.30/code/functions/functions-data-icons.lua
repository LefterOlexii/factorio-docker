------------------------------------------------------------------------------------------------------------------------------------------------------

-- ICONS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- return a formatted IR icon path

function DIR.get_icon_path(name, icon_size, path)
	return string.format("%s/%s/%s.png", path or DIR.icon_path, tostring(icon_size or DIR.icon_size), name)
end

function DIR.get_vanilla_constant_icon_path(name)
	return string.format("%s/%s.png", DIR.core_constant_icons_path, name)
end

function DIR.get_base_tech_icon_path(name)
	return string.format("__base__/graphics/technology/%s.png", name)
end

-- replace an item's icon

function DIR.replace_item_icon(item_name, icon, icon_path)
	local item = nil
	for _,ptype in pairs(DIR.append_list(DIR.all_the_item_types,{"fluid"})) do
		item = data.raw[ptype][item_name]
		if item ~= nil then break end
	end
	if not item then
		error("Asked to update icon for unlocatable item "..item_name)
		return
	end
	if not icon then icon = item_name end
	item.icon = DIR.get_icon_path(icon, DIR.icon_size, icon_path)
	item.icons = nil
	item.icon_size = DIR.icon_size
	item.icon_mipmaps = DIR.icon_mipmaps
	if item.place_result then
		local entity = DIR.wild_stab_at_entity_by_name(item.place_result)
		if entity then
			entity.icon = item.icon
			entity.icon_size = item.icon_size
			entity.icon_mipmaps = item.icon_mipmaps
		end
	end
	-- 1.1 - a handful of items have pictures property e.g. for lighting - kill it and recreate separately if necessary
	item.pictures = nil
end

function DIR.add_mask_to_item_icon(item_name, icon, tint, icon_path)
	local item = data.raw.item[item_name] or data.raw.fluid[item_name] or data.raw.tool[item_name] or data.raw.module[item_name]
	if item.icons == nil then
		item.icons = item.icon ~= nil and {{icon = item.icon, icon_size = item.icon_size, icon_mipmaps = item.icon_mipmaps }} or {}
	end
	table.insert(item.icons, 
		{ icon = DIR.get_icon_path(icon, DIR.icon_size, icon_path or DIR.icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, tint = tint }
	)
end

function DIR.add_light_to_item(item_name, icon, icon_path)
	if not data.raw.item[item_name] and not data.raw.fluid[item_name] and not data.raw.tool[item_name] and not data.raw.module[item_name] then
		error("Asked to update light picture for non-existent item/fluid/tool/module "..item_name)
		return
	end
	if not icon then icon = item_name end
	local item = data.raw.item[item_name] or data.raw.fluid[item_name] or data.raw.tool[item_name] or data.raw.module[item_name]
	item.pictures = { layers = {} }
	table.insert(item.pictures.layers, {
		filename = DIR.get_icon_path(icon, DIR.icon_size, icon_path),
		size = DIR.icon_size,
		mipmap_count = DIR.icon_mipmaps,
		scale = 16 / DIR.icon_size,
	})
	table.insert(item.pictures.layers, {
		filename = DIR.get_icon_path(icon.."-light", DIR.icon_size, icon_path),
		size = DIR.icon_size,
		mipmap_count = DIR.icon_mipmaps,
		scale = 16 / DIR.icon_size,
		draw_as_light = true,
		flags = {"light"},
		blend_mode = "additive",
	})
end

function DIR.replace_recipe_icon(recipe_name, icon, icon_path)
	if not data.raw.recipe[recipe_name] then
		error("Asked to update icon for non-existent recipe "..recipe_name)
		return
	end
	if not icon then icon = recipe_name end
	local recipe = data.raw.recipe[recipe_name]
	recipe.icon = DIR.get_icon_path(icon, DIR.icon_size, icon_path)
	recipe.icons = nil
	recipe.icon_size = DIR.icon_size
	recipe.icon_mipmaps = DIR.icon_mipmaps
end

-- replace a tech's icon

function DIR.replace_tech_icon(tech_name, icon)
	if not data.raw.technology[tech_name] then
		error("Asked to update icon for non-existent technology "..tech_name)
		return
	end
	if not icon then icon = tech_name end
	data.raw.technology[tech_name].icon = DIR.get_icon_path(icon, DIR.high_icon_size)
	data.raw.technology[tech_name].icons = nil
	data.raw.technology[tech_name].icon_size = DIR.high_icon_size
	data.raw.technology[tech_name].icon_mipmaps = DIR.high_icon_mipmaps
end

function DIR.copy_item_icon_to_recipe(item)
	if data.raw.item[item] and data.raw.recipe[item] then
		data.raw.recipe[item].icons = nil
		data.raw.recipe[item].icon = data.raw.item[item].icon
		data.raw.recipe[item].icon_size = data.raw.item[item].icon_size
		data.raw.recipe[item].icon_mipmaps = data.raw.item[item].icon_mipmaps
	else
		DIR.spam_log("copy_item_icon_to_recipe couldn't find item/recipe "..item, DIR.log_level.warning)
	end
end

function DIR.convert_recipe_icon_to_icons(recipe)
	if recipe.icons then return end
	if not recipe.icon then 
		recipe.icons = {}
		return
	end
	recipe.icons = {
		{
			icon = recipe.icon,
			icon_size = recipe.icon_size,
			icon_mipmaps = recipe.icon_mipmaps,
		},
	}
	recipe.icon = nil
	recipe.icon_size = nil
	recipe.icon_mipmaps = nil
end

function DIR.is_icon_in_icons(icon,icons)
	for _,this_icon in pairs(icons) do
		if this_icon.icon == icon then return true end
	end
	return false
end

function DIR.add_icons_to_recipe(recipe, newicons, dy, x)
	local max_shift = 8.5
	if x == nil then x = -max_shift end
	local number = math.max(2,#newicons)
	local scale = 0.5
	local count = 1
	for _,this_icon in pairs(newicons) do
		if this_icon.icon and this_icon.icon_size then
			table.insert(recipe.icons, {
				icon = this_icon.icon,
				icon_size = this_icon.icon_size,
				icon_mipmaps = this_icon.icon_mipmaps,
				scale = scale * (32/this_icon.icon_size),
				shift = { 1.5 + DIR.linear_transform(count,1,number,x,max_shift), 1.5 + (dy * max_shift) },
				tint = {0,0,0,0.4}
			})
			table.insert(recipe.icons, {
				icon = this_icon.icon,
				icon_size = this_icon.icon_size,
				icon_mipmaps = this_icon.icon_mipmaps,
				scale = scale * (32/this_icon.icon_size),
				shift = { DIR.linear_transform(count,1,number,x,max_shift), dy * max_shift },
			})
			count = count + 1
		end
	end
end

function DIR.add_category_icon_to_recipe(recipe,icon_name)
	DIR.convert_recipe_icon_to_icons(recipe)
	local base_shadow = table.deepcopy(recipe.icons[1])
	base_shadow.tint = {0,0,0,0.4}
	base_shadow.shift = {1.5,1.5}
	table.insert(recipe.icons, 1, base_shadow)
	table.insert(recipe.icons, 1, {icon = DIR.get_icon_path(icon_name), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps})
end

function DIR.add_ingredient_icons_to_recipe(recipe, ignore, icon_path)
	DIR.convert_recipe_icon_to_icons(recipe)
	local newicons = {}
	for _,ingredient in pairs(recipe.ingredients) do
		local name = ingredient.name or ingredient[1]
		if not DIR.icon_overlay_ingredient_ignores[name] and (name ~= ignore) then
			local itype = ingredient.type or "item"
			-- either the item already exists, in which case it is either a vanilla item or an IR/other mod's item that has already been prototyped
			-- or, the item doesn't (yet) exist, which (hopefully) means it's an IR component system item which is further down the queue
			local item = data.raw[itype][name]
			local size = item and item.icon_size or DIR.icon_size
			local icon = item and item.icon or DIR.get_icon_path(name,size,icon_path)
			local icon_size = size
			local icon_mipmaps = item and item.icon_mipmaps or DIR.icon_mipmaps
			table.insert(newicons, { icon = icon, icon_size = icon_size, icon_mipmaps = icon_mipmaps })
		end
	end
	DIR.add_icons_to_recipe(recipe,newicons,-1)
end

function DIR.recipe_contains_ingredient(recipe,name)
	if recipe.ingredients then
		for _,ingredient in pairs(recipe.ingredients) do
			local iname = ingredient.name or ingredient[1]
			if iname == name then return true end
		end
	end
	return false
end

function DIR.add_result_icons_to_recipe(recipe, include_main, ignore, icon_path)
	DIR.convert_recipe_icon_to_icons(recipe)
	local newicons = {}
	if recipe.results then
		for _,result in pairs(recipe.results) do
			local name = result.name or result[1]
			if not DIR.icon_overlay_ingredient_ignores[name] and (name ~= ignore) then
				if (name ~= recipe.main_product or include_main) and not DIR.icon_overlay_result_ignores[name] and (include_main or not DIR.recipe_contains_ingredient(recipe,name)) then
					table.insert(newicons, { icon = DIR.get_icon_path(name, DIR.icon_size, result.icon_path or icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps })
				end
			end
		end
	end
	DIR.add_icons_to_recipe(recipe,newicons,1)
end

function DIR.get_player_color(name)
	if not data then return nil end
	local pcs = data.raw["utility-constants"]["default"]["player_colors"]
	for _,colour in pairs(pcs) do
		if colour.name == name then return colour.player_color end
	end
	error("Asked to use non-existent player colour "..name)
end

function DIR.nice_multi_icon(size,list)
	local l = table_size(list)
	if l<1 or l>4 then error("nice_multi_icon() needs 1-4 icons") end
	local icons = {}
	local shifts = {
		[1] = {
			{0,0},
		},
		[2] = {
			-- {0,-0.1875},
			{0,0},
			{0,0.25},
		},
		[3] = {
			-- {0,-0.1875},
			{0,0},
			{-0.25,0.25},
			{0.25,0.25},
		},
		[4] = {
			-- {0,-0.1875},
			{0,0},
			{-0.25,0.2},
			{0,0.25},
			{0.25,0.2},
		},
	}
	local size_base = (size == 64) and 0.5 or 1
	local shift_base = (size == 64) and 32 or size
	for k,v in pairs(list) do
		if k >1 and size==64 then
			table.insert(icons, {
				icon = DIR.get_icon_path(v,size),
				icon_size = size,
				icon_mipmaps = DIR.icon_mipmaps,
				shift = {(shifts[l][k][1] * shift_base) + 1.5, (shifts[l][k][2] * shift_base) + 1.5},
				scale = size_base * ((k==1) and 1 or 0.5),
				tint = {0,0,0,0.5},
			})
		end
		table.insert(icons, {
			icon = DIR.get_icon_path(v,size),
			icon_size = size,
			icon_mipmaps = DIR.icon_mipmaps,
			shift = {shifts[l][k][1] * shift_base, shifts[l][k][2] * shift_base},
			scale = size_base * ((k==1) and 1 or 0.5),
		})
	end
	return icons
end

------------------------------------------------------------------------------------------------------------------------------------------------------
