------------------------------------------------------------------------------------------------------------------------------------------------------

-- AMMO 

------------------------------------------------------------------------------------------------------------------------------------------------------

function DIR.get_projectile_name(prefix, base_damage, hue, saturation)
	if hue == nil then hue = 0 end
	return prefix.."-"..math.floor(hue*1000).."-"..math.floor(DIR.get_saturation(hue,saturation)*100).."-"..base_damage
end

function DIR.create_bullet_projectile(base_damage, hue, saturation, path, piercing, class, width, dtype)
	class = class or "bullet"
	width = width or 7
	local name = DIR.get_projectile_name(class,base_damage, hue, saturation)
	if not data.raw.projectile[name] then
		data:extend({{
			name = name,
			type = "projectile",
			acceleration = 0,
			action = {
				action_delivery = {
					target_effects = {
						{
							entity_name = "explosion-hit",
							type = "create-entity"
						},
						{
							damage = {
								amount = base_damage,
								type = "physical"
							},
							type = "damage",
						},
						dtype and {
							damage = {
								amount = base_damage,
								type = dtype,
							},
							type = "damage",
						} or nil,
					},
					type = "instant"
				},
				type = "direct"
			},
			piercing_damage = piercing and base_damage or 0,
			animation = {
				filename = path.."/"..class..".png",
				tint = DIR.hsva2rgba(hue,DIR.get_saturation(hue,saturation)/4,1),
				frame_count = 1,
				height = 100,
				width = width,
				scale = 0.5,
				priority = "high",
				draw_as_glow = true,
				blend_mode = "additive",
			},
			collision_box = {{-0.05,-0.25},{0.05,0.25}},
			direction_only = true,
			flags = {"not-on-map"},
			hit_at_collision_position = true,
			force_condition = "not-same",
		}})
	end
end

function DIR.get_ammo_type(projectile_type, base_damage, range, speed, pellets, deviation, category, hue, saturation)
    local ammo_type = {
        action = {
            {
                action_delivery = {
                    source_effects = {
                        {
                            entity_name = "explosion-gunshot",
                            type = "create-explosion"
                        }
                    },
                    type = "instant"
                },
                type = "direct"
            },
        },
        category = category,
        target_type = (pellets > 1) and "direction" or "entity"
    }
	table.insert(ammo_type.action, 
		{
			action_delivery = {
				direction_deviation = deviation,
				max_range = range,
				projectile = DIR.get_projectile_name(projectile_type, base_damage, hue, saturation),
				range_deviation = deviation,
				starting_speed_deviation = (pellets > 1) and 0.1 or 0,
				starting_speed = speed,
				type = "projectile"
			},
			repeat_count = pellets,
			type = "direct"
		}
	)
	return ammo_type
end

------------------------------------------------------------------------------------------------------------------------------------------------------
