------------------------------------------------------------------------------------------------------------------------------------------------------

-- PARTICLES

------------------------------------------------------------------------------------------------------------------------------------------------------

function DIR.particle_sheet(name,variations,y,shadow)
	local shadow_shift = shadow and {3/64,1/64}
	local shadow_tint = shadow and {r=0,g=0,b=0,a=1}
    return {
        filename = DIR.particles_path.."/"..name..".png",
        frame_count = 32,
        line_length = 32,
        height = 32,
        width = 32,
        scale = 0.4,
        variation_count = variations,
        shift = shadow_shift,
		tint = shadow_tint,
        draw_as_shadow = shadow,
		y = y,
    }
end

function DIR.particle_effect(name,number,deviation,height,trailing,speed)
    if not number then number = 16 end
	if not deviation then deviation = 0.2 end
	if not height then height = 0.75 end
	local probability = math.min(number,1)
    return {
        type = "create-particle",
		damage_type_filters = {"fire","impact"},
        particle_name = (trailing and "trailing-" or "")..name.."-particle",
        initial_height = height,
        initial_vertical_speed = 0.07,
        initial_vertical_speed_deviation = 0.1,
        offset_deviation = {{0-deviation,0-deviation},{deviation,deviation}},
        repeat_count = math.ceil(number),
		probability = probability,
        speed_from_center = speed or 0.04,
        speed_from_center_deviation = (speed and speed/2) or 0.02,
		frame_speed = 1,
		frame_speed_deviation = 0.1,
    }
end

function DIR.create_IR_particle(name,variations,y,sheet_name,ttl)
    return {
        name = name,
        type = "optimized-particle",
        life_time = DIR.seconds_to_ticks(ttl or 180),
        movement_modifier_when_on_ground = 0,
        pictures = {
            sheet = DIR.particle_sheet(sheet_name or name, variations, y),
        },
        shadows = {
            sheet = DIR.particle_sheet(sheet_name or name, variations, y, true),
        },
        render_layer = "air-object",
        render_layer_when_on_ground = "lower-object-above-shadow",
    }
end

function DIR.create_IR_particle_trail(name,variations)
	local particle = DIR.create_IR_particle(name,variations)
	particle.name = "trailing-"..particle.name
    particle.regular_trigger_effect_frequency = 2
	particle.regular_trigger_effect = {
		type = "create-trivial-smoke",
		smoke_name = "IR-particle-smoke",
        starting_frame_deviation = 5,
		offset_deviation = {{-0.03, -0.03}, {0.03, 0.03}},
		speed_from_center = nil,
	}
    particle.ended_in_water_trigger_effect = {
		type = "create-entity",
		entity_name = "water-splash"
	}
	return particle
end

------------------------------------------------------------------------------------------------------------------------------------------------------
