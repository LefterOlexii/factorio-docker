------------------------------------------------------------------------------------------------------------------------------------------------------

-- add analysis (science) pack unlocks to key milestones before rebuild so their ingredients are correctly dependent

local packs = {}

for material,tech_name in pairs(DIR.components.analysis.unlocking_techs) do
	local tech = data.raw.technology[tech_name]
	if not tech or not tech.effects then error("Analysis pack "..pack.." specifies non-existent or no-effects unlocking tech") end
	if not DIR.is_tech_rebuildable(tech) then error("Analysis pack "..pack.." specifies non-rebuildable unlocking tech") end
	local pack = DIR.get_item_name(material,"analysis")
	if data.raw.tool[pack] and data.raw.recipe[pack] then
		table.insert(tech.effects, {type="unlock-recipe",recipe=pack})
		packs[pack] = tech_name
	end
	DIR.add_tech_icon_overlay(tech_name, DIR.get_icon_path("analysis-pack-unlock"))
end

-- double-check automation (red) packs for ... reasons

local red_pack_root = DIR.components.analysis.unlocking_techs["copper"]
if red_pack_root then
	local pack = DIR.get_item_name("copper","analysis")
	for _,tech in pairs(data.raw.technology) do
		if DIR.is_tech_rebuildable(tech) and (tech.name ~= red_pack_root) and (not DIR.technologies[tech.name] or not DIR.technologies[tech.name].IR_has_schematic) then
			DIR.add_prereq_to_tech(tech.name, DIR.components.analysis.unlocking_techs["copper"])
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

