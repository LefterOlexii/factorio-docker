------------------------------------------------------------------------------------------------------------------------------------------------------

-- techs which only unlock bonuses
-- try to contain the excitement

-- braking force - why so many tiny bonuses

for i=1,7 do
	-- disable levels 4-7 and spread the total bonus (100%) across remaining three
	local tech = DIR.add_new_minimal_tech("braking-force-"..i, "braking-force", true, nil, {"railway"},
		{{type = "train-braking-force-bonus", modifier = (i < 3) and 0.25 or 0.5 }}
	) 
	-- tech.upgrade = (i < 4)
	tech.enabled = (i < 4)
	tech.icon = nil
	tech.icons = util.technology_icon_constant_braking_force(DIR.get_base_tech_icon_path("braking-force"))
end

-- physical projectile damage

-- 3.1.28 - tweak physical projectile damage
local tech = data.raw.technology["physical-projectile-damage-1"]
tech.effects = {
	{ type = "ammo-damage", ammo_category = "shotgun-shell", modifier = 0.1 },
	{ type = "turret-attack", turret_id = "scattergun-turret", modifier = 0.1 },
}
local tech = data.raw.technology["physical-projectile-damage-2"]
tech.effects = {
	{ type = "ammo-damage", ammo_category = "bullet", modifier = 0.2 },
	{ type = "turret-attack", turret_id = "gun-turret", modifier = 0.2 },
	{ type = "ammo-damage", ammo_category = "shotgun-shell", modifier = 0.1 },
	{ type = "turret-attack", turret_id = "scattergun-turret", modifier = 0.1 },
}

for i=3,7 do
	-- mirror scattergun with autogun
	local tech = data.raw.technology["physical-projectile-damage-"..i]
	local gt = 0
	for _,effect in pairs(tech.effects) do
		if effect.type == "turret-attack" and effect.turret_id == "gun-turret" then
			gt = effect.modifier
			break
		end
	end
	if gt > 0 then
		table.insert(tech.effects, {type = "turret-attack", modifier = gt, turret_id = "scattergun-turret"})
	end
end



-- laser damage

for i=1,7 do
	-- icon only
	local tech = data.raw.technology["energy-weapons-damage-"..i]
	tech.icon = nil
	tech.icons = util.technology_icon_constant_damage(DIR.get_icon_path("helium-laser-tech", DIR.high_icon_size))
	local tech = data.raw.technology["laser-shooting-speed-"..i]
	tech.icon = nil
	tech.icons = util.technology_icon_constant_speed(DIR.get_icon_path("helium-laser-tech", DIR.high_icon_size))
end

-- photon torpedo damage (native)

for i=1,4 do
	-- native
	local tech = DIR.add_new_minimal_tech("ir-photon-turret-damage-"..i, "", false, nil, {"ir-photon-turret"},
		{
			{type = "ammo-damage", modifier = 0.5, ammo_category = "photon-torpedo"},
		}
	) 
	tech.icon = nil
	tech.icons = util.technology_icon_constant_damage(DIR.get_icon_path("photon-turret", DIR.high_icon_size))
	DIR.add_machine_mask_to_tech(tech, "photon-turret")
	tech.upgrade = true
	if i == 4 then
		tech.max_level = "infinite"
		tech.unit.count = nil
	end
end

-- inserter capacity bonus

for i=1,7 do
	-- disable levels 4-7 - we split this into two branches (normal vs stack inserters) in technology-native
	-- for level 1-3 overwrite whole tech with +2 for stack only since we start stack inserters off at 1+5
	local tech = DIR.add_new_minimal_tech("inserter-capacity-bonus-"..i, "inserters-3", false, nil, {"ir-inserters-3"},
		{
			{type = "stack-inserter-capacity-bonus", modifier = 2}
		}
	) 
	tech.upgrade = (i < 4)
	tech.enabled = (i < 4)
	tech.icon = nil
	tech.icons = util.technology_icon_constant_capacity(DIR.get_icon_path("inserters-3", DIR.high_icon_size))
end

-- robot movement

local total = 2
for i=1,5 do
	-- mirror battery to speed, up to +200%
	local tech = data.raw.technology["worker-robots-speed-"..i]
	local ws = 0
	for _,effect in pairs(tech.effects) do
		if effect.type == "worker-robot-speed" and effect.modifier > ws then ws = effect.modifier end
	end
	if ws > 0 and total > 0 then
		table.insert(tech.effects, {type = "worker-robot-battery", modifier = math.min(total,ws)})
		total = total - ws
	end
end

-- follower count (icon only)

for i=1,7 do
	-- disable use of defender as base icon for follower count (IR has an earlier combat bot)
	local tech = data.raw.technology["follower-robot-count-"..i]
	if tech then
		for _,effect in pairs(tech.effects) do
			if effect.type == "maximum-following-robots-count" then
				effect.icon = DIR.get_icon_path("count")
				effect.icon_size = DIR.icon_size
				effect.icon_mipmaps = DIR.icon_mipmaps
				effect.icons = nil
				effect.use_icon_overlay_constant = false
			end
		end
	end
end

-- research speed (icon only)

for i=1,6 do
	local tech = data.raw.technology["research-speed-"..i]
	if tech then
		tech.icon = nil
		tech.icon_size = nil
		tech.icon_mipmaps = nil
		tech.icons = util.technology_icon_constant_speed(DIR.get_icon_path("electric-lab", DIR.high_icon_size))
	end
end

-- mining productivity (icon only)

for i=1,4 do
	local tech = data.raw.technology["mining-productivity-"..i]
	if tech and tech.effects then
		tech.icon = nil
		tech.icon_size = nil
		tech.icon_mipmaps = nil
		tech.icons = util.technology_icon_constant_productivity(DIR.get_icon_path("chrome-drill", DIR.high_icon_size))
		for _,effect in pairs(tech.effects) do
			if effect.type == "mining-drill-productivity-bonus" then 
				effect.icon = DIR.get_icon_path("mining-productivity")
				effect.icon_size = DIR.icon_size
				effect.icon_mipmaps = DIR.icon_mipmaps
				effect.icons = nil
				effect.use_icon_overlay_constant = false
			end
		end
	end
end


------------------------------------------------------------------------------------------------------------------------------------------------------
