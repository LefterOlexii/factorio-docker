------------------------------------------------------------------------------------------------------------------------------------------------------

-- BACKBONE TECHNOLOGIES 
-- these produce the main structure of IR's research progression
-- different to "native" technologies in that most of them need to consult material-component tables

------------------------------------------------------------------------------------------------------------------------------------------------------

for techname,techdata in pairs(DIR.technologies) do
	local ingredients = {{name = "automation-science-pack", type = "item", amount = 1}}
	local icon = nil
	local icons = nil
	if not techdata.icon and not techdata.icons then
		error("Backbone tech "..techname.." does not specify icon or icons")
	elseif not techdata.icons then
		if techdata.use_vanilla_icon then
			icon = "__base__/graphics/technology/"..techdata.icon..".png"
		else
			icon = DIR.get_icon_path(techdata.icon,DIR.high_icon_size,techdata.icon_path)		
		end
	end
	local tech = {
		name = techname,
		type = "technology",
		icon = icon,
		icons = techdata.icons,
		icon_size = not techdata.icons and DIR.high_icon_size or nil,
		icon_mipmaps = not techdata.icons and DIR.high_icon_mipmaps or nil,
		upgrade = false,
		enabled = true,
		unit = {
			count = 1, -- overridden later
			time = 60,
			ingredients = ingredients,
		},
		prerequisites = techdata.prerequisites,
		effects = {},
		IR_native = true,
		IR_tech_rebuild_ignore = techdata.IR_tech_rebuild_ignore,
	}
	for _,unlock in pairs(techdata.machines) do
		table.insert(tech.effects, { type = "unlock-recipe", recipe = unlock })
	end
	if techdata.unlocks then
		for material,unlocks in pairs(techdata.unlocks) do
			for _,unlock in pairs(unlocks) do
				if unlock == "derivatives" then
					for component,componentdata in pairs(DIR.components) do
						local recipe = DIR.get_item_name(material, component)
						if componentdata.derivative and not (componentdata.made_from_exceptions and componentdata.made_from_exceptions[material]) then
							if data.raw.recipe[recipe] then
								table.insert(tech.effects, {type = "unlock-recipe", recipe = recipe })
								if techdata.IR_tech_rebuild_ignore_as_provider then data.raw.recipe[recipe].IR_tech_rebuild_ignore_as_provider = true end
							end
						end
					end
				else
					local recipe = DIR.get_item_name(material, unlock)
					if data.raw.recipe[recipe] then
						table.insert(tech.effects, { type = "unlock-recipe", recipe = recipe })
						if techdata.IR_tech_rebuild_ignore_as_provider then data.raw.recipe[recipe].IR_tech_rebuild_ignore_as_provider = true end
					else
						DIR.spam_log("Backbone tech "..tech.name.." couldn't find recipe "..recipe, DIR.log_level.warning)
					end
				end
			end
		end
	end
	if techdata.additional_unlocks then
		for _,unlock in pairs(techdata.additional_unlocks) do
			if not data.raw.recipe[unlock] then error("Tech backbone: no such recipe as "..unlock) end
			table.insert(tech.effects, { type = "unlock-recipe", recipe = unlock })
			if techdata.IR_tech_rebuild_ignore_as_provider then data.raw.recipe[unlock].IR_tech_rebuild_ignore_as_provider = true end
		end
	end
	if techdata.category_unlocks then
		local category_unlocks = DIR.values_to_keys(techdata.category_unlocks)
		local unlocks = {}
		for _,recipe in pairs(data.raw.recipe) do
			if category_unlocks[recipe.category] then
				table.insert(unlocks, { type = "unlock-recipe", recipe = recipe.name })
				if techdata.IR_tech_rebuild_ignore_as_provider then recipe.IR_tech_rebuild_ignore_as_provider = true end
			end
		end
		table.sort(unlocks, function(a,b) return a.recipe < b.recipe end)
		tech.effects = DIR.append_list(tech.effects,unlocks)
	end
	data:extend({tech})
end

------------------------------------------------------------------------------------------------------------------------------------------------------
