------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY - pre-requisite conversion
-- run late (data-final-fixes)

local conversion = {
	["advanced-electronics"] = "ir-electronics-2",
	["advanced-electronics-2"] = "ir-electronics-3",
	["advanced-material-processing"] = "ir-furnaces-2",
	["advanced-material-processing-2"] = "ir-furnaces-3",
	["advanced-oil-processing"] = "ir-crude-oil-processing", -- 3.0.0
	["cliff-explosives"] = "explosives",
	["concrete"] = "ir-concrete-1",
	["construction-robotics"] = "personal-roboport-equipment",
	["effectivity-module"] = "ir-modules-1",
	["effectivity-module-2"] = "ir-modules-2",
	["effectivity-module-3"] = "ir-modules-3",
	["electronics"] = "ir-electronics-1",
	["fast-inserter"] = "ir-inserters-2",
	["logistic-robotics"] = "robotics",
	["modules"] = "ir-modules-1",
	["oil-processing"] = "ir-crude-oil-processing", -- 3.0.0
	["productivity-module"] = "ir-modules-1",
	["productivity-module-2"] = "ir-modules-2",
	["productivity-module-3"] = "ir-modules-3",
	["rail-signals"] = "automated-rail-transportation",
	["rocket-control-unit"] = "rocket-silo",
	["solar-energy"] = "ir-solar-energy-1",
	["speed-module"] = "ir-modules-1",
	["speed-module-2"] = "ir-modules-2",
	["speed-module-3"] = "ir-modules-3",
	["stack-inserter"] = "ir-inserters-3",
	["steel-processing"] = "ir-steel-milestone",
	["uranium-ammo"] = "military-4",
	-- added 3.0.0
	["logistic-science-pack"] = DIR.components.analysis.unlocking_techs.iron,
	["chemical-science-pack"] = DIR.components.analysis.unlocking_techs.steel,
	["production-science-pack"] = DIR.components.analysis.unlocking_techs.chromium,
	["utility-science-pack"] = DIR.components.analysis.unlocking_techs.electrum,
	["military-science-pack"] = DIR.components["special-analysis"].project_info.sulphur.unlocked_by,
}

-- if any prerequisite for a tech has been disabled (most likely by IR), replace it with a known substitute where possible
-- see technology-vanilla.lua for further notes

for _,tech in pairs(data.raw.technology) do
	if tech.prerequisites then
		for k,prereq in pairs(tech.prerequisites) do
			local ptech = data.raw.technology[prereq]
			if ptech and ptech.enabled == false then
				if conversion[prereq] then
					DIR.spam_log("Converting prereq for tech "..tech.name..": "..prereq.." > "..conversion[prereq])
					tech.prerequisites[k] = conversion[prereq]
				else
					DIR.spam_log("No alternative available for disabled prerequisite \""..prereq.."\" in \""..tech.name.."\"", DIR.log_level.warning)
					tech.prerequisites[k] = nil
				end
			end
		end
		tech.prerequisites = DIR.unique_values_only(tech.prerequisites)
	end
end

-- check disabled vanilla techs for unknown recipe unlocks (assumed to be added by other mods)
-- and transfer them to IR3 equivalent tech if possible

for vanilla,equivalent in pairs(conversion) do
	local tech = data.raw.technology[vanilla]
	local etech = data.raw.technology[equivalent]
	if etech and tech and (tech.enabled == false) and tech.effects and (table_size(tech.effects) > 0) and DIR.vanilla_techs[vanilla] then
		local unlocks = DIR.values_to_keys(DIR.vanilla_techs[vanilla])
		for _,effect in pairs(tech.effects) do
			if effect.type == "unlock-recipe" and not unlocks[effect.recipe] then
				if not etech.effects then etech.effects = {} end
				table.insert(etech.effects, effect)
				DIR.spam_log("Copied unknown unlock \""..effect.recipe.."\" from disabled vanilla tech \""..tech.name.."\" to IR3 tech \""..etech.name.."\"", DIR.log_level.warning)
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
