------------------------------------------------------------------------------------------------------------------------------------------------------

-- NATIVE NON-BACKBONE TECHS

------------------------------------------------------------------------------------------------------------------------------------------------------

local logistics_effects = {{type = "character-logistic-requests", modifier = true}, {type = "character-logistic-trash-slots", modifier = 30}}

local tree_planters = {}
for _,tree in pairs(DIR.plantable_trees) do table.insert(tree_planters, "tree-planter-"..tree) end

DIR.add_new_minimal_tech("ir-advanced-batteries", "steel-battery-charger", false, {"advanced-battery","charged-advanced-battery","steel-battery-charger","steel-battery-discharger"},
	{"battery","electric-energy-distribution-2","ir-washing-1"}) 
DIR.add_new_minimal_tech("ir-arc-turret", "arc-turret", false, {"arc-turret"}, {"military-2"}) 
DIR.add_new_minimal_tech("ir-arc-turret-equipment", "arc-turret-equipment", false, {"arc-turret-equipment"}, {"ir-arc-turret","power-armor"}) 
DIR.add_new_minimal_tech("ir-barrelling", "barrel", false, {"empty-barrel"}, {"ir-steel-milestone"}) 
DIR.add_new_minimal_tech("ir-high-pressure-canisters", "high-pressure-canisters", false, {"barrelling-machine","empty-canister","fill-oxygen-canister","empty-oxygen-canister","fill-hydrogen-canister","empty-hydrogen-canister","fill-nitrogen-canister","empty-nitrogen-canister","fill-helium-canister","empty-helium-canister","fill-carbon-canister","empty-carbon-canister","fill-natural-canister","empty-natural-canister"}, {"ir-cryogenics"}) 
DIR.add_new_minimal_tech("ir-bronze-telescope", "bronze-telescope", false, {"bronze-telescope"}, {}) 
DIR.add_new_minimal_tech("ir-bronze-forestry", "bronze-forestry", false, DIR.append_list({"bronze-forestry","forestry-wood-example","forestry-rubber-wood-example"}, tree_planters), {}) 
DIR.add_new_minimal_tech("ir-chrome-forestry", "chrome-forestry", false, 
	DIR.append_list({"chrome-forestry","ammonia-gas","liquid-fertiliser","forestry-wood-fertiliser-example","forestry-rubber-wood-fertiliser-example"}, tree_planters), 
	{"ir-cryogenics","ir-electroplating"}) 
DIR.add_new_minimal_tech("ir-concrete-1", "concrete", true, {"concrete-fluid","concrete-fluid-from-scrap","concrete-block","concrete", "hazard-concrete"}, {"automation-2","ir-grinding-2"}) 
DIR.add_new_minimal_tech("ir-concrete-2", "concrete", true, {"refined-concrete","refined-hazard-concrete"}, {}) 
DIR.add_new_minimal_tech("ir-force-fields", "supermagnet", false, {"supermagnet","carbon-coil","electrum-gem-charged","field-effector"}, {}) 
DIR.add_new_minimal_tech("ir-graphene", "nanoglass-tech", false, {"carbon-foil","nanoglass"}, {"automation-4","ir-cryogenics"})
DIR.add_new_minimal_tech("ir-heavy-roller", "heavy-roller", false, {"heavy-roller"}, {"ir-monowheel","ir-bronze-furnace"})
DIR.add_new_minimal_tech("ir-heavy-picket", "heavy-picket", false, {"heavy-picket"}, {"ir-hydrogen-battery"})
DIR.add_new_minimal_tech("ir-inserters-1", "inserters-1", false, {"inserter","long-handed-inserter","slow-filter-inserter"}, {"automation","logistics"}) 
DIR.add_new_minimal_tech("ir-inserters-2", "inserters-2", false, {"fast-inserter","filter-inserter"}, {}) 
DIR.add_new_minimal_tech("ir-inserters-3", "inserters-3", false, {"stack-inserter","stack-filter-inserter"}, {}, {{type = "stack-inserter-capacity-bonus", modifier = 5}}) 
DIR.add_new_minimal_tech("ir-iron-forestry", "iron-forestry", false, DIR.append_list({"iron-forestry","forestry-wood-example","forestry-rubber-wood-example"}, tree_planters), {}) 
DIR.add_new_minimal_tech("ir-iron-motor", "iron-motor", false, {"iron-motor","iron-rotor"}, {"ir-steam-power"}) 
DIR.add_new_minimal_tech("ir-lampbot", "lampbot", false, {"lampbot-capsule"}, {}) 
DIR.add_new_minimal_tech("ir-monowheel", "monowheel", false, {"monowheel"}, {"logistics"})
DIR.add_new_minimal_tech("ir-rocket-turret", "rocket-turret", false, {"rocket-turret"}, {}) 
DIR.add_new_minimal_tech("ir-photon-turret", "photon-turret", false, {"photon-turret","chromium-frame-turret"}, {"military-3"}) 
DIR.add_new_minimal_tech("ir-radar", "radar", false, {"radar"}, {}) 
DIR.add_new_minimal_tech("ir-research-1", "electric-lab", false, {"lab"}, {"optics","ir-inserters-1"}) 
DIR.add_new_minimal_tech("ir-research-2", "quantum-lab", false, {"quantum-lab","quantum-ring"}, {"research-speed-6"}) 
DIR.add_new_minimal_tech("ir-robotower", "robotower", false, {"robotower","logistic-robot","logistic-chest-passive-provider","logistic-chest-storage"}, {"personal-roboport-equipment"}, logistics_effects) 
DIR.add_new_minimal_tech("ir-scattergun-turret", "scattergun-turret", false, {"scattergun-turret"}) 
DIR.add_new_minimal_tech("ir-scatterbot", "scatterbot", false, {"scatterbot-capsule"}, {"ir-steambot"}, 
	{{modifier = 4, type = "maximum-following-robots-count", icon = DIR.get_icon_path("count"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, use_icon_overlay_constant = false}}) 
DIR.add_new_minimal_tech("ir-solar-energy-1", "solar-panel", false, {"solar-panel"}, {"electric-energy-distribution-1"}) 
DIR.add_new_minimal_tech("ir-solar-energy-2", "solar-array", false, {"solar-array"}, {}) 
DIR.add_new_minimal_tech("ir-steambot", "steambot", false, {"steambot","copper-roboport-equipment"}, {"automation"}, {{type = "ghost-time-to-live", modifier = 36288000}}) 
DIR.add_new_minimal_tech("ir-petro-generator", "petro-generator", false, {"petro-generator"}, {"ir-crude-oil-processing"}) 
DIR.add_new_minimal_tech("ir-steel-wall", "steel-plate-wall", false, {"steel-plate-wall"}, {}) 
DIR.add_new_minimal_tech("ir-transmat", "chrome-transmat", false, {"chrome-transmat"}, {"ir-research-2"}) 
DIR.add_new_minimal_tech("laser", "ruby-laser-tech", false, {"ruby-laser","ruby-rod"}, {"automation-3"}) 
DIR.add_new_minimal_tech("laser-2", "helium-laser-tech", false, {"helium-laser"}, {"ir-cryogenics","automation-4"}) 
DIR.add_new_minimal_tech("automation-4", "laser-assembler", false, {"laser-assembler","electronic-circuit-laser","advanced-circuit-laser"}, {"ir-cryogenics"}) 
DIR.add_new_minimal_tech("ir-medical-pack", "medical-pack", false, {"medical-pack"}, {"ir-ethanol-1"}) 
DIR.add_new_minimal_tech("plastics-2", "plastics", true, {"plastic-bar-from-ethanol","rubber-from-ethanol"}, {"ir-ethanol-1","ir-washing-1"}) 

data.raw.technology["automation-4"].localised_description = {"technology-description.automation-4"}

local suffixes = {"","-2","-3"}
local modules = {"effectivity","productivity","speed"}
for i=1,3 do
	local unlocks = {}
	for _,mod in pairs(modules) do
		table.insert(unlocks, "program-"..mod.."-module"..suffixes[i])
		table.insert(unlocks, "deprogram-"..mod.."-module"..suffixes[i])
	end
	DIR.add_new_minimal_tech("ir-modules-"..i,"ir-module-"..i, false, unlocks, {"ir-electronics-"..i}) 
end

DIR.add_unlock_to_tech("ir-modules-1","module-loader")

local inserter_effects = {{type = "inserter-stack-size-bonus", modifier = 1}}
DIR.add_new_minimal_tech("ir-normal-inserter-capacity-bonus-1", "inserters-0", false, nil, {"logistics"}, inserter_effects)
DIR.add_new_minimal_tech("ir-normal-inserter-capacity-bonus-2", "inserters-1", false, nil, {"ir-inserters-1"}, inserter_effects)
data.raw.technology["ir-normal-inserter-capacity-bonus-1"].icon = nil
data.raw.technology["ir-normal-inserter-capacity-bonus-1"].icons = util.technology_icon_constant_capacity(DIR.get_icon_path("inserters-0",DIR.high_icon_size))
data.raw.technology["ir-normal-inserter-capacity-bonus-2"].icon = nil
data.raw.technology["ir-normal-inserter-capacity-bonus-2"].icons = util.technology_icon_constant_capacity(DIR.get_icon_path("inserters-1",DIR.high_icon_size))

------------------------------------------------------------------------------------------------------------------------------------------------------
