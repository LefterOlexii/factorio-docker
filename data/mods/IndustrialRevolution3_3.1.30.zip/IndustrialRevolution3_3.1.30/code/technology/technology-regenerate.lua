------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY WORK-OVER PART 2
-- now run in data-updates after technology.lua

-- AUTOMATED RECURSIVE PRE-REQUISITE ADJUSTMENT
-- In the Revolution, if a technology unlocks a recipe, then all the ingredients for all of those recipes *must* already have been unlocked
-- so either a recipe is enabled at game start, or it is chained from previous/concurrent research
-- method: scan every technology and create a list of all non-enabled ingredients used by its unlocked recipe results
-- then for every ingredient, find the tech that unlocks it, and add it to the prereqs
-- finally, remove all duplications and redundancies

-- As of IR 2.0.0, this generator only reorganises vanilla and native IR techs. Unknown techs from other mods are ignored.
-- This decreases the chances of cyclical technology trees due to assumptions about unlocking order, but it increases the chance of impossible unlocking orders
-- (i.e. game is more likely to load but less likely to be playable).
-- The only exception is that IR will still try to replace prerequisites in any technology if they refer to a vanilla tech that IR has disabled and there is a sensible substitute.
-- Mods can "opt in" any of their own native technologies for automatic chaining by flagging them with a key/value pair "IR_native = true".
-- Mods can also force vanilla recipes (or entire technologies) to be ignored by the regenerator by flagging them with a key/value pair "IR_tech_rebuild_ignore = true".
-- The ignore flag is recommended for "advanced" recipes/techs that open up additional routes to items/fluids that were already unlocked (e.g. cracking, uranium enrichment).
-- The tech tree generation is now run in IR's data-updates stage, so techs must be prototyped and have these flags before that.

-- As of IR 2.2.0, you can also add a property "IR_tech_rebuild_ignore_as_provider = true" to any recipe.
-- This ignores only that recipe unlock as a "provider" for chaining techs. The tech which unlocks it will still chain back to ancestors that provide *ingredients* for
-- the recipe, but the tech will not be treated as a provider for the result of the recipe.

-- As of IR 3.0.0, you can also set "IR_tech_rebuild_ignore_as_provider = true" within any result in a recipe.results table - only that result will be ignored, not the whole recipe.
-- Recipes that use a single result/result_count properties instead of a results table have to use the flag on the whole recipe (which has the same net effect).
-- Furthermore, any result in a results table that specifies any catalyst_amount is also ignored as a provider (the assumption is that some of this item also went in, so you can already make it).

------------------------------------------------------------------------------------------------------------------------------------------------------

-- add IR_tech_rebuild_ignore flags listed in globals

for _,tech in pairs(DIR.tech_rebuild_tech_ignore_list) do
	local tech = data.raw.technology[tech]
	if not tech then error("DIR.tech_rebuild_tech_ignore_list contains non-existent tech") end
	tech.IR_tech_rebuild_ignore = true
end

for _,recipe in pairs(data.raw.recipe) do
	for _,ignore in pairs(DIR.tech_rebuild_recipe_substring_ignore_list) do
		if string.find(recipe.name,ignore,1,true) then recipe.IR_tech_rebuild_ignore = true end
	end
end

-- populate look ups, recipes <> technologies
-- we don't care about expensive recipes (99% of them are nuked by IR anyway)

local tech_requires_items = {}
local tech_provides_items = {}
local item_provided_by_techs = {}

for _,tech in pairs(data.raw.technology) do
	if DIR.is_tech_rebuildable(tech) and tech.effects and not DIR.is_an_ignored_technology(tech.name) then
		tech_requires_items[tech.name] = {} 
		for _,effect in pairs(tech.effects) do
			if effect.type == "unlock-recipe" and not DIR.is_an_ignored_recipe(effect.recipe) then
				-- tech -> required items
				local recipe = data.raw.recipe[effect.recipe]
				if not recipe then error("Tech contains non-existent recipe unlock: "..tech.name..", "..effect.recipe) end
				local ingredients = recipe.normal and recipe.normal.ingredients or recipe.ingredients
				if ingredients then
					for _,ingredient in pairs(ingredients) do
						local name = ingredient.name
						if not name then name = ingredient[1] end
						if not DIR.tech_rebuild_ingredient_ignore_list[name] then
							tech_requires_items[tech.name][name] = true
						end
					end
				end
				-- provided item -> techs
				if not DIR.is_an_ignored_ingredient_provider(effect.recipe) then
					if string.find(effect.recipe,"iron%-ingot%-blast") then log(serpent.block(recipe)) end
					local recipe_root = recipe.normal or recipe
					if recipe_root.result then 
						if not tech_provides_items[tech.name] then tech_provides_items[tech.name] = {} end 
						table.insert(tech_provides_items[tech.name], recipe_root.result) 
						if not item_provided_by_techs[recipe_root.result] then item_provided_by_techs[recipe_root.result] = {} end 
						table.insert(item_provided_by_techs[recipe_root.result], tech.name) 
					elseif recipe_root.results then 
						for _,result in pairs(recipe_root.results) do
							if not result.IR_tech_rebuild_ignore_as_provider and not result.catalyst_amount then
								local name = result.name or result[1]
								if not tech_provides_items[tech.name] then tech_provides_items[tech.name] = {} end 
								table.insert(tech_provides_items[tech.name], name) 
								if not item_provided_by_techs[name] then item_provided_by_techs[name] = {} end 
								table.insert(item_provided_by_techs[name], tech.name) 
							end
						end
					end
				end
			end
		end
		tech_requires_items[tech.name] = DIR.keys_to_values(tech_requires_items[tech.name])
	end
end

-- for every ingredient needed, get the tech that provides it and add it as a pre-req
-- if multiple techs provide it, add them all - we already have to remove redundancies later anyway

for tech,ingredients in pairs(tech_requires_items) do
	local tech_prototype = data.raw.technology[tech]
	for _,ingredient in pairs(ingredients) do
		local providers = item_provided_by_techs[ingredient]
		if providers then 
			local prereqs_as_keys = DIR.values_to_keys(tech_prototype.prerequisites) or {}
			for _,provider in pairs(providers) do
				if provider ~= tech then 
					prereqs_as_keys[provider] = true
				end
			end	
			tech_prototype.prerequisites = DIR.keys_to_values(prereqs_as_keys)
		end
	end
end

-- then rescan the prereqs and remove redundancies

for _,tech in pairs(data.raw.technology) do
	if DIR.is_tech_rebuildable(tech) and tech.prerequisites then
		local ancestors = {}
		for _,prerequisite in pairs(tech.prerequisites) do
			if not data.raw.technology[prerequisite] then error("Error: tech "..tech.name.." has non-existent pre-requisite "..prerequisite) end
			if data.raw.technology[prerequisite].enabled ~= false then 
				ancestors = DIR.merge_keys(ancestors, DIR.get_ancestors_of_tech(prerequisite))
			end
		end
		local parents = DIR.values_to_keys(tech.prerequisites)
		for parent,_ in pairs(parents) do
			if ancestors[parent] then
				parents[parent] = nil
			end			
		end
		tech.prerequisites = DIR.keys_to_values(parents)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
