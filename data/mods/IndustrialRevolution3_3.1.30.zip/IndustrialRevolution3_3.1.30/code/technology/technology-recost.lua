------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY WORK-OVER PART 3
-- rework inheritances and costs based on tree depth
-- now run in data-updates after technology-regenerate.lua

------------------------------------------------------------------------------------------------------------------------------------------------------

-- SCIENCE PACK PREREQUISITES
-- work through the science packs - any tech with a science pack tech unlock as an ancestor must use that pack as an ingredient

-- 3.0.0: this stage was changed and simplified - a pack's unlocking tech is specified as part of their component definition, and then this prereq is recursively added to children
-- backbone techs no longer specify seed packs, and no more long duplicate lists of milestone seeds in globals, in the interests of fully automated luxury communism
-- only disadvantage to this change is that bonus upgrade type techs that don't unlock any recipes are often missed, so they have to be done separately
-- fortunately there are not many and IR only adds one which works out OK, the rest are vanilla and handled in technology-vanilla conceptual prereqs

-- recursively add to all children
-- this creates a lot of redundancies but they are stripped in the final stage

for material,tech_name in pairs(DIR.components.analysis.unlocking_techs) do
    -- no need to validate since we already did it in technology-packs
	local tech = data.raw.technology[tech_name]
	local pack = DIR.get_item_name(material,"analysis")
	DIR.recursive_add_pack_to_tech(pack, tech_name, false)
end

-- cost calculation
-- find all techs with no prereqs at all - that's depth 1

local depths = {}
for _,tech in pairs(data.raw.technology) do
	if DIR.is_tech_rebuildable(tech) and (tech.prerequisites == nil or #tech.prerequisites == 0) then
		depths[tech.name] = 1
	end
end

-- any techs that have a tech with depth 1 as a prereq are depth 2. rinse and repeat

for d=2,100 do
	local found = false
	for _,tech in pairs(data.raw.technology) do
		if tech.prerequisites ~= nil and DIR.is_tech_rebuildable(tech) then
			for _,prereq in pairs(tech.prerequisites) do
				if depths[prereq] == d-1 and (not depths[tech.name] or depths[tech.name] < d) then
					depths[tech.name] = d
					found = true
				end
			end
		end
	end
	if not found then break end
end

-- assign costs based on tree depth

local max_depth = #DIR.technology_costs
local max_cost = DIR.technology_costs[max_depth]
local beyond = DIR.technology_cost_beyond_max_depth
for tech,depth in pairs(depths) do
	local cost = (depth <= max_depth) and DIR.technology_costs[depth] or max_cost + ((depth - max_depth) * beyond)
	local cost = data.raw.technology[tech].IR_minimum_cost and math.max(data.raw.technology[tech].IR_minimum_cost, cost) or cost
	if data.raw.technology[tech].unit.count then data.raw.technology[tech].unit.count = cost end
	data.raw.technology[tech].order = string.format("%03d", depth)
	if data.raw.technology[tech].max_level == "infinite" then
		cost = math.ceil(cost/1000)*1000
		local level = string.match(tech, "%d+") or 1
		data.raw.technology[tech].unit.count = nil
		data.raw.technology[tech].unit.count_formula = "2^(L-" .. level .. ")*" .. cost
	end
	data.raw.technology[tech].unit.time = DIR.base_research_time
end

------------------------------------------------------------------------------------------------------------------------------------------------------
