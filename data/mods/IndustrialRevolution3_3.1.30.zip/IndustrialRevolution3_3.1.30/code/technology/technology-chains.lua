------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECH CHAINS

------------------------------------------------------------------------------------------------------------------------------------------------------

-- re-create any prereqs based on numbered chains 

for _,tech in pairs(data.raw.technology) do
	base,_ = string.gsub(tech.name, "-%d$", "")
	if DIR.is_tech_rebuildable(tech) then
		for i=10,2,-1 do
			if tech.name == (base.."-"..i) then 
				if i > 2 then
					if data.raw.technology[base.."-"..(i-1)] then DIR.add_prereq_to_tech(tech.name, base.."-"..(i-1)) end
				else
					if data.raw.technology[base.."-1"] then DIR.add_prereq_to_tech(tech.name, base.."-1")
					elseif data.raw.technology[base] then DIR.add_prereq_to_tech(tech.name, base) end
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- add space pack to all infinite researches

for _,tech in pairs(data.raw.technology) do
	if DIR.is_tech_rebuildable(tech) then
		if tech.max_level == "infinite" then
			DIR.add_pack_to_tech("space-science-pack", tech.name)
			DIR.add_prereq_to_tech(tech.name, "space-science-pack") -- 3.0.0 - this has to be done manually for space science now because no "recipe"
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
