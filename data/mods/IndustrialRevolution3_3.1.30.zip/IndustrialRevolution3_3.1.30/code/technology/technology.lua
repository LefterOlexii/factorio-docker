------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY WORK-OVER
-- as of IR 2.0.0 this is all done in the data-updates stage

-- stages: disable redundant vanilla techs, destroy the entire tech tree graph, add new techs, add conceptual prerequisites, calculate science pack prereqs

-- technology-regenerate.lua then fixes all of this mayhem (probably)
-- see comments there if you're wondering why IR moved your sofa or you want IR to treat your mod's techs as native (i.e. build their dependencies automatically)

------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.spam_log("Starting tech rebuild", DIR.log_level.milestone)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- CHANGES & IR-NATIVE TECH

-- adjust vanilla techs
require("code.technology.technology-vanilla")

-- IR-specific non-backbone techs
require("code.technology.technology-native")

-- rework weapon and other infinite upgrades
require("code.technology.technology-upgrades")

-- backbone techs (major milestone IR techs that structure everything else)
require("code.technology.technology-backbone")

-- tech chains (science pack research dependencies, numbered chain dependencies)
require("code.technology.technology-chains")

-- set up third party mods which need to have ingredients adjusted before the tree rebuild
require("code.mods.mods-data-updates-pretech")

-- misc cosmetics pre-rebuild
require("code.technology.technology-misc-pretech")

-- add analysis pack unlocks - should be the last thing run pre-rebuild
require("code.technology.technology-packs")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECH TREE REBUILD

require("code.technology.technology-regenerate")
require("code.technology.technology-recost")
require("code.technology.technology-special-projects")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- POST-TECH MODS
-- third party mods which need adjustment only after the tree rebuild

require("code.mods.mods-data-updates-posttech")

------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.spam_log("Tech rebuild complete", DIR.log_level.milestone)

------------------------------------------------------------------------------------------------------------------------------------------------------