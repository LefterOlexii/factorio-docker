------------------------------------------------------------------------------------------------------------------------------------------------------

-- CHANGES TO / REPLACEMENTS FOR VANILLA TECHNOLOGY

-- dump vanilla tech list?

if DIR.dump_vanilla_techs then
	local list = {}
	local techdump = ""
	for _,tech in pairs(data.raw.technology) do
		if not tech.enabled or tech.enabled ~= false then list[DIR.strip_numeric_suffix(tech.name)] = true end
	end
	local array = {}
	for techname,_ in pairs (list) do
		table.insert(array,techname)
	end
	table.sort(array)
	for _,techname in pairs(array) do
		local effects = "{"
		local tech = data.raw.technology[techname]
		if tech and tech.effects and table_size(tech.effects) > 0 then
			local first = true
			for _,effect in pairs(tech.effects) do
				if effect.type == "unlock-recipe" then
					if not first then effects = effects .. ", " end
					effects = effects .. "\"" .. effect.recipe .. "\""
					first = false
				end
			end
		end
		effects = effects .. "}"
		techdump = techdump .. "    [\"" .. techname .. "\"] = " .. effects .. ",\n"
	end
	log("\n\n\nreturn {\n"..techdump.."}\n\n\n")	
end

-- completely wipe all vanilla prereqs and all science pack costs. harsh but fair

for _,tech in pairs(data.raw.technology) do
	if DIR.is_tech_rebuildable(tech) then
		tech.prerequisites = tech.IR_native and tech.prerequisites or nil
		tech.unit.ingredients = {{name = "automation-science-pack", type = "item", amount = 1}}
		tech.unit.time = 60
		tech.unit.count = 1
		tech.unit.count_formula = nil
	end
end

-- disable fluff or weirdly-named stuff
-- see technology-prereq-convert.lua for how things are actually substituted in data-final-fixes

DIR.disable_technology("advanced-electronics") --> ir-electronics-2
DIR.disable_technology("advanced-electronics-2") --> ir-electronics-3
DIR.disable_technology("advanced-material-processing") --> no material equivalent, functionally this would be ir-bronze-furnace
DIR.disable_technology("advanced-material-processing-2") --> no material equivalent, functionally this would be ir-electric-furnace
DIR.disable_technology("advanced-oil-processing") --> somewhere in the oil processing chain
DIR.disable_technology("cliff-explosives") --> explosives
DIR.disable_technology("concrete") --> ir-concrete-1
DIR.disable_technology("construction-robotics") --> personal-roboport-equipment
DIR.disable_technology("effectivity-module") --> ir-modules-1
DIR.disable_technology("effectivity-module-2") --> ir-modules-2
DIR.disable_technology("effectivity-module-3") --> ir-modules-3
DIR.disable_technology("electronics") --> ir-electronics-1
DIR.disable_technology("fast-inserter") --> ir-inserters-2
DIR.disable_technology("flammables") --> no equivalent, unlocks nothing, shouldn't exist
DIR.disable_technology("inserter-capacity-bonus-4") --> no equivalent really; in IR, non-stack inserter bonuses are from ir-normal-inserter-capacity-bonus-1/2; see also stack-inserter
DIR.disable_technology("inserter-capacity-bonus-5") --> inserter-capacity-bonus-1
DIR.disable_technology("inserter-capacity-bonus-6") --> inserter-capacity-bonus-2
DIR.disable_technology("inserter-capacity-bonus-7") --> inserter-capacity-bonus-3
DIR.disable_technology("logistic-robotics") --> robotics
DIR.disable_technology("modules") --> no equivalent, i guess ir-modules-1
DIR.disable_technology("oil-processing") --> ir-crude-oil-processing (3.0.0)
DIR.disable_technology("productivity-module") --> ir-modules-1
DIR.disable_technology("productivity-module-2") --> ir-modules-2
DIR.disable_technology("productivity-module-3") --> ir-modules-3
DIR.disable_technology("rail-signals") --> automated-rail-transportation
DIR.disable_technology("rocket-control-unit") --> rocket-silo
DIR.disable_technology("solar-energy") --> ir-solar-energy-1
DIR.disable_technology("speed-module") --> ir-modules-1
DIR.disable_technology("speed-module-2") --> ir-modules-2
DIR.disable_technology("speed-module-3") --> ir-modules-3
DIR.disable_technology("stack-inserter") --> ir-inserters-3; also adds bonus to stack inserters covered in vanilla by inserter-capacity-bonus-1/2/3/4
DIR.disable_technology("steel-axe") --> no equivalent
DIR.disable_technology("steel-processing") --> ir-steel-milestone
DIR.disable_technology("toolbelt") --> no equivalent, inventory bonuses are purely armour-based in IR
DIR.disable_technology("uranium-ammo") --> military-4
-- following added 3.0.0
DIR.disable_technology("logistic-science-pack") --> ir-bronze-milestone
DIR.disable_technology("chemical-science-pack") --> ir-iron-milestone
DIR.disable_technology("production-science-pack") --> ir-steel-milestone
DIR.disable_technology("utility-science-pack") --> ir-electroplating
DIR.disable_technology("military-science-pack") --> military

-- fiddle with / replace / stretch out / merge vanilla techs
-- no need to specify chains as prereqs, (mostly) no need to specify prereqs that provide ingredients - conceptual prereqs only

DIR.add_new_minimal_tech("automated-rail-transportation", "automated-rail-transportation", true, {"train-stop","rail-signal","rail-chain-signal"}, {"railway"}) 
DIR.add_new_minimal_tech("battery", "iron-battery-charger", false, {"battery","charged-battery","iron-battery-charger","iron-battery-discharger","battery-discharge-equipment"}, {}) 
DIR.add_new_minimal_tech("defender","defender",true, {"defender-capsule"}, {}) -- removes follower count bonus
DIR.add_new_minimal_tech("electric-energy-distribution-1","electric-energy-distribution-1",true, {"medium-electric-pole","big-electric-pole"}, {})
DIR.add_new_minimal_tech("electric-energy-distribution-2","electric-energy-distribution-2",true, {"substation"}, {})
DIR.add_new_minimal_tech("electric-engine", "electric-engine-unit", false, {"electric-engine-unit","flying-robot-frame","gyroscope"}, {})
DIR.add_new_minimal_tech("explosives", "explosives", true, {"explosives","cliff-explosives","waterfill-explosive"}, {}) 
DIR.add_new_minimal_tech("gun-turret", "autogun-turret", false, {"gun-turret"}, {"military"}) 
DIR.add_new_minimal_tech("laser-turret", "laser-turret", false, {"laser-turret","steel-frame-turret"}, {"military-2"}) 
DIR.add_new_minimal_tech("military", "military", true, {"submachine-gun","firearm-magazine","iron-cartridge"}, nil) 
DIR.add_new_minimal_tech("military-2", "military", true, {"piercing-rounds-magazine","piercing-shotgun-shell","grenade"}, {"explosives"}) 
DIR.add_new_minimal_tech("military-3", "military", true, {"combat-shotgun","chromium-magazine","slowdown-capsule","poison-capsule"}, {}) 
DIR.add_new_minimal_tech("military-4", "military", true, {"uranium-rounds-magazine","uranium-cannon-shell","explosive-uranium-cannon-shell","cluster-grenade"}, {}) 
DIR.add_new_minimal_tech("personal-roboport-equipment", "personal-roboport-equipment", true, {"construction-robot","personal-roboport-equipment"}, {"modular-armor"}, {{type = "ghost-time-to-live", modifier = 36288000}})
DIR.add_new_minimal_tech("plastics", "plastics", true, {"plastic-bar"}, {}) 
DIR.add_new_minimal_tech("robotics", "roboport", false, {"roboport"}, {"ir-robotower"})
DIR.add_new_minimal_tech("sulfur-processing", "sulfuric-acid", false, {"sulfur","sulfuric-acid"}, {"ir-heavy-oil-processing"}) 
DIR.add_new_minimal_tech("lubricant", "lubricant", false, {"lubricant"}, {"ir-crude-oil-processing"}) 
DIR.add_new_minimal_tech("low-density-structure", "foam-components", false, {"low-density-structure"}, {"ir-cryogenics","ir-washing-1"})

DIR.add_unlock_to_tech("atomic-bomb","atomic-artillery-shell")
DIR.add_unlock_to_tech("automation","small-assembler-1")
DIR.add_unlock_to_tech("automation","steam-barrelling-machine")
DIR.add_unlock_to_tech("automation","empty-cell")
DIR.add_unlock_to_tech("automation","fill-steam-cell")
DIR.add_unlock_to_tech("automation","empty-steam-cell")
DIR.add_unlock_to_tech("automation-2","iron-scrapper")
DIR.add_unlock_to_tech("automation-2","small-assembler-2")
DIR.add_unlock_to_tech("automation-3","small-assembler-3")
DIR.add_unlock_to_tech("fluid-handling", "small-tank")
DIR.add_unlock_to_tech("fluid-handling", "barrelling-machine")
DIR.add_unlock_to_tech("fluid-handling", "empty-iron-canister")
DIR.add_unlock_to_tech("fluid-handling", "fill-steam-iron-canister")
DIR.add_unlock_to_tech("fluid-handling", "empty-steam-iron-canister")
DIR.add_unlock_to_tech("logistics", "transfer-plate")
DIR.add_unlock_to_tech("logistics", "transfer-plate-2x2")
DIR.add_unlock_to_tech("modular-armor", "iron-burner-generator-equipment")
DIR.add_unlock_to_tech("rocket-fuel","high-octane-fluid",1)
DIR.add_unlock_to_tech("rocket-fuel","empty-rocket-fuel")
DIR.add_unlock_to_tech("rocket-silo", "rocket-control-unit")
DIR.add_unlock_to_tech("rocket-silo", "steel-hull")
DIR.add_unlock_to_tech("space-science-pack", "solar-assembly")
DIR.add_unlock_to_tech("space-science-pack", "space-mirror")
DIR.add_unlock_to_tech("uranium-processing","lead-plate-special")
DIR.remove_unlock_from_tech("atomic-bomb", "atomic-bomb")
DIR.remove_unlock_from_tech("automation", "long-handed-inserter")
DIR.remove_unlock_from_tech("kovarex-enrichment-process", "nuclear-fuel")
DIR.replace_tech_icon("automation","assembler1")
DIR.replace_tech_icon("automation-2","assembler2")
DIR.replace_tech_icon("automation-3","assembler3")
DIR.replace_tech_icon("rocket-fuel","rocket-fuel")
DIR.replace_tech_icon("space-science-pack","satellite")
DIR.replace_tech_icon("coal-liquefaction","coal-liquefaction")
DIR.replace_tech_icon("engine","iron-engine-tech")

DIR.remove_all_barrels_from_tech("fluid-handling") -- handled in fluid-update

------------------------------------------------------------------------------------------------------------------------------------------------------

-- add conceptual prerequisites

DIR.add_prereq_to_tech("artillery", "military-4")
DIR.add_prereq_to_tech("artillery-shell-range-1", "artillery")
DIR.add_prereq_to_tech("artillery-shell-speed-1", "artillery")
DIR.add_prereq_to_tech("atomic-bomb", "nuclear-power")
DIR.add_prereq_to_tech("automated-rail-transportation", "railway")
DIR.add_prereq_to_tech("automobilism", "military")
DIR.add_prereq_to_tech("battery-equipment", "modular-armor")
DIR.add_prereq_to_tech("battery-mk2-equipment", "battery-equipment")
DIR.add_prereq_to_tech("battery-mk2-equipment", "power-armor-mk2")
DIR.add_prereq_to_tech("belt-immunity-equipment", "modular-armor")
DIR.add_prereq_to_tech("braking-force-1", "railway")
DIR.add_prereq_to_tech("braking-force-3", DIR.components.analysis.unlocking_techs.steel)
DIR.add_prereq_to_tech("coal-liquefaction", "ir-natural-gas-processing")
DIR.add_prereq_to_tech("defender", "military")
DIR.add_prereq_to_tech("destroyer", "ir-arc-turret")
DIR.add_prereq_to_tech("destroyer", "military-4")
DIR.add_prereq_to_tech("discharge-defense-equipment", "ir-arc-turret")
DIR.add_prereq_to_tech("discharge-defense-equipment", "power-armor")
DIR.add_prereq_to_tech("distractor", "military-2")
DIR.add_prereq_to_tech("effect-transmission", "ir-modules-3")
DIR.add_prereq_to_tech("energy-shield-equipment", "power-armor")
DIR.add_prereq_to_tech("energy-shield-mk2-equipment", "energy-shield-equipment")
DIR.add_prereq_to_tech("energy-shield-mk2-equipment", "power-armor-mk2")
DIR.add_prereq_to_tech("energy-weapons-damage-1", "laser-turret")
DIR.add_prereq_to_tech("energy-weapons-damage-4", "military-4")
DIR.add_prereq_to_tech("exoskeleton-equipment", "power-armor")
DIR.add_prereq_to_tech("flamethrower", "military-2")
DIR.add_prereq_to_tech("fluid-handling", "ir-steam-power")
DIR.add_prereq_to_tech("fluid-wagon", "fluid-handling")
DIR.add_prereq_to_tech("fluid-wagon", "railway")
DIR.add_prereq_to_tech("follower-robot-count-1", "defender")
DIR.add_prereq_to_tech("follower-robot-count-4", "distractor")
DIR.add_prereq_to_tech("follower-robot-count-7", "destroyer")
DIR.add_prereq_to_tech("fusion-reactor-equipment", "nuclear-power")
DIR.add_prereq_to_tech("fusion-reactor-equipment", "power-armor-mk2")
DIR.add_prereq_to_tech("inserter-capacity-bonus-1", "ir-inserters-3")
DIR.add_prereq_to_tech("kovarex-enrichment-process", "uranium-processing")
DIR.add_prereq_to_tech("landfill", "ir-grinding-2")
DIR.add_prereq_to_tech("land-mine", "military-2")
DIR.add_prereq_to_tech("laser-shooting-speed-1", "laser-turret")
DIR.add_prereq_to_tech("laser-shooting-speed-4", "military-4")
DIR.add_prereq_to_tech("logistic-system", "robotics")
DIR.add_prereq_to_tech("military-science-pack", "ir-research-1")
DIR.add_prereq_to_tech("military-science-pack", "military")
DIR.add_prereq_to_tech("mining-productivity-1", "ir-mining-2")
DIR.add_prereq_to_tech("night-vision-equipment", "modular-armor")
DIR.add_prereq_to_tech("night-vision-equipment", "optics")
DIR.add_prereq_to_tech("nuclear-fuel-reprocessing", "nuclear-power")
DIR.add_prereq_to_tech("nuclear-power", "uranium-processing")
DIR.add_prereq_to_tech("personal-laser-defense-equipment", "laser-turret")
DIR.add_prereq_to_tech("personal-laser-defense-equipment", "military-4")
DIR.add_prereq_to_tech("personal-laser-defense-equipment", "power-armor-mk2")
DIR.add_prereq_to_tech("personal-roboport-equipment", "modular-armor")
DIR.add_prereq_to_tech("personal-roboport-mk2-equipment", "personal-roboport-equipment")
DIR.add_prereq_to_tech("personal-roboport-mk2-equipment", "power-armor-mk2")
DIR.add_prereq_to_tech("physical-projectile-damage-2", "military")
DIR.add_prereq_to_tech("physical-projectile-damage-3", "military-2")
DIR.add_prereq_to_tech("physical-projectile-damage-4", "military-3")
DIR.add_prereq_to_tech("physical-projectile-damage-5", "military-4")
DIR.add_prereq_to_tech("power-armor", "modular-armor")
DIR.add_prereq_to_tech("power-armor-mk2", "power-armor")
DIR.add_prereq_to_tech("rail-signals", "railway")
DIR.add_prereq_to_tech("refined-flammables-1", "flamethrower")
DIR.add_prereq_to_tech("refined-flammables-3", "military-3")
DIR.add_prereq_to_tech("refined-flammables-5", "military-4")
DIR.add_prereq_to_tech("research-speed-1", "ir-research-1")
DIR.add_prereq_to_tech("research-speed-5", DIR.components.analysis.unlocking_techs.steel)
DIR.add_prereq_to_tech("research-speed-6", DIR.components.analysis.unlocking_techs.chromium)
DIR.add_prereq_to_tech("rocket-fuel", "ir-high-pressure-canisters")
DIR.add_prereq_to_tech("rocket-silo", "ir-high-pressure-canisters")
DIR.add_prereq_to_tech("rocketry", "military-2")
DIR.add_prereq_to_tech("solar-panel-equipment", "modular-armor")
DIR.add_prereq_to_tech("space-science-pack", "rocket-silo")
DIR.add_prereq_to_tech("space-science-pack", "ir-research-2")
DIR.add_prereq_to_tech("stronger-explosives-1", "explosives")
DIR.add_prereq_to_tech("stronger-explosives-1", "military-2")
DIR.add_prereq_to_tech("stronger-explosives-2", "land-mine")
DIR.add_prereq_to_tech("stronger-explosives-3", "rocketry")
DIR.add_prereq_to_tech("stronger-explosives-3", "tank")
DIR.add_prereq_to_tech("tank", "automobilism")
DIR.add_prereq_to_tech("tank", "military-3")
DIR.add_prereq_to_tech("weapon-shooting-speed-2", "military")
DIR.add_prereq_to_tech("weapon-shooting-speed-3", "military-2")
DIR.add_prereq_to_tech("weapon-shooting-speed-3", "rocketry")
DIR.add_prereq_to_tech("weapon-shooting-speed-4", "military-3")
DIR.add_prereq_to_tech("weapon-shooting-speed-5", "military-4")
DIR.add_prereq_to_tech("worker-robots-speed-1", "ir-robotower")
DIR.add_prereq_to_tech("worker-robots-speed-5", DIR.components.analysis.unlocking_techs.chromium)
DIR.add_prereq_to_tech("worker-robots-storage-1", "robotics")
DIR.add_prereq_to_tech("worker-robots-storage-2", DIR.components.analysis.unlocking_techs.chromium)

------------------------------------------------------------------------------------------------------------------------------------------------------
