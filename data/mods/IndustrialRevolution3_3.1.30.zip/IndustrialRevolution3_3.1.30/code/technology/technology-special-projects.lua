------------------------------------------------------------------------------------------------------------------------------------------------------

-- Special research packs added after everything else in the tree has been changed; these packs deliberately do not chain and are manually specified

for pack,packdata in pairs(DIR.components["special-analysis"].project_info) do
	if not packdata.unlocked_by then error("Special analysis pack "..pack.." doesn't specify unlocked_by") end
	if not DIR.get_tech_unlocks_recipe(packdata.unlocked_by, DIR.get_item_name(pack,"special-analysis")) then
		local unlocker = data.raw.technology[packdata.unlocked_by]
		if not unlocker then error("Special project pack "..pack.." specifies unlocking tech that doesn't exist") end
		if not packdata.used_by or type(packdata.used_by) ~= "table" then error("Special project pack "..pack.." has bad used by list") end
		table.insert(unlocker.effects, {
			type = "unlock-recipe",
			recipe = DIR.get_item_name(pack,"special-analysis")
		})
		if not unlocker.icons then DIR.add_tech_icon_overlay(packdata.unlocked_by, DIR.get_icon_path("analysis-pack-unlock")) end
		local cost = 0
		for _,tech_name in pairs(packdata.used_by) do
			local tech = data.raw.technology[tech_name]
			if not tech then error("Special project pack "..pack.." specifies project tech that doesn't exist") end
			if not DIR.get_tech_has_pack(tech,DIR.get_item_name(pack,"special-analysis")) then
				if packdata.time_factor then tech.unit.time = tech.unit.time * packdata.time_factor end
				if packdata.cost_override then tech.unit.count = packdata.cost_override end
				if packdata.do_not_identify ~= true then
					if not tech.unit.count then error("Special project pack "..pack.." used with technology that has no unit count, either bad tech or infinite") end
					cost = cost + tech.unit.count
					local level = DIR.pull_numbers_from_string(tech.name)
					if level ~= "" then level = " "..level end
					tech.localised_name = {"technology-name.ir-special-project", tech.localised_name or {"technology-name."..DIR.strip_numeric_suffix(tech.name)}, level}
					tech.unit.ingredients = {{DIR.get_item_name(pack,"special-analysis"), 1}}
				else
					table.insert(tech.unit.ingredients, {DIR.get_item_name(pack,"special-analysis"), 1})
				end
			end
		end
		-- tag the pack's description
		if packdata.do_not_identify ~= true then
			data.raw.tool[DIR.get_item_name(pack,"special-analysis")].localised_description = {"item-description.special-project", cost}
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
