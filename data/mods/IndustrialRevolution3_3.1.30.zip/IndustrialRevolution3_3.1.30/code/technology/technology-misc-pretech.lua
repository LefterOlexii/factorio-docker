------------------------------------------------------------------------------------------------------------------------------------------------------

-- misc updates to techs pre-rebuild

------------------------------------------------------------------------------------------------------------------------------------------------------

-- equipment icon overlays

for _,name in pairs({"ir-steambot","ir-arc-turret-equipment","personal-roboport-equipment","battery","modular-armor"}) do
	local tech = data.raw.technology[name]
	if tech.icon and not tech.icons then
		tech.icons = util.technology_icon_constant_equipment(tech.icon)
		tech.icon = nil
	end
end

-- techs with masked icons

local machinetechs = {
	["gun-turret"] = "gun-turret",
	["laser-turret"] = "laser-turret",
	["ir-scattergun-turret"] = "scattergun-turret",
	["ir-arc-turret"] = "arc-turret",
	["ir-photon-turret"] = "photon-turret",
	["ir-rocket-turret"] = "rocket-turret",
}

for tech,machine in pairs(machinetechs) do
	local tech = data.raw.technology[tech]
	if tech then DIR.add_machine_mask_to_tech(tech, machine) end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
