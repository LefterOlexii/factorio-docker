------------------------------------------------------------------------------------------------------------------------------------------------------

-- IR3 floor coverings

local free_layer = 58

local function get_next_layer()
    free_layer = free_layer + 2
    return free_layer
end

local function get_current_layer()
    return free_layer
end

local sounds = {
    concrete = {
        {
            filename = "__base__/sound/walking/concrete-01.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-02.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-03.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-04.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-05.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-06.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-07.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-08.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-09.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-10.ogg",
            volume = 0.5
        },
        {
            filename = "__base__/sound/walking/concrete-11.ogg",
            volume = 0.5
        }
    },
    gravel = {
        {
            filename = DIR.sound_path .. "/gravel-footstep-1.ogg",
            volume = 0.5
        },
        {
            filename = DIR.sound_path .. "/gravel-footstep-2.ogg",
            volume = 0.5
        },
        {
            filename = DIR.sound_path .. "/gravel-footstep-3.ogg",
            volume = 0.5
        },
        {
            filename = DIR.sound_path .. "/gravel-footstep-4.ogg",
            volume = 0.5
        },
        {
            filename = DIR.sound_path .. "/gravel-footstep-5.ogg",
            volume = 0.5
        }
    }
}

-- make 'em

-- local function deep_picture_replace(prop, from, to)
	-- for k,v in pairs(prop) do
		-- if type(v) == "table" then deep_picture_replace(v, from, to)
		-- elseif k == "picture" then
			-- prop[k] = DIR.escaped_gsub(v, from, to)
		-- end
	-- end
-- end

for _, component in pairs({"covering"}) do
    if DIR.components[component].tile_walking_speed then
        for material, speed in pairs(DIR.components[component].tile_walking_speed) do
			local tile = {
				name = DIR.get_item_name(material,component),
				type = "tile",
				collision_mask = {"ground-tile"},
				decorative_removal_probability = 1,
				layer = get_next_layer(),
				map_color = DIR.hsva2rgba(DIR.materials[material].hue, DIR.get_saturation(DIR.materials[material].hue,0.25), DIR.materials[material].value),
				minable = {
					mining_time = DIR.standard_pickup_time,
					result = DIR.get_item_name(material,component),
				},
				build_sound = data.raw.tile.concrete.build_sound,
				mined_sound = data.raw.tile.concrete.mined_sound,
				needs_correction = false,
				pollution_absorption_per_second = 0,
				transition_overlay_layer_offset = 1,
				variants = {
					main = {
						{
							count = 1,
							picture = "__base__/graphics/terrain/concrete/concrete-dummy.png",
							size = 1,
							scale = 0.5,
						},
					},
					material_background = {
						count = 1,
						picture = DIR.entities_path_2 .. "/tiles/" .. DIR.get_item_name(material,component) .. ".png",
						scale = 0.5
					},
				},
				walking_sound = (material == "gravel") and sounds.gravel or sounds.concrete,
				walking_speed_modifier = speed,
				vehicle_friction_modifier = DIR.components[component].vehicle_speed and DIR.components[component].vehicle_speed[material],
			}
			if DIR.components[component].tile_sprites and DIR.components[component].tile_sprites[material] then
				tile.variants.side = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_sprites[material].."-side.png"
				}
				tile.variants.inner_corner = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_sprites[material].."-inner-corner.png"
				}
				tile.variants.outer_corner = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_sprites[material].."-outer-corner.png"
				}
				tile.variants.o_transition = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_sprites[material].."-o-transition.png"
				}
				tile.variants.u_transition = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_sprites[material].."-u-transition.png"
				}
			end
			if DIR.components[component].tile_masks and DIR.components[component].tile_masks[material] then
				tile.variants.side_mask = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_masks[material].."-side.png"
				}
				tile.variants.inner_corner_mask = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_masks[material].."-inner-corner.png"
				}
				tile.variants.outer_corner_mask = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_masks[material].."-outer-corner.png"
				}
				tile.variants.o_transition_mask = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_masks[material].."-o-transition.png"
				}
				tile.variants.u_transition_mask = {
					count = 1,
					scale = 0.5,
					picture = DIR.entities_path_2 .. "/tiles/"..DIR.components[component].tile_masks[material].."-u-transition.png"
				}
			end
			if DIR.components[component].transition_source and DIR.components[component].transition_source[material] then
				local original = data.raw.tile[DIR.components[component].transition_source[material]]
				if not original then error("No such transition source tile as "..DIR.components[component].transition_source[material]) end
				tile.transitions = table.deepcopy(original.transitions)
				tile.transitions_between_transitions = table.deepcopy(original.transitions_between_transitions)
			end
			data:extend({tile})
        end
    end
end

-- tweak existing tile properties and layers

if mods["Dectorio"] and DECT.ENABLED["gravel"] then
    for _, variant in pairs(DECT.CONFIG.GRAVEL_VARIANTS) do
        data.raw.tile["dect-" .. variant.name .. "-gravel"].layer = get_next_layer()
    end
end

data.raw.tile["stone-path"].layer = get_next_layer()

data.raw.tile["concrete"].layer = get_next_layer()
data.raw.tile["hazard-concrete-left"].layer = get_current_layer()
data.raw.tile["hazard-concrete-right"].layer = get_current_layer()

if mods["Dectorio"] and DECT.ENABLED["concrete"] then
    data.raw.tile["dect-concrete-grid"].layer = get_current_layer()
end

local directions = {"left", "right"}

if mods["Dectorio"] and DECT.ENABLED["painted-concrete"] then
    local layer = get_next_layer()
    for _, variant in pairs(DECT.CONFIG.PAINT_VARIANTS) do
        for _, direction in pairs(directions) do
            data.raw.tile["dect-paint-" .. variant.name .. "-" .. direction].layer = layer
        end
    end
end

data.raw.tile["refined-concrete"].layer = get_next_layer()
data.raw.tile["refined-hazard-concrete-left"].layer = get_current_layer()
data.raw.tile["refined-hazard-concrete-right"].layer = get_current_layer()

if mods["Dectorio"] and DECT.ENABLED["painted-concrete"] then
    local layer = get_next_layer()
    for _, variant in pairs(DECT.CONFIG.PAINT_VARIANTS) do
        for _, direction in pairs(directions) do
            data.raw.tile["dect-paint-refined-" .. variant.name .. "-" .. direction].layer = layer
        end
    end
end

if mods["Dectorio"] and DECT.ENABLED["wood-floor"] then
    data.raw.tile["dect-wood-floor"].layer = get_next_layer()
end

-- fix the damn decoratives

local tiles = {
    "stone-path",
    "concrete",
    "hazard-concrete-left",
    "hazard-concrete-right",
    "refined-concrete",
    "refined-hazard-concrete-left",
    "refined-hazard-concrete-right"
}

for _, tile in pairs(tiles) do
    local this_tile = data.raw.tile[tile]
    if this_tile then
        this_tile.decorative_removal_probability = 1
    end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
