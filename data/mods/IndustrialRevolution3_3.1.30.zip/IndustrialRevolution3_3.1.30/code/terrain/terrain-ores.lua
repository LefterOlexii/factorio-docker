------------------------------------------------------------------------------------------------------------------------------------------------------

-- TERRAIN - ores

------------------------------------------------------------------------------------------------------------------------------------------------------

-- mining particles

local particles = {
	["coal"] = 0,
	["copper-ore"] = 1,
	["gold-ore"] = 2,
	["iron-ore"] = 3,
	["stone"] = 4,
	["tin-ore"] = 5,
	["uranium-ore"] = 6,
}

for particle,y in pairs(particles) do
    data:extend({
        DIR.create_IR_particle(particle.."-mining-particle", 1, y*32, "mining-particles", 5),
    })
end

-- ore resources

local orefields =  require("code.data.orefields")
local resource_autoplace = require("code.terrain.resource-autoplace")

local function twelve_stage_counts()
	local stage_counts = {}
	for i=12,1,-1 do
		table.insert(stage_counts, math.ceil((50.7298 * math.exp(0.4555*i))/10)*10) -- starts low, tops out at 15000
	end
	return stage_counts
end

local function resource(name, oredata)
	local graphic = oredata.icon_and_sheet_name or name
	local results = {}
	if not oredata.no_main_result then 
		table.insert(results, { name = name, type = "item", amount = 1, probability = oredata.main_result and 0.5 or 1})
	end
	local icons = oredata.use_vanilla_assets and {
		{ icon = DIR.base_icons_path.."/"..graphic..".png", DIR.get_icon_path(name), icon_size = 64, icon_mipmaps = 4 },
	} or {
		{ icon = DIR.get_icon_path(graphic), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
	}
	if oredata.bonus_results then
		for result,prob in pairs(oredata.bonus_results) do
			table.insert(results, { name = result, type = "item", amount = 1, probability = prob })
			table.insert(icons, { icon = DIR.get_icon_path(result), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps })
		end
	end
	local mining_particle = data.raw["optimized-particle"][name.."-mining-particle"] and name.."-mining-particle" or "stone-mining-particle"
    return {
        type = "resource",
        name = name,
		localised_name = {"item-name."..name},
        icons = icons,
        flags = {"placeable-neutral"},
        order = "b",
        minable = {
            mining_time = oredata.mining_time or 1,
			mining_particle = mining_particle,
            results = results,
			required_fluid = oredata.required_fluid,
			fluid_amount = oredata.fluid_amount,
        },
        collision_box = {{ -0.1, -0.1}, {0.1, 0.1}},
        selection_box = {{ -0.5, -0.5}, {0.5, 0.5}},
        autoplace = (oredata.control or oredata.start) and resource_autoplace.resource_autoplace_settings {
			name = name,
			order = "b",
			base_density = oredata.base_density,
			has_starting_area_placement = oredata.start,
			regular_rq_factor_multiplier = oredata.ban_outside_start and -1 or oredata.frequency,
			starting_rq_factor_multiplier = oredata.frequency,
			autoplace_control_name = oredata.control and name or "generic",
			base_spots_per_km2 = oredata.base_spots_per_km2,
			random_spot_size_minimum = oredata.random_spot_size_minimum,
			random_spot_size_maximum = oredata.random_spot_size_maximum,
			non_starter_fade_in = oredata.non_starter_fade_in,
			starter_radius = oredata.starter_radius,
		} or nil,
		stage_counts = (oredata.use_vanilla_assets and data.raw.resource[name].stage_counts) or twelve_stage_counts(),
		stages = oredata.use_vanilla_assets and data.raw.resource[name].stages or {
			sheet = {
				filename = DIR.resource_path .. "/" .. graphic .. ".png",
				priority = "extra-high",
				width = 128,
				height = 128,
				frame_count = oredata.sheet_variants or 8,
				variation_count = oredata.sheet_stages or 12,
				scale = 0.5
			},
		},
		effect_animation_period = oredata.light_layer and (oredata.autoplace and 6 or 4) or nil,
		effect_animation_period_deviation = oredata.light_layer and (oredata.autoplace and 1 or 0.5) or nil,
		effect_darkness_multiplier = oredata.light_layer and 1 or nil,
		stages_effect = oredata.light_layer and (oredata.use_vanilla_assets and data.raw.resource[name].stages_effect or {
			sheet = {
				filename = DIR.resource_path .. "/" .. graphic .. "-light.png",
				draw_as_light = true,
				blend_mode = "additive-soft",
				priority = "extra-high",
				width = 128,
				height = 128,
				frame_count = (oredata.use_vanilla_assets and 8) or oredata.sheet_variants or 8,
				variation_count = (oredata.use_vanilla_assets and 8) or oredata.sheet_stages or 12,
				scale = 0.5
			},
		}) or nil,
		tree_removal_max_distance = 1024,
		tree_removal_probability = 0.9,
        map_color = oredata.map_color or {1,0,1,1},
		walking_sound = DIR.vanilla_sounds.ore,
		map_grid = true,
    }
end

data:extend {{
	type = "autoplace-control",
	name = "tin-ore",
	localised_name = {"", "[item=tin-ore] ", {"item-name.tin-ore"}},
	richness = true,
	order = "b-ab",
	category = "resource"
}}    

data:extend {{    
	type = "autoplace-control",
	name = "gold-ore",
	localised_name = {"", "[item=gold-ore] ", {"item-name.gold-ore"}},
	richness = true,
	order = "b-bb",
	category = "resource"
}}

for name,oredata in pairs(orefields) do
	data:extend({ resource(name, oredata) })
	if oredata.control or oredata.initialise then
		resource_autoplace.initialize_patch_set(name, oredata.start)
		data:extend {{ type = "noise-layer", name = name }}
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
