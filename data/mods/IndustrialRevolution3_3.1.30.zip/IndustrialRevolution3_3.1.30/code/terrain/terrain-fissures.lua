------------------------------------------------------------------------------------------------------------------------------------------------------

-- Gas fissures

------------------------------------------------------------------------------------------------------------------------------------------------------

local fissures = require("code.data.fissures")
local resource_autoplace = require("resource-autoplace")
local noise = require("noise")
local tne = noise.to_noise_expression

data:extend({
	{
		type = "resource-category",
		name = "ir-gas",
	},
	{
		type = "resource-category",
		name = "ir-steam",
	},
})

local fissure_template = {
	type = "resource",
	flags = {"placeable-neutral"},
	category = "ir-gas",
	subgroup = "raw-resource",
	order = "a-z-a",
	infinite = true,
	highlight = true,
	minimum = 1,
	normal = 1,
	infinite_depletion_amount = 1,
	resource_patch_search_radius = 12,
	tree_removal_probability = 1,
	tree_removal_max_distance = 32 * 32,
	remove_decoratives = "true", -- yes it's a string
	walking_sound = nil,
	collision_box = {{-1.4, -1.4}, {1.4, 1.4}},
	selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
	stage_counts = {0},
	stages = {
		sheet = {
			filename = DIR.entities_path_2 .. "/resources/fissures.png",
			priority = "extra-high",
			width = 192,
			height = 192,
			variation_count = 1,
			frame_count = 8,
			line_length = 2,
			scale = 0.5
		}
	},
	stages_effect = {
		sheet = {
			filename = DIR.entities_path_2 .. "/resources/fissures-glow.png",
			priority = "extra-high",
			width = 192,
			height = 192,
			variation_count = 1,
			frame_count = 8,
			line_length = 2,
			scale = 0.5,
			blend_mode = "additive",
			draw_as_glow = true,
		}
	},
	effect_animation_period	= 4,
	effect_animation_period_deviation = 0.5,
	max_effect_alpha = 1,
	min_effect_alpha = 0.125,
	map_color = {1,0,1},
	map_grid = false,
}

data:extend {{    
	type = "autoplace-control",
	name = "ir-fissures",
	localised_name = {"", "[img=ir-fissures] ", {"autoplace-control-names.ir-fissures"}},
	richness = false,
	order = "c-c",
	category = "resource"
}}

resource_autoplace.initialize_patch_set("ir-fissures", false)
local autoplace_template = resource_autoplace.resource_autoplace_settings {
	name = "ir-fissures",
	order = "c",
	base_density = 8,
	base_spots_per_km2 = 6,
	random_probability = 1/100,
	random_spot_size_minimum = 1,
	random_spot_size_maximum = 1,
	additional_richness = 0,
	has_starting_area_placement = false,
	regular_rq_factor_multiplier = 1
}

data:extend{
  {
    type = "noise-expression",
    name = "ir-fissure-type-noise",
    intended_property = "ir-fissure-type-noise",
    expression = {
      type = "function-application",
      function_name = "factorio-basis-noise",
      arguments = {
        x = noise.var("x"),
        y = noise.var("y"),
        seed0 = tne(noise.var("map_seed")), -- map.seed
        seed1 = tne(989),
        input_scale = tne(1/200),
        output_scale = tne(0.5),
      }
    }
  }
}

local function min_distance_expr(d)
	return noise.less_or_equal(d, noise.var("distance"))
end

local function max_distance_expr(d)
	return noise.less_or_equal(noise.var("distance"), d)
end

-- data.raw.container["wooden-chest"].autoplace = { probability_expression = min_distance_expr(250) * max_distance_expr(251)}
-- data.raw.container["tin-chest"].autoplace = { probability_expression = min_distance_expr(500) * max_distance_expr(501)}
-- data.raw.container["bronze-chest"].autoplace = { probability_expression = min_distance_expr(750) * max_distance_expr(751)}
-- data.raw.container["iron-chest"].autoplace = { probability_expression = min_distance_expr(1000) * max_distance_expr(1001)}

for material,properties in pairs(fissures) do

	if not DIR.values_to_keys(DIR.components.gas.materials)[material] then
		error("Gas component does not exist for fissure "..material)
	end

	local gas_name = DIR.get_item_name(material, "gas")
	local fissure_name = gas_name.."-fissure"
	local hue = DIR.materials[material].hue
	local msaturation = 0.75
	local gsaturation = DIR.components.gas.fluid_saturation_exceptions and DIR.components.gas.fluid_saturation_exceptions[material] or DIR.materials[material].saturation or 0.5

	local yield_at_start = properties.yield_at_start or 30 -- fluid/s
	local time_to_hit_zero = 3 * 60 * 60
	local deplete_level = 0.1

	local fissure_prototype = table.deepcopy(fissure_template)
	fissure_prototype.name = fissure_name
	fissure_prototype.localised_name = {"entity-name.gas-fissure", {"fluid-name." .. gas_name}}
	fissure_prototype.icons = {
		{ icon = DIR.get_icon_path("generic-fissure"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		{ icon = DIR.get_icon_path(gas_name), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, scale = 0.25, shift = {0,-8}},
	}
	fissure_prototype.category = (gas_name == "steam") and "ir-steam" or "ir-gas"
	fissure_prototype.minimum = math.ceil(time_to_hit_zero * deplete_level)
	fissure_prototype.normal = time_to_hit_zero
	fissure_prototype.map_color = properties.map_colour or DIR.hsva2rgba(hue, DIR.get_saturation(hue, msaturation), 0.8)
	fissure_prototype.minable = {
		mining_time = 1,
		results = {
			{
				type = "fluid",
				name = gas_name,
				amount = yield_at_start,
				temperature = properties.temperature or 15,
			}
		},
	}
	
	if properties.autoplace then
		local v = "ir-fissure-type-noise"
		local band_condition = noise.less_than(noise.var(v), (properties.high_band*2)-1) * noise.less_or_equal((properties.low_band*2)-1, noise.var(v))
		fissure_prototype.autoplace = {
			control = autoplace_template.control,
			order = autoplace_template.name,
			richness_expression = autoplace_template.richness_expression,
			probability_expression = autoplace_template.probability_expression * band_condition * min_distance_expr(properties.min_distance or 300),
		}
	end

	fissure_prototype.stages_effect = (gas_name == "sulphur-gas") and fissure_prototype.stages_effect or nil

	local smoke_source_prototype = {
		type = "particle-source",
		name = gas_name .. "-fissure-smoke",
		subgroup = "particles",
		time_to_live = 10^9,
		time_before_start = 0,
		height = 0.4,
		height_deviation = 0.1,
		vertical_speed = 0,
		vertical_speed_deviation = 0,
		horizontal_speed = 0,
		horizontal_speed_deviation = 0,
		smoke = {
			{
				name = gas_name .. "-fissure-soft-smoke",
				frequency = 0.10, 
				position = {0, 0}, -- -0.8},
				starting_frame_deviation = 60,
				starting_vertical_speed = 0.01,
				starting_vertical_speed_deviation = 0.005,
				vertical_speed_slowdown = 1 -- 0.99
			}
		},
		flags = {"placeable-off-grid"},
	}

	local tint = DIR.hsva2rgba(hue, DIR.get_saturation(hue, gsaturation), 1, 0.15)
	
	local trivial_smoke_prototype = {
		type = "trivial-smoke",
		name = gas_name .. "-fissure-soft-smoke",
		duration = 180,
		fade_in_duration = 5,
		fade_away_duration = 30,
		spread_duration = 180,
		start_scale = 0.1,
		end_scale = 1.3,
		color = util.premul_color(tint),
		cyclic = true,
		affected_by_wind = true,
		animation = {
			width = 152,
			height = 120,
			line_length = 5,
			frame_count = 60,
			axially_symmetrical = false,
			direction_count = 1,
			priority = "high",
			flags = {"smoke"},
			animation_speed = 0.25,
			filename = "__base__/graphics/entity/smoke/smoke.png"
		}
	}

	data:extend({fissure_prototype, smoke_source_prototype, trivial_smoke_prototype})
end

------------------------------------------------------------------------------------------------------------------------------------------------------
