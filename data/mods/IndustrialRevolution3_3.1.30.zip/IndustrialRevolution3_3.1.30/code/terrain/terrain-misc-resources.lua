------------------------------------------------------------------------------------------------------------------------------------------------------

-- gem-bearing rocks

local resource_autoplace = require("resource-autoplace")
local noise = require("noise")
local tne = noise.to_noise_expression

data:extend{
  {
    type = "noise-expression",
    name = "ir-gem-rock-noise",
    intended_property = "ir-gem-rock-noise",
    expression = {
      type = "function-application",
      function_name = "factorio-basis-noise",
      arguments = {
        x = noise.var("x"),
        y = noise.var("y"),
        seed0 = tne(noise.var("map_seed")), -- map.seed
        seed1 = tne(989989),
        input_scale = tne(1/200),
        output_scale = tne(0.5),
      }
    }
  }
}

local expressions = {}

for gem,mdata in pairs(DIR.components.gem.ore_patch_chances) do
	for ore,probability in pairs(mdata) do
		expressions[gem] = (expressions[gem] or tne(0)) + (util.copy(data.raw.resource[ore].autoplace.probability_expression) * noise.less_than(noise.var("ir-gem-rock-noise"), 0) * tne({
		type = "function-application",
		function_name = "random-penalty",
		arguments =	{
			source = tne(1),
			x = noise.var("x"),
			y = noise.var("y"),
			amplitude = tne(1/probability)
		}
	}))
	end
end

for _,gem in pairs(DIR.components.gem.materials) do
	if DIR.components.gem.ore_patch_chances[gem] then
		local rock = table.deepcopy(data.raw["simple-entity"]["rock-big"])
		rock.name = "gem-rock-"..gem
		rock.localised_name = {"entity-name.rock-gem",{"item-name."..DIR.get_item_name(gem,"gem")}}
		rock.minable.result = nil
		rock.minable.amount = nil
		rock.minable.results = {
			{name = "stone", type = "item", amount_min = 10, amount_max = 25},
			{name = DIR.get_item_name(gem,"gem"), type = "item", amount_min = 2, amount_max = 5}
		}
		rock.loot = {
			{item = "stone", count_min = 7, count_max = 20},
			{item = DIR.get_item_name(gem,"gem"), count_min = 1, count_max = 4}
		}
		rock.icons = {
			{icon = rock.icon, icon_size = rock.icon_size, icon_mipmaps = rock.icon_mipmaps},
			{icon = DIR.get_icon_path(DIR.get_item_name(gem,"gem")), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, scale = 0.25},
		}
		rock.icon = nil
		rock.icon_size = nil
		rock.icon_mipmaps = nil
		rock.order = "z"
		rock.autoplace = {
			control = nil,
			order = "c",
			richness_expression = nil,
			probability_expression = expressions[gem] * noise.less_or_equal(250, noise.var("distance")),
		}
		-- rock.map_color = {1,0,1},
		data:extend({rock})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- junkpiles

local materials = {
	[1] = {"copper","tin"},
	[2] = {"iron","copper"},
	[3] = {"steel","iron"},
}

local components = {
	scrap = {
		["scrap"] = {50,100},
	},
	non_scrap = {
		["scrap"] = {40,80},
		["plate"] = {6,20},
		["rod"] = {6,12},
		["gear-wheel"] = {6,20},
		["rivet"] = {6,12},
	},
}

for jtype,loot in pairs(components) do

	for index,mpair in ipairs(materials) do
		local name = mpair[1].."-"..mpair[2].."-junkpile"
		local pname = name .. (jtype == "scrap" and "-scrap" or "")
		local results = {}
		for component,range in pairs(loot) do
			for _,material in pairs(mpair) do
				local cname = DIR.get_item_name(material,component)
				if data.raw.item[cname] then
					table.insert(results, {name = cname, type = "item", amount_min = range[1], amount_max = range[2]})
				end
			end
		end
		local decorative = {
			name = pname,
			localised_name = {"entity-name."..name},
			type = "simple-entity",
			order = "scraps-"..index,
			subgroup = "grass",
			render_layer = "transport-belt",
			icon = DIR.get_icon_path(name),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			corpse = nil,
			minable = {
				mining_time = 2,
				results = results,
			},
			max_health = standard_health("copper",1),
			flags = {"placeable-neutral", "placeable-off-grid"},
			collision_box = { {-0.8,-0.8}, {0.8,0.8} },
			selection_box = { {-1,-1}, {1,1} },
			tile_width = 2,
			tile_height = 2,
			collision_mask = {
				"item-layer",
				"object-layer",
				"water-tile",
				"resource-layer", -- stop it spawning on ores
			},
			pictures = {
				sheet = {
					filename = DIR.entities_path_2.."/resources/junkpiles.png",
					priority = "high",
					shift = {0,0},
					height = 128,
					width = 128,
					scale = 0.5,
					y = 128 * (index-1),
					variation_count = 4,
				},
			},
			random_variation_on_create = true,
			map_color = DIR.materials[mpair[1]].rgba or {1,0,1},
		}
		data:extend({decorative})
	end

end

------------------------------------------------------------------------------------------------------------------------------------------------------