------------------------------------------------------------------------------------------------------------------------------------------------------

-- Adjust existing presets to include IR ores

for _, preset in pairs(data.raw["map-gen-presets"]["default"]) do
    if preset.basic_settings and preset.basic_settings.autoplace_controls then
        preset.basic_settings.autoplace_controls["tin-ore"] = preset.basic_settings.autoplace_controls["copper-ore"]
        preset.basic_settings.autoplace_controls["gold-ore"] = preset.basic_settings.autoplace_controls["copper-ore"]
    end
end

-- "IR challenging"

data.raw["map-gen-presets"]["default"]["ir"] = {
    order = "ab",
    basic_settings = {
        property_expression_names = {},
        autoplace_controls = {
            coal = {
                frequency = 1/3,
                size = 1,
            },
            ["copper-ore"] = {
                frequency = 1/3,
                size = 1,
				richness = 0.5,
            },
            ["iron-ore"] = {
                frequency = 1/3,
                size = 1,
				richness = 0.5,
            },
            ["tin-ore"] = {
                frequency = 1/3,
                size = 1,
				richness = 0.5,
            },
            ["gold-ore"] = {
                frequency = 1/3,
                size = 1,
				richness = 0.5,
            },
            stone = {
                frequency = 1/3,
                size = 1,
            },
            ["crude-oil"] = {
                frequency = 1/3,
                size = 1,
            },
            ["uranium-ore"] = {
                frequency = 1/3,
                size = 1,
            },
            ["enemy-base"] = {
                size = 1
            },
            ["ir-fissures"] = {
                frequency = 1/3,
                size = 1,
            },
        },
        terrain_segmentation = 0.5,
        water = 1.5
    },
    advanced_settings = {
        enemy_evolution = {
            time_factor = 0.000001
        },
    }
}

-- "IR tech marathon"

data.raw["map-gen-presets"]["default"]["ir-tech"] = table.deepcopy(data.raw["map-gen-presets"]["default"]["ir"])
data.raw["map-gen-presets"]["default"]["ir-tech"].order = "ac"
data.raw["map-gen-presets"]["default"]["ir-tech"].advanced_settings.difficulty_settings = { technology_price_multiplier = 10 }

-- "IR tech marathon, no biters"

data.raw["map-gen-presets"]["default"]["ir-tech-no-biters"] = table.deepcopy(data.raw["map-gen-presets"]["default"]["ir-tech"])
data.raw["map-gen-presets"]["default"]["ir-tech-no-biters"].basic_settings.autoplace_controls["enemy-base"] = {frequency = 0, size = 0}
data.raw["map-gen-presets"]["default"]["ir-tech-no-biters"].basic_settings.cliff_settings = {richness = 0}

------------------------------------------------------------------------------------------------------------------------------------------------------
