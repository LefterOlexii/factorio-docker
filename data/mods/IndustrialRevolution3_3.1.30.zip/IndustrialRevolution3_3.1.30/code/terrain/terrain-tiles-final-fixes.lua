------------------------------------------------------------------------------------------------------------------------------------------------------

-- late pass on tile properties

------------------------------------------------------------------------------------------------------------------------------------------------------

-- not needed as of 3.0.9

-- local tiles = { "water", "deepwater", "water-green", "deepwater-green", "water-shallow", "water-mud" }
-- local minimal_friction = DIR.components["covering"].vehicle_speed and DIR.components["covering"].vehicle_speed["carbon"]

-- if minimal_friction then
	-- for _,t in pairs(tiles) do
		-- local tile = data.raw.tile[t]
		-- if tile and tile.vehicle_friction_modifier == nil then tile.vehicle_friction_modifier = minimal_friction end
	-- end
-- end

------------------------------------------------------------------------------------------------------------------------------------------------------
