------------------------------------------------------------------------------------------------------------------------------------------------------

-- TREES

------------------------------------------------------------------------------------------------------------------------------------------------------

-- rubber tree

local tree_to_cannibalise = "tree-08"

data:extend({
	{
		name = "ir-rubber-trees",
		type = "autoplace-control",
		category = "terrain",
		order = "c-z",
		richness = true,
		localised_description = {"autoplace-control-descriptions.ir-rubber-trees"},
	},
	{
		name = "ir-rubber-trees-1",
		type = "noise-layer",
	},
	{
		name = "ir-rubber-trees-2",
		type = "noise-layer",
	},
})

local tree = table.deepcopy(data.raw.tree[tree_to_cannibalise])
tree.name = "ir-rubber-tree"
tree.localised_name = {"entity-name.ir-rubber-tree"}
tree.localised_description = nil
tree.map_color = DIR.rubber_tree_map_colour
tree.control = "ir-rubber-trees"
tree.icon_size = DIR.icon_size
tree.colors = {
    {r=0.95,g=0.95,b=0.2},
    {r=0.9,g=0.9,b=0.2},
    {r=0.85,g=0.85,b=0.2},
}
tree.minable.results = {
    {type = "item", name = "rubber-wood", amount = 4},
}
tree.autoplace = {
    control = "ir-rubber-trees",
    max_probability = 0.1,
    order = "a[tree]-b[forest]",
    peaks = {
        {
            influence = 0,
            richness_influence = 0.75
        },
        {
            influence = -0.75,
            richness_influence = 0.75
        },
        {
            influence = 0.375,
            noise_layer = "ir-rubber-trees-1",
            noise_octaves_difference = -0.5,
            noise_persistence = 0.8,
            richness_influence = -0.5
        },
        {
            influence = 0.5,
            noise_layer = "ir-rubber-trees-2",
            noise_octaves_difference = -0.5,
            noise_persistence = 0.6,
            richness_influence = -0.5
        },
		-- more near water
        {
			min_influence = 0,
			max_influence = 1,
            temperature_max_range = 12.5,
            temperature_optimal = 27.5,
            temperature_range = 7.5,
            water_max_range = 0.3,
            water_optimal = 0.75,
            water_range = 0.25
        },
		-- more near shores
        {
			min_influence = 0,
			max_influence = 3,
            elevation_max_range = 3,
            elevation_optimal = 0,
            elevation_range = 1,
        },
		-- less, ideally none, in starting area
        {
			-- pre 3.0.4 using starting area weight 
			-- min_influence = -1,
			-- max_influence = 0,
            -- starting_area_weight_max_range = 0.5,
            -- starting_area_weight_optimal = 0,
            -- starting_area_weight_range = 0.5,
			-- 3.0.4: use distance and *_top_property_limit to exclude, instead of starting area
			influence = -2,
			richness_influence = 0,
            distance_optimal = 0,
            distance_range = DIR.starting_area_clearing_radius - DIR.starting_area_clearing_border,
			distance_top_property_limit = DIR.starting_area_clearing_radius,
			distance_max_range = DIR.starting_area_clearing_radius + DIR.starting_area_clearing_border,
        },
    },
    random_probability_penalty = 0.001,
    richness_base = 0,
    richness_multiplier = 1,
    sharpness = 0.4
}
data:extend({tree})

local props = {"colors","darkness_of_burnt_tree","pictures","variation_weights","variations","icon"}
for _,prop in pairs(props) do
	data.raw.tree[tree_to_cannibalise][prop] = table.deepcopy(data.raw.tree["tree-05"][prop])
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- placeable trees

for _,tree in pairs(DIR.plantable_trees) do
	local entity = table.deepcopy(data.raw.tree[tree])
	local name = tree .. "-planted"
	entity.name = name
	entity.icon = (tree == "ir-rubber-tree") and DIR.get_icon_path(tree_to_cannibalise.."-bed") or DIR.get_icon_path(tree.."-bed")
	entity.selection_box = nil
	entity.selectable_in_game = false
	entity.minable = nil
	entity.autoplace = nil
	entity.control = nil
	-- no "fallen" trees
	if entity.variations then
		entity.variations[11] = nil
		entity.variations[12] = nil
	end
	if entity.variation_weights then
		entity.variation_weights[11] = nil
		entity.variation_weights[12] = nil
	end
	data:extend({entity})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- make blue trees greener?

if settings.startup["ir-no-blue-trees"].value == "on" then
	for _,tree in pairs(data.raw.tree) do
		if tree.colors and not string.find(tree.name,"rubber") then
			for _,col in pairs(tree.colors) do
				local threshold = col.g * 0.8
				if col.b > threshold then
					DIR.spam_log("Tree "..tree.name.." was de-blued")
					col.g = col.b
					col.b = threshold
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

