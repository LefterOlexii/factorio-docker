------------------------------------------------------------------------------------------------------------------------------------------------------

-- EQUIPMENT (vanilla)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fusion reactor -> fission reactor

local reactor = data.raw["generator-equipment"]["fusion-reactor-equipment"]
reactor.power = "2MW"
reactor.burner = {
    fuel_category = "nuclear",
    fuel_inventory_size = 1,
    burnt_inventory_size = 1,
    type = "burner"
}
data.raw.item["fusion-reactor-equipment"].order = "a[energy-source]-z[nuclear]"

------------------------------------------------------------------------------------------------------------------------------------------------------

-- solar panel buff

local panel = data.raw["solar-panel-equipment"]["solar-panel-equipment"]
panel.power = "40kW"

------------------------------------------------------------------------------------------------------------------------------------------------------

-- upgrades to vanilla armour & add specific equipment to vehicle grids

data:extend {
    {
        type = "equipment-grid",
        name = "copper-equipment-grid",
        equipment_categories = {"armor","IR-player-only"},
        height = 4,
        width = 2
    },
    {
        type = "equipment-grid",
        name = "bronze-equipment-grid",
        equipment_categories = {"armor","IR-player-only"},
        height = 6,
        width = 2
    },
    {
        type = "equipment-grid",
        name = "IR-vehicle-equipment-grid-platform",
        equipment_categories = {"IR-vehicle"},
        height = 4,
        width = 10,
    },
    {
        type = "equipment-grid",
        name = "IR-vehicle-equipment-grid-platform-picket",
        equipment_categories = {"IR-vehicle-2"},
        height = 8,
        width = 10
    },
	{
		type = "equipment-category",
		name = "IR-vehicle",
	},
	{
		type = "equipment-category",
		name = "IR-vehicle-2",
	},
	{
		type = "equipment-category",
		name = "IR-player-only",
	},
}

data.raw.armor["light-armor"].inventory_size_bonus = 0
data.raw.armor["light-armor"].equipment_grid = "copper-equipment-grid"
data.raw.armor["light-armor"].stack_size = 1

data.raw.armor["heavy-armor"].equipment_grid = "bronze-equipment-grid"
data.raw.armor["heavy-armor"].stack_size = 1
data.raw.armor["heavy-armor"].inventory_size_bonus = 20

data.raw.armor["modular-armor"].inventory_size_bonus = 30
data.raw.armor["power-armor"].inventory_size_bonus = 40
data.raw.armor["power-armor-mk2"].inventory_size_bonus = 50

table.insert(data.raw["equipment-grid"]["small-equipment-grid"].equipment_categories, "IR-player-only")
table.insert(data.raw["equipment-grid"]["medium-equipment-grid"].equipment_categories, "IR-player-only")
table.insert(data.raw["equipment-grid"]["large-equipment-grid"].equipment_categories, "IR-player-only")

table.insert(data.raw["battery-equipment"]["battery-equipment"].categories, "IR-vehicle")
table.insert(data.raw["battery-equipment"]["battery-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["battery-equipment"]["battery-mk2-equipment"].categories, "IR-vehicle")
table.insert(data.raw["battery-equipment"]["battery-mk2-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["energy-shield-equipment"]["energy-shield-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["energy-shield-equipment"]["energy-shield-mk2-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["generator-equipment"]["fusion-reactor-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["roboport-equipment"]["personal-roboport-equipment"].categories, "IR-vehicle")
table.insert(data.raw["roboport-equipment"]["personal-roboport-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].categories, "IR-vehicle")
table.insert(data.raw["roboport-equipment"]["personal-roboport-mk2-equipment"].categories, "IR-vehicle-2")
table.insert(data.raw["solar-panel-equipment"]["solar-panel-equipment"].categories, "IR-vehicle")
table.insert(data.raw["solar-panel-equipment"]["solar-panel-equipment"].categories, "IR-vehicle-2")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- should be a quickbar toggle, innit

data.raw["belt-immunity-equipment"]["belt-immunity-equipment"].energy_consumption = "10kW"

------------------------------------------------------------------------------------------------------------------------------------------------------
