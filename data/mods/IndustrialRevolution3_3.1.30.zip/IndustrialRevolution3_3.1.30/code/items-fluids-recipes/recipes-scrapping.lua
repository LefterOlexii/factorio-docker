------------------------------------------------------------------------------------------------------------------------------------------------------

-- SCRAPPING

------------------------------------------------------------------------------------------------------------------------------------------------------

local scrap_to_shrap = {
	["iron-scrap"] = "iron",
	["copper-scrap"] = "copper",
	["tin-scrap"] = "iron",
	["gold-scrap"] = "gold",
	["electrum-scrap"] = "gold",
	["bronze-scrap"] = "bronze",
	["steel-scrap"] = "steel",
	["nickel-scrap"] = "steel",
	["lead-scrap"] = "rubber",
	["glass-scrap"] = "glass",
	["stone"] = "stone",
	["wood-chips"] = "wood",
}

DIR.spam_log("Starting scrap calculation", DIR.log_level.milestone)

-- cache scrappable recipe list and primary results, for speed

for _,recipe in pairs(data.raw.recipe) do
	if DIR.is_a_crafting_recipe(recipe) and DIR.is_recipe_one_item_result(recipe) then
		local result = DIR.get_first_item_result(recipe)
		if result
			and result.name
			and result.amount >= 1
			and not recipe.hidden
			and not recipe.IR_not_scrappable
			and recipe.allow_as_intermediate ~= false
			and recipe.allow_intermediates ~= false
		then
			DIR.scrappable_recipes[recipe.name] = result.name
		end
	end
end

local scraptable = {}

-- generate scrap table - first anything that has both an ingot and a scrap component (unless handled separately)

for _,material in pairs(DIR.components.ingot.materials) do
	if DIR.is_value_in_list(DIR.components.scrap.materials, material) and not DIR.is_value_in_list(DIR.components.scrap.separately_handled_materials, material) then
		local divider = material == "glass" and (2 * DIR.scrap_divider) or DIR.scrap_divider -- ugh
		DIR.calculate_scraps({item = DIR.get_item_name(material,"ingot"), base_value = 1 / divider, base_item = DIR.get_item_name(material,"scrap")}, scraptable)
	end
end

-- manually do non-ingot / non-scrap things from basic roots

DIR.calculate_scraps({item = "stone", base_value = 1, base_item = "stone"}, scraptable)
DIR.calculate_scraps({item = "wood", base_value = 2, base_item = "wood-chips"}, scraptable)
DIR.calculate_scraps({item = "rubber-wood", base_value = 1.5, base_item = "wood-chips"}, scraptable)
DIR.calculate_scraps({item = "concrete-fluid", base_value = 0.1, base_item = "concrete-scrap"}, scraptable)

DIR.spam_log("Scrap calculation complete; generating scrap explosions/recipes",DIR.log_level.milestone)

-- generate explosions

local function is_explodey(entity)
	if entity.burner then return true end
	if entity.energy_source then
		if (entity.energy_source.type == "burner") or (entity.energy_source.type == "electric") then return true end
		if (entity.energy_source.type == "fluid") and entity.energy_source.fluid_box and entity.energy_source.fluid_box.filter ~= "steam" then return true end
	end
	return false
end

for name,scrapdata in pairs(scraptable) do
	-- nightmare fuel
    local entity = DIR.wild_stab_at_entity_by_name(
		(data.raw.item[name] and data.raw.item[name].place_result) or 
		(data.raw["item-with-entity-data"][name] and data.raw["item-with-entity-data"][name].place_result) or
		(data.raw.capsule[name])
	)
    if entity and not DIR.explosion_blacklist[entity.type] then
        -- calculate shrapnel
        local total = 0
		local shrapnel = {}
        for scrap,amount in pairs(scrapdata) do
			local particle = scrap_to_shrap[scrap]
			if particle then
				total = total + math.max(amount, 5)
				shrapnel[particle] = (shrapnel[particle] or 0) + math.max(amount, 5)
			end
        end
		if total > 0 then
			-- create custom explosions
			local area = (entity.type == "spider-vehicle") and 25 or DIR.get_area_of_bounding_box(entity.selection_box)
			local explosion = nil
			if is_explodey(entity) then
				if area >= 25 then
					explosion = table.deepcopy(data.raw.explosion["massive-explosion"])
				elseif area >= 9 then
					explosion = table.deepcopy(data.raw.explosion["big-explosion"])
				elseif area > 1 then
					explosion = table.deepcopy(data.raw.explosion["medium-explosion"])
				else
					explosion = table.deepcopy(data.raw.explosion["explosion"])
				end
			else
				explosion = table.deepcopy(data.raw.explosion["ir-smoke-explosion"])
			end
			if entity.type == "spider-vehicle" then
				explosion.height = entity.height
			end
			local max_shrapnel = 128
			if total > max_shrapnel then
				for particle,amount in pairs(shrapnel) do
					shrapnel[particle] = (amount/total) * max_shrapnel
				end
			end
			local target_effects = {}
			for particle,amount in pairs(shrapnel) do
				table.insert(target_effects, DIR.particle_effect(particle, amount, DIR.clamp(0.25+(area/100), 0.25, 1), explosion.height or 0.5, true, DIR.clamp(0.02*math.sqrt(area), 0.02, 0.1)))
			end
			explosion.created_effect = {
				type = "direct",
				action_delivery = {
					type = "instant",
					target_effects = target_effects,
				}
			}
			explosion.name = entity.name.."-explosion"
			explosion.icon = entity.icon
			explosion.icon_size = entity.icon_size
			explosion.icon_mipmaps = entity.icon_mipmaps
			explosion.icons = entity.icons
			explosion.subgroup = "ir-explosions"
			explosion.localised_name = {"entity-name.ir-explosion", {"entity-name."..entity.name}}
			data.raw.explosion[explosion.name] = nil
			data:extend({explosion})
			entity.dying_explosion = explosion.name
			-- create shrapnel hit effect
			entity.damaged_trigger_effect = {}
			for particle,amount in pairs(shrapnel) do
				table.insert(entity.damaged_trigger_effect, DIR.particle_effect(particle, amount/total, 0.5, explosion.height or 0.5, false, 0.02))
			end
		end
    end
end

-- thin scraps down to a maximum

for name,scrapdata in pairs(scraptable) do
    while table_size(scrapdata) > DIR.max_scrap_types do
        local lowest = nil
        for scrap,amount in pairs(scrapdata) do
            if lowest == nil or (scrapdata[lowest] > amount) then lowest = scrap end
        end
        scrapdata[lowest] = nil
        DIR.spam_log("removed "..lowest.." from "..name.." scrapping recipe (over max scrap materials)")
    end
end

-- generate scrapping recipes

for name,scrapdata in pairs(scraptable) do
    -- results
    local results = {}
    local description = {"", {"item-description.scrap"}, " "}
    local so_called_energy = 0
    for scrap,amount in pairs(scrapdata) do
        so_called_energy = so_called_energy + amount
        -- cap scrap at 5k because of other mods with insane recipes
        local maximum = math.min(5000, math.floor(amount))
        local minimum = math.min(5000, math.max(1, math.floor(amount * DIR.scrap_minimum_rate)))
        local probability = amount * ((DIR.scrap_minimum_rate+1)/2)
		if probability >= 1 then
			local average = (minimum+maximum)/2
			if average >= 1000 then average = string.format("%.1f", math.floor(average/100)/10) .. "k"
			elseif average >= 10 then average = string.format("%d", average)
			else average = string.format("%s", math.floor(average*10)/10) end
			table.insert(results, {name = scrap, type = "item", amount_max = maximum, amount_min = minimum})
		else
			table.insert(results, {name = scrap, type = "item", amount = 1, probability = probability})
		end
		if amount > 0 then
			local v = amount * DIR.scrap_divider
			table.insert(description, string.format("[img=item/%s] %s ", scrap, DIR.nice_round(v, (v<10) and 2 or 0)))
		end
    end
    so_called_energy = math.max(0.1, math.floor(math.sqrt(so_called_energy)*10)/10)
    -- scrap recipe
	local localised_name = {"item-name."..name}
	if data.raw.item[name] and data.raw.item[name].place_result then localised_name = {"entity-name."..data.raw.item[name].place_result} end
    data:extend({{
        name = "scrap-"..name,
        localised_name = {"recipe-name.scrapping", localised_name},
        type = "recipe",
        category = "scrapping",
        subgroup = "scrapping",
        hide_from_player_crafting = true,
		hide_from_stats = true,
        allow_decomposition = false,
        allow_intermediates = false,
        allow_as_intermediate = false,
		always_show_products = true,
        icon = DIR.get_icon_path("scrapping"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
        enabled = true,
        ingredients = { { name = name, type = "item", amount = 1 } },
        results = results,
        energy_required = so_called_energy,
		show_amount_in_title = false,
		order = "z-"..string.format("%08d", so_called_energy*10),
		IR_tech_rebuild_ignore = true, -- these are made after data-updates but just in case
    }})
	local item = data.raw.item[name] or data.raw["item-with-entity-data"][name] or data.raw.capsule[name] or data.raw.module[name] or data.raw.tool[name]
	if item and DIR.show_item_scrap then
		if not item.localised_description then
			item.localised_description = description
		else
			item.localised_description = {"", item.localised_description, "\n", description}
		end
	end
end

DIR.spam_log("Scrap explosions/recipes complete",DIR.log_level.milestone)

------------------------------------------------------------------------------------------------------------------------------------------------------
