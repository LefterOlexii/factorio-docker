------------------------------------------------------------------------------------------------------------------------------------------------------

-- oil processing

local oil_unit = 120 -- must be a multiple of 6 (= DIR.standard_petro_time's multiplier)
local oil_half = oil_unit / 2
local oil_third = oil_unit / 3
local oil_two_thirds = oil_third * 2
local oil_quarter = oil_unit / 4
local oil_sixth = oil_unit / 6
local smallest_fraction = oil_unit / 12
local fluid_per_coke = 15
local coke_fuel_value = 12 -- MJ
local oil_fuel_value = DIR.hydrogen_energy_value_MJ
-- local ethanol_fuel_value = DIR.base_energy_unit * DIR.components.fluid.fuel_values.natural.multiplier
-- local petroleum_in_rocket_fuel = 180
-- local ethanol_in_rocket_fuel = 60
-- local rocket_fuel_value = ((petroleum_in_rocket_fuel * oil_fuel_value) + (ethanol_in_rocket_fuel * ethanol_fuel_value)) * 1.25

local function add_recipe_defaults_and_extend(recipe)
	recipe.type = "recipe"
	recipe.enabled = false
	recipe.show_amount_in_title = false
	recipe.always_show_products = true
	data:extend({recipe})
	return data.raw.recipe[recipe.name]
end

local function get_single_icons(icon)
	return {
		{ icon = DIR.get_icon_path(icon), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
	}
end

-- refinery recipes

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-crude-oil-processing",
	category = "oil-processing",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("ir-crude-oil-processing"),
	subgroup = "fluid-recipes",
	order = "o1",
	ingredients = {
		{
			name = "crude-oil",
			amount = oil_unit,
			type = "fluid"
		},
		{
			name = "water",
			amount = oil_unit,
			type = "fluid"
		},
	},
	results = {
		{
			name = "heavy-oil",
			amount = oil_half,
			type = "fluid",
		},
		{
			name = "light-oil",
			amount = oil_third,
			type = "fluid",
		},
		{
			name = "petroleum-gas",
			amount = oil_sixth,
			type = "fluid",
		},
		{
			name = "bitumen",
			amount = 1,
			type = "item",
		},
	},
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-heavy-oil-processing",
	category = "oil-processing",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("ir-heavy-oil-processing"),
	subgroup = "fluid-recipes",
	order = "o2",
	ingredients = {
		{
			name = "silica",
			amount = 1,
			type = "item"
		},
		{
			name = "heavy-oil",
			amount = oil_unit,
			type = "fluid"
		},
		{
			name = "water",
			amount = oil_unit,
			type = "fluid"
		},
	},
	results = {
		{
			name = "light-oil",
			amount = oil_two_thirds,
			type = "fluid",
		},
		{
			name = "petroleum-gas",
			amount = oil_third,
			type = "fluid",
		},
		{
			name = "sulphur-gas",
			amount = oil_half,
			type = "fluid",
		},
	},
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-light-oil-processing",
	category = "oil-processing",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("ir-light-oil-processing"),
	subgroup = "fluid-recipes",
	order = "o3",
	ingredients = {
		{
			name = "silica",
			amount = 1,
			type = "item"
		},
		{
			name = "light-oil",
			amount = oil_unit,
			type = "fluid"
		},
		{
			name = "water",
			amount = oil_unit,
			type = "fluid"
		},
	},
	results = {
		{
			name = "petroleum-gas",
			amount = oil_half,
			type = "fluid",
		},
		{
			name = "natural-gas",
			amount = oil_half,
			type = "fluid",
		},
		{
			name = "sulphur-gas",
			amount = oil_half,
			type = "fluid",
		},
	},
})

-- chemplant recipes

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-petroleum-processing",
	category = "chemistry",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("ir-petroleum-processing"),
	subgroup = "fluid-recipes",
	order = "o4",
	ingredients = {
		{
			name = "nickel-pellet",
			amount = 1,
			type = "item"
		},
		{
			name = "petroleum-gas",
			amount = oil_half,
			type = "fluid"
		},
		{
			name = "steam",
			amount = oil_half,
			type = "fluid"
		},
	},
	results = {
		{
			name = "natural-gas",
			amount = oil_half,
			type = "fluid"
		},
		{
			name = "solid-fuel",
			amount = math.floor(oil_quarter / fluid_per_coke),
			type = "item"
		},
		-- {
			-- name = "sulphur-gas",
			-- amount = oil_quarter,
			-- type = "fluid"
		-- },
	},
	crafting_machine_tint = DIR.get_crafting_tints_from_hues(0.5,DIR.hues.magenta,DIR.hues.violet,DIR.hues.blue,DIR.hues.azure,0.75,0.5),
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-natural-gas-processing",
	localised_name = {"recipe-name.ir-natural-gas-processing"},
	category = "chemistry",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("ir-natural-gas-processing"),
	subgroup = "fluid-recipes",
	order = "o5",
	ingredients = {
		{
			name = "platinum-pellet",
			amount = 1,
			type = "item"
		},
		{
			name = "natural-gas",
			amount = oil_half,
			type = "fluid"
		},
		{
			name = "steam",
			amount = oil_unit,
			type = "fluid"
		},
	},
	results = {
		{
			name = "hydrogen-gas",
			amount = oil_unit * 2,
			type = "fluid"
		},
		{
			name = "carbon-gas",
			amount = oil_half,
			type = "fluid"
		},
	},
	crafting_machine_tint = DIR.get_crafting_tints_from_hues(0.5,DIR.hues.blue,DIR.hues.azure,DIR.hues.red,DIR.hues.pink,0.75,0.5),
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "lubricant",
	localised_name = {"fluid-name.lubricant"},
	category = "chemistry",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("lubricant"),
	subgroup = "ir-fluid-recipes",
	order = "t",
	ingredients = {
		{
			name = "heavy-oil",
			amount = oil_half,
			type = "fluid"
		},
		{
			name = "steam",
			amount = oil_half,
			type = "fluid"
		},
	},
	results = {
		{
			name = "lubricant",
			amount = oil_half,
			type = "fluid"
		},
		{
			name = "sulphur-gas",
			amount = oil_half,
			type = "fluid"
		},
	},
	crafting_machine_tint = DIR.get_crafting_tints_from_hues(0.5,DIR.hues.red,DIR.hues.orange,DIR.hues.green,DIR.hues.lime,0.75,0.5),
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "coal-liquefaction",
	category = "chemistry",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("coal-liquefaction"),
	subgroup = "fluid-recipes",
	order = "o6",
	ingredients = {
		{
			name = "heavy-oil",
			amount = smallest_fraction * 2 * speed,
			type = "fluid"
		},
		{
			name = "steam",
			amount = smallest_fraction * 6 * speed,
			type = "fluid"
		},
		{
			name = "carbon-crushed",
			amount = smallest_fraction * 1 * speed,
			type = "item",
		},
	},
	results = {
		{
			name = "heavy-oil",
			amount = smallest_fraction * 8 * speed,
			type = "fluid"
		},
		{
			name = "light-oil",
			amount = smallest_fraction * 4 * speed,
			type = "fluid"
		},
	},
	crafting_machine_tint = DIR.get_crafting_tints_from_hues(0.5,1,1,0.125,1,0.75,0.5),
})

local speed = 1
local recipe = add_recipe_defaults_and_extend({
	name = "ir-bitumen-upgrading",
	category = "oil-processing",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("bitumen-upgrading"),
	subgroup = "fluid-recipes",
	order = "o9",
	ingredients = {
		{
			name = "bitumen-fluid",
			amount = 120,
			type = "fluid"
		},
		{
			name = "water",
			amount = 120,
			type = "fluid"
		},
	},
	results = {
		{
			name = "heavy-oil",
			amount = 30,
			type = "fluid",
		},
		{
			name = "light-oil",
			amount = 20,
			type = "fluid",
		},
		{
			name = "petroleum-gas",
			amount = 70,
			catalyst_amount = 60, -- should match amount that went into dilbit
			type = "fluid",
		},
	},
	emissions_multiplier = 1.25,
})

local speed = 1
local high_octane_amount = 240

local recipe = add_recipe_defaults_and_extend({
	name = "rocket-fuel",
	category = "barrelling",
	energy_required = DIR.standard_petro_time * speed,
	icons = get_single_icons("rocket-fuel"),
	subgroup = "ir-canisters",
	order = "ba",
	ingredients = {
		{
			name = "high-octane-fluid",
			amount = high_octane_amount,
			type = "fluid"
		},
		{
			name = "empty-canister",
			amount = 1,
			type = "item",
		},
	},
	results = {
		{
			name = "rocket-fuel",
			amount = 1,
			type = "item"
		},
	},
	always_show_made_in = true,
	allow_decomposition = false,
	show_amount_in_title = false,
	always_show_products = true,
	IR_tech_rebuild_ignore = true,
	crafting_machine_tint = {
		secondary = {r=1,g=1,b=1,a=1},
	},
	-- crafting_machine_tint = DIR.get_crafting_tints_from_hues(0.5,DIR.hues.violet,DIR.hues.lime,DIR.hues.violet,DIR.hues.lime,0.75,0.5),
})
DIR.add_icons_to_recipe(data.raw.recipe["rocket-fuel"], {{icon = DIR.get_icon_path("high-octane-fluid"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)

data:extend({
	{
		type = "recipe",
		name = "empty-rocket-fuel",
		localised_name = {"recipe-name.empty-filled-canister",{"fluid-name.high-octane-fluid"}},
		subgroup = "ir-canisters",
		order = "bb",
		ingredients = {
			{name = "rocket-fuel", type = "item", amount = 1},
		},
		results = {
			{name = "empty-canister", type = "item", amount = 1},
			{name = "high-octane-fluid", type = "fluid", amount = high_octane_amount},
		},
		icons = {
			{icon = DIR.get_icon_path("empty-rocket-fuel"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
		},
		category = "unbarrelling",
		enabled = false,
		energy_required = DIR.standard_petro_time * speed,
		always_show_made_in = true,
		allow_decomposition = false,
		show_amount_in_title = false,
		always_show_products = true,
		IR_tech_rebuild_ignore = true,
		crafting_machine_tint = {
			secondary = {r=1,g=1,b=1,a=1},
		},
		hide_from_player_crafting = true,
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------

data.raw.fluid["petroleum-gas"].fuel_value = oil_fuel_value.."MJ"

DIR.change_item_and_recipe_subgroup("rocket-fuel","ir-canisters")
DIR.change_item_and_recipe_order("rocket-fuel", "bb")
data.raw.item["rocket-fuel"].fuel_value = "144MJ"
data.raw.item["rocket-fuel"].stack_size = 10
data.raw.item["rocket-fuel"].burnt_result = "empty-canister"
data.raw.item["rocket-fuel"].fuel_category = "canister"
-- data.raw.item["rocket-fuel"].localised_description = DIR.get_container_localised_description("barrelling")
data.raw.item["rocket-fuel"].fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["chromium"].acceleration
data.raw.item["rocket-fuel"].fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["chromium"].top_speed

------------------------------------------------------------------------------------------------------------------------------------------------------
