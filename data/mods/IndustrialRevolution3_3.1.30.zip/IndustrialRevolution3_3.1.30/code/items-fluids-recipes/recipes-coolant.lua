------------------------------------------------------------------------------------------------------------------------------------------------------

-- add coolants to all laser assembler recipes

for _,recipe in pairs(data.raw.recipe) do
	if recipe.category == "laser-crafting" then
		local root = recipe.normal and {recipe.normal,recipe.expensive} or {recipe}
		for _,r in pairs(root) do
			if type(r) == "table" then
				if r.result then
					r.results = {
						{ name = r.result, amount = r.result_count, type = "item" }
					}
					r.result = nil
					r.result_count = nil
				end
				for _,i in pairs(r.ingredients) do
					if i.type == "fluid" then i.fluidbox_index = 1 end
				end
				for _,i in pairs(r.results) do
					if i.type == "fluid" then i.fluidbox_index = 1
					else r.main_product = i[1] or i.name
					end
				end
				local amount = DIR.laser_coolant_amount * ((recipe.energy_required or 1)/DIR.standard_crafting_time)
				table.insert(recipe.ingredients, {name = "nitrogen-fluid", type = "fluid", amount = amount, fluidbox_index = 2})
				table.insert(recipe.results, {name = "nitrogen-gas", type = "fluid", amount = amount / DIR.liquified_gas_ratio, fluidbox_index = 2, IR_tech_rebuild_ignore_as_provider = true})
			end
		end
		if recipe.icons == nil or #recipe.icons < 2 then
			DIR.convert_recipe_icon_to_icons(recipe)
			DIR.add_icons_to_recipe(recipe,{{icon = DIR.get_icon_path(DIR.category_overlays["laser-crafting"],DIR.icon_size,icon_path), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
		end
	end
end

-- now scan all recipes for the same elemental fluid in both inputs and outputs and mark them as catalysts if found
-- we don't do this above because the mat/comp system can also generate this kind of thing, maybe also manual recipes, gotta catch 'em all

local materials = {"air","oxygen","nitrogen","hydrogen","helium"}

for _,recipe in pairs(data.raw.recipe) do
	-- we don't care about normal/expensive here because (a) it's toast in 1.2 and (b) IR doesn't use it
	-- nor do we care about single result recipes because we're only looking for fluids
	if recipe.ingredients and recipe.results then
		for _,material in pairs(materials) do
			local i_indexes = {}
			local r_indexes = {}
			for i,ingredient in pairs(recipe.ingredients) do
				if ingredient.type == "fluid" and ((ingredient.name == DIR.get_item_name(material,"fluid")) or (ingredient.name == DIR.get_item_name(material,"gas"))) then
					table.insert(i_indexes,i)					
				end
			end
			for i,result in pairs(recipe.results) do
				if result.type == "fluid" and ((result.name == DIR.get_item_name(material,"fluid")) or (result.name == DIR.get_item_name(material,"gas"))) then
					table.insert(r_indexes,i)					
				end
			end
			if #i_indexes > 0 and #r_indexes > 0 then
				DIR.spam_log("Setting "..material.." as catalyst pair in recipe "..recipe.name)
				for _,index in pairs(i_indexes) do
					recipe.ingredients[index].catalyst_amount = recipe.ingredients[index].amount
				end
				for _,index in pairs(r_indexes) do
					recipe.results[index].catalyst_amount = recipe.results[index].amount
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
