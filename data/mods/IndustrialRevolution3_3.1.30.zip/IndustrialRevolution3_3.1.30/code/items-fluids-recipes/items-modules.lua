------------------------------------------------------------------------------------------------------------------------------------------------------

-- rework vanilla modules

local modules = {[1] = "speed", [2] = "effectivity", [3] = "productivity"}
local computers = {[1] = "computer-mk1", [2] = "computer-mk2", [3] = "computer-mk3"}

for i=1,3 do
	for level=1,3 do
		local name = modules[i].."-module"..((level > 1) and "-"..level or "")
		local module_item = data.raw.module[name]
		if module_item then
			-- hide vanilla recipe
			data.raw.recipe[name].hidden = true
			-- update icon
			DIR.replace_item_icon(name)
			-- update limitations
			if modules[i] == "productivity" then
				module_item.limitation = DIR.productivity_limitation
			end
			-- create new program/format recipes
			data:extend({
				{
					type = "recipe",
					name = "program-"..name,
					result = name,
					result_count = 1,
					category = "module-loading",
					enabled = false,
					ingredients = {
						{computers[level],1},
					},
					energy_required = 2 * (2^(level-1)) * DIR.standard_crafting_time,
					subgroup = "module",
					hide_from_stats = true,
					always_show_products = true,
					localised_name = {"recipe-name.program-module",{"item-name."..name}},
					order = module_item.order,
					IR_tech_rebuild_ignore = true,
				},
				{
					type = "recipe",
					name = "deprogram-"..name,
					result = computers[level],
					result_count = 1,
					category = "module-loading",
					enabled = false,
					ingredients = {
						{name,1},
					},
					icons = {
						{ icon = DIR.get_icon_path(name), icon_size = DIR.icon_size},
						{ icon = DIR.get_icon_path("deprogram"), icon_size = DIR.icon_size, scale = 0.25, shift = {-8,-8}},
					},
					energy_required = DIR.standard_crafting_time * 2,
					subgroup = "ir-module-reversed",
					hide_from_stats = true,
					allow_as_intermediate = false,
					allow_intermediates = false,
					always_show_products = true,
					localised_name = {"recipe-name.deprogram-module",{"item-name."..name}},
					order = module_item.order,
					IR_tech_rebuild_ignore = true,
				}
			})
		end
	end
end

-- 3.1.0 - hide vanilla crafting recipes

for i=1,3 do
	for m=1,3 do
		local suffix = (i==1) and "" or "-"..i
		if data.raw.recipe[modules[m]..suffix] then data.raw.recipe[modules[m]..suffix].hidden = true end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
