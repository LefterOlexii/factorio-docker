------------------------------------------------------------------------------------------------------------------------------------------------------

-- update vanilla recipes with DIR scheme

------------------------------------------------------------------------------------------------------------------------------------------------------

-- disable/enable some of the default recipes

DIR.disable_recipes({
	"pistol",
    "boiler",
    "electric-mining-drill",
    "electronic-circuit",
    "firearm-magazine",
    "inserter",
    "iron-chest",
    "lab",
    "offshore-pump",
    "pipe",
    "pipe-to-ground",
    "radar",
    "repair-pack",
    "small-electric-pole",
    "steam-engine",
	-- "wooden-chest",
	-- "transport-belt",
	-- "burner-inserter",
	-- "shotgun",
	-- "light-armor",
})

DIR.hide_recipes({
	"advanced-oil-processing",
	"basic-oil-processing",
	"heavy-oil-cracking",
	"light-oil-cracking",
	"solid-fuel-from-light-oil",
	"solid-fuel-from-heavy-oil",
	"solid-fuel-from-petroleum-gas",
	"atomic-bomb",
	"nuclear-fuel",
})

DIR.enable_recipes({
    "shotgun",
})

DIR.hide_items({
	"pistol",
	"nuclear-fuel",
	"atomic-bomb",
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- science packs
-- 3.0.0 - now part of component system

-- belts
DIR.replace_recipe_ingredients("transport-belt", {{"tin-plate", 1}, {"copper-rod", 1}, {"copper-gear-wheel", 2}}, 2)
DIR.replace_recipe_ingredients("underground-belt", {{"tin-plate", 4}, {"transport-belt", 5}}, 2)
DIR.replace_recipe_ingredients("splitter", {{"tin-plate", 2}, {"tin-gear-wheel", 4}, {"transport-belt", 2}})
DIR.replace_recipe_ingredients("fast-transport-belt", {{"rubber",1}, {"iron-plate", 1}, {"iron-stick", 1}, {"iron-gear-wheel", 2}})
DIR.replace_recipe_ingredients("fast-underground-belt", {{"iron-plate", 4}, {"fast-transport-belt", 7}}, 2)
DIR.replace_recipe_ingredients("fast-splitter", {{"iron-plate", 2}, {"iron-gear-wheel", 4}, {"fast-transport-belt", 2}, {"electronic-circuit", 1}})
DIR.replace_recipe_ingredients("express-transport-belt", {{"rubber",1}, {type = "item", name = "steel-plate", amount = 2}, {type = "item", name = "steel-rod", amount = 1}, {type = "item", name = "brass-gear-wheel", amount = 2}, {type = "fluid", name = "lubricant", amount = 20}}, 1, "advanced-crafting")
DIR.replace_recipe_ingredients("express-underground-belt", {{"steel-plate", 4}, {"express-transport-belt", 9}}, 2, "crafting")
DIR.replace_recipe_ingredients("express-splitter", {{"steel-plate", 2}, {"brass-gear-wheel", 4}, {"express-transport-belt", 2}, {"advanced-circuit", 1}}, 1, "crafting")

-- assemblers
DIR.replace_recipe_ingredients("assembling-machine-1", {{"copper-frame-large", 1}, {"steam-inserter", 2}, {"tin-gear-wheel", 4}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("assembling-machine-2", {{"iron-frame-large", 1}, {"inserter", 2}, {"iron-gear-wheel", 8}}, 1, "crafting", 5)
DIR.replace_recipe_ingredients("assembling-machine-3", {
	{name = "steel-frame-large", type = "item", amount = 1}, 
	{name = "fast-inserter", type = "item", amount = 2}, 
	{name = "brass-gear-wheel", type = "item", amount = 12}
}, 1, "crafting", 6)

-- inserters
DIR.replace_recipe_ingredients("burner-inserter", {{"tin-plate", 2}, {"copper-piston", 1}, {"copper-motor", 1}, {"tin-rod", 3}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("inserter", {{"electronic-circuit",1}, {"iron-piston", 1}, {"iron-motor", 1}, {"iron-stick", 3}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("long-handed-inserter", {{"inserter", 1}, {"iron-stick", 3}, {"iron-piston", 1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("fast-inserter", {{"electronic-circuit", 1}, {"steel-piston", 2}, {"electric-engine-unit", 1}, {"steel-rod", 4}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("filter-inserter", {{"fast-inserter", 1}, {"electronic-circuit", 2}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("stack-inserter", {{"advanced-circuit",1}, {"chromium-piston", 4}, {"electric-engine-unit", 2}, {"chromium-rod", 6}}, 1, "crafting", 2)
DIR.replace_recipe_ingredients("stack-filter-inserter", {{"stack-inserter", 1}, {"advanced-circuit", 2}}, 1, "crafting", 2)

-- electric age
DIR.replace_recipe_ingredients("concrete", {
	{type = "item", name = "iron-stick", amount = 10},
	{type = "fluid", name = "concrete-fluid", amount = 100},
}, 10, "advanced-crafting", 5)
DIR.replace_recipe_ingredients("refined-concrete", {
	{type = "item", name = "sulfur", amount = 3},
	{type = "item", name = "steel-rod", amount = 10},
	{type = "fluid", name = "concrete-fluid", amount = 200},
}, 10, "advanced-crafting", 10)
DIR.replace_recipe_ingredients("small-lamp", {{"iron-plate", 1}, {"copper-cable", 1}, {"copper-gate", 1}, {"glass",1}})
DIR.replace_recipe_ingredients("small-electric-pole", {{"wood-beam", 1}, {"copper-cable", 1}})
DIR.replace_recipe_ingredients("medium-electric-pole", {{"steel-beam", 2}, {"copper-cable", 2}})
DIR.replace_recipe_ingredients("big-electric-pole", {{"steel-beam", 8}, {"steel-rod", 12}, {"copper-cable-heavy", 2}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("substation", {{"steel-frame-small", 3}, {"junction-box", 1}, {"steel-rod", 16}, {"copper-cable-heavy",4}})
DIR.replace_recipe_ingredients("stone-wall", {{"stone-brick", 5}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("gate", {{"stone-wall", 1}, {"iron-plate-heavy", 2}, {"iron-motor", 1}, {"electronic-circuit", 1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("offshore-pump", {{"pipe", 2}, {"iron-gear-wheel", 4}, {"iron-plate", 2}, {"iron-stick",2}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("solar-panel", {{"glass", 9}, {"silicon", 9}, {"steel-plate", 18}, {"advanced-circuit",1}}, 1, "crafting", 2)
DIR.replace_recipe_ingredients("accumulator", {{"steel-frame-small", 4}, {"junction-box",1}, {"advanced-battery", 3}, {"copper-coil", 9}}, 1, "crafting", 5)
DIR.replace_recipe_ingredients("pump", {{"pipe", 2}, {"iron-motor", 4}, {"electronic-circuit", 1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("storage-tank", {{"pipe", 4}, {"iron-plate-heavy", 40}, {"iron-stick", 20}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("boiler", {{"iron-beam", 8}, {"iron-plate",12}, {"pipe", 4}, {"stone-brick", 40}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("steam-engine", {{"iron-beam", 12}, {"iron-piston", 16}, {"iron-gear-wheel", 16}, {"iron-plate", 32}}, 1, "crafting", 5)
DIR.replace_recipe_ingredients("pumpjack", {{"iron-frame-small", 1}, {"iron-piston", 4}, {"iron-plate", 8}, {"iron-beam", 8}}, 1, "crafting", 3)

-- rail and vehicles
-- DIR.replace_recipe_ingredients("engine-unit", {{"iron-piston", 4}, {"iron-gear-wheel",4}, {"iron-plate", 6},{"pipe",2}}, 1, "crafting", 4)
DIR.replace_recipe_ingredients("rail", {{"iron-ingot", 2}, {"wood-beam",1}, {"gravel", 1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("rail-signal", {{"glass", 1}, {"copper-cable",3}, {"electronic-circuit", 1}, {"iron-plate",1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("rail-chain-signal", {{"glass", 1}, {"copper-cable",2}, {"electronic-circuit", 1}, {"iron-plate",1}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("train-stop", {{"rail-signal", 1}, {"iron-frame-small", 1}, {"iron-beam", 4}}, 1, "crafting", 1)
DIR.replace_recipe_ingredients("locomotive", {{"engine-unit", 4}, {"iron-beam", 8}, {"iron-gear-wheel",24}, {"computer-mk1",1}})
DIR.replace_recipe_ingredients("cargo-wagon", {{"iron-plate-heavy", 16}, {"iron-beam", 4}, {"iron-gear-wheel",16}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("fluid-wagon", {{"iron-plate-heavy", 16}, {"iron-beam", 2}, {"iron-gear-wheel",16}, {"pipe",6}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("artillery-wagon", {{"chromium-plate-heavy",40},{"brass-gear-wheel",16},{"artillery-turret",1}}, 1, "crafting", 5)
DIR.replace_recipe_ingredients("car", {{"engine-unit", 1}, {"iron-beam", 8}, {"rubber",40}, {"iron-plate",6}, {"iron-gear-wheel",8}})
DIR.replace_recipe_ingredients("tank", {{"engine-unit", 4}, {"steel-plate-heavy",40}, {"brass-gear-wheel",24}, {"steel-beam",8}})
DIR.replace_recipe_ingredients("spidertron", {{"rocket-turret",1}, {"low-density-structure", 150}, {"computer-mk3", 8}, {"exoskeleton-equipment",8}, {"fusion-reactor-equipment",3},{"chromium-plate-heavy",50}})
DIR.replace_recipe_ingredients("spidertron-remote", {{"computer-mk3", 1}, {"steel-rod", 1}})

-- petrochem
DIR.replace_recipe_ingredients("oil-refinery", {{"iron-frame-large",1}, {"iron-beam",24}, {"pipe",20}, {"concrete-block",40}})
DIR.replace_recipe_ingredients("chemical-plant", {{"iron-frame-large", 1}, {"iron-motor",6}, {"pipe", 6}, {"concrete-block",20}})
DIR.replace_recipe_ingredients("empty-barrel", {{"steel-plate", 4},{"steel-rivet",1}})

-- electronics
-- circuits are found in items-misc
DIR.replace_recipe_ingredients("red-wire", {{"copper-cable", 10}}, 10)
DIR.replace_recipe_ingredients("green-wire", {{"copper-cable", 10}}, 10)
DIR.replace_recipe_ingredients("arithmetic-combinator", {{"iron-frame-small",1}, {"copper-cable",2}, {"electronic-circuit",1}})
DIR.replace_recipe_ingredients("decider-combinator", {{"iron-frame-small",1}, {"copper-cable",2}, {"electronic-circuit",1}})
DIR.replace_recipe_ingredients("constant-combinator", {{"iron-frame-small",1}, {"copper-cable",1}, {"copper-gate",1}})
DIR.replace_recipe_ingredients("power-switch", {{"iron-frame-small",1}, {"iron-stick",2}, {"copper-cable",2}, {"copper-gate",1}})
DIR.replace_recipe_ingredients("programmable-speaker", {{"computer-mk1",1}, {"iron-beam",1}, {"iron-plate",2}, {"copper-cable",2}})

-- storage & logistics
DIR.replace_recipe_ingredients("wooden-chest", {{"wood-beam",6}}, 1, "crafting", 2)
DIR.replace_recipe_ingredients("iron-chest", {{"iron-stick",6}, {"iron-plate",6}}, 1, "crafting", 2)
DIR.replace_recipe_ingredients("steel-chest", {{"steel-rod",6}, {"steel-plate",6}}, 1, "crafting", 2)
DIR.replace_recipe_ingredients("logistic-chest-active-provider", {{"steel-chest",1}, {"advanced-circuit",1}, {"electric-engine-unit", 1}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("logistic-chest-passive-provider", {{"steel-chest",1}, {"advanced-circuit",1}, {"electric-engine-unit", 1}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("logistic-chest-storage", {{"steel-chest",1}, {"advanced-circuit",1}, {"electric-engine-unit", 1}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("logistic-chest-requester", {{"steel-chest",1}, {"processing-unit",1}, {"electric-engine-unit", 1}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("logistic-chest-buffer", {{"steel-chest",1}, {"processing-unit",1}, {"electric-engine-unit", 1}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("construction-robot", {{"electronic-circuit",3}, {"iron-stick",4}, {"iron-rotor",1}, {"battery",1}})
DIR.replace_recipe_ingredients("logistic-robot", {{"advanced-circuit",3}, {"steel-rod",4}, {"flying-robot-frame",1}, {"battery",1}})
DIR.replace_recipe_ingredients("roboport", {{"electric-engine-unit",4}, {"steel-frame-large",1}, {"copper-cable-heavy",4}, {"accumulator",1}})

-- late game
DIR.replace_recipe_ingredients("beacon", {{"chromium-frame-large",1}, {"junction-box",1}, {"field-effector",4}, {"chromium-rod",64}}, 1, "crafting", 3)
DIR.replace_recipe_ingredients("steam-turbine", {{"chromium-engine-unit", 4},{"copper-cable-heavy",2},{"chromium-plate-heavy",60}})
DIR.replace_recipe_ingredients("centrifuge", {{"chromium-frame-large", 1}, {"lead-plate-special",24}, {"chromium-engine-unit",3}})
DIR.replace_recipe_ingredients("nuclear-reactor", {{"computer-mk3",4}, {"lead-plate-special",120}, {"graphite",80}, {"heat-pipe",8}})
DIR.replace_recipe_ingredients("heat-exchanger", {{"steel-beam", 6}, {"pipe", 4}, {"heat-pipe",4}, {"steel-plate-heavy", 40}})
DIR.replace_recipe_ingredients("heat-pipe", {{"copper-rod",6}, {"steel-rod", 12}, {"steel-rivet",2}})
DIR.replace_recipe_ingredients("low-density-structure", {{"steel-rod", 4}, {"copper-foil", 20}, {"nanoglass", 4}}, 1, "advanced-crafting", 16)
DIR.replace_recipe_ingredients("uranium-fuel-cell", {{"lead-plate-special",10}, {"uranium-235", 1}, {"uranium-238", 19}}, 10, "centrifuging", 16)
DIR.replace_recipe_ingredients("rocket-silo", {{"chromium-plate-heavy",240},{"concrete-block",240},{"computer-mk3",8},{"junction-box",16},{"pipe",40},{"copper-cable-heavy",16}})

-- military
DIR.replace_recipe_ingredients("pistol", {{"wood-beam",1}, {"copper-plate", 1}, {"tin-plate", 2}})
DIR.replace_recipe_ingredients("shotgun", {{"wood-beam", 1}, {"copper-plate", 4}, {"copper-gear-wheel", 1}, {"copper-rod",2}})
DIR.replace_recipe_ingredients("submachine-gun", {{"iron-plate", 8}, {"iron-gear-wheel", 1}, {"iron-stick",4}})
DIR.replace_recipe_ingredients("combat-shotgun", {{"steel-plate", 16}, {"brass-gear-wheel", 3}, {"steel-rod",4}})
DIR.replace_recipe_ingredients("rocket-launcher", {{"steel-plate", 20}, {"steel-gear-wheel", 4}, {"steel-rod",2}, {"electronic-circuit",1}})
DIR.replace_recipe_ingredients("flamethrower", {{"steel-plate-heavy", 8}, {"steel-gear-wheel", 4}, {"pipe",2}})
DIR.replace_recipe_ingredients("flamethrower-ammo", {{name = "steel-plate", amount = 2, type = "item"}, {name = "light-oil", amount = 30, type = "fluid"}})
DIR.replace_recipe_ingredients("flamethrower-turret", {{"steel-beam",12},{"electric-engine-unit",2},{"steel-plate-heavy",12},{"gyroscope",1}})
DIR.replace_recipe_ingredients("artillery-turret", {{"chromium-frame-turret",1},{"concrete-block",80},{"chromium-plate-heavy",80},{"chromium-piston",12}})
DIR.replace_recipe_ingredients("radar", {{"iron-frame-large",1},{"copper-cable-heavy",1},{"iron-plate",16},{"copper-coil",4}})
DIR.replace_recipe_ingredients("explosive-rocket", {{"rocket",1}, {"explosives",4}})
DIR.replace_recipe_ingredients("rocket", {{"steel-plate",8}, {"steel-rod",4}, {"electronic-circuit",1}, {"explosives",1}})
DIR.replace_recipe_ingredients("explosives", {{"solid-fuel",3}, {"sulfur",3}, {name = "water", type = "fluid", amount = 10}}, 1, "chemistry", 4)
DIR.replace_recipe_ingredients("cliff-explosives", {{"explosives",10},{"pipe",1}})
DIR.replace_recipe_ingredients("land-mine", {{"steel-plate-heavy",4}, {"explosives",2}}, 4)
DIR.replace_recipe_ingredients("cannon-shell", {{"steel-plate-heavy",6}, {"explosives",1}})
DIR.replace_recipe_ingredients("explosive-cannon-shell", {{"cannon-shell",1}, {"explosives",4}})
DIR.replace_recipe_ingredients("uranium-cannon-shell", {{"cannon-shell",1}, {"uranium-238",1}, {"lead-plate",4}})
DIR.replace_recipe_ingredients("explosive-uranium-cannon-shell", {{"explosive-cannon-shell",1}, {"uranium-238",1}, {"lead-plate",4}})
DIR.replace_recipe_ingredients("artillery-shell", {{"steel-plate-heavy",20}, {"explosives",40}, {"advanced-circuit",1} })
DIR.replace_recipe_ingredients("grenade", {{"steel-plate",2}, {"explosives",1}})
DIR.replace_recipe_ingredients("cluster-grenade", {{"grenade",7}, {"steel-rivet",2}, {"explosives",1}})
DIR.replace_recipe_ingredients("poison-capsule", {{name = "glass", amount = 1, type = "item"}, {name = "sulphur-gas", amount = 200, type = "fluid"}, {name = "explosives", amount = 1, type = "item"}}, 1, "advanced-crafting", 4)
DIR.replace_recipe_ingredients("slowdown-capsule", {{name = "glass", amount = 1, type = "item"}, {name = "lubricant", amount = 200, type = "fluid"}, {name = "explosives", amount = 1, type = "item"}}, 1, "advanced-crafting", 4)
DIR.replace_recipe_ingredients("defender-capsule", {{"iron-plate-heavy",10}, {"firearm-magazine",10}, {"electronic-circuit",15}, {"iron-rotor",5}, {"charged-battery",5}}, 1, "crafting", 10)
DIR.replace_recipe_ingredients("distractor-capsule", {{"steel-plate-heavy",6}, {"helium-laser",3}, {"advanced-circuit",9}, {"flying-robot-frame",3}, {"charged-battery",6}}, 1, "crafting", 12)
DIR.replace_recipe_ingredients("destroyer-capsule", {{"chromium-plate-heavy",10}, {"flying-robot-frame",5}, {"charged-advanced-battery",10}, {"copper-coil",5}, {"processing-unit",15}}, 1, "crafting", 15)
DIR.replace_recipe_ingredients("artillery-targeting-remote", {{"processing-unit",1}})

-- equipment
DIR.replace_recipe_ingredients("light-armor", {{"tin-plate", 20}})
DIR.replace_recipe_ingredients("heavy-armor", {{"bronze-plate-heavy",20}})
DIR.replace_recipe_ingredients("modular-armor", {{"iron-frame-small",1},{"iron-plate-heavy",20},{"rubber",20},{"iron-motor",8},{"computer-mk1",1}})
DIR.replace_recipe_ingredients("power-armor", {{"steel-frame-small",1},{"steel-plate-heavy",40},{"rubber",40},{"electric-engine-unit",8},{"computer-mk2",1}})
DIR.replace_recipe_ingredients("power-armor-mk2", {{"chromium-frame-small",2},{"chromium-plate-heavy",40},{"low-density-structure",40}, {"chromium-engine-unit",3},{"computer-mk3",1}})
DIR.replace_recipe_ingredients("night-vision-equipment", {{"iron-plate",2},{"glass",2},{"electronic-circuit",2},{"rubber",2}})
DIR.replace_recipe_ingredients("belt-immunity-equipment", {{"iron-ingot",2},{"iron-gear-wheel",12}})
DIR.replace_recipe_ingredients("solar-panel-equipment", {{"solar-panel",1}, {"steel-rivet", 4}, {"copper-cable",2}})
DIR.replace_recipe_ingredients("energy-shield-equipment", {{"steel-frame-small",1},{"copper-coil",6},{"computer-mk2",1}})
DIR.replace_recipe_ingredients("energy-shield-mk2-equipment", {{"chromium-frame-small",1},{"field-effector",12},{"copper-coil",12},{"computer-mk3",1}})
DIR.replace_recipe_ingredients("battery-equipment", {{"iron-stick",8},{"iron-plate",4},{"battery",4},{"electronic-circuit",3}})
DIR.replace_recipe_ingredients("battery-mk2-equipment", {{"chromium-plate",8},{"nanoglass",8},{"advanced-battery",5},{"processing-unit",3}})
DIR.replace_recipe_ingredients("exoskeleton-equipment", {{"electric-engine-unit",8},{"steel-piston",4},{"computer-mk2",1},{"steel-rod",24}})
DIR.replace_recipe_ingredients("personal-roboport-equipment", {{"iron-frame-small",2},{"iron-motor",1},{"iron-gear-wheel",4},{"computer-mk1",1}})
DIR.replace_recipe_ingredients("personal-roboport-mk2-equipment", {{"chromium-frame-small",2},{"electric-engine-unit",1},{"brass-gear-wheel",8},{"computer-mk2",1}})
DIR.replace_recipe_ingredients("personal-laser-defense-equipment", {{"helium-laser",1}, {"chromium-frame-small", 2}, {"computer-mk3",1}, {"low-density-structure",8}})
DIR.replace_recipe_ingredients("discharge-defense-equipment", {{"advanced-battery",1}, {"steel-frame-small", 1}, {"copper-coil",3}, {"computer-mk2",1},{"steel-rod",8}})
DIR.replace_recipe_ingredients("fusion-reactor-equipment", {{"computer-mk3",3}, {"chromium-plate",24}, {"lead-plate-special", 24}, {"graphite",16}})

-- misc
DIR.replace_recipe_ingredients("landfill", {{"gravel",15},{"silica",15}}, 1, "mixing", 4)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- cosmetic/organisational tweaks

DIR.change_item_order("accumulator","x")
DIR.change_item_order("artillery-turret","b[turret]-za")
DIR.change_item_order("artillery-targeting-remote","b[turret]-zb")
DIR.change_item_order("assembling-machine-1","aa")
DIR.change_item_order("assembling-machine-2","ab")
DIR.change_item_order("assembling-machine-3","ac")
DIR.change_item_order("beacon", "z")
DIR.change_item_order("belt-immunity-equipment","g")
DIR.change_item_order("cliff-explosives","e[boom]")
DIR.change_item_order("construction-robot","ab")
DIR.change_item_order("electric-mining-drill", "b")
DIR.change_item_order("empty-barrel", "b")
-- DIR.change_item_order("engine-unit", "adc-b")
DIR.change_item_order("exoskeleton-equipment","h")
DIR.change_item_order("explosives","zzz")
DIR.change_item_order("gate","c")
DIR.change_item_order("gun-turret","b[turret]-b")
DIR.change_item_order("lab", "b")
DIR.change_item_order("laser-turret","b[turret]-d")
-- DIR.change_item_order("logistic-chest-passive-provider","ab")
-- DIR.change_item_order("logistic-chest-active-provider","aa")
-- DIR.change_item_order("logistic-chest-buffer","ad")
-- DIR.change_item_order("logistic-chest-requester","ae")
-- DIR.change_item_order("logistic-chest-storage","ac")
DIR.change_item_order("logistic-robot","ac")
DIR.change_item_order("low-density-structure","d")
DIR.change_item_order("offshore-pump", "z[pipe]-b[a]")
DIR.change_item_order("pump", "z[pipe]-c[a]")
DIR.change_item_order("pumpjack", "c")
DIR.change_item_order("radar","z")
DIR.change_item_order("roboport","ae")
DIR.change_item_order("rocket-control-unit","f")
DIR.change_item_order("rocket-silo", "zzz")
DIR.change_item_order("shotgun", "a")
DIR.change_item_order("small-lamp","ac")
DIR.change_item_order("stone-wall","a")
DIR.change_item_order("storage-tank","zc")
DIR.change_item_and_recipe_order("rocket","a[rocket]-a")
DIR.change_item_and_recipe_order("explosive-rocket","a[rocket]-b")
DIR.change_item_and_recipe_order("flamethrower-ammo","a[flame]-a")

DIR.change_item_and_recipe_subgroup("accumulator","ir-battery-entities")
DIR.change_item_and_recipe_subgroup("assembling-machine-1", "ir-machines-production")
DIR.change_item_and_recipe_subgroup("assembling-machine-2", "ir-machines-production")
DIR.change_item_and_recipe_subgroup("assembling-machine-3", "ir-machines-production")
DIR.change_item_and_recipe_subgroup("battery", "ir-vessels")
DIR.change_item_and_recipe_subgroup("beacon", "ir-machines-labs")
DIR.change_item_and_recipe_subgroup("cliff-explosives","ir-tiles")
DIR.change_item_and_recipe_subgroup("construction-robot","logistic-network")
DIR.change_item_and_recipe_subgroup("empty-barrel", "ir-vessels")
DIR.change_item_subgroup("explosives", "ir-fuels")
DIR.change_recipe_subgroup("explosives", "ir-fluid-recipes")
DIR.change_item_and_recipe_subgroup("gate", "ir-walls")
DIR.change_item_and_recipe_subgroup("lab", "ir-machines-labs")
DIR.change_item_and_recipe_subgroup("landfill","ir-tiles")
DIR.change_item_and_recipe_subgroup("logistic-robot","logistic-network")
DIR.change_item_and_recipe_subgroup("low-density-structure","ir-intermediates")
DIR.change_item_and_recipe_subgroup("offshore-pump", "ir-pipes-2")
DIR.change_item_and_recipe_subgroup("pump", "ir-pipes-2")
DIR.change_item_and_recipe_subgroup("pumpjack", "ir-machines-resources")
DIR.change_item_and_recipe_subgroup("radar", "ir-walls")
DIR.change_item_and_recipe_subgroup("concrete","ir-tiles")
DIR.change_item_and_recipe_subgroup("hazard-concrete","ir-tiles")
DIR.change_item_and_recipe_subgroup("refined-concrete","ir-tiles")
DIR.change_item_and_recipe_subgroup("refined-hazard-concrete","ir-tiles")
DIR.change_item_and_recipe_subgroup("roboport","logistic-network")
DIR.change_item_and_recipe_subgroup("rocket-control-unit", "ir-intermediates")
DIR.change_item_and_recipe_subgroup("rocket-silo", "ir-machines-labs")
DIR.change_item_and_recipe_subgroup("small-lamp", "ir-lamps")
DIR.change_item_and_recipe_subgroup("stone-wall", "ir-walls")
DIR.change_item_and_recipe_subgroup("storage-tank","energy-pipe-distribution")
DIR.change_item_and_recipe_subgroup("solar-panel-equipment","equipment-power")
DIR.change_item_and_recipe_subgroup("fusion-reactor-equipment","equipment-power")
DIR.change_item_and_recipe_subgroup("battery-equipment","equipment-power")
DIR.change_item_and_recipe_subgroup("battery-mk2-equipment","equipment-power")
DIR.change_item_and_recipe_subgroup("nuclear-reactor","ir-nuclear-machines")
DIR.change_item_and_recipe_subgroup("heat-pipe","ir-nuclear-machines")
DIR.change_item_and_recipe_subgroup("heat-exchanger","ir-nuclear-machines")
DIR.change_item_and_recipe_subgroup("steam-turbine","ir-nuclear-machines")
DIR.change_item_and_recipe_subgroup("centrifuge","ir-nuclear-machines")

DIR.change_item_subgroup("used-up-uranium-fuel-cell","ir-fuels")

DIR.change_recipe_category("battery", "crafting-with-fluid")
DIR.change_recipe_category("flamethrower-ammo", "advanced-crafting")
-- DIR.change_recipe_category("engine-unit", "crafting")

DIR.change_recipe_subgroup("uranium-processing", "ir-fuels")
DIR.change_item_and_recipe_subgroup("uranium-fuel-cell", "ir-fuels")
DIR.change_recipe_subgroup("nuclear-fuel-reprocessing", "ir-fuels")
DIR.change_recipe_subgroup("kovarex-enrichment-process", "ir-fuels")

DIR.change_recipe_order("uranium-processing", "za")
DIR.change_recipe_order("kovarex-enrichment-process", "zb")
DIR.change_item_and_recipe_order("uranium-fuel-cell", "zc")
DIR.change_recipe_order("nuclear-fuel-reprocessing", "zd")

data.raw.capsule["raw-fish"].order = "zzzz"
data.raw.capsule["raw-fish"].subgroup = "natural"

DIR.replace_item_icon("assembling-machine-1","assembler1")
DIR.replace_item_icon("assembling-machine-2","assembler2")
DIR.replace_item_icon("assembling-machine-3","assembler3")
DIR.replace_item_icon("empty-barrel","barrel")
DIR.replace_item_icon("battery")
DIR.replace_item_icon("crude-oil")
DIR.replace_item_icon("gun-turret","autogun-turret")
DIR.replace_item_icon("heavy-oil")
DIR.replace_item_icon("laser-turret")
DIR.replace_item_icon("light-oil")
DIR.replace_item_icon("lubricant")
DIR.replace_item_icon("medium-electric-pole","medium-steel-pole")
DIR.replace_item_icon("petroleum-gas")
DIR.replace_item_icon("rocket-fuel")
DIR.replace_item_icon("solar-panel")
DIR.replace_item_icon("steam")
DIR.replace_item_icon("sulfuric-acid")
DIR.replace_item_icon("water")

local rockets = {
	["rocket"] = DIR.hues.yellow,
	["explosive-rocket"] = DIR.hues.red,
}

for r,h in pairs(rockets) do
	data.raw.ammo[r].icon = nil
	data.raw.ammo[r].icon_size = nil
	data.raw.ammo[r].icon_mipmaps = nil
	data.raw.ammo[r].icons = {
		{ icon = DIR.get_icon_path("rocket"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		{ icon = DIR.get_icon_path("rocket-mask"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps, tint = DIR.hsva2rgba(h,1,1,0.75) },
	}
end

local r = data.raw.recipe["nuclear-fuel-reprocessing"]
DIR.replace_recipe_ingredients("nuclear-fuel-reprocessing", {{"used-up-uranium-fuel-cell", 1}}, 1, "centrifuging", 2)
r.result = nil
r.result_count = nil
r.results = {
	{ name = "uranium-238", amount_min = 1, amount_max = 2 },
	{ name = "lead-scrap", amount_min = 1, amount_max = 2 },
	{ name = "steel-scrap", amount_min = 1, amount_max = 3 },
	{ name = "concrete-scrap", amount_min = 1, amount_max = 2 },
}

DIR.recipe_shows_products("artillery-shell")
DIR.recipe_shows_products("cannon-shell")
DIR.recipe_shows_products("explosive-cannon-shell")
DIR.recipe_shows_products("uranium-cannon-shell")
DIR.recipe_shows_products("explosive-uranium-cannon-shell")
DIR.recipe_shows_products("rocket")
DIR.recipe_shows_products("explosive-rocket")
DIR.recipe_shows_products("flamethrower-ammo")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- stack sizes

data.raw.item["burner-inserter"].stack_size = 100
data.raw.item["chemical-plant"].stack_size = 50
data.raw.item["fast-inserter"].stack_size = 100
data.raw.item["filter-inserter"].stack_size = 100
data.raw.item["inserter"].stack_size = 100
data.raw.item["long-handed-inserter"].stack_size = 100
data.raw.item["medium-electric-pole"].stack_size = 100
data.raw.item["offshore-pump"].stack_size = 50
data.raw.item["pumpjack"].stack_size = 50
data.raw.item["rail-chain-signal"].stack_size = 100
data.raw.item["rail-signal"].stack_size = 100
data.raw.item["small-lamp"].stack_size = 100
data.raw.item["stack-filter-inserter"].stack_size = 100
data.raw.item["stack-inserter"].stack_size = 100
data.raw.item["train-stop"].stack_size = 50

------------------------------------------------------------------------------------------------------------------------------------------------------
