------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- cryogenics: air separation

local helium_amount = 0.8
local nitrogen_amount = 80
local oxygen_amount = 40

local variants = {
	["air-separation"] = {
		{name = "helium-fluid", type = "fluid", amount = helium_amount * DIR.liquified_gas_ratio, fluidbox_index = 1},
		{name = "oxygen-fluid", type = "fluid", amount = oxygen_amount * DIR.liquified_gas_ratio, fluidbox_index = 2},
		{name = "nitrogen-fluid", type = "fluid", amount = nitrogen_amount * DIR.liquified_gas_ratio, fluidbox_index = 3},
	},
	["air-separation-reversed"] = {
		{name = "helium-fluid", type = "fluid", amount = helium_amount * DIR.liquified_gas_ratio, fluidbox_index = 1},
		{name = "nitrogen-fluid", type = "fluid", amount = nitrogen_amount * DIR.liquified_gas_ratio, fluidbox_index = 2},
		{name = "oxygen-fluid", type = "fluid", amount = oxygen_amount * DIR.liquified_gas_ratio, fluidbox_index = 3},
	},
	["air-separation-oxygen"] = {
		{name = "oxygen-fluid", type = "fluid", amount = oxygen_amount * DIR.liquified_gas_ratio, fluidbox_index = 1},
	},
	["air-separation-nitrogen"] = {
		{name = "nitrogen-fluid", type = "fluid", amount = nitrogen_amount * DIR.liquified_gas_ratio, fluidbox_index = 1},
	},
	["air-separation-helium"] = {
		{name = "helium-fluid", type = "fluid", amount = helium_amount * DIR.liquified_gas_ratio, fluidbox_index = 1},
	},
	["fossil-gas-separation"] = {
		{name = "natural-fluid", type = "fluid", amount = 90 * DIR.liquified_gas_ratio, fluidbox_index = 1},
		{name = "nitrogen-fluid", type = "fluid", amount = 20 * DIR.liquified_gas_ratio, fluidbox_index = 2},
		{name = "helium-fluid", type = "fluid", amount = 10 * DIR.liquified_gas_ratio, fluidbox_index = 3},
	},
	["fossil-gas-separation-reversed"] = {
		{name = "natural-fluid", type = "fluid", amount = 90 * DIR.liquified_gas_ratio, fluidbox_index = 1},
		{name = "helium-fluid", type = "fluid", amount = 10 * DIR.liquified_gas_ratio, fluidbox_index = 2},
		{name = "nitrogen-fluid", type = "fluid", amount = 20 * DIR.liquified_gas_ratio, fluidbox_index = 3},
	},
	["fossil-gas-separation-natural"] = {
		{name = "natural-fluid", type = "fluid", amount = 90 * DIR.liquified_gas_ratio, fluidbox_index = 1},
	},
}

local ingredients = {
	["fossil-gas-separation"] = "fossil-gas",
	["fossil-gas-separation-reversed"] = "fossil-gas",
	["fossil-gas-separation-natural"] = "fossil-gas",
}

local not_hidden = {
	["air-separation"] = true,
	["fossil-gas-separation"] = true,
}

local tints = {
	["fossil-gas-separation"] = {
		tertiary = DIR.hsva2rgba(DIR.materials.helium.hue, DIR.materials.helium.saturation or 1, 0.75, 0.25),
		secondary = DIR.hsva2rgba(DIR.materials.natural.hue, DIR.materials.natural.saturation or 1, 0.75, 0.25),
		primary = DIR.hsva2rgba(DIR.materials.nitrogen.hue, DIR.materials.nitrogen.saturation or 1, 0.75, 0.25),
	},
	["fossil-gas-separation-reversed"] = {
		tertiary = DIR.hsva2rgba(DIR.materials.helium.hue, DIR.materials.helium.saturation or 1, 0.75, 0.25),
		secondary = DIR.hsva2rgba(DIR.materials.natural.hue, DIR.materials.natural.saturation or 1, 0.75, 0.25),
		primary = DIR.hsva2rgba(DIR.materials.nitrogen.hue, DIR.materials.nitrogen.saturation or 1, 0.75, 0.25),
	},
	["fossil-gas-separation-natural"] = {
		tertiary = DIR.hsva2rgba(DIR.materials.helium.hue, DIR.materials.helium.saturation or 1, 0.75, 0.25),
		secondary = DIR.hsva2rgba(DIR.materials.natural.hue, DIR.materials.natural.saturation or 1, 0.75, 0.25),
		primary = DIR.hsva2rgba(DIR.materials.nitrogen.hue, DIR.materials.nitrogen.saturation or 1, 0.75, 0.25),
	},
}

local orders = {
	["fossil-gas-separation"] = "zzzza",
	["fossil-gas-separation-reversed"] = "zzzzb",
	["fossil-gas-separation-natural"] = "zzzzc",
}

local descriptions = {
	["fossil-gas-separation"] = {"recipe-description.air-separation"},
}

local order = 1
for variant,results in pairs(variants) do
	local airbase = {
		type = "recipe",
		name = variant,
		localised_name = {"recipe-name."..variant},
		localised_description = descriptions[variant],
		ingredients = {
			{name = ingredients[variant] or "air-gas", type = "fluid", amount = 120, fluidbox_index = 1},
		},
		results = results,
		category = "air-separation",
		enabled = false,
		energy_required = DIR.standard_smelting_time / 2,
		always_show_products = true,
		show_amount_in_title = false,
		icons = {
			{ icon = DIR.get_icon_path(variant), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		},
		crafting_machine_tint = tints[variant] or {
			tertiary = DIR.hsva2rgba(DIR.materials.oxygen.hue, DIR.materials.oxygen.saturation or 1, 0.75, 0.25),
			secondary = DIR.hsva2rgba((DIR.materials.oxygen.hue+DIR.materials.nitrogen.hue)/2, DIR.materials.oxygen.saturation or 1, 0.75, 0.25),
			primary = DIR.hsva2rgba(DIR.materials.nitrogen.hue, DIR.materials.nitrogen.saturation or 1, 0.75, 0.25),
		},
		order = orders[variant] or "zza-"..order,
		subgroup = "ir-gas",
		hide_from_player_crafting = (not_hidden[variant] ~= true),
	}
	data:extend({airbase})
	order = order + 1
end

------------------------------------------------------------------------------------

-- coke gasification

local tints = DIR.get_crafting_tints_from_hues(0.333,DIR.materials.hydrogen.hue,DIR.materials.hydrogen.hue,0,0,0.75,0.25)

local recipes = {
	coke = {
		item = "solid-fuel",
		amount = 2,
		time_multiplier = 1,
		tints = tints,
	},
}

local gas_amount = DIR.hydrogen_to_base_energy_unit * 12

local order = 7

for name,recipedata in pairs(recipes) do

	local recipe_name = name.."-gasification"
	data:extend({
		{
			name = recipe_name,
			type = "recipe",
			category = "chemistry",
			enabled = false,
			energy_required = DIR.standard_petro_time * recipedata.time_multiplier,
			icon = DIR.get_icon_path(recipe_name),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			crafting_machine_tint = recipedata.tints,
			ingredients = {
				{
					name = "steam",
					amount = gas_amount / 2,
					type = "fluid"
				},
				{
					name = recipedata.item,
					amount = recipedata.amount,
					type = "item",
				},
				{
					name = "platinum-pellet",
					amount = 1,
					type = "item",
				},
			},
			results = {
				{
					name = "hydrogen-gas",
					amount = gas_amount,
					type = "fluid"
				},
				{
					name = "carbon-gas",
					amount = gas_amount / 4,
					type = "fluid",
				},
			},
			allow_decomposition = false,
			subgroup = "fluid-recipes",
			order = "o"..order,
			main_product = nil,
			IR_tech_rebuild_ignore = true,
		}
	})

	order = order + 1

	table.insert(DIR.productivity_limitation, recipe_name)

end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- other hand-made gas recipes follow

------------------------------------------------------------------------------------------------------------------------------------------------------

-- water electrolysis below is balanced correctly - but not really worth it, like real life
-- if potential energy obtained from output hydrogen is balanced to a realistic 80% of the electricity put in,
-- it would take 13.333s to get just 20 hydrogen, because chem plant power input is so low
-- that requires 27 chem plants running electrolysis to keep up with 1 cryogenic plant's demand for making liquid hydrogen (without modules)
-- round to 12s means 24 chem plants per cryo plant and an energy return of 88.89%
-- with 3x speed 3 modules per plant (250%), that becomes recipe speed of 4.8s, 9.6 chem plants per cryo plant, energy return of 71.68%

-- solution: specialist electrolysis module?
-- with 1200% (3x +366%) consumption and speed limited to that recipe, recipe speed becomes 1s, 2 chem plants per cryo plant
-- but more issues: beacons can then be used with efficiency modules to create positive energy loop, and consumption can't be blacklisted on the recipe because the specialist module needs it
-- chem plant animation also runs 12x as fast

-- only real solution is a specialist machine with huge energy consumption that disallows module effects

-- DIR.electrolysis_hydrogen_output = 20
-- DIR.electrolysis_efficiency = 0.8
-- DIR.electrolysis_machine_power = 2
-- DIR.electrolysis_speed = (((DIR.hydrogen_energy_value_MJ/3) * DIR.electrolysis_hydrogen_output) / (DIR.get_scaled_energy_usage(DIR.electrolysis_machine_power).total_as_numeric_MW * DIR.electrolysis_efficiency))
-- log(DIR.electrolysis_speed) 

-- data:extend({
	-- {
		-- type = "recipe",
		-- name = "water-electrolysis",
		-- ingredients = {
			-- {name = "water", type = "fluid", amount = 10},
		-- },
		-- results = {
			-- {name = "hydrogen-gas", type = "fluid", amount = 20},
			-- {name = "oxygen-gas", type = "fluid", amount = 10},
		-- },
		-- category = "chemistry",
		-- enabled = false,
		-- energy_required = 12,
		-- emissions_multiplier = 0,
		-- always_show_products = true,
		-- show_amount_in_title = false,
		-- icons = {
			-- { icon = DIR.get_icon_path("water-electrolysis"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		-- },
		-- order = "zzzz",
		-- subgroup = "ir-gas",
		-- crafting_machine_tint = {
			-- primary = DIR.hsva2rgba(DIR.materials.hydrogen.hue, DIR.materials.hydrogen.saturation or 1, 1),
			-- secondary = DIR.hsva2rgba(DIR.materials.oxygen.hue, DIR.materials.oxygen.saturation or 1, 1),
			-- tertiary = DIR.hsva2rgba(DIR.materials.water.hue, 0.1, 1),
			-- quaternary = DIR.hsva2rgba(DIR.materials.water.hue, 0.05, 1),
		-- },
	-- },
-- })

------------------------------------------------------------------------------------------------------------------------------------------------------