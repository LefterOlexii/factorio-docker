------------------------------------------------------------------------------------------------------------------------------------------------------

-- INCINERATION AND VOIDING

------------------------------------------------------------------------------------------------------------------------------------------------------

-- gas venting

function venting(name,pollution,tint,speed_multiplier)
	if pollution == 1 then pollution = 1.0000000001 end
	if tint == nil then error("Venting: "..name.." has no rgba value") end
	tint = DIR.multiply_colour(tint,1)
	tint.a = tint.a and (tint.a * 0.5) or 0.5
	tint = DIR.get_premultiplied_colour(tint)
	data:extend({{
		type = "recipe",
		name = "vent-"..name,
		localised_name = {"recipe-name.venting", {"fluid-name."..name}},
		category = "venting",
		results = {},
		icons = {
			{
				icon = DIR.get_icon_path("venting-overlay"),
				icon_size = DIR.icon_size,
				icon_mipmaps = DIR.icon_mipmaps,
			},
		},
		subgroup = "ir-venting",
		ingredients = { {type = "fluid", name = name, amount = DIR.voiding_per_cycle * 0.1} },
		hide_from_player_crafting = true,
		energy_required = DIR.standard_voiding_time * (speed_multiplier or 1) * 0.1,
		allow_decomposition = false,
		hide_from_stats = true,
		enabled = true,
		emissions_multiplier = pollution,
		crafting_machine_tint = {primary = tint},
		order = data.raw.fluid[name].order,
	}})
	-- DIR.add_icons_to_recipe(data.raw.recipe["vent-"..name],{{icon = DIR.get_icon_path(name), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- vent (gas)

local ventables = {
	gas = DIR.components.gas.materials,
	cryofluid = DIR.components.cryofluid.materials,
}

for component,materials in pairs(ventables) do
	for _,material in pairs(materials) do
		local rgba = DIR.materials[material].rgba
		local name = DIR.get_item_name(material,component)
		local pollution = DIR.get_fluid_spill_multiplier(name)
		if not (DIR.components[component].ventable_exceptions and DIR.components[component].ventable_exceptions[material]) then
			venting(name, pollution, rgba, (component == "gas") and 1 or (1/DIR.liquified_gas_ratio))
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
