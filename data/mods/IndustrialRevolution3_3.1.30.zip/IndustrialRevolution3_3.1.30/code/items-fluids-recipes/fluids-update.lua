------------------------------------------------------------------------------------------------------------------------------------------------------

-- move fluids & barrelling to the correct technology
-- adjust barrelling amounts
-- prevent filled barrels from being scrappable
-- set a few vanilla fluids as having spill emissions

local function replace_fluids(recipe,amount)
	for _,property in pairs({"ingredients","results"}) do
		if recipe[property] then
			for _,item in pairs(recipe[property]) do
				if item.type == "fluid" then
					item.amount = amount
					item.catalyst_amount = amount
				end
			end
		end
	end
end

for _,fluid in pairs(data.raw.fluid) do
	local empty_recipe_name = "empty-"..fluid.name.."-barrel"
	local fill_recipe_name = "fill-"..fluid.name.."-barrel"
	local empty_recipe = data.raw.recipe[empty_recipe_name]
	local fill_recipe = data.raw.recipe[fill_recipe_name]
	local item = data.raw.item[fluid.name.."-barrel"]
	local tint = {
		primary = {r=1,g=1,b=1,a=1},
	}
	if item and empty_recipe and fill_recipe and fluid.auto_barrel ~= false then
		DIR.remove_unlock_from_tech("fluid-handling", fill_recipe_name)
		DIR.remove_unlock_from_tech("fluid-handling", empty_recipe_name)
		DIR.add_unlock_to_tech("ir-barrelling", fill_recipe_name)
		DIR.add_unlock_to_tech("ir-barrelling", empty_recipe_name)
		replace_fluids(empty_recipe, DIR.fluid_in_barrels)
		replace_fluids(fill_recipe, DIR.fluid_in_barrels)
		empty_recipe.energy_required = DIR.standard_crafting_time * 2
		fill_recipe.energy_required = DIR.standard_crafting_time * 2
		empty_recipe.order = fluid.order
		fill_recipe.order = fluid.order
		empty_recipe.always_show_products = true
		fill_recipe.always_show_products = true
		empty_recipe.allow_as_intermediate = false
		fill_recipe.allow_as_intermediate = false
		empty_recipe.category = "unbarrelling"
		fill_recipe.category = "barrelling"		
		empty_recipe.crafting_machine_tint = tint
		fill_recipe.crafting_machine_tint = tint
		empty_recipe.hide_from_player_crafting = true
		-- style
		item.icons = {
			{
			  icon = DIR.get_icon_path("barrel"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			},
			{
			  icon = DIR.get_icon_path("barrel-mask-side"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			  tint = util.get_color_with_alpha(fluid.base_color, 0.65, true)
			},
			{
			  icon = DIR.get_icon_path("barrel-mask-top"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			  tint = util.get_color_with_alpha(fluid.flow_color, 0.65, true)
			}
		}
		fill_recipe.icons = table.deepcopy(item.icons)
		DIR.add_icons_to_recipe(fill_recipe, data.raw.fluid[fluid.name].icons or {{icon = data.raw.fluid[fluid.name].icon, icon_size = data.raw.fluid[fluid.name].icon_size, icon_mipmaps = data.raw.fluid[fluid.name].icon_mipmaps}}, -1)
		fill_recipe.localised_name = item.localised_name
		empty_recipe.icons = {
			{
			  icon = DIR.get_icon_path("barrel-empty"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			},
			{
			  icon = DIR.get_icon_path("barrel-empty-mask-side"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			  tint = util.get_color_with_alpha(fluid.base_color, 0.65, true)
			},
			{
			  icon = DIR.get_icon_path("barrel-empty-mask-top"),
			  icon_size = DIR.icon_size,
			  icon_mipmaps = DIR.icon_mipmaps,
			  tint = util.get_color_with_alpha(fluid.flow_color, 0.65, true)
			}
		}
		DIR.add_icons_to_recipe(empty_recipe, data.raw.fluid[fluid.name].icons or {{icon = data.raw.fluid[fluid.name].icon, icon_size = data.raw.fluid[fluid.name].icon_size, icon_mipmaps = data.raw.fluid[fluid.name].icon_mipmaps}}, 1)
		empty_recipe.localised_name = {"recipe-name.empty-filled-barrel", {"fluid-name."..fluid.name}}
	end
end

-- add fuel values to barrels

local specific_accelerations = {
	["petroleum-gas"] = DIR.vehicle_fuel_modifier_tiers["iron"].acceleration,
	["ethanol"] = DIR.vehicle_fuel_modifier_tiers["iron"].acceleration,
}
local specific_speeds = {
	["petroleum-gas"] = DIR.vehicle_fuel_modifier_tiers["iron"].top_speed,
	["ethanol"] = DIR.vehicle_fuel_modifier_tiers["iron"].top_speed,
}

for fluid,prototype in pairs(data.raw.fluid) do
	local barrel = data.raw.item[fluid.."-barrel"]
	if prototype.fuel_value and barrel then
		barrel.fuel_value = DIR.format_number_to_units(util.parse_energy(prototype.fuel_value) * DIR.fluid_in_barrels, "J")
		barrel.fuel_category = "barrel"
		barrel.burnt_result = "empty-barrel"
		barrel.fuel_acceleration_multiplier = specific_accelerations[fluid] or data.raw.item["solid-fuel"].fuel_acceleration_multiplier
		barrel.fuel_top_speed_multiplier = specific_speeds[fluid] or data.raw.item["solid-fuel"].fuel_top_speed_multiplier
	end
	if barrel then
		-- barrel.localised_description = DIR.get_container_localised_description("barrelling")
	end
end

for fluid,spille in pairs(DIR.vanilla_polluting_fluids) do
	DIR.set_fluid_spill_multiplier(fluid,spille)
end

------------------------------------------------------------------------------------------------------------------------------------------------------
