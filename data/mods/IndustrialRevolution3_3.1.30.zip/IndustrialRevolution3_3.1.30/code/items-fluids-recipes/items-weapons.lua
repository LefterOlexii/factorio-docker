------------------------------------------------------------------------------------------------------------------------------------------------------

-- it was inevitable

DIR.replace_item_icon("shotgun","blunderbuss")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- more weapons use bullet projectiles now, so range/cooldown have to be matched or ammo gets wasted

local guns = {
	["submachine-gun"] = "magazine",
	["vehicle-machine-gun"] = "magazine",
	["tank-machine-gun"] = "magazine",
	["shotgun"] = "cartridge",
	["combat-shotgun"] = "cartridge",
}

local cooldown_modifiers = {
	["combat-shotgun"] = 0.5,
}

for gun,ammo in pairs(guns) do
	data.raw.gun[gun].attack_parameters.cooldown = DIR.components[ammo].ammo.cooldown * (cooldown_modifiers[gun] or 1)
	data.raw.gun[gun].attack_parameters.range = DIR.components[ammo].ammo.range
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- change those 0.18 spud gun sounds

-- data.raw.gun["shotgun"].attack_parameters.sound = {
    -- variations = {
        -- {
            -- filename = DIR.sound_path.."/shotgun1.ogg",
            -- volume = 0.5
        -- },
        -- {
            -- filename = DIR.sound_path.."/shotgun2.ogg",
            -- volume = 0.5
        -- },
        -- {
            -- filename = DIR.sound_path.."/shotgun3.ogg",
            -- volume = 0.5
        -- },
    -- },
-- }

-- data.raw.gun["combat-shotgun"].attack_parameters.sound = data.raw.gun["shotgun"].attack_parameters.sound

------------------------------------------------------------------------------------------------------------------------------------------------------

-- atomic artillery

local shell = data.raw.ammo["artillery-shell"]

shell.icons = nil
shell.icon = DIR.get_icon_path("artillery-shell")
shell.icon_size = DIR.icon_size
shell.icon_mipmaps = DIR.icon_mipmaps

local a_shell = table.deepcopy(shell)


local reload = 30
a_shell.name = "atomic-artillery-shell"
a_shell.localised_description = {"item-description.atomic-artillery-shell", {"time-symbol-seconds", reload}}
a_shell.ammo_type = {
    action = {
        action_delivery = {
            direction_deviation = 0,
            projectile = "atomic-artillery-projectile",
            range_deviation = 0,
            source_effects = {
                entity_name = "artillery-cannon-muzzle-flash",
                type = "create-explosion"
            },
            starting_speed = 1,
			-- trigger_fired_artillery = true,
            type = "artillery"
        },
        type = "direct"
    },
    category = "atomic-artillery-shell",
    target_type = "position",
}
a_shell.icon = DIR.get_icon_path("atomic-artillery-shell")
a_shell.order = "d[explosive-cannon-shell]-d[b]"
a_shell.reload_time = DIR.seconds_to_ticks(reload)

data:extend({a_shell})
data:extend({
    {
      name = "atomic-artillery-shell",
      type = "ammo-category",
      bonus_gui_order = "z",
    }
})

local gun = data.raw.gun["artillery-wagon-cannon"]
if gun and gun.attack_parameters then
	gun.attack_parameters.ammo_categories = gun.attack_parameters.ammo_categories or (gun.attack_parameters.ammo_category and {gun.attack_parameters.ammo_category}) or {}
	table.insert(gun.attack_parameters.ammo_categories, "atomic-artillery-shell")
end

local a_proj = table.deepcopy(data.raw["artillery-projectile"]["artillery-projectile"])
a_proj.name = "atomic-artillery-projectile"
a_proj.action = table.deepcopy(data.raw.projectile["atomic-rocket"].action)
table.insert(a_proj.action.action_delivery.target_effects,
	{
		type = "script",
		effect_id = "ir-pollution-bomb",
	}
)

data:extend({a_proj})

local r = {
        type = "recipe",
        name = "atomic-artillery-shell",
        results = {
            { type = "item", name = "atomic-artillery-shell", amount = 1 }
        },
        category = "crafting",
        enabled = false,
        show_amount_in_title = false,
        always_show_products = true,
        ingredients = {
            {"artillery-shell",1},
            {"uranium-235",10},
            {"lead-plate",20},
        },
        energy_required = 60,
		icon = DIR.get_icon_path("atomic-artillery-shell"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
    }

data:extend({r})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- add pollution to weapon capsules

for _,capsule in pairs({"poison-capsule","slowdown-capsule"}) do
	local p = data.raw.projectile[capsule]
	if p and p.action and p.action[1] and p.action[1].action_delivery and p.action[1].action_delivery.target_effects then
		table.insert(p.action[1].action_delivery.target_effects, {
			type = "script",
			effect_id = "ir-"..capsule,
		})
	else
		DIR.spam_log("Could not locate target effects for capsule projectile ("..capsule..")", DIR.log_level.warning)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

