------------------------------------------------------------------------------------------------------------------------------------------------------

-- dirty water cleaning

data:extend({
	{
		type = "recipe",
		name = "dirty-water-cleaning",
		order = "zzz",
		subgroup = "pure",
		ingredients = {
			{
				name = "dirty-water",
				type = "fluid",
				amount = DIR.washing_base * DIR.washers_to_cleaners,
				catalyst_amount = DIR.washing_base * DIR.washers_to_cleaners
			}
		},
		results = {
			{
				name = "water",
				type = "fluid",
				amount = DIR.washing_base * DIR.washers_to_cleaners * DIR.washing_ratio,
				catalyst_amount = DIR.washing_base * DIR.washers_to_cleaners * DIR.washing_ratio
			},
			{name = "gravel", type = "item", amount = 1, probability = 0.10},
			{name = "silica", type = "item", amount = 1, probability = 0.10},
			{name = "sulfur", type = "item", amount = 1, probability = 0.10}
		},
		icons = {
			{icon = DIR.get_icon_path("water"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
		},
		category = "cleaning",
		enabled = false,
		energy_required = DIR.components.pure.speed,
		allow_decomposition = false
	}
})

DIR.add_icons_to_recipe(
    data.raw.recipe["dirty-water-cleaning"],
    {{icon = DIR.get_icon_path("dirty-water"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- geothermal

local exchange_rate = DIR.washing_base * DIR.washers_to_cleaners

data:extend({
    {
        name = "geothermal-exchange",
        type = "recipe",
        category = "geothermal-exchange",
        enabled = false,
        energy_required = DIR.components.pure.speed,
        icons = {
            { icon = DIR.get_icon_path("steam"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
        },
        ingredients = {
            {
                name = "dirty-steam",
                amount = exchange_rate,
                type = "fluid",
				minimum_temperature = 200,
            },
            {
                name = "water",
                amount = exchange_rate,
                type = "fluid",
            },
        },
        results = {
            {
                name = "dirty-water",
                amount = exchange_rate,
                type = "fluid",
            },
            {
                name = "steam",
                amount = exchange_rate,
                type = "fluid",
				temperature = 165,
            },
        },
        subgroup = "ir-fuels",
        order = "acb",
		always_show_products = true,
		show_amount_in_title = false,
    }
})

data:extend({
    {
        name = "geothermal-hot-water",
        type = "recipe",
        category = "geothermal-exchange",
        enabled = false,
        energy_required = DIR.components.pure.speed,
        icons = {
            { icon = DIR.get_icon_path("water"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
        },
        ingredients = {
            {
                name = "dirty-steam",
                amount = exchange_rate / 2,
                type = "fluid",
				minimum_temperature = 200,
            },
            {
                name = "water",
                amount = exchange_rate,
				maximum_temperature = 90,
                type = "fluid",
            },
        },
        results = {
            {
                name = "dirty-water",
                amount = exchange_rate / 2,
                type = "fluid",
            },
            {
                name = "water",
                amount = exchange_rate,
                type = "fluid",
				temperature = 90,
            },
        },
        subgroup = "ir-fuels",
        order = "aca",
		always_show_products = true,
		show_amount_in_title = false,
    }
})

DIR.add_icons_to_recipe(
    data.raw.recipe["geothermal-exchange"],
    {{icon = DIR.get_icon_path("geothermal-exchange"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)

DIR.add_icons_to_recipe(
    data.raw.recipe["geothermal-hot-water"],
    {{icon = DIR.get_icon_path("geothermal-exchange"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- warm water, steam

local water_amount = 30
local dj = 0.2 -- kJ
local machine_energy = 900 -- kW
-- local machine_speed = 1.25
local t = (dj * water_amount) / machine_energy -- time to heat water by 1 degree

data:extend({
    {
        name = "electric-hot-water",
		localised_name = {"recipe-name.electric-hot-water"},
        type = "recipe",
        category = "electric-boiler",
        enabled = false,
        energy_required = DIR.nice_round(t * 75, 1) * 2, -- should come out as 1 second
        icons = {
            { icon = DIR.get_icon_path("water"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
        },
        ingredients = {
            {
                name = "water",
                amount = water_amount * 2,
                type = "fluid",
				maximum_temperature = 90,
            },
        },
        results = {
            {
                name = "water",
                amount = water_amount * 2,
                type = "fluid",
				temperature = 90,
            },
        },
        subgroup = "ir-fuels",
        order = "aa",
		always_show_products = true,
		show_amount_in_title = false,
    },
    {
        name = "electric-steam",
		localised_name = {"recipe-name.electric-steam"},
        type = "recipe",
        category = "electric-boiler",
        enabled = false,
        energy_required = DIR.nice_round(t * 150, 1), -- should come out as 1 second
        icons = {
            { icon = DIR.get_icon_path("steam"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
        },
        ingredients = {
            {
                name = "water",
                amount = water_amount,
                type = "fluid",
            },
        },
        results = {
            {
                name = "steam",
                amount = water_amount,
                type = "fluid",
				temperature = 165,
            },
        },
        subgroup = "ir-fuels",
        order = "ab",
		always_show_products = true,
		show_amount_in_title = false,
    },
})

DIR.add_icons_to_recipe(
    data.raw.recipe["electric-hot-water"],
    {{icon = DIR.get_icon_path("heating-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)
DIR.add_icons_to_recipe(
    data.raw.recipe["electric-steam"],
    {{icon = DIR.get_icon_path("heating-overlay"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)


------------------------------------------------------------------------------------------------------------------------------------------------------

-- alternative rubber (easier to manually specify, bends the component system too far)

data:extend({
    {
        name = "rubber-from-ethanol",
		localised_name = {"recipe-name.rubber-from-ethanol"},
        type = "recipe",
        category = "chemistry",
        enabled = false,
        energy_required = 2,
        icons = {
            { icon = DIR.get_icon_path("rubber"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
        },
        ingredients = {
            {
                name = "nickel-pellet",
                amount = 1,
                type = "item",
            },
            {
                name = "steam",
                amount = 20,
                type = "fluid",
            },
            {
                name = "ethanol",
                amount = 20,
                type = "fluid",
            },
        },
        results = {
            {
                name = "rubber",
                amount = 2,
                type = "item",
            },
        },
        subgroup = "wood",
        order = "zzz",
		always_show_products = true,
		show_amount_in_title = false,
		IR_tech_rebuild_ignore_as_provider = true,
    },
})

DIR.add_icons_to_recipe(
    data.raw.recipe["rubber-from-ethanol"],
    {{icon = DIR.get_icon_path("ethanol"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}},
    -1
)

------------------------------------------------------------------------------------------------------------------------------------------------------
