------------------------------------------------------------------------------------------------------------------------------------------------------

-- does what it says on the tin

data:extend({
	{
		name = "carbon-filter",
		type = "item",
		subgroup = "intermediate-product",
		order = "z-f",
		icon = DIR.get_icon_path("carbon-filter"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 100,
	},
	{
        name = "carbon-filter",
        type = "recipe",
        category = "crafting",
		subgroup = "intermediate-product",
		order = "z-f",
        enabled = false,
        ingredients = { 
			{ name = "graphite", type = "item", amount = 1 }, 
			{ name = "gold-foil", type = "item", amount = 2 }, 
		},
        results = {
			{ name = "carbon-filter", type = "item", amount = 4 }, 
		},
		main_product = "carbon-filter",
		show_amount_in_title = false,
		always_show_products = true,
        energy_required = DIR.standard_crafting_time * 2,
    },
    {
        name = "air-purification",
		localised_name = {"recipe-name.air-purification"},
        type = "recipe",
        category = "air-purification",
        subgroup = "ir-gas",
		order = "zz-b",
        hidden = false,
        allow_decomposition = false,
        allow_intermediates = false,
        allow_as_intermediate = false,
        enabled = false,
        ingredients = { { name = "carbon-filter", type = "item", amount = 1 } },
        results = {},
        energy_required = DIR.standard_smelting_time,
		icons = {
			{icon = DIR.get_icon_path("air-purification"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		},
		crafting_machine_tint = {primary = DIR.get_premultiplied_colour(DIR.multiply_colour(DIR.materials.air.rgba,1),0.5)},
	},
    {
        name = "air-compression",
		localised_name = {"recipe-name.air-compression"},
        type = "recipe",
        category = "air-compression",
        subgroup = "ir-gas",
		order = "zz-a",
        hidden = false,
		always_show_made_in = true,
		allow_decomposition = false,
		show_amount_in_title = false,
		always_show_products = true,
        enabled = false,
        ingredients = { { name = "carbon-filter", type = "item", amount = 1 } },
        results = { { name = "air-gas", type = "fluid", amount = 240 } },
        energy_required = DIR.standard_smelting_time,
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------
