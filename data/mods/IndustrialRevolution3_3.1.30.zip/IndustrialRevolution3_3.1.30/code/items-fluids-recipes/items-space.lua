------------------------------------------------------------------------------------------------------------------------------------------------------

-- SPACE and shit

------------------------------------------------------------------------------------------------------------------------------------------------------

-- rocket launches

DIR.replace_recipe_ingredients("rocket-control-unit", {
	{"processing-unit", 1}, 
	{"gyroscope",1}, 
	{"gold-cable",3}
}, 1, "crafting", 4)

DIR.replace_recipe_ingredients("rocket-part", {
	{"steel-hull",10},
	{"rocket-control-unit",10},
	{"hydrogen-canister",5},
	{"oxygen-canister",5},
}, 1, "rocket-building", 4)

DIR.change_item_and_recipe_subgroup("rocket-part", "ir-intermediates")
DIR.change_item_and_recipe_order("rocket-part", "zz")
data.raw.recipe["rocket-part"].hidden = false

-- vanilla satellite

DIR.replace_recipe_ingredients("satellite", {
	{"space-mirror",16},
	{"steel-hull",80},
	{"computer-mk3",4},
	{"solar-assembly",4},
}, 1, "crafting", 60)

data.raw.item["satellite"].stack_size = 1
data.raw.item["satellite"].rocket_launch_product = {"space-science-pack",1000}
DIR.change_item_subgroup("satellite", "ir-intermediates")
DIR.change_item_order("satellite", "zzz-a")
DIR.replace_item_icon("satellite")

data:extend({
    {
        type = "item",
        name = "steel-hull",
        order = "za",
        stack_size = 10,
        icon = DIR.get_icon_path("steel-hull"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "steel-hull",
        result = "steel-hull",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"low-density-structure",4},
            {"chromium-plate-heavy",2},
            {"nanoglass",2},
            {"copper-cable-heavy",2},
        },
        energy_required = DIR.standard_crafting_time * 4,
		show_amount_in_title = false,
		always_show_products = true,
    },
    {
        type = "item",
        name = "space-mirror",
        order = "zb",
        stack_size = 10,
        icon = DIR.get_icon_path("space-mirror"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "space-mirror",
        result = "space-mirror",
        result_count = 1,
        category = "advanced-crafting",
        enabled = false,
        ingredients = {
            {"gold-plate",20},
            {"chromium-rod",12},
            {"diamond-powder",1},
            {"advanced-circuit",1},
        },
        energy_required = DIR.standard_crafting_time * 4,
		show_amount_in_title = false,
		always_show_products = true,
    },
    {
        type = "item",
        name = "solar-assembly",
        order = "zc",
        stack_size = 10,
        icon = DIR.get_icon_path("solar-assembly"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "solar-assembly",
        result = "solar-assembly",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"accumulator",3},
            {"solar-array",8},
            {"chromium-plate-heavy",16},
        },
        energy_required = DIR.standard_crafting_time * 15,
		show_amount_in_title = false,
		always_show_products = true,
    },
    {
        type = "item",
        name = "solar-assembly",
        order = "zc",
        stack_size = 10,
        icon = DIR.get_icon_path("solar-assembly"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "solar-assembly",
        result = "solar-assembly",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"accumulator",3},
            {"solar-array",8},
            {"chromium-plate-heavy",16},
        },
        energy_required = DIR.standard_crafting_time * 15,
		show_amount_in_title = false,
		always_show_products = true,
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- no

local space = data.raw.tool["space-science-pack"]
if space and space.rocket_launch_product and space.rocket_launch_product[1] == "raw-fish" then
	space.rocket_launch_product = nil
end

------------------------------------------------------------------------------------------------------------------------------------------------------
