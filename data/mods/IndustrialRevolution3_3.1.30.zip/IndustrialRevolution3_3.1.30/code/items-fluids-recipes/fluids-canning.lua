------------------------------------------------------------------------------------------------------------------------------------------------------

-- gas canisters

local gases = {
	hydrogen = 1,
	oxygen = 1,
	nitrogen = 1,
	helium = 1,
	carbon = 1,
	natural = 1,
}

local fuel_properties = {
	natural = {
		fuel_value = "128MJ",
		burnt_result = "empty-canister",
		fuel_category = "canister",
		fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["steel"].acceleration,
		fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["steel"].top_speed,
	},
}

for gas,amount_multiplier in pairs(gases) do
	local tint = {
		secondary = {r=1,g=1,b=1,a=1},
	}
	local order = data.raw.fluid[gas.."-gas"].order
	data:extend({
		{
			type = "item",
			name = gas.."-canister",
			localised_name = {"item-name.filled-canister",{"fluid-name."..gas.."-fluid"}},
			-- localised_description = DIR.get_container_localised_description("barrelling"),
			order = "zzz-"..order,
			stack_size = 10,
			icon = DIR.get_icon_path(gas.."-canister"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			subgroup = "ir-canisters",
			fuel_value = fuel_properties[gas] and fuel_properties[gas].fuel_value,
			burnt_result = fuel_properties[gas] and fuel_properties[gas].burnt_result,
			fuel_category = fuel_properties[gas] and fuel_properties[gas].fuel_category,
			fuel_acceleration_multiplier = fuel_properties[gas] and fuel_properties[gas].fuel_acceleration_multiplier,
			fuel_top_speed_multiplier = fuel_properties[gas] and fuel_properties[gas].fuel_top_speed_multiplier,
		},
		{
			type = "recipe",
			name = "fill-"..gas.."-canister",
			subgroup = "ir-canisters",
			order = "c-"..order,
			ingredients = {
				{name = "empty-canister", type = "item", amount = 1},
				{name = gas.."-fluid", type = "fluid", amount = DIR.gas_amount_in_canisters * amount_multiplier},
			},
			results = {
				{name = gas.."-canister", type = "item", amount = 1},
			},
			icons = {
				{icon = DIR.get_icon_path(gas.."-canister"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
			},
			category = "barrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time * 2,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
			-- hide_from_player_crafting = true,
		},
		{
			type = "recipe",
			name = "empty-"..gas.."-canister",
			localised_name = {"recipe-name.empty-filled-canister",{"fluid-name."..gas.."-fluid"}},
			subgroup = "ir-canisters",
			order = "z-"..order,
			ingredients = {
				{name = gas.."-canister", type = "item", amount = 1},
			},
			results = {
				{name = "empty-canister", type = "item", amount = 1},
				{name = gas.."-fluid", type = "fluid", amount = DIR.gas_amount_in_canisters * amount_multiplier},
			},
			icons = {
				{icon = DIR.get_icon_path("empty-"..gas.."-canister"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
			},
			category = "unbarrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time * 2,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
			hide_from_player_crafting = true,
		},
	})
	DIR.add_icons_to_recipe(data.raw.recipe["fill-"..gas.."-canister"], {{icon = DIR.get_icon_path(gas.."-fluid"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper steam cells
-- TODO: fold this into canisters below

local gases = {
	water = 100 -- 3 MJ
}

for gas,amount in pairs(gases) do
	local tint = {
		tertiary = {r=1,g=1,b=1,a=1},
	}
	local fluid_name = DIR.get_item_name(gas,"gas")
	local order = data.raw.fluid[fluid_name].order
	data:extend({
		{
			type = "item",
			name = fluid_name.."-cell",
			localised_name = {"item-name.filled-cell",{"fluid-name."..fluid_name}},
			-- localised_description = DIR.get_container_localised_description("steam-barrelling"),
			order = "a",
			stack_size = 50,
			icon = DIR.get_icon_path(fluid_name.."-cell"),
			icon_size = DIR.icon_size,
			icon_mipmaps = DIR.icon_mipmaps,
			subgroup = "ir-canisters",
			burnt_result = "empty-cell",
			fuel_value = (amount * 30) .."kJ",
			fuel_category = "steam-cell",
		},
		{
			type = "recipe",
			name = "fill-"..fluid_name.."-cell",
			subgroup = "ir-canisters",
			order = "aa",
			ingredients = {
				{name = "empty-cell", type = "item", amount = 1},
				{name = fluid_name, type = "fluid", amount = amount , minimum_temperature = 165},
			},
			results = {
				{name = fluid_name.."-cell", type = "item", amount = 1},
			},
			icons = {
				{icon = DIR.get_icon_path(fluid_name.."-cell"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
			},
			category = "steam-barrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
		},
		{
			type = "recipe",
			name = "empty-"..fluid_name.."-cell",
			localised_name = {"recipe-name.empty-filled-cell",{"fluid-name."..fluid_name}},
			subgroup = "ir-canisters",
			order = "ab",
			ingredients = {
				{name = fluid_name.."-cell", type = "item", amount = 1},
			},
			results = {
				{name = "empty-cell", type = "item", amount = 1},
				{name = fluid_name, type = "fluid", amount = amount, temperature = 165},
			},
			icons = {
				{icon = DIR.get_icon_path("empty-"..fluid_name.."-cell"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
			},
			category = "steam-unbarrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
			hide_from_player_crafting = true,
		},
	})
	DIR.add_icons_to_recipe(data.raw.recipe["fill-"..fluid_name.."-cell"], {{icon = DIR.get_icon_path(fluid_name), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)

end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron canisters

local fluids = {
	steam = 200,
	["petroleum-gas"] = 30,
}

local fuel_properties = {
	steam = {
		fuel_value = "6MJ",
		burnt_result = "empty-iron-canister",
		fuel_category = "steam-cell",
		temperature = 165,
	},
	["petroleum-gas"] = {
		fuel_value = "12MJ",
		burnt_result = "empty-iron-canister",
		fuel_category = "canister",
		fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["iron"].acceleration,
		fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["iron"].top_speed,
	},
}

for fluid,amount in pairs(fluids) do
	local tint = {
		quaternary = {r=1,g=1,b=1,a=1},
	}
	local order = data.raw.fluid[fluid].order
	data:extend({
		{
			type = "item",
			name = fluid.."-iron-canister",
			localised_name = {"item-name.filled-iron-canister",{"fluid-name."..fluid}},
			-- localised_description = DIR.get_container_localised_description((fluid == "steam") and "steam-barrelling" or "barrelling"),
			order = "b-"..order,
			stack_size = 50,
			icons = {
				{ icon = DIR.get_icon_path(fluid.."-iron-canister"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
			},
			subgroup = "ir-canisters",
			fuel_value = fuel_properties[fluid] and fuel_properties[fluid].fuel_value,
			burnt_result = fuel_properties[fluid] and fuel_properties[fluid].burnt_result,
			fuel_category = fuel_properties[fluid] and fuel_properties[fluid].fuel_category,
			fuel_acceleration_multiplier = fuel_properties[fluid] and fuel_properties[fluid].fuel_acceleration_multiplier,
			fuel_top_speed_multiplier = fuel_properties[fluid] and fuel_properties[fluid].fuel_top_speed_multiplier,
		},
		{
			type = "recipe",
			name = "fill-"..fluid.."-iron-canister",
			subgroup = "ir-canisters",
			order = "ba-"..order,
			ingredients = {
				{name = "empty-iron-canister", type = "item", amount = 1},
				{name = fluid, type = "fluid", amount = amount , minimum_temperature = fuel_properties[fluid] and fuel_properties[fluid].temperature},
			},
			results = {
				{name = fluid.."-iron-canister", type = "item", amount = 1},
			},
			icons = {
				{ icon = DIR.get_icon_path(fluid.."-iron-canister"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
			},
			category = (fluid == "steam") and "steam-barrelling" or "barrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time * 2,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
		},
		{
			type = "recipe",
			name = "empty-"..fluid.."-iron-canister",
			localised_name = {"recipe-name.empty-filled-canister",{"fluid-name."..fluid}},
			subgroup = "ir-canisters",
			order = "bb-"..order,
			ingredients = {
				{name = fluid.."-iron-canister", type = "item", amount = 1},
			},
			results = {
				{name = "empty-iron-canister", type = "item", amount = 1},
				{name = fluid, type = "fluid", amount = amount, temperature = fuel_properties[fluid] and fuel_properties[fluid].temperature},
			},
			icons = {
				{icon = DIR.get_icon_path("empty-"..fluid.."-iron-canister"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps},
			},
			category = (fluid == "steam") and "steam-unbarrelling" or "unbarrelling",
			enabled = false,
			energy_required = DIR.standard_crafting_time * 2,
			always_show_made_in = true,
			allow_decomposition = false,
			show_amount_in_title = false,
			always_show_products = true,
			IR_tech_rebuild_ignore = true,
			crafting_machine_tint = tint,
			hide_from_player_crafting = true,
		},
	})
	DIR.add_icons_to_recipe(data.raw.recipe["fill-"..fluid.."-iron-canister"], {{icon = DIR.get_icon_path(fluid), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
end


------------------------------------------------------------------------------------------------------------------------------------------------------