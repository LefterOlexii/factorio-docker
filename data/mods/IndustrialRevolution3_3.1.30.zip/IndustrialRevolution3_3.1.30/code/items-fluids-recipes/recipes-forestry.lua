------------------------------------------------------------------------------------------------------------------------------------------------------

-- forestry 3.0.0

for ordera,suffix in pairs{"", "-fertiliser"} do
	for rate = 0,DIR.max_forestry_trees do
		for orderb,wood in pairs({"wood", "rubber-wood"}) do
			local name = string.format("forestry-%s%s-%02d", wood, suffix, rate)
			local bars = math.floor((rate/DIR.max_forestry_trees)*4)
			local p = rate/DIR.max_forestry_trees
			local scaled_fluid_amount = math.floor(DIR.forestry_fluid_minimum*10*p)/10
			local input_fluid_amount = DIR.forestry_fluid_minimum + scaled_fluid_amount
			local ingredients = (suffix == "") and {
				{type = "fluid", name = "water", amount = input_fluid_amount},
			} or {
				{type = "fluid", name = "liquid-fertiliser", amount = input_fluid_amount}, -- 3.1.15: must be in this order 
				{type = "fluid", name = "carbon-gas", amount = input_fluid_amount},
			}
			local results = (p == 0) and {} or ((suffix == "") and {
				{type = "item", name = wood, amount = 1, probability = p},
			} or {
				{type = "item", name = wood, amount = 1, probability = p},
				{type = "fluid", name = "oxygen-gas", amount = input_fluid_amount},
			})
			data:extend({
				{
					type = "recipe",
					name = name,
					localised_name = {"item-name."..wood},
					category = (suffix == "") and "forestry" or "forestry-advanced",
					subgroup = "wood",
					order = "a"..ordera.."-"..orderb.."-"..string.format("%02d",rate),
					hidden = true,
					allow_decomposition = false,
					show_amount_in_title = false,
					always_show_products = true,
					enabled = true,
					ingredients = ingredients,
					results = results,
					energy_required = (suffix == "") and 12 or 6,
					icons = {
						{ icon =  DIR.get_icon_path((rate > 0) and string.format("forestry-%s-%d", wood, bars) or "splitter-blocker"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
					},
					emissions_multiplier = rate/DIR.max_forestry_trees,
					IR_tech_rebuild_ignore = true,
				}
			})
		end
	end
end

for order,wood in pairs({"wood","rubber-wood"}) do
	for _,suffix in pairs{"", "-fertiliser"} do
		local name = string.format("forestry-%s%s-%02d", wood, suffix, DIR.max_forestry_trees)
		local fake = table.deepcopy(data.raw.recipe[name])
		fake.name = "forestry-"..wood..suffix.."-example"
		fake.icons = {
			{ icon = DIR.get_icon_path(wood), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps },
		}
		DIR.add_icons_to_recipe(fake, {{icon = DIR.get_icon_path((suffix == "") and "water" or "liquid-fertiliser"), icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps}}, -1)
		fake.hidden = false
		fake.enabled = false
		fake.localised_description = (suffix == "") and {"recipe-description.forestry-recipes"} or {"recipe-description.advanced-forestry-recipes"},
		data:extend({fake})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
