------------------------------------------------------------------------------------------------------------------------------------------------------

-- scatterbot capsules

data:extend({
    {
        type = "capsule",
        name = "scatterbot-capsule",
        icon = DIR.get_icon_path("scatterbot"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
		order = "d[a-scatterbot]",
		stack_size = 50,
		subgroup = "capsule",
        capsule_action = {
            attack_parameters = {
				activation_type = "throw",
                ammo_category = "capsule",
                ammo_type = {
                    action = {
                        action_delivery = {
                            projectile = "scatterbot-capsule",
                            starting_speed = 0.3,
                            type = "projectile"
                        },
                        type = "direct"
                    },
                    category = "capsule",
                    target_type = "position"
                },
                cooldown = 15,
                projectile_creation_distance = 0.6,
                range = 20,
                type = "projectile"
            },
            type = "throw"
        },
    },
    {
        type = "recipe",
        name = "scatterbot-capsule",
        category = "crafting",
        enabled = false,
        ingredients = {
            {"copper-rotor",5},
            {"bronze-plate-heavy",5},
            {"copper-plate",5},
            {"bronze-cartridge",10},
        },
        result = "scatterbot-capsule",
        result_count = 1,
        energy_required = DIR.standard_crafting_time * 10,
    },
    {
        name = "scatterbot-capsule",
        type = "projectile",
        acceleration = 0.005,
        action = {
            action_delivery = {
                target_effects = {
                    {
                        entity_name = "scatterbot",
                        show_in_tooltip = true,
                        type = "create-entity"
                    }
                },
                type = "instant"
            },
            type = "direct"
        },
        animation = {
            filename = DIR.entities_path_2.."/bots/scatterbot-base.png",
            frame_count = 1,
            line_length = 16,
            height = 128,
            priority = "high",
            width = 128,
            scale = 0.5,
            y = 128,
        },
        enable_drawing_with_mask = false,
        flags = {
            "not-on-map"
        },
        shadow = {
            filename = DIR.entities_path_2.."/bots/scatterbot-shadow.png",
            frame_count = 1,
            line_length = 16,
            height = 128,
            priority = "high",
            width = 192,
            scale = 0.5,
            draw_as_shadow = true,
            shift = {1.0,0.6},
            y = 128,
        },
        smoke = {
            {
                deviation = {
                    0.15,
                    0.15
                },
                frequency = 1,
                name = "smoke-fast",
                position = {
                    0,
                    0
                },
                starting_frame = 3,
                starting_frame_deviation = 5,
                starting_frame_speed_deviation = 5
            }
        },
    }
})

-- lampbot capsules

data:extend({
    {
        type = "capsule",
        name = "lampbot-capsule",
        icon = DIR.get_icon_path("lampbot"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
		order = "b",
		stack_size = 50,
		subgroup = "ir-lamps",
        capsule_action = {
            attack_parameters = {
				activation_type = "throw",
                ammo_category = "capsule",
                ammo_type = {
                    action = {
                        action_delivery = {
                            projectile = "lampbot-capsule",
                            starting_speed = 0.3,
                            type = "projectile"
                        },
                        type = "direct"
                    },
                    category = "capsule",
                    target_type = "position"
                },
                cooldown = 30,
                projectile_creation_distance = 0.6,
                range = 10,
                type = "projectile"
            },
            type = "throw"
        },
    },
    {
        type = "recipe",
        name = "lampbot-capsule",
        category = "crafting",
        enabled = false,
        ingredients = {
            {"iron-rotor",1},
            {"iron-plate",4},
            {"small-lamp",1},
            {"charged-battery",1},
        },
        result = "lampbot-capsule",
        result_count = 1,
        energy_required = DIR.standard_crafting_time * 2,
    },
    {
        name = "lampbot-capsule",
        type = "projectile",
        acceleration = 0.005,
        action = {
            action_delivery = {
                target_effects = {
                    {
                        entity_name = "lampbot",
                        show_in_tooltip = true,
                        type = "create-entity",
						trigger_created_entity = true,
                    }
                },
                type = "instant"
            },
            type = "direct"
        },
        animation = {
            filename = DIR.entities_path_2.."/bots/lampbot-base.png",
            frame_count = 1,
            line_length = 8,
            height = 96,
            priority = "high",
            width = 96,
            scale = 0.5,
        },
        enable_drawing_with_mask = false,
        flags = {
            "not-on-map"
        },
        shadow = {
            filename = DIR.entities_path_2.."/bots/lampbot-shadow.png",
            frame_count = 1,
            line_length = 8,
            height = 96,
            priority = "high",
            width = 128,
            scale = 0.5,
            draw_as_shadow = true,
            shift = {1.0,0.6},
        },
        smoke = {
            {
                deviation = {
                    0.15,
                    0.15
                },
                frequency = 1,
                name = "smoke-fast",
                position = {
                    0,
                    0
                },
                starting_frame = 3,
                starting_frame_deviation = 5,
                starting_frame_speed_deviation = 5
            }
        },
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- let's not have to click 20 times maybe?
-- set all (following) combat bot capsules to provide 5 bots

local offsets = {{0,0},{0.7,0.7},{-0.7,0.7},{0.7,-0.7},{-0.7,-0.7}}

local bots = {"scatterbot","defender","destroyer"}
for _,bot in pairs(bots) do
	local projectile = data.raw.projectile[bot.."-capsule"]
	if not projectile then error("No such bot projectile as "..bot.."-capsule") end
	for _,effect in pairs(projectile.action.action_delivery.target_effects) do
		if type(effect) == "table" and effect.type == "create-entity" then effect.offsets = offsets end
	end
	local capsule = data.raw.projectile[bot.."-capsule"]
	if not capsule then error("No such bot capsule as "..bot.."-capsule") end
	capsule.stack_size = 50
end

------------------------------------------------------------------------------------------------------------------------------------------------------
