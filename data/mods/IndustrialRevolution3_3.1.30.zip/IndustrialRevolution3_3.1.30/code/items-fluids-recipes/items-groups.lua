------------------------------------------------------------------------------------------------------------------------------------------------------

-- basic product subgroups

for component,componentdata in pairs(DIR.components) do
	local tabgroup = componentdata.tabgroup or "ir-basics"
	local subgroup = componentdata.subgroup or component
	if not data.raw["item-subgroup"][subgroup] then 
		data:extend({{
			type = "item-subgroup",
			name = subgroup,
			group = tabgroup,
			order = componentdata.order,
		}})
	end
	if componentdata.subgroup_source_exceptions then
		for source,exception in pairs(componentdata.subgroup_source_exceptions) do
			if not data.raw["item-subgroup"][exception] then 
				data:extend({{
					type = "item-subgroup",
					name = exception,
					group = componentdata.tabgroup_source_exceptions and componentdata.tabgroup_source_exceptions[source] or tabgroup,
					order = "c-"..componentdata.order,
				}})
			end
		end
	end
	if componentdata.item_subgroup and not data.raw["item-subgroup"][componentdata.item_subgroup] then
		data:extend({{
			type = "item-subgroup",
			name = componentdata.item_subgroup,
			group = tabgroup,
			order = componentdata.order,
		}})
	end
end
for component,componentdata in pairs(DIR.components) do
	if componentdata.subgroup_exceptions then
		local tabgroup = componentdata.tabgroup or "ir-basics"
		for material,subgroupx in pairs(componentdata.subgroup_exceptions) do
			if not data.raw["item-subgroup"][subgroupx] then
				data:extend({{
					type = "item-subgroup",
					name = subgroupx,
					group = tabgroup,
					order = componentdata.order,
				}})
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- crafting categories

for _,category in pairs(DIR.crafting_categories) do
    data:extend({
        {
            type = "recipe-category",
            name = category,
        }
    })
end

for _,category in pairs(DIR.tiered_categories) do
	for i=2,DIR.max_tiers do
		data:extend({
			{
				type = "recipe-category",
				name = category.."-"..i,
			}
		})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- tidy up messy groups/subgroups

data.raw["item-group"]["intermediate-products"].icon = DIR.get_icon_path("intermediate-products-tab", DIR.high_icon_size)
data.raw["item-group"]["intermediate-products"].icon_size = DIR.high_icon_size
data.raw["item-group"]["intermediate-products"].icon_mipmaps = DIR.high_icon_mipmaps
data.raw["item-subgroup"]["raw-resource"].order = "b"
data.raw["item-subgroup"]["raw-material"].order = "c"
data.raw["item-subgroup"]["intermediate-product"].order = "d"
data.raw["item-subgroup"]["science-pack"].order = "g"
data.raw["item-subgroup"]["fluid-recipes"].order = "x" 
data.raw["item-subgroup"]["fluid-recipes"].group = "ir-processing" 
data.raw["item-subgroup"]["fill-barrel"].order = "h"
data.raw["item-subgroup"]["empty-barrel"].order = "i"
data.raw["item-subgroup"]["barrel"].order = "de"
data.raw["item-subgroup"]["equipment"].order = "eb"
data.raw["item-subgroup"]["module"].order = "y"

-- production group

local tab = data.raw["item-group"]["production"]
if tab then
	tab.icon = DIR.get_icon_path("assembler2",DIR.high_icon_size)
	tab.icon_size = DIR.high_icon_size
	tab.icon_mipmaps = DIR.high_icon_mipmaps
	tab.icons = nil
end

-- blunderbuss combat group

local tab = data.raw["item-group"]["combat"]
if tab then
	tab.icon = DIR.get_icon_path("blunderbuss",DIR.high_icon_size)
	tab.icon_size = DIR.high_icon_size
	tab.icon_mipmaps = DIR.high_icon_mipmaps
	tab.icons = nil
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- handmade item groups, subgroups

data:extend({
    {
        type = "item-group",
        name = "ir-processing",
        order = "bx",
        icon = DIR.get_icon_path("processing-tab", DIR.high_icon_size),
        icon_size = DIR.high_icon_size,
		icon_mipmaps = DIR.high_icon_mipmaps,
    },
    {
        type = "item-group",
        name = "ir-basics",
        order = "bz",
        icon = DIR.get_icon_path("basic-products-tab", DIR.high_icon_size),
        icon_size = DIR.high_icon_size,
		icon_mipmaps = DIR.high_icon_mipmaps,
    },
	{
		type = "item-group",
		name = "ir-molten",
		order = "by",
		icon = DIR.get_icon_path("blast-arc-furnaces", DIR.high_icon_size),
        icon_size = DIR.high_icon_size,
		icon_mipmaps = DIR.high_icon_mipmaps,
	},
	{
		type = "item-group",
		name = "ir-reclamation",
		order = "zz",
		icon = DIR.get_icon_path("scrapping", DIR.high_icon_size),
        icon_size = DIR.high_icon_size,
		icon_mipmaps = DIR.high_icon_mipmaps,
	},
	{
		type = "item-group",
		name = "ir-lighting",
		order = "zzz",
		icon = DIR.get_icon_path("lighting", DIR.high_icon_size),
        icon_size = DIR.high_icon_size,
		icon_mipmaps = DIR.high_icon_mipmaps,
	},
    {
        type = "item-subgroup",
        name = "ir-battery-entities",
        group = "production",
        order = "bb",
    },
    {
        type = "item-subgroup",
        name = "wood",
        group = "ir-processing",
        order = "a",
    },
    {
        type = "item-subgroup",
        name = "alloy",
        group = "ir-processing",
        order = "in-z",
    },
    {
        type = "item-subgroup",
        name = "scrapping",
        group = "ir-reclamation",
        order = "b",
    },
    {
        type = "item-subgroup",
        name = "melting",
        group = "ir-reclamation",
        order = "a",
    },
	{
		type = "item-subgroup",
		name = "ir-electronics",
		group = "intermediate-products",
		order = "aa",
	},
	{
		type = "item-subgroup",
		name = "ir-electronics-2",
		group = "intermediate-products",
		order = "ab",
	},
	{
		type = "item-subgroup",
		name = "ir-module-reversed",
		group = "production",
		order = "z",
	},
	{
		type = "item-subgroup",
		name = "ir-filters",
		group = "production",
		order = "z",
	},
	{
		type = "item-subgroup",
		name = "virtual-signal-map-markers",
		group = "signals",
		order = "zzzzz",
	},
	{
		type = "item-subgroup",
		name = "ir-tiles",
		group = "intermediate-products",
		order = "zzzzzzz",
	},
	{
		type = "item-subgroup",
		name = "ir-trees",
		group = "production",
		order = "zzzb",
	},
	{
		type = "item-subgroup",
		name = "ir-walls",
		group = "combat",
		order = "zzz",
	},
	{
		type = "item-subgroup",
		name = "ir-pipes",
		group = "logistics",
		order = "dba",
	},
	{
		type = "item-subgroup",
		name = "ir-pipes-2",
		group = "logistics",
		order = "dbb",
	},
	{
		type = "item-subgroup",
		name = "logistic-network-2",
		group = "logistics",
		order = "gb",
	},
	{
		type = "item-subgroup",
		name = "ir-lamps",
		group = "logistics",
		order = "hb",
	},
	{
		type = "item-subgroup",
		name = "ir-ammo",
		group = "combat",
		order = "ab",
	},
	{
		type = "item-subgroup",
		name = "ir-fluid-recipes",
		group = "ir-processing",
		order = "y",
	},
	{
		type = "item-subgroup",
		name = "ir-intermediates",
		group = "intermediate-products",
		order = "db",
	},
	{
		type = "item-subgroup",
		name = "ir-batteries",
		group = "intermediate-products",
		order = "dc",
	},
	{
		type = "item-subgroup",
		name = "ir-vessels",
		group = "intermediate-products",
		order = "dd",
	},
	{
		type = "item-subgroup",
		name = "ir-glows",
		group = "ir-lighting",
		order = "a",
	},
	{
		type = "item-subgroup",
		name = "natural",
		group = "ir-processing",
		order = "0",
	},
	{
		type = "item-subgroup",
		name = "equipment-power",
		group = "combat",
		order = "ea",
	},
	{
		type = "item-subgroup",
		name = "ir-gas",
		group = "ir-processing",
		order = "z",
	},
	{
		type = "item-subgroup",
		name = "ir-canisters",
		group = "intermediate-products",
		order = "i",
	},
	{
		type = "item-subgroup",
		name = "ir-nuclear-machines",
		group = "production",
		order = "w",
	},
	{
		type = "item-subgroup",
		name = "ir-fuels",
		group = "ir-processing",
		order = "zzz",
	},
	{
		type = "item-subgroup",
		name = "blast-smelting",
		group = "ir-molten",
		order = "a",
	},
	{
		type = "item-subgroup",
		name = "ir-flaring",
		group = "ir-molten",
		order = "zzzzzb",
	},
	{
		type = "item-subgroup",
		name = "ir-venting",
		group = "ir-molten",
		order = "zzzzza",
	},
	{
		type = "item-subgroup",
		name = "ir-explosions",
		group = "effects",
		order = "deb"
	},
})

-- machine subgroups

local count = 1
for _,machinedata in pairs(DIR.machines) do
	if not data.raw["item-subgroup"][machinedata.subgroup] then
		data:extend {{
			type = "item-subgroup",
			name = machinedata.subgroup,
			order = "ac"..count,
			group = "production",
		}}
		count = count + 1
	end
end

-- material-based subgroups per tabgroup

for material,materialdata in pairs(DIR.materials) do
	for _,group in pairs(data.raw["item-group"]) do
		data:extend({{
			type = "item-subgroup",
			name = group.name.."-"..material,
			group = group.name,
			order = "b-"..materialdata.order,
		}})
	end
end

-- component-based subgroups per tabgroup

for component,componentdata in pairs(DIR.components) do
	for _,group in pairs(data.raw["item-group"]) do
		data:extend({{
			type = "item-subgroup",
			name = group.name.."-"..component,
			group = group.name,
			order = "a-"..(componentdata.order or "a"),
		}})
	end
end


------------------------------------------------------------------------------------------------------------------------------------------------------
