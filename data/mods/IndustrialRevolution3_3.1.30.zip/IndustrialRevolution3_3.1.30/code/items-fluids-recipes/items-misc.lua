------------------------------------------------------------------------------------------------------------------------------------------------------

-- gyroscope

data:extend({
    {
        type = "item",
        name = "gyroscope",
        stack_size = 100,
        icon = DIR.get_icon_path("gyroscope"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-motors",
        order = "adz",
    },
    {
        type = "recipe",
        name = "gyroscope",
        result = "gyroscope",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"electric-engine-unit",1},
            {"steel-rod",6},
            {"steel-gear-wheel",3},
            {"electronic-circuit",3},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 3,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- effector

data:extend({
    {
        type = "item",
        name = "field-effector",
        order = "c",
        stack_size = 50,
        icon = DIR.get_icon_path("field-effector"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "field-effector",
        result = "field-effector",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"electrum-gem-charged",1},
            {"electrum-plate-special",1},
            {"carbon-foil",6},
            {"processing-unit",1},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 5,
        crafting_machine_tint = DIR.get_crafting_tints_from_hue(DIR.tier_hues[3],DIR.get_saturation(DIR.tier_hues[3]))
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- graphite electrode

data:extend({
    {
        type = "item",
        name = "graphite-electrode",
        order = "z-f",
        stack_size = 50,
        icon = DIR.get_icon_path("graphite-electrode"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "intermediate-product",
    },
    {
        type = "recipe",
        name = "graphite-electrode",
        result = "graphite-electrode",
        result_count = 1,
        category = "advanced-crafting",
        enabled = false,
        ingredients = {
            {"graphite",32},
            {"copper-rod",8},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 8,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- quantum ring

data:extend({
    {
        type = "item",
        name = "quantum-ring",
        order = "e",
        stack_size = 50,
        icon = DIR.get_icon_path("quantum-ring"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-intermediates",
    },
    {
        type = "recipe",
        name = "quantum-ring",
        result = "quantum-ring",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {name = "carbon-coil", type = "item", amount = 4},
            {name = "field-effector", type = "item", amount = 16},
            {name = "electrum-plate-special", type = "item", amount = 32},
            {name = "nanoglass", type = "item", amount = 32},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 12,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- junction box

data:extend({
    {
        type = "item",
        name = "junction-box",
        order = "q-f",
        stack_size = 50,
        icon = DIR.get_icon_path("junction-box"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "intermediate-product",
    },
    {
        type = "recipe",
        name = "junction-box",
        result = "junction-box",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"steel-frame-small",1},
            {"advanced-circuit",1},
            {"copper-cable-heavy",4},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 3,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- heatsink

-- data:extend({
-- {
-- type = "item",
-- name = "copper-heatsink",
-- order = "z",
-- stack_size = 50,
-- icon = DIR.get_icon_path("copper-heatsink"),
-- icon_size = DIR.icon_size,
-- icon_mipmaps = DIR.icon_mipmaps,
-- subgroup = "ir-electronics",
-- },
-- {
-- type = "recipe",
-- name = "copper-heatsink",
-- result = "copper-heatsink",
-- result_count = 1,
-- category = "crafting",
-- subgroup = "ir-electronics",
-- order = "z",
-- enabled = false,
-- ingredients = {
-- {"copper-foam",1},
-- {"copper-plate",2},
-- {"copper-rivet",1},
-- },
-- energy_required = DIR.standard_crafting_time * 2,
-- }
-- })

------------------------------------------------------------------------------------------------------------------------------------------------------

-- data storage

-- data:extend({
-- {
-- type = "item",
-- name = "data-storage",
-- order = "z",
-- stack_size = 50,
-- icon = DIR.get_icon_path("data-storage"),
-- icon_size = DIR.icon_size,
-- icon_mipmaps = DIR.icon_mipmaps,
-- subgroup = "ir-electronics",
-- },
-- {
-- type = "recipe",
-- name = "data-storage",
-- result = "data-storage",
-- result_count = 1,
-- category = "crafting",
-- subgroup = "ir-electronics",
-- order = "z",
-- enabled = false,
-- ingredients = {
-- {"plastiglass",2},
-- {"gold-foil",2},
-- {"steel-rod",1},
-- {"gold-gate",4},
-- },
-- energy_required = DIR.standard_crafting_time * 2,
-- }
-- })

------------------------------------------------------------------------------------------------------------------------------------------------------

-- blocker (for splitters)

data:extend({
    {
        type = "item",
        name = "splitter-blocker",
        order = "zzzzz",
        stack_size = 1,
        icon = DIR.get_icon_path("splitter-blocker"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "natural",
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- gas canister

data:extend({
    {
        type = "item",
        name = "empty-canister",
        order = "c",
        stack_size = 10,
        icon = DIR.get_icon_path("empty-canister"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-vessels",
    },
    {
        type = "recipe",
        name = "empty-canister",
        result = "empty-canister",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"steel-plate-heavy",2},
            {"nanoglass",1},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 2,
    }
})

-- empty steam cell

data:extend({
    {
        type = "item",
        name = "empty-cell",
        order = "aa",
        stack_size = 50,
        icon = DIR.get_icon_path("empty-cell"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-vessels",
    },
    {
        type = "recipe",
        name = "empty-cell",
        result = "empty-cell",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"copper-plate",1},
            {"copper-rivet",1},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 1,
    }
})


-- empty iron canister

data:extend({
    {
        type = "item",
        name = "empty-iron-canister",
        order = "ab",
        stack_size = 50,
        icon = DIR.get_icon_path("empty-iron-canister"),
        icon_size = DIR.icon_size,
        icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "ir-vessels",
    },
    {
        type = "recipe",
        name = "empty-iron-canister",
        result = "empty-iron-canister",
        result_count = 1,
        category = "crafting",
        enabled = false,
        ingredients = {
            {"iron-plate",2},
            {"iron-rivet",1},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 2,
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- medical pack

data:extend({
    {
        type = "capsule",
        name = "medical-pack",
        icon = DIR.get_icon_path("medical-pack"),
        icon_size = DIR.icon_size, icon_mipmaps = DIR.icon_mipmaps,
        subgroup = "capsule",
        order = "a[a]",
        stack_size = 50,
        capsule_action =
        {
            type = "use-on-self",
            attack_parameters =
            {
                type = "projectile",
                activation_type = "consume",
                ammo_category = "capsule",
                cooldown = 120,
                range = 0,
                ammo_type =
                {
                    category = "capsule",
                    target_type = "position",
                    action =
                    {
                        type = "direct",
                        action_delivery =
                        {
                            type = "instant",
                            target_effects =
                            {
                                {
                                    type = "damage",
                                    damage = {type = "physical", amount = -160}
                                },
                                {
                                    type = "play-sound",
                                    sound = { filename = DIR.sound_path .. "/medical-pack.ogg", volume = 1 },
                                }
                            }
                        }
                    }
                }
            }
        },
    },
    {
        type = "recipe",
        name = "medical-pack",
        result = "medical-pack",
        result_count = 1,
        category = "advanced-crafting",
        enabled = false,
        ingredients = {
            {name = "plastic-bar", type = "item", amount = 4},
            {name = "rubber", type = "item", amount = 4},
            {name = "steel-rod", type = "item", amount = 4},
            {name = "ethanol", type = "fluid", amount = 60},
        },
        show_amount_in_title = false,
        always_show_products = true,
        energy_required = DIR.standard_crafting_time * 4,
    }

})

------------------------------------------------------------------------------------------------------------------------------------------------------
