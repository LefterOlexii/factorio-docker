------------------------------------------------------------------------------------------------------------------------------------------------------

-- POWER ITEMS, batteries etc.

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fuel categories

data:extend({
    {
        type = "fuel-category",
        name = "battery",
    },
    {
        type = "fuel-category",
        name = "canister",
    },
    {
        type = "fuel-category",
        name = "barrel",
    },
    {
        type = "fuel-category",
        name = "steam-cell",
    },
    {
        type = "fuel-category",
        name = "coke",
    },
    {
        type = "fuel-category",
        name = "fluid-spill",
    },
})

-- vanilla battery

DIR.replace_recipe_ingredients("battery", {
	{type = "item", name = "iron-plate", amount = 4},
	{type = "item", name = "copper-plate", amount = 2},
	{type = "fluid", name = "sulfuric-acid", amount = 20}
}, 1, "advanced-crafting", 3)

data.raw.item["battery"].stack_size = 100
DIR.change_item_order("battery", "da")

data:extend({
	{
		type = "item",
		name = "charged-battery",
		icon = DIR.get_icon_path("charged-battery"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 100,
		order = "db",
		subgroup = "ir-vessels",
		burnt_result = "battery",
		fuel_value = "5MJ",
		fuel_category = "battery", 
		fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["copper"].acceleration,
		fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["copper"].top_speed,
	},
    {
        type = "recipe",
        name = "charged-battery",
        results = {
            { type = "item", name = "charged-battery", amount = 1, probability = 0.98 },
        },
        category = "charging",
        enabled = false,
        always_show_made_in = true,
        show_amount_in_title = false,
        always_show_products = true,
        ingredients = {
            {"battery",1},
        },
        energy_required = 10,
        hide_from_stats = true,
        allow_decomposition = false,
		crafting_machine_tint = {
			primary = {0xB2,0x53,0x36},
		},
    },
})

-- advanced battery

data:extend({
	{
		type = "item",
		name = "advanced-battery",
		icon = DIR.get_icon_path("advanced-battery"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 50,
		order = "ea",
		subgroup = "ir-vessels",
	},
	{
		type = "item",
		name = "charged-advanced-battery",
		icon = DIR.get_icon_path("charged-advanced-battery"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 50,
		order = "eb",
		subgroup = "ir-vessels",
		burnt_result = "advanced-battery",
		fuel_value = "20MJ",
		fuel_category = "battery",
		fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["steel"].acceleration,
		fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["steel"].top_speed,
	},
    {
        type = "recipe",
        name = "advanced-battery",
        results = {
            { type = "item", name = "advanced-battery", amount = 1 }
        },
        category = "advanced-crafting",
        enabled = false,
        show_amount_in_title = false,
        ingredients = {
            {type = "item", name = "steel-plate", amount = 6},
            {type = "item", name = "lead-plate", amount = 4},
            {type = "fluid", name = "sulfuric-acid", amount = 30},
        },
        energy_required = DIR.standard_crafting_time * 4,
    },
    {
        type = "recipe",
        name = "charged-advanced-battery",
        results = {
            { type = "item", name = "charged-advanced-battery", amount = 1, probability = 0.99 }
        },
        category = "charging",
        enabled = false,
        always_show_made_in = true,
        show_amount_in_title = false,
        always_show_products = true,
        ingredients = {
            {"advanced-battery",1},
        },
        energy_required = 40,
        hide_from_stats = true,
        allow_decomposition = false,
		crafting_machine_tint = {
			primary = {0xE6,0xBA,0x39},
		},
    },
})

-- hydrogen battery

data:extend({
	{
		type = "item",
		name = "hydrogen-battery",
		icon = DIR.get_icon_path("hydrogen-battery"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 50,
		order = "fa",
		subgroup = "ir-vessels",
	},
	{
		type = "item",
		name = "charged-hydrogen-battery",
		icon = DIR.get_icon_path("charged-hydrogen-battery"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		stack_size = 50,
		order = "fb",
		subgroup = "ir-vessels",
		burnt_result = "hydrogen-battery",
		fuel_value = DIR.hydrogen_cell_MJ.."MJ",
		fuel_category = "battery",
		fuel_acceleration_multiplier = DIR.vehicle_fuel_modifier_tiers["hydrogen"].acceleration,
		fuel_top_speed_multiplier = DIR.vehicle_fuel_modifier_tiers["hydrogen"].top_speed,
	},
    {
        type = "recipe",
        name = "hydrogen-battery",
        results = {
            { type = "item", name = "hydrogen-battery", amount = 1 }
        },
        category = "advanced-crafting",
        enabled = false,
        always_show_made_in = true,
        show_amount_in_title = false,
        always_show_products = true,
        ingredients = {
            {type = "item", name = "chromium-plate", amount = 6},
            {type = "item", name = "platinum-pellet", amount = 6},
            {type = "item", name = "nanoglass", amount = 3},
            {type = "item", name = "processing-unit", amount = 1},			
        },
        energy_required = DIR.standard_crafting_time * 4,
    },
    {
        type = "recipe",
        name = "charged-hydrogen-battery",
        results = {
            { type = "item", name = "charged-hydrogen-battery", amount = 1, probability = 0.999 }
        },
        category = "advanced-crafting",
        enabled = false,
        always_show_made_in = true,
        show_amount_in_title = false,
        always_show_products = true,
        ingredients = {
            {type = "item", name = "hydrogen-battery", amount = 1},
            {type = "fluid", name = "hydrogen-gas", amount = DIR.hydrogen_in_cell},
        },
        energy_required = DIR.standard_crafting_time * 8,
        hide_from_stats = true,
        allow_decomposition = false,
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------


