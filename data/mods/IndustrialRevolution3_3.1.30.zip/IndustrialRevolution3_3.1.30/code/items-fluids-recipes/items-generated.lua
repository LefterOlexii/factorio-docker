------------------------------------------------------------------------------------------------------------------------------------------------------

-- GENERATED ITEMS

------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.spam_log("Starting item generation",DIR.log_level.milestone)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- loop through material-component combinations, create items and recipes

DIR.belt_variant_count = {}
for component,componentdata in pairs(DIR.components) do
	for _,material in pairs(componentdata.materials) do
		DIR.generate_system_item(material,component)
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- generate bullet-style projectiles from the materials available

for component,componentdata in pairs(DIR.components) do
    if componentdata.ammo then
		for _,material in pairs(componentdata.materials) do
			local materialdata = DIR.materials[material]
			DIR.create_bullet_projectile(materialdata.base_damage, materialdata.hue, materialdata.saturation, DIR.projectiles_path, componentdata.ammo.piercing and componentdata.ammo.piercing[material])
		end
	end
end

for component,componentdata in pairs(DIR.components) do
	if componentdata.ammo and componentdata.ammo.category and not data.raw["ammo-category"][componentdata.ammo.category] then
		data:extend({{
			type = "ammo-category",
			name = componentdata.ammo.category,
			bonus_gui_order = "z-"..componentdata.ammo.category,
		}})
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- set up tiles
-- TODO: this is very old code from IR1, it should really be part of generate_system_item()

for component,componentdata in pairs(DIR.components) do
	for _,material in pairs(componentdata.materials) do
		if componentdata.tile_walking_speed and componentdata.tile_walking_speed[material] then
			local name = DIR.get_item_name(material,component)
			local item = data.raw[componentdata.type][name]
			local tile = (name == "stone-brick") and "stone-path" or name
			if item then
				if not data.raw.tile[tile] then error("Item has walking speed, but tile "..tile.." does not exist") end
				item.place_as_tile = {
					condition = {"water-tile"},
					condition_size = componentdata.tile_condition_size or 1,
					result = tile
				}
				data.raw.tile[tile].walking_speed_modifier = componentdata.tile_walking_speed[material]
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

DIR.spam_log("Item generation complete",DIR.log_level.milestone)

------------------------------------------------------------------------------------------------------------------------------------------------------
