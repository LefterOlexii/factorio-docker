------------------------------------------------------------------------------------------------------------------------------------------------------

-- EQUIPMENT

------------------------------------------------------------------------------------------------------------------------------------------------------

-- battery discharge equipment

data:extend(
    {
        {
            type = "item",
            name = "battery-discharge-equipment",
            placed_as_equipment_result = "battery-discharge-equipment",
            order = "a[energy-source]-a[battery]",
            stack_size = 10,
            icon = DIR.get_icon_path("battery-discharge-equipment"),
            icon_size = DIR.icon_size,
            icon_mipmaps = DIR.icon_mipmaps,
            subgroup = "equipment-power"
        },
        {
            type = "recipe",
            name = "battery-discharge-equipment",
            result = "battery-discharge-equipment",
            result_count = 1,
            category = "crafting",
            enabled = false,
            ingredients = {
                {"iron-frame-small", 1},
                {"iron-stick", 8},
                {"copper-cable", 3},
                {"electronic-circuit", 1}
            },
            energy_required = DIR.standard_crafting_time * 4
        },
        {
            type = "generator-equipment",
            name = "battery-discharge-equipment",
            categories = {"armor", "IR-vehicle", "IR-vehicle-2"},
            energy_source = {
                type = "electric",
                usage_priority = "secondary-output"
            },
            power = "250kW",
            shape = {
                height = 2,
                type = "full",
                width = 2
            },
            sprite = {
                filename = DIR.get_icon_path("battery-discharge-equipment", 128),
                height = 128,
                priority = "medium",
                width = 128,
				flags = {"gui"},
                mipmap_count = 2
            },
            burner = {
                fuel_category = "battery",
                fuel_inventory_size = 1,
                burnt_inventory_size = 1,
                type = "burner"
            }
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- iron burner generator equipment

data:extend(
    {
        {
            type = "item",
            name = "iron-burner-generator-equipment",
            placed_as_equipment_result = "iron-burner-generator-equipment",
            order = "a[energy-source]-a[b]",
            stack_size = 10,
            icon = DIR.get_icon_path("iron-burner-generator"),
            icon_size = DIR.icon_size,
            icon_mipmaps = DIR.icon_mipmaps,
            subgroup = "equipment-power"
        },
        {
            type = "recipe",
            name = "iron-burner-generator-equipment",
            result = "iron-burner-generator-equipment",
            result_count = 1,
            category = "crafting",
            enabled = false,
            ingredients = {
                {"iron-frame-small", 1},
                {"engine-unit", 1},
                {"iron-piston", 4},
            },
            energy_required = DIR.standard_crafting_time * 3
        },
        {
            type = "generator-equipment",
            name = "iron-burner-generator-equipment",
            categories = {"armor", "IR-vehicle", "IR-vehicle-2"},
            energy_source = {
                type = "electric",
                usage_priority = "secondary-output"
            },
            power = "250kW",
            shape = {
                height = 2,
                type = "full",
                width = 2
            },
            sprite = {
                filename = DIR.get_icon_path("iron-burner-generator", 128),
                height = 128,
                priority = "medium",
                width = 128,
				flags = {"gui"},
                mipmap_count = 2
            },
            burner = {
                emissions_per_minute = DIR.get_standard_emissions(1),
                fuel_category = "steam-cell",
                fuel_inventory_size = 1,
                burnt_inventory_size = 1,
                type = "burner"
            }
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- copper personal roboport

data:extend(
    {
        {
            type = "item",
            name = "copper-roboport-equipment",
            placed_as_equipment_result = "copper-roboport-equipment",
            order = "e[robotics]-a[a-personal-roboport-equipment]",
            stack_size = 10,
            icon = DIR.get_icon_path("copper-personal-roboport"),
            icon_size = DIR.icon_size,
            icon_mipmaps = DIR.icon_mipmaps,
            subgroup = "equipment"
        },
        {
            type = "recipe",
            name = "copper-roboport-equipment",
            result = "copper-roboport-equipment",
            result_count = 1,
            category = "crafting",
            enabled = false,
            ingredients = {
                {"copper-frame-small", 1},
                {"copper-gear-wheel", 4},
                {"copper-motor", 1}
            },
            energy_required = DIR.standard_crafting_time * 3
        },
        {
            type = "roboport-equipment",
            name = "copper-roboport-equipment",
            take_result = "copper-roboport-equipment",
            sprite = {
                filename = DIR.get_icon_path("copper-personal-roboport", 128),
                width = 128,
                height = 128,
                priority = "medium",
				flags = {"gui"},
                mipmap_count = 2
            },
            shape = {
                width = 2,
                height = 2,
                type = "full"
            },
            energy_source = {
                type = "electric",
                buffer_capacity = "7.2MJ",
                input_flow_limit = "0kW",
                usage_priority = "secondary-input"
            },
			burner = {
                emissions_per_minute = DIR.get_standard_emissions(1),
                fuel_category = "steam-cell",
                fuel_inventory_size = 1,
                burnt_inventory_size = 1,
                type = "burner"
			},
			power = (1.2/60).."MJ",
            charging_energy = "0.6MW",
            robot_limit = 5,
            construction_radius = 7.5,
            spawn_and_station_height = 0.4,
            charge_approach_distance = 2.6,
            recharging_animation = {
                filename = "__base__/graphics/entity/smoke-fast/smoke-fast.png",
                priority = "high",
                width = 50,
                height = 50,
                frame_count = 16,
                scale = 1,
                animation_speed = 0.5
            },
            recharging_light = {intensity = 0.4, size = 5},
            stationing_offset = {0, -0.6},
            charging_station_shift = {0, 0.5},
            charging_station_count = 2,
            charging_distance = 1.6,
            charging_threshold_distance = 5,
            categories = {"armor", "IR-vehicle"},
            robots_shrink_when_entering_and_exiting = true
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- spell it out

local function add_fuel_manager_tip_to_item(item)
    if data.raw.item[item] then
        data.raw.item[item].localised_description = {
            "",
            {"item-description." .. item},
            " ",
            {"item-description.fuel-manager-tip"}
        }
    end
end

for _,item in pairs({
	"burner-generator-equipment",
	"iron-burner-generator-equipment",
	"battery-discharge-equipment",
	"fusion-reactor-equipment",
	"copper-roboport-equipment"
}) do add_fuel_manager_tip_to_item(item) end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- arc turret equipment

data:extend(
    {
        {
            type = "item",
            name = "arc-turret-equipment",
			localised_description = {"entity-description.arc-turret"},
            placed_as_equipment_result = "arc-turret-equipment",
            order = "b[active-defense]-a",
            stack_size = 10,
            icon = DIR.get_icon_path("arc-turret-equipment"),
            icon_size = DIR.icon_size,
            icon_mipmaps = DIR.icon_mipmaps,
            subgroup = "military-equipment"
        },
        {
            type = "recipe",
            name = "arc-turret-equipment",
            result = "arc-turret-equipment",
            result_count = 1,
            category = "crafting",
            enabled = false,
            ingredients = {
                {"copper-coil", 4},
                {"steel-frame-small", 2},
                {"computer-mk2", 1},
                {"gyroscope", 1}
            },
            energy_required = DIR.standard_crafting_time * 4
        },
        {
            type = "active-defense-equipment",
            name = "arc-turret-equipment",
            categories = {"armor"},
            sprite = {
                filename = DIR.get_icon_path("arc-turret-equipment", 128),
                width = 128,
                height = 128,
                priority = "medium",
				flags = {"gui"},
                mipmap_count = 2
            },
            shape = {
                width = 2,
                height = 2,
                type = "full"
            },
            energy_source = {
                type = "electric",
                usage_priority = "secondary-input",
                buffer_capacity = "1250kJ"
            },
            attack_parameters = {
                type = "beam",
                cooldown = DIR.arc_turret_shooting_speed,
                range = DIR.arc_turret_max_range,
				min_range = DIR.arc_turret_min_range,
                damage_modifier = 0,
                ammo_type = {
                    category = "emp-turret",
                    energy_consumption = "1000kJ",
                    action = {
                        type = "direct",
                        action_delivery = {
                            type = "beam",
                            beam = "emp-beam",
                            max_length = DIR.arc_turret_max_range,
                            duration = DIR.arc_turret_shooting_speed,
                        }
                    }
                }
            },
            automatic = true,
        }
    }
)

------------------------------------------------------------------------------------------------------------------------------------------------------
