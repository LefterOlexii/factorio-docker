------------------------------------------------------------------------------------------------------------------------------------------------------

-- MANIFESTO / INFORMATRON

------------------------------------------------------------------------------------------------------------------------------------------------------

local manifesto_page_titles = {
	[1] = "IndustrialRevolution3",
	[2] = "ir_power_sources",
	[3] = "ir_mining",
	[4] = "ir_processing",
	[5] = "ir_melting",
	[6] = "ir_modules",
	[7] = "ir_pollution_control",
	[8] = "ir_pollution_spill",
	[9] = "ir_forestry",
    [10] = "ir_weapons",
	[11] = "ir_transmats",
	[12] = "ir_transfers",
	[13] = "ir_fuelman",
	[14] = "ir_entity_toggle",
}

local manifesto_titles_by_page = DIR.values_to_keys(manifesto_page_titles)

------------------------------------------------------------------------------------------------------------------------------------------------------

function CONTROL.get_manifesto_page_titles()
	local titles = {}
	for i,title in pairs(manifesto_page_titles) do titles[i] = title end
	for mod,_ in pairs(game.active_mods) do
		if remote.interfaces[mod.."-ir-manifesto"] and remote.interfaces[mod.."-ir-manifesto"]["titles"] then
			local new_pages = remote.call(mod.."-ir-manifesto", "titles")
			if type(new_pages) == "table" then
				for page,_ in pairs(new_pages) do
					table.insert(titles, page)
				end
			end
		end
	end
	return titles
end

function CONTROL.get_manifesto_page_index_from_title(title)
	for i,t in pairs(CONTROL.get_manifesto_page_titles()) do
		if t == title then return i end
	end
	return nil
end

function CONTROL.init_informatron_interface()
	remote.add_interface("IndustrialRevolution3", {
		informatron_menu = function(data)
			local imenu = {}
			local titles = CONTROL.get_manifesto_page_titles()
			for i=2,#titles do
				imenu[titles[i]] = true
			end
			return imenu
		end,
		informatron_page_content = function(data)
			return CONTROL.page_content(data.page_name, data.element)
		end
	})
end

local function add_sprite_bullet(element, sprite, page_name, number, parameter, width, height)
	local t = element.add {type = "table", column_count = 2, style = "transmat_bare_table"}
	t.style.bottom_margin = 4
	t.style.column_alignments[1] = "top-center"
	t.style.column_alignments[2] = "top-left"
	local s = t.add {type = "sprite", sprite = sprite, style = "transmat_header_icon"}
	s.style.height = height or 24
	s.style.width = width or 24
	s.style.right_margin = 8
	s.style.vertical_align = "top"
	local l = t.add {type = "label", caption = {"IndustrialRevolution3.bullet_"..page_name.."_"..number, parameter}}
	l.style.single_line = false
	l.style.maximal_width = 860
end

local function add_paragraph(element, page_name, number, parameter)
	local l = element.add {type = "label", style = "manifesto_paragraph", caption = {"IndustrialRevolution3.paragraph_"..page_name.."_"..number, parameter}}
end

local function add_image(element, page_name)
	local flow = element.add {type = "flow", direction = "vertical"}
	flow.style.horizontally_stretchable = true
	flow.style.horizontal_align = "center"
	flow.style.bottom_margin = 8
	local sprite = flow.add {type = "sprite", style = "help-image-"..page_name, sprite = "help-image-"..page_name, resize_to_sprite = false}
end

function CONTROL.page_content(page_name, element)
	for mod,_ in pairs(game.active_mods) do
		if remote.interfaces[mod.."-ir-manifesto"] then
			local new_pages = remote.call(mod.."-ir-manifesto", "titles")
			if new_pages and new_pages[page_name] then
				return remote.call(mod.."-ir-manifesto", "content", page_name, element)
			end
		end
	end
	local pages = {
		default = function(page_name, element)
			element.add{type = "label", caption = "Guru meditation error: no page content for title "..page_name}
			return true
		end,
		IndustrialRevolution3 = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 192, "decorative-logo")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_sprite_bullet(element, "bronze-bullet", page_name, 1, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 2, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 3, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 4, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 5, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 6, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 7, nil, 12)
			add_paragraph(element, page_name, 3)
			return true
		end,
		ir_mining = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "chrome-drill")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 4)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 5)
			return true
		end,
		ir_power_sources = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "steam-valve")
			add_sprite_bullet(element, "tooltip-category-chemical", page_name, 1, nil, 20, 20)
			add_sprite_bullet(element, "tooltip-category-steam", page_name, 2, nil, 20, 20)
			add_sprite_bullet(element, "tooltip-category-electricity", page_name, 3, nil, 20, 20)
			add_sprite_bullet(element, "tooltip-category-fluid", page_name, 4, nil, 20, 20)
			add_sprite_bullet(element, "tooltip-category-battery", page_name, 5, nil, 20, 20)
			add_sprite_bullet(element, "tooltip-category-barrel", page_name, 6, nil, 20, 20)
			return true
		end,
		ir_processing = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "steel-washer")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 4)
			return true
		end,
		ir_fuelman = function(page_name, element)
			add_image(element, page_name)
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			add_sprite_bullet(element, "warning-fuel-yellow", page_name, 1)
			add_sprite_bullet(element, "warning-fuel-red", page_name, 2)
			add_sprite_bullet(element, "warning-inventory", page_name, 3)
			add_paragraph(element, page_name, 4)
			add_paragraph(element, page_name, 5)
			add_paragraph(element, page_name, 6)
			return true
		end,
		ir_forestry = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "bronze-forestry")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2, DIR.max_forestry_trees)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 4)
			return true
		end,
		ir_pollution_control = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "air-purifier")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_sprite_bullet(element, "entity/air-compressor", page_name, 1)
			add_sprite_bullet(element, "entity/air-purifier", page_name, 2)
			add_sprite_bullet(element, "entity/bronze-forestry", page_name, 3)
			return true
		end,
		ir_pollution_spill = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "storage-tank")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 4)
			local t = element.add {type = "table", column_count = 20}
			t.style.horizontal_spacing = 1
			t.style.vertical_spacing = 1
			t.style.padding = 0
			local list = {}
			for _,fluid in pairs(game.fluid_prototypes) do
				if not string.find(fluid.name,"unknown") and not fluid.hidden and (CONTROL.get_fluid_spill_multiplier(fluid.name) == 0) then
					table.insert(list,fluid.name)
				end
			end
			table.sort(list, function(a,b)
				return game.fluid_prototypes[a].order < game.fluid_prototypes[b].order
			end)
			for _,fluid in pairs(list) do
				if game.is_valid_sprite_path("fluid/"..fluid) then
					local l = t.add {type = "sprite", sprite = "fluid/"..fluid, tooltip = {"fluid-name."..fluid} }
					l.style.size = 32
					l.style.right_margin = 8
					l.resize_to_sprite = false
				end
			end
			return true
		end,
		ir_weapons = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "photon-turret", {2,0})
			add_paragraph(element, page_name, 1)
			add_sprite_bullet(element, "item/scattergun-turret", page_name, 1)
			add_sprite_bullet(element, "item/gun-turret", page_name, 2)
			add_sprite_bullet(element, "item/laser-turret", page_name, 3)
			add_sprite_bullet(element, "item/arc-turret", page_name, 4)
			add_sprite_bullet(element, "item/rocket-turret", page_name, 7)
			add_sprite_bullet(element, "item/photon-turret", page_name, 5)
			add_sprite_bullet(element, "item/atomic-artillery-shell", page_name, 6)
		end,
		ir_melting = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "arc-furnace")
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 4)
			add_paragraph(element, page_name, 5)
		end,
		ir_transfers = function(page_name, element)
			add_paragraph(element, page_name, 1)
			add_sprite_bullet(element, "entity/character", page_name, 1)
			add_sprite_bullet(element, "item/shotgun", page_name, 6)
			add_sprite_bullet(element, "item/heavy-roller", page_name, 2)
			add_sprite_bullet(element, "item/bronze-chest", page_name, 3)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			add_paragraph(element, page_name, 4)
			add_sprite_bullet(element, "item/charged-battery", page_name, 4)
			add_sprite_bullet(element, "item/iron-ore", page_name, 5)
			add_paragraph(element, page_name, 5)
			return true
		end,
		ir_entity_toggle = function(page_name, element)
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_sprite_bullet(element, "item/locomotive", page_name, 1)
			add_sprite_bullet(element, "item/constant-combinator", page_name, 5)
			add_sprite_bullet(element, "item/power-switch", page_name, 4)
			add_sprite_bullet(element, "item/iron-battery-discharger", page_name, 7)
			add_sprite_bullet(element, "item/steel-cast", page_name, 8)
			add_sprite_bullet(element, "item/barrelling-machine", page_name, 9)
			add_sprite_bullet(element, "item/steel-boiler", page_name, 10)
			add_sprite_bullet(element, "item/rocket-turret", page_name, 12)
			add_sprite_bullet(element, "item/photon-turret", page_name, 2)
			add_sprite_bullet(element, "item/copper-aetheric-lamp-straight", page_name, 3)
			add_sprite_bullet(element, "item/steel-chest", page_name, 6)
			add_sprite_bullet(element, "item/valve", page_name, 11)
			return true
		end,
		ir_transmats = function(page_name, element)
			-- add_image(element, page_name)
			CONTROL.add_sim_camera_element(element, 900, 256, "chrome-transmat", {0,-1})
			add_paragraph(element, page_name, 1)
			add_sprite_bullet(element, "bronze-bullet", page_name, 1, nil, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 2, {"", string.format("%d", DIR.transmat_cost/1000000), " ", {"si-prefix-symbol-mega"}, {"si-unit-symbol-joule"}}, 12)
			add_sprite_bullet(element, "bronze-bullet", page_name, 3, nil, 12)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			return true
		end,
		ir_modules = function(page_name, element)
			CONTROL.add_sim_camera_element(element, 900, 256, "module-loader", {0,-0.5})
			add_paragraph(element, page_name, 1)
			add_paragraph(element, page_name, 2)
			add_paragraph(element, page_name, 3)
			return true
		end,
	}
	if pages[page_name] then return pages[page_name](page_name, element)
	else return pages["default"](page_name, element) end
end

function CONTROL.toggle_manifesto(event, opened_title)

	-- don't create gui if informatron is installed
	if game.active_mods["informatron"] then
		if opened_title then
			remote.call("informatron", "informatron_open_to_page", {player_index = event.player_index, interface = "IndustrialRevolution3", page_name = opened_title})
		end
		return
	end

	-- pop window, close transmat gui
    local player = game.players[event.player_index]
	local frame = player.gui.screen[CONTROL.manifesto_gui]
	if frame then
		frame.destroy()
		player.opened = nil
		return
	end
	CONTROL.on_gui_close(event)
	
	-- frame
	player.opened = player.gui.screen
	
	-- create frame
	local frame = player.gui.screen.add {
		type = "frame",
		name = CONTROL.manifesto_gui,
		direction = "vertical",
		style = "transmat_frame",
	}
	frame.force_auto_center()

	-- header
	local header = frame.add {
		type = "flow",
		direction = "horizontal",
		name = "manifesto-header",
	}
	header.style.bottom_padding = -4
	header.style.horizontally_stretchable = true
	
	-- icon
	local icon = header.add {
		name = "manifesto-icon",
		type = "sprite",
		sprite = "manifesto",
		style = "transmat_header_icon",
	}
	icon.style.size = 24
	icon.style.margin = 0
	icon.style.padding = 0
	icon.style.right_margin = 2
	
	-- title
	local title = header.add {
		name = "manifesto-header-title",
		type = "label",
		caption = {"shortcut-name.ir-manifesto"},
		style = "frame_title",
	}
	title.style.right_padding = 8

	-- "drag filler"
	local filler = header.add {
		type = "empty-widget",
		style = "draggable_space_header",
	}
	filler.style.natural_height = 24
	filler.style.horizontally_stretchable = true
	filler.drag_target = frame

	-- close button
	local close_button = header.add {
		name = "manifesto-header-close",
		type = "sprite-button",
		style = "transmat_small_button",
		sprite = "utility/close_white",
		hovered_sprite = "utility/close_black",
		clicked_sprite = "utility/close_black",
		tooltip = {"gui.close-gui"},
	}
	
	-- body table
	local body = frame.add {
		name = "manifesto-body",
		type = "table",
		column_count = 2,
		vertical_spacing = 0,
		horizontal_spacing = 8,
		style = "transmat_bare_table",
	}
	body.style.horizontal_spacing = 10
	body.style.padding = 0
	body.style.margin = 0
	body.style.top_margin = 10

	local opened_title_index = opened_title and CONTROL.get_manifesto_page_index_from_title(opened_title) or nil
	local selected = opened_title_index or CONTROL.get_player_global(player.index,"last_selected_manifesto_page") or 1
	
	local list = {}
	local titles = CONTROL.get_manifesto_page_titles()
	for i,title in ipairs(titles) do
		list[i] = {"", manifesto_titles_by_page[title] and "[img=bronze-bullet] " or "[img=plus-bullet] ", {"IndustrialRevolution3.title_"..title}}
	end
	if not titles[selected] then selected = 1 end

	local listbox = body.add {
		name = "manifesto-list",
		type = "list-box",
		style = "transmat_list_box",
		items = list,
		selected_index = (selected <= #list) and selected or 1,
	}
	listbox.style.width = 192
	listbox.style.height = CONTROL.manifesto_content_height

	local page = body.add {
		name = "manifesto-pages",
		type = "frame",
		style = "transmat_deep_frame",
	}
	page.style.height = CONTROL.manifesto_content_height
	CONTROL.add_manifesto_page(page, titles[selected], selected)
		
end

function CONTROL.add_manifesto_page(root, page_title, index)
	local titles = CONTROL.get_manifesto_page_titles()
	local flow = root.add {
		name = "manifesto-page-"..index,
		type = "scroll-pane",
		horizontal_scroll_policy = "never",
		vertical_scroll_policy = "auto",
	}
	flow.style.padding = 12
	flow.style.width = 924
	-- flow.visible = (page_number == selected)
	CONTROL.page_content(page_title, flow)
end

function CONTROL.select_manifesto_page(element,player_index)
	local player = game.players[player_index]
	local selected = element.selected_index
	CONTROL.set_player_global(player.index,"last_selected_manifesto_page",selected)
	for page_number,_ in ipairs(element.items) do
		if element.parent["manifesto-pages"]["manifesto-page-"..page_number] then 
			element.parent["manifesto-pages"]["manifesto-page-"..page_number].visible = (page_number == selected)
		elseif page_number == selected then
			local titles = CONTROL.get_manifesto_page_titles()
			CONTROL.add_manifesto_page(element.parent["manifesto-pages"], titles[selected], selected)
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
