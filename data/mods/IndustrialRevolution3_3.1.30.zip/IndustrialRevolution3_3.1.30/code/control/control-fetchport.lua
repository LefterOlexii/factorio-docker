------------------------------------------------------------------------------------------------------------------------------------------------------

-- fetchports

local allowed_types = {
	["ammo"] = true,
	["capsule"] = true,
	["gun"] = true,
	["item"] = true,
	["module"] = true,
	["repair-tool"] = true,
	["tool"] = true,
	["rail-planner"] = true,
}

function CONTROL.get_combined_inventory_structure(inventories)
	local structure = {}
	for _,inventory in pairs(inventories) do
		local last_slot = inventory.supports_bar() and (inventory.get_bar() - 1) or #inventory
		for i=1,last_slot do
			table.insert(structure, {
				inventory = inventory,
				slot_index = i,
			})
		end
	end
	return structure
end

function CONTROL.get_structure_slot_owner(slot)
	return slot.inventory.player_owner or slot.inventory.entity_owner
end

function CONTROL.get_combined_inventory_structure_from_chests(player,selected,settings_override,square_radius_override)
	local setting = settings_override or settings.get_player_settings(player)["ir-fetchport-containers"].value
	local containers = square_radius_override and player.surface.find_entities_filtered{
		type = CONTROL.fetchport_settings[setting].type,
		name = CONTROL.fetchport_settings[setting].name,
		force = player.force,
		area = {{selected.position.x-square_radius_override,selected.position.y-square_radius_override}, {selected.position.x+square_radius_override,selected.position.y+square_radius_override}},
	} or player.surface.find_entities_filtered{
		type = CONTROL.fetchport_settings[setting].type,
		name = CONTROL.fetchport_settings[setting].name,
		force = player.force,
		position = selected.position,
		radius = CONTROL.fetchport_target_radius,
	}
	local inventories = {}
	for _,container in pairs(containers) do
		if container.get_inventory(defines.inventory.chest) and #container.get_inventory(defines.inventory.chest) > 0 then
			table.insert(inventories, container.get_inventory(defines.inventory.chest))
		end
	end
	return CONTROL.get_combined_inventory_structure(inventories)
end

function CONTROL.get_filters_from_slots(slots)
	local filters = {}
	for _,slot in pairs(slots) do
		if slot.inventory.supports_filters() and slot.inventory.get_filter(slot.slot_index) ~= nil then
			filters[slot.inventory.get_filter(slot.slot_index)] = true
		end
	end
	return filters
end

-- 3.1.18 - don't move items that have less than maximum durability or health or used-up ammo
local function safe_remove(inventory, name, count)
	local removed = 0
	local i = 1
	while (count > 0) and (i <= #inventory) do
		local stack = inventory[i]
		if stack.valid_for_read and stack.name == name then
			local d = (stack.durability == game.item_prototypes[stack.name].durability)
			local a = (stack.type ~= "ammo") or (stack.ammo == game.item_prototypes[stack.name].magazine_size)
			local h = (stack.health == 1)
			if d and a and h then
				local stack_count = stack.count
				if count >= stack.count then
					inventory[i].set_stack()
					removed = removed + stack_count
					count = count - stack_count
				else
					stack.count = stack.count - count
					removed = removed + count
					count = 0
				end
			end
		end
		i = i + 1
	end
	return removed
end

function CONTROL.fetchport_pull(transfers, target_slot_structure, source_slot_structure, ignore_filters)
	ignore_filters = ignore_filters or {}
	for _,target_slot in pairs(target_slot_structure) do
		local item_name = target_slot.inventory.supports_filters() and target_slot.inventory.get_filter(target_slot.slot_index)
		if item_name and not ignore_filters[item_name] then
			-- 3.1.10 - account for filtered slots with a different item in them. treat them as blocking
			local current_stack_name = target_slot.inventory[target_slot.slot_index].valid_for_read and target_slot.inventory[target_slot.slot_index].name or nil
			-- 3.1.18 - only handle items without tricksy metadata
			if allowed_types[game.item_prototypes[item_name].type] and ((current_stack_name == nil) or (current_stack_name == item_name)) then
				local count = target_slot.inventory[target_slot.slot_index].valid_for_read and target_slot.inventory[target_slot.slot_index].count or 0
				local needed = game.item_prototypes[item_name].stack_size - count
				local source_index = 1
				while (needed > 0) and (source_index <= #source_slot_structure) do
					local source_slot = source_slot_structure[source_index]
					local contains = source_slot.inventory.get_item_count(item_name)
					if contains > 0 then
						local removed = safe_remove(source_slot.inventory, item_name, needed)
						if removed > 0 then
							local inserted = target_slot.inventory.insert({name=item_name, count=removed})
							needed = needed - inserted
							table.insert(transfers, {
								item_name = item_name,
								amount = inserted,
								to = CONTROL.get_structure_slot_owner(target_slot),
								from = CONTROL.get_structure_slot_owner(source_slot),
							})
						end
					end
					source_index = source_index + 1
				end		
			end
		end
	end
end

function CONTROL.has_needy_slots(structure)
	for _,target_slot in pairs(structure) do
		local item_name = target_slot.inventory.supports_filters() and target_slot.inventory.get_filter(target_slot.slot_index)
		if item_name then
			local count = target_slot.inventory[target_slot.slot_index].valid_for_read and target_slot.inventory[target_slot.slot_index].count or 0
			local needed = game.item_prototypes[item_name].stack_size - count
			if needed > 0 then return true end
		end
	end
	return false
end

function CONTROL.fetchport_replenish(player, identity, selected, settings_override, square_radius_override, silent)

	-- must have a character
	if player.controller_type ~= defines.controllers.character then return end

	-- look for chests
	local chest_slots = CONTROL.get_combined_inventory_structure_from_chests(player, selected, settings_override, square_radius_override)
	if #chest_slots == 0 then return end

	-- list player inventories including vehicle
	local player_inventories = {
		player.get_main_inventory(),
		player.get_inventory(defines.inventory.character_ammo),
	}
	local non_ammo_player_inventories = {
		player.get_main_inventory(),	
	}
	if player.vehicle and player.vehicle.valid and (player.vehicle.type == "car") then
		table.insert(player_inventories, player.vehicle.get_inventory(defines.inventory.car_trunk))
		table.insert(player_inventories, player.vehicle.get_inventory(defines.inventory.car_ammo))
		table.insert(non_ammo_player_inventories, player.vehicle.get_inventory(defines.inventory.car_trunk))
	end
	local player_slots = CONTROL.get_combined_inventory_structure(player_inventories)
	local non_ammo_player_slots = CONTROL.get_combined_inventory_structure(non_ammo_player_inventories)

	-- reference filters in inventories; no filters = halt
	local chest_filters = CONTROL.get_filters_from_slots(chest_slots)
	local player_filters = CONTROL.get_filters_from_slots(player_slots)
	if table_size(chest_filters) == 0 and table_size(player_filters) == 0 then
		if not silent then CONTROL.player_flying_notification(player, {"", CONTROL.grey_text, {"notification.fetchport-no-filters"}, CONTROL.end_colour_text}) end
		return
	end

	-- all filters full = halt
	if not CONTROL.has_needy_slots(player_slots) and not CONTROL.has_needy_slots(chest_slots) then
		if not silent then CONTROL.player_flying_notification(player, {"", CONTROL.green_text, {"notification.fetchport-no-items-needed"}, CONTROL.end_colour_text}) end
		return
	end

	-- do the transfers - pull to player never fetches things that are filtered in any of the chests
	local transfers = {}
	CONTROL.fetchport_pull(transfers, player_slots, chest_slots, chest_filters)
	CONTROL.fetchport_pull(transfers, chest_slots, non_ammo_player_slots, nil)

    -- no transfers = halt
	if table_size(transfers) == 0 then
		if not silent then CONTROL.player_flying_notification(player, {"", CONTROL.red_text, {"notification.fetchport-no-items-found"}, CONTROL.end_colour_text}) end
		return
	end

	-- custom event
	script.raise_event(CONTROL.generated_event_ids.on_transfer_plate_or_hotkey, {
		player_index = player.index,
		transfers = transfers,
		silent = silent or false,
		identity = identity,
	})

	-- notify and draw missiles
	local totals = {}
	local owner_counts = {}
	local sources = {}
	for _,transfer in pairs(transfers) do
		local amount = transfer.amount * (((transfer.to == player) or (transfer.to == player.vehicle)) and 1 or -1)
		totals[transfer.item_name] = (totals[transfer.item_name] or 0) + amount
		local id = (transfer.from == player) and 0 or transfer.from.unit_number
		owner_counts[id] = owner_counts[id] or {}
		owner_counts[id][transfer.item_name] = (owner_counts[id][transfer.item_name] or 0) + math.abs(amount)
		sources[id] = (transfer.from == player) and transfer.to or transfer.from
	end
	local delay = 1
	for id,items in pairs(owner_counts) do
		for item,count in pairs(items) do
			CONTROL.add_delayed_action(delay, {
				action = "fetchport_projectile",
				item = item,
				source = (id == 0) and player.character or sources[id],
				target = (id == 0) and sources[id] or player.character,
				source_distance = 0.5,
				bundle = math.ceil(count/100),
			})
			delay = delay + 5
		end
	end
	local message = ""
	local count = 0
	local r = 3
	local s = table_size(totals)
	for item,amount in pairs(totals) do
		local a = (amount >= 0) and (CONTROL.green_text.."+"..amount..CONTROL.end_colour_text) or (CONTROL.red_text..amount..CONTROL.end_colour_text)
		if message ~= "" then message = message .. " " end
		message = message .. "[img=item/"..item.."] " .. a
		count = count + 1
		if (count % r == 0) or (count == s) then
			CONTROL.add_delayed_action(6, {
				action = "pseudo_flying_text",
				surface = player.surface,
				players = {player},
				text = message,
				position = {x = player.position.x, y = player.position.y - 3 - math.floor(s/r) + math.ceil(count/r)},
			})
			message = ""
		end
	end
	
end

------------------------------------------------------------------------------------------------------------------------------------------------------
