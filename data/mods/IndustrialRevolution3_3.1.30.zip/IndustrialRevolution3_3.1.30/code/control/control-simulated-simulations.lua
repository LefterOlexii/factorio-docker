------------------------------------------------------------------------------------------------------------------------------------------------------

-- SIMULATED SIMULATIONS
-- just because

------------------------------------------------------------------------------------------------------------------------------------------------------

local master_blueprints = require("code.data.blueprints")

local function get_blueprints()
	local bps = {
		[1] = master_blueprints,
	}
	for mod,_ in pairs(game.active_mods) do
		if remote.interfaces[mod.."-ir-manifesto"] and remote.interfaces[mod.."-ir-manifesto"]["blueprint"] then
			local bp = remote.call(mod.."-ir-manifesto", "blueprint")
			if bp then
				table.insert(bps, bp)
			end
		end
	end
	return bps
end

local ores_for_drills = {
    ["steam-drill-simulation"] = "tin",
    ["electric-mining-drill-simulation"] = "copper",
    ["chrome-drill-simulation"] = "gold"
}

function CONTROL.build_sim_surface()
	-- local profiler = game.create_profiler()
	local size = 196
	local blueprints = get_blueprints()
    local surface = CONTROL.create_limbo_surface(CONTROL.sim_surface_name, size, #blueprints)
    for _, entity in pairs(surface.find_entities()) do
        entity.destroy{raise_destroy=true}
    end
    local inventory = game.create_inventory(1)
	-- use a custom force because researched techs can affect entity behaviours, recipe unlocks etc.
	-- if they already exist, reset, because sometimes game can be saved with a sim running and techs change in the meantime
	local sim_force = game.forces["ir-sims"]
	if sim_force then
		sim_force.reset()
	else
		sim_force = game.create_force("ir-sims")
	end
	sim_force.chart_all(surface)
	for _, tech in pairs(sim_force.technologies) do
		if tech.enabled and not tech.upgrade then
			tech.researched = true
		end
	end
	global.mine_and_create = {}
	global.fake_alt_mode_visualisations = {}
	global.fake_transmats = {}
	global.fake_transmat_character = nil
	global.camera_positions = {}
	global.camera_entity_count = {}
	local revived_ghosts = {}
	for i=1,#blueprints do
		local stack = inventory[1]
		stack.import_stack(blueprints[i])
		local entities = stack.get_blueprint_entities()
		for _, entity in pairs(entities) do
			if game.entity_prototypes[entity.name.."-simulation"] then
				entity.name = entity.name.."-simulation"
			end
			if ores_for_drills[entity.name] then
				entity.tags = {[entity.name] = ores_for_drills[entity.name]}
				entity.name = "constant-combinator"
			end
		end
		stack.set_blueprint_entities(entities)
			
		-- game.print{"", "Pre blueprint: ", profiler}
		local ghosts = stack.build_blueprint {
			surface = CONTROL.sim_surface_name,
			force = sim_force,
			position = {(i-(#blueprints/2)-0.5)*size, 0},
			force_build = true,
			skip_fog_of_war = false,
			raise_built = true,
		}
		-- game.print{"", "Post blueprint: ", profiler}
		for _, ghost in pairs(ghosts) do
			if ghost.valid and ghost.tags then
				local size = 3
				for name, ore in pairs(ghost.tags) do
					for x = -size, size do
						for y = -size, size do
							local amount = math.ceil(16000 - (math.sqrt((x ^ 2) + (y ^ 2)) * 5000))
							if amount > 0 then
								surface.create_entity {
									name = ore .. "-ore",
									position = {x = ghost.position.x + x, y = ghost.position.y + y},
									amount = amount,
									create_build_effect_smoke = false,
								}
							end
						end
					end
					local entity = surface.create_entity {
						name = name,
						position = ghost.position,
						direction = ghost.direction,
						create_build_effect_smoke = false,
						force = sim_force,
						raise_built = true,
					}
					table.insert(revived_ghosts, entity)
				end
				ghost.destroy()
			else
				if ghost.valid then
					local _, entity, _ = ghost.silent_revive{raise_revive=true}
					if entity and entity.valid then
						table.insert(revived_ghosts, entity)
					end
				end
			end
		end
	end
	for _,entity in pairs(revived_ghosts) do
		if entity and entity.valid then
			if global.camera_positions[entity.name] == nil then
				global.camera_positions[entity.name] = entity.position
				global.camera_entity_count[entity.name] = 1
			else
				global.camera_positions[entity.name] = DIR.get_vector_sum(global.camera_positions[entity.name], entity.position)
				global.camera_entity_count[entity.name] = global.camera_entity_count[entity.name] + 1
			end
			if entity.name == "air-purifier" or entity.name == "air-purifier-simulation" then
				table.insert(global.fake_alt_mode_visualisations, {entity = entity})
				local character = entity.surface.create_entity {name = "character", force = entity.force, position = {entity.position.x - 4, entity.position.y + 1}, create_build_effect_smoke = false}
				character.direction = defines.direction.east
				character.color = CONTROL.sim_character_colour
			elseif entity.name == "storage-tank" then
				table.insert(global.mine_and_create, {
					position = entity.position,
					direction = entity.direction,
					name = entity.name,
					entity = entity,
					force = entity.force,
					surface = entity.surface
				})
			elseif entity.name == "constant-combinator" then
				local character = entity.surface.create_entity {name = "character", force = entity.force, position = entity.position, create_build_effect_smoke = false}
				character.direction = defines.direction.west
				character.color = CONTROL.sim_character_colour
				entity.destroy{raise_destroy=true}
			-- elseif entity.type == "lab" then
				-- local character = entity.surface.create_entity {name = "decorative-"..entity.name, force = entity.force, position = entity.position, create_build_effect_smoke = false}
				-- entity.destroy{raise_destroy=true}
			elseif entity.name == "chrome-transmat" then
				table.insert(global.fake_transmats, entity)
				if global.fake_transmat_character == nil then
					local character = entity.surface.create_entity {name = "character", force = entity.force, position = entity.position, create_build_effect_smoke = false}
					character.direction = defines.direction.south
					character.color = CONTROL.sim_character_colour
					global.fake_transmat_character = character
				end
			elseif entity.type == "ammo-turret" or entity.type == "electric-turret" then
				local layers = {
					["scattergun-turret"] = 6,
					["gun-turret"] = 7,
					["laser-turret"] = 6,
					["arc-turret"] = 7,
					["photon-turret"] = 7,
					["rocket-turret"] = 6,
				}
				if layers[entity.name] then
					for i=1,layers[entity.name] do
						rendering.draw_animation{animation = entity.name.."-"..i, x_scale = 1, y_scale = 1, render_layer = "object", animation_speed = 1, surface = entity.surface, target = entity.position, forces={"player"}}
					end
					entity.destroy{raise_destroy=true}
				end
			end
		end
	end
	for name,position in pairs(global.camera_positions) do
		if global.camera_entity_count[name] and global.camera_entity_count[name] > 1 then
			global.camera_positions[name] = DIR.multiply_vector(position, 1/global.camera_entity_count[name])
		end
	end
    inventory.destroy()
	-- game.print{"", "Build sim surface: ", profiler}
    return surface
end

function CONTROL.get_or_create_sim_surface()
    local surface = game.surfaces[CONTROL.sim_surface_name]
    if not surface then
        surface = CONTROL.build_sim_surface()
    end
	script.on_nth_tick(CONTROL.handle_sim_surface_interval, CONTROL.handle_sim_surface)
	global.handle_sim_surface = true
	CONTROL.set_sim_surface_state(true)
    return surface
end

function CONTROL.set_sim_surface_state(active)
    local surface = game.surfaces[CONTROL.sim_surface_name]
    if not surface then
        surface = CONTROL.build_sim_surface()
    end
	for _,entity in pairs(surface.find_entities()) do
		entity.active = active
	end
end

function CONTROL.add_sim_camera_element(root, width, height, entityname, offset)

	if offset == nil then offset = {x=0,y=0} end

    local surface = CONTROL.get_or_create_sim_surface()
    local player = game.players[root.player_index]

    local position = global.camera_positions[entityname] or global.camera_positions[entityname.."-simulation"]
	if not position then return end

    local frame = root.add {
        type = "frame",
        style = "inner_hard_shadow_frame"
    }
    local cam = frame.add {
        name = "sim_camera",
        type = "camera",
        position = DIR.get_vector_sum(position,offset),
        surface_index = surface.index,
        zoom = player.display_scale
    }
    cam.style.width = width
    cam.style.height = height
    cam.style.horizontal_align = "center"
    frame.style.left_margin = (900 - width) / 2
    frame.style.right_margin = 0
    frame.style.top_margin = 0
    frame.style.bottom_margin = 8
	
end

function CONTROL.does_any_player_have_help_open()
	local window_names = {CONTROL.manifesto_gui, CONTROL.informatron_gui}
    for _, player in pairs(game.connected_players) do
		if player and player.valid then
			for _,name in pairs(window_names) do
				if player.gui.screen[name] then
					return true
				end
			end
		end
    end
	return false
end

function CONTROL.handle_sim_surface()
    local surface = game.surfaces[CONTROL.sim_surface_name]
	if not (surface and surface.valid) then return end
	local window_open = CONTROL.does_any_player_have_help_open()
    -- nothing to do?
    if not window_open then
		script.on_nth_tick(CONTROL.handle_sim_surface_interval, nil)
		global.handle_sim_surface = false
		CONTROL.set_sim_surface_state(false)
        return
    end
    -- handle entities
    if global.mine_and_create then
        for _, edata in pairs(global.mine_and_create) do
            if edata.entity and edata.entity.valid then
                if edata.highlight == nil then
                    edata.highlight = surface.create_entity {
                        name = "highlight-box",
                        box_type = "entity",
                        position = edata.entity.position,
                        source = edata.entity,
                        create_build_effect_smoke = false
                    }
                else
                    local inv = game.create_inventory(1)
                    edata.entity.mine {inventory = inv}
                    edata.highlight.destroy()
                    edata.highlight = nil
                    inv.destroy()
                end
            else
                edata.entity = edata.surface.create_entity {
                    name = edata.name,
                    position = edata.position,
                    direction = edata.direction,
                    force = edata.force,
                    create_build_effect_smoke = true
                }
            end
        end
    end
    if global.fake_alt_mode_visualisations then
        for _, edata in pairs(global.fake_alt_mode_visualisations) do
			if edata.entity and edata.entity.valid then
				if edata.renders then
					for _,render in pairs(edata.renders) do rendering.destroy(render) end
					edata.renders = nil
					if edata.highlight and edata.highlight.valid then
						edata.highlight.destroy()
					end
				else
					edata.renders = CONTROL.highlight_chunk_at_position(edata.entity.surface,edata.entity.position,nil,{x=12,y=14})
					edata.highlight = surface.create_entity {
						name = "highlight-box",
						box_type = "entity",
						position = edata.entity.position,
						source = edata.entity,
						create_build_effect_smoke = false
					}
				end
			end
        end
    end
	if global.fake_transmats and (table_size(global.fake_transmats) == 2) and global.fake_transmat_character then
		local p1 = global.fake_transmats[1].position
		local p2 = global.fake_transmats[2].position
		local from, to
		if DIR.vectors_are_equal(global.fake_transmat_character.position, p1) then
			from = p1
			to = p2
		elseif DIR.vectors_are_equal(global.fake_transmat_character.position, p2) then
			from = p2
			to = p1
		end
		if from and to then
			for i=1,6 do CONTROL.add_delayed_action(1+((i-1)*20), {action = "render_transmat_hex_light", light = i, from = global.fake_transmats[1], to = global.fake_transmats[2], ttl = 300}) end
			CONTROL.add_delayed_action(120, {action = "rings", surface = surface, position = from, no_base = false, no_sound = true})
			CONTROL.add_delayed_action(180, {action = "disappear", surface = surface, position = from})
			CONTROL.add_delayed_action(180, {action = "teleport", entity = global.fake_transmat_character, position = DIR.get_vector_sum(global.fake_transmat_character.position, {0,10})})
			CONTROL.add_delayed_action(240, {action = "rings", surface = surface, position = to, no_base = false, no_sound = true})
			CONTROL.add_delayed_action(300, {action = "appear", surface = surface, position = to})
			CONTROL.add_delayed_action(300, {action = "teleport", entity = global.fake_transmat_character, position = to})
		end
	end
	for mod,_ in pairs(global.registered_mod_manifesto_cycles or {}) do
		if remote.interfaces[mod.."-ir-manifesto"] and remote.interfaces[mod.."-ir-manifesto"]["cycle"] then
			remote.call(mod.."-ir-manifesto", "cycle", surface)
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
