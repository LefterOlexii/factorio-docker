------------------------------------------------------------------------------------------------------------------------------------------------------

function CONTROL.create_underspace(name,seed)
	local settings = {
		water = 0,
		default_enable_all_autoplace_controls = false,
		seed = seed,
		starting_area = 0,
		starting_points = {{x=0,y=0}},
		autoplace_settings = {
			tile = {
				treat_missing_as_default = false,
				settings = {
					["dry-dirt"] = {
						frequency = 1,
						size = 1,
						richness = 1,
					},
					["ir-chasm"] = {
						frequency = 1,
						size = 1,
						richness = 1,
					},
				},
			},
			entity = {
				treat_missing_as_default = false,
			},
			decorative = {
				treat_missing_as_default = false,
				settings = {
				},
			}
		},
		peaceful_mode = false,
		cliff_settings = {cliff_elevation_0 = 1024},
		map_gen_settings = {
			property_expression_names = {
				["tile:dry-dirt:probability"] = 75,
				["tile:ir-chasm:probability"] = 25,
			},
		},		
	}
	-- for _,decorative in pairs(DU.underspace_decoratives) do
		-- settings.autoplace_settings.decorative.settings[decorative] = {
			-- frequency = 0.5,
			-- size = 1,
			-- richness = 1,
		-- }
		-- settings.map_gen_settings.property_expression_names["decorative:"..decorative..":probability"] = 0.5
	-- end
	local underspace = game.create_surface(name, settings)
	underspace.freeze_daytime = true
	underspace.daytime = 0.5
	underspace.solar_power_multiplier = 0
	underspace.brightness_visual_weights = { 0, 1/0.75, 1/0.75 }
	return underspace
end

------------------------------------------------------------------------------------------------------------------------------------------------------
