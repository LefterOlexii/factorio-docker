------------------------------------------------------------------------------------------------------------------------------------------------------

-- misc

function CONTROL.player_cannot_reach(player,entity)
	player.play_sound{path = "utility/cannot_build"}
	CONTROL.player_flying_notification(player, {"cant-reach"})
end

local function reverse_projected_orientation(turn)
	turn = turn + 0.25
	local x = math.sin(turn * math.pi * 2)
	local y = -math.cos(turn * math.pi * 2)
	y = y * math.cos(math.pi / 4)
	return (math.atan2(x, -y) / (math.pi * 2)) - 0.25
end

local function orientation_to_direction(orientation,directions)
	return math.floor((reverse_projected_orientation(orientation)*directions)+0.5) % directions
end

function CONTROL.get_turret_beam_origin(position, height, width, orientation, convert_directions)
	local new = {x = position.x, y = position.y - height}
	if convert_directions ~= nil then orientation = orientation_to_direction(orientation,convert_directions)/convert_directions end -- for use with turrets that have directions
	local offset = {x = width * math.sin(orientation * math.pi * 2), y = -width * 0.707 * math.cos(orientation * math.pi * 2)}
	return DIR.get_vector_sum(new,offset)
end

function CONTROL.player_flying_notification(player,text,ttl,position)
	if player and player.valid then
		-- player.create_local_flying_text{text = text, position = position or {player.position.x,player.position.y-2}, time_to_live = ttl or 180, speed = 0.5} 
		CONTROL.add_delayed_action(1, {
			action="pseudo_flying_text",
			surface = player.surface,
			players = {player},
			text = text,
			position = {x = player.position.x, y = player.position.y - 2},
		})
	end
end

function CONTROL.entity_flying_notification(entity,text)
	CONTROL.add_delayed_action(1, {
		action="pseudo_flying_text",
		surface = entity.surface,
		players = nil,
		text = text,
		position = entity.position,
	})
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- notifications

CONTROL.notification_height = 96
CONTROL.notification_width = 320
CONTROL.notification_padding = 16
CONTROL.notification_frame_name = "ir3-notifications"

local function adjust_container(player,container)
	container.location = {
		x = (player.display_resolution.width / 2) - (CONTROL.notification_width * player.display_scale / 2),
		-- y = player.display_resolution.height - 192 - (table_size(container.children) * CONTROL.notification_height * player.display_scale)
		y = 96
	}
end

function CONTROL.add_notification(player,id,sprite,text)
	local frame = player.gui.screen
	local container = frame[CONTROL.notification_frame_name]
	if not container then
		container = frame.add {
			name = CONTROL.notification_frame_name,
			type = "frame",
			-- style = "naked_frame_with_no_spacing",
			direction = "vertical",
		}
		container.style.width = CONTROL.notification_width
		container.style.maximal_width = CONTROL.notification_width
		container.style.padding = 0
		container.style.margin = 0
	end
	adjust_container(player,container)
	if container[id] then container[id].destroy() end
	local notification = container.add {
		name = id,
		type = "table",
		column_count = 1,
	}
	notification.style.height = CONTROL.notification_height
	notification.style.maximal_height = CONTROL.notification_height
	notification.style.horizontally_stretchable = true
	notification.style.padding = 0
	notification.style.margin = 0
	notification.style.horizontal_align = "center"
	local sprite = notification.add {
		type = "sprite",
		sprite = sprite,
		style = "transmat_header_icon",
	}
	sprite.style.size = 64
	sprite.style.horizontal_align = "center"
	sprite.style.left_margin = (CONTROL.notification_width / 2) - 32
	sprite.style.right_margin = (CONTROL.notification_width / 2) - 32
	local label = notification.add {
		type = "label",
		caption = text,
		style = "caption_label",
	}
	label.style.horizontal_align = "center"
	label.style.single_line = true
	-- label.style.vertically_stretchable = true
	-- label.style.horizontally_stretchable = true
	-- label.style.margin = 0
end

function CONTROL.destroy_notification(player,id)
	local frame = player.gui.screen
	local container = frame[CONTROL.notification_frame_name]
	if container then 
		if container[id] then container[id].destroy() end
		if table_size(container.children) == 0 then
			container.destroy()
		else
			adjust_container(player,container)
		end
	end
end

function CONTROL.notify_player(params)
	if not params or not params.player_index or not params.timeout or not params.id or not params.text or not params.sprite then error("notify_player: bad params") end
	local player = game.players[params.player_index]
	if player and player.valid then
		CONTROL.add_notification(player,params.id,params.sprite,params.text)
		CONTROL.add_delayed_action(params.timeout, {
			action = "remove_notification",
			id = params.id,
			player_index = params.player_index,
		})
	end
end

-- function CONTROL.spell_out_letters(material,text,surface,position)
	-- position.x = position.x - (string.len(text)*0.5) + 0.5
	-- local count = 0
	-- for letter in text:gmatch(".") do 
		-- letter = (letter == ".") and "stop" or letter
		-- if letter ~= " " then
			-- surface.create_entity{name=material.."-letter-"..letter, position = {position.x + count, position.y}, force="neutral"}
		-- end
		-- count = count + 1
	-- end
-- end

----------------------------------------------------------------------------------------------------------------------------------------------------
