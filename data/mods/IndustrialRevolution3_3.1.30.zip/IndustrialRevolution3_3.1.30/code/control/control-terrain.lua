------------------------------------------------------------------------------------------------------------------------------------------------------

-- forestry management

local function get_chunk_area_from_position(position)
	local cp = { x = math.floor(position.x/32), y = math.floor(position.y/32) }
	return { {(cp.x*32),(cp.y*32)}, {(cp.x*32)+31.9,(cp.y*32)+31.9}}
end

-- find_entities_filtered returns things whose bounding box overlaps with area - we want strict position
local function get_position_is_in_area(position,area)
	return (position.x >= area[1][1]) and
		(position.x <= area[2][1]) and
		(position.y >= area[1][2]) and
		(position.y <= area[2][2])
end

local function get_cached_tree_validity(treename)
	global.cached_trees = global.cached_trees or {}
	if global.cached_trees[treename] == nil then
		global.cached_trees[treename] = not string.find(treename, "dead") and not string.find(treename, "dry")
	end
	return global.cached_trees[treename]
end

local function get_is_rubber_tree(treename)
	return (treename == "ir-rubber-tree") or (treename == "ir-rubber-tree-planted")
end

function CONTROL.get_husbanded_trees(event_surface,event_position,ignore_this_entity)
	local area = get_chunk_area_from_position(event_position)
	local entities = event_surface.find_entities_filtered{type = "tree", area = area}
	if entities ~= nil and table_size(entities) > 0 then
		-- split entities into two lists, rubber and non-rubber
		local rubbers = {}
		local nonrubbers = {}
		for _,e in pairs(entities) do
			if (e ~= ignore_this_entity) and get_position_is_in_area(e.position,area) and get_cached_tree_validity(e.name) then
				local t = get_is_rubber_tree(e.name) and rubbers or nonrubbers
				if table_size(t) < DIR.max_forestry_trees then table.insert(t, e) end
			end
		end
		entities = {}
		local wood = nil
		if table_size(rubbers) > 0 then
			entities = rubbers
			wood = "rubber-wood"
		elseif table_size(nonrubbers) > 0 then
			entities = nonrubbers
			wood = "wood"
		end
		return entities, wood
	end
	return {}
end

function CONTROL.get_forestries_in_chunk(event_surface,event_position,ignore_this_entity)
	local area = get_chunk_area_from_position(event_position)
	local forestries = {}
	local entities = event_surface.find_entities_filtered{name = CONTROL.forestry_names, area = area}
	if entities ~= nil and table_size(entities) > 0 then
		for _,e in pairs(entities) do
			if (e ~= ignore_this_entity) and get_position_is_in_area(e.position,area) then
				table.insert(forestries,e)
			end
		end
	end
	return forestries
end

function CONTROL.initialise_forestry_cache(surface)
	local chunks = {}
	local entities = surface.find_entities_filtered{name = CONTROL.forestry_names}
	if entities ~= nil and table_size(entities) > 0 then
		for _,e in pairs(entities) do
			local cp = { x = math.floor(e.position.x/32), y = math.floor(e.position.y/32) }
			if chunks[cp.x] == nil then chunks[cp.x] = {} end
			chunks[cp.x][cp.y] = true
		end
	end
	CONTROL.set_surface_global(surface.index,"forestries_in_chunks",chunks)
end

function CONTROL.initialise_forestry_caches()
	for _,surface in pairs(game.surfaces) do
		if (surface.name ~= CONTROL.sim_surface_name) and (surface.name ~= CONTROL.limbo_surface_name) then
			CONTROL.initialise_forestry_cache(surface)
		end
	end
end

function CONTROL.update_forestries_in_chunk(event_surface,event_position,ignore_this_entity)
	local cp = { x = math.floor(event_position.x/32), y = math.floor(event_position.y/32) }
	if CONTROL.get_surface_global(event_surface.index,"forestries_in_chunks") == nil then
		CONTROL.initialise_forestry_cache(event_surface)
	end
	if CONTROL.get_surface_global(event_surface.index,"forestries_in_chunks")[cp.x] == nil then
		local forestry_chunks = CONTROL.get_surface_global(event_surface.index,"forestries_in_chunks")
		forestry_chunks[cp.x] = {}
		CONTROL.set_surface_global(event_surface.index,"forestries_in_chunks",forestry_chunks)
	end
	-- get the chunk bounding box
	local area = get_chunk_area_from_position(event_position)
	-- count the number of forestries in the chunk
	local forestries = CONTROL.get_forestries_in_chunk(event_surface,event_position,ignore_this_entity)
	local forestry_count = table_size(forestries)
	local forestry_chunks = CONTROL.get_surface_global(event_surface.index,"forestries_in_chunks")
	forestry_chunks[cp.x][cp.y] = (forestry_count > 0) and forestry_count or nil
	if table_size(forestry_chunks[cp.x]) == 0 then forestry_chunks[cp.x] = nil end
	CONTROL.set_surface_global(event_surface.index,"forestries_in_chunks", forestry_chunks)
	local tree_count = 0
	if forestry_count > 0 then
		-- get the trees
		local trees, wood = CONTROL.get_husbanded_trees(event_surface,event_position,ignore_this_entity)
		tree_count = table_size(trees)
		local effective_count = math.floor(tree_count / forestry_count)
		-- for each forestry, set the recipe according to tree count
		for _,e in pairs(forestries) do
			if (ignore_this_entity == nil) or (e.unit_number ~= ignore_this_entity.unit_number) then
				local suffix = (e.name == "chrome-forestry") and "-fertiliser" or ""
				if effective_count >= 0 then 
					local p = e.crafting_progress
					e.set_recipe(string.format("forestry-%s%s-%02d", (effective_count > 0) and wood or "wood", suffix, effective_count))
					e.crafting_progress = p
				end
				e.recipe_locked = true
			end
		end
	end
	-- raise custom event
	script.raise_event(CONTROL.generated_event_ids.on_forestry_chunk_updated, {
		surface_index = event_surface.index,
		chunk_position = cp,
		chunk_area = area,
		tree_count = tree_count,
		forestries = forestries,
	})
end

local function tree_is_near_death(tree)
	return ((tree.tree_stage_index / tree.tree_stage_index_max) + (tree.tree_gray_stage_index / tree.tree_gray_stage_index_max)) >= 1.2
end

local function create_new_tree(surface,chunk_position,tree)
	local x = chunk_position.x
	local y = chunk_position.y
	-- audit all of the spots and then pick one of those
	local candidates = {}
	for xx=(x*32)+1,(x*32)+30,2 do
		for yy=(y*32)+1,(y*32)+30,2 do
			local p = {x=xx+0.5,y=yy+0.5}
			if not CONTROL.get_is_tile_mineable(surface,p) then
				table.insert(candidates,p)
			end
		end
	end
	-- 3.1.0: we used to check every candidate position for collision, but it's faster on average if we only check candidates one by one after random selection
	while table_size(candidates) > 0 do
		local n = CONTROL.get_RNG(surface,1,table_size(candidates))
		local p = candidates[n]
		if surface.can_place_entity{name=tree, position=p, build_check_type=defines.build_check_type.manual_ghost} then
			local name = string.gsub(tree, "%-planted", "")
			local tree = surface.create_entity{name = name, position = p, raise_built = true, create_build_effect_smoke = true, move_stuck_players = true}
			if tree and tree.valid then
				-- variants 11 and 12 (k and l) are usually fallen trees, we don't want those
				if tree.graphics_variation > 10 then
					tree.graphics_variation = CONTROL.get_RNG(surface,1,10)
				end
				local delay = 1
				for i=1,8 do
					CONTROL.add_delayed_action(delay, {action = "create_entity", surface = surface, name = "tree-twinkle", position = DIR.get_vector_sum(p,{x = 1-(CONTROL.get_RNG(surface)*2), y = CONTROL.get_RNG(surface) * -4})})
					delay = delay + CONTROL.get_RNG(surface,5,10)
				end
			end
			return
		else
			table.remove(candidates,n)
		end
	end
end

local function get_any_forestry_can_grow(forestries)
	local fluids = {
		["chrome-forestry"] = "liquid-fertiliser",
	}
	for _,forestry in pairs(forestries) do
		local powered = not forestry.prototype.electric_energy_source_prototype or (forestry.energy > 0)
		local fluid = forestry.get_fluid_contents()[fluids[forestry.name] or "water"]
		if powered and fluid and fluid >= DIR.forestry_fluid_minimum then return true end
	end
	return false
end

function CONTROL.process_forestry_chunk(surface, chunk_position)
	local x = chunk_position.x
	local y = chunk_position.y
	local trees,_ = CONTROL.get_husbanded_trees(surface,{x=x*32,y=y*32})
	local tree_count = table_size(trees)
	local new_trees = {}
	local forestries = CONTROL.get_forestries_in_chunk(surface,{x=x*32,y=y*32})
	-- growth
	if get_any_forestry_can_grow(forestries) then
		if tree_count > 0 and tree_count < DIR.max_forestry_trees then
			if CONTROL.get_RNG(surface) < (tree_count / DIR.max_forestry_trees) then
				local pick = CONTROL.get_RNG(surface,1,tree_count)
				table.insert(new_trees,trees[pick].name)
			end
		end
		for _,tree in pairs(trees) do
			if CONTROL.get_RNG(surface) <= (1/DIR.max_forestry_trees) then
				table.insert(new_trees,tree.name)
				tree.damage(9000, "neutral", "poison")
			end
		end
	end
	-- deaths
	for _,tree in pairs(trees) do
		if tree and tree.valid and tree_is_near_death(tree) then
			surface.create_entity({name = "pollution-cloud-5", position = tree.position})
			tree.damage(9000, "neutral", "poison")
		end
	end
	-- births
	for _,tree in pairs(new_trees) do create_new_tree(surface,chunk_position,tree) end
	-- klaxon
	local tree_threshold = game.parse_map_exchange_string(game.get_map_exchange_string()).map_settings.pollution.min_pollution_to_damage_trees
	if tree_count > 0 and surface.get_pollution({x*32,y*32}) >= tree_threshold then
		for _,f in pairs(forestries) do
			surface.play_sound{path = "klaxon", volume_modifier = 1, position = f.position}
			rendering.draw_animation{
				animation="pollution-warning-animation",
				render_layer="air-entity-info-icon",
				target=f,
				target_offset={0,-1.25},
				surface=surface,
				time_to_live = CONTROL.forestry_cycle_interval
			}
		end
	end
end

function CONTROL.forestry_cycle()
	local delay = CONTROL.forestry_cycle_chunk_interval
	for _,surface in pairs(game.surfaces) do
		if (surface.name ~= CONTROL.sim_surface_name) and (surface.name ~= CONTROL.limbo_surface_name) then
			if CONTROL.get_surface_global(surface.index,"forestries_in_chunks") == nil then
				CONTROL.initialise_forestry_cache(surface)
			end
			for x,row in pairs(CONTROL.get_surface_global(surface.index,"forestries_in_chunks")) do
				for y,_ in pairs(row) do
					CONTROL.add_delayed_action(delay, {action = "process_forestry_chunk", chunk_position = {x=x,y=y}, surface_index = surface.index })
					delay = delay + CONTROL.forestry_cycle_chunk_interval
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- resources: gem rocks and fissures

function CONTROL.get_RNG(surface,from,to)
	if not surface or not surface.valid then error("CONTROL.get_RNG() called on bad surface") end
	if global.RNG == nil then global.RNG = {} end
	if global.RNG[surface.index] == nil then global.RNG[surface.index] = game.create_random_generator(surface.map_gen_settings.seed) end
	if from == nil or to == nil then return global.RNG[surface.index]() end
	return global.RNG[surface.index](from,to)
end

-- function CONTROL.allow_gems(surface_name, value)
	-- local surface = game.surfaces[surface_name]
	-- if not surface then return false end
	-- if global.surfaces_with_gems == nil then global.surfaces_with_gems = { nauvis = true } end
	-- global.surfaces_with_gems[surface_name] = value
	-- return true
-- end

-- function CONTROL.surface_allows_gems(surface_name)
	-- if global.surfaces_with_gems == nil then global.surfaces_with_gems = { nauvis = true } end
	-- return global.surfaces_with_gems[surface_name]
-- end

-- function CONTROL.set_surface_gem_radius(surface_name,radius)
	-- if global.surface_gem_replacement_radii == nil then global.surface_gem_replacement_radii = {} end
	-- global.surface_gem_replacement_radii[surface_name] = radius
-- end

-- function CONTROL.get_surface_gem_replacement_radius(surface_name)
	-- if global.surface_gem_replacement_radii == nil then global.surface_gem_replacement_radii = {} end
	-- return global.surface_gem_replacement_radii[surface_name]
-- end

-- function CONTROL.allow_fissures(surface_name, value)
	-- local surface = game.surfaces[surface_name]
	-- if not surface then return false end
	-- if global.surfaces_with_fissures == nil then global.surfaces_with_fissures = { nauvis = true } end
	-- global.surfaces_with_fissures[surface_name] = value
	-- return true
-- end

-- function CONTROL.surface_allows_fissures(surface_name)
	-- if global.surfaces_with_fissures == nil then global.surfaces_with_fissures = { nauvis = true } end
	-- return global.surfaces_with_fissures[surface_name]
-- end

--[[
function CONTROL.get_checkerboard_offset(surface)
	if global.checkerboards == nil then global.checkerboards = {} end
	if global.checkerboards[surface.index] == nil then
		global.checkerboards[surface.index] = { x = CONTROL.get_RNG(surface,8*32)-(4*32), y = CONTROL.get_RNG(surface,0,8*32)-(4*32)}
	end
	return global.checkerboards[surface.index]
end

function CONTROL.add_rock_gems(surface,chunk_position,area)
	if DIR.components.gem and DIR.components.gem.ore_patch_chances then
		-- check that surface is allowed
		if not CONTROL.surface_allows_gems(surface.name) then return end
		-- checkerboard of 8x8 chunk regions - half of regions are ignored
		-- keep track of a once-generated RNG offset to the checkerboard so that you can't expect to find gems by heading in the same directions every game
		local offset = CONTROL.get_checkerboard_offset(surface)
		if (math.floor((chunk_position.x+offset.x)/8)+math.floor((chunk_position.y+offset.y)/8)) % 2 == 0 then return end
		-- by default gems never appear in starting area - unless remote interface set radius override
		local chunk_distance = ((chunk_position.x*32)^2)+((chunk_position.y*32)^2)
		local exclusion_radius = CONTROL.get_surface_gem_replacement_radius(surface.name) or DIR.starting_area_clearing_radius
		if chunk_distance < (exclusion_radius^2) then return end
		-- otherwise add a smattering of sparklies
		local resources = surface.find_entities_filtered{area=area, type="resource"}
		if table_size(resources) > 0 then
			for _,resource in pairs(resources) do
				for material,ores in pairs(DIR.components.gem.ore_patch_chances) do
					for target,chance in pairs(ores) do
						if resource and resource.valid and target == resource.name and CONTROL.get_RNG(surface) < chance then
							local name = "gem-rock-"..material
							local p = surface.find_non_colliding_position(name, resource.position, 5, 0.25, true)
							if p then
								local rock = surface.create_entity{name=name, position=p, raise_built=true}
							end
						end
					end
				end
			end
		end
	end
end
--]]

-- 3.1.17 - decorate autoplaced gem rocks
function CONTROL.decorate_gem_rocks(surface,chunk_position,area)
	local rocks = surface.find_entities_filtered{ area = area, name = CONTROL.gem_rocks }
	for _,rock in pairs(rocks) do
		script.raise_event(defines.events.script_raised_built, {entity = rock})
	end
end

-- 3.1.17: replace autoplaced fissures with a normalised yield one - this also triggers raise_built which is needed for the gas smoke
function CONTROL.replace_fissures(surface,chunk_position,area)
	local fissures = surface.find_entities_filtered{area = area, name = CONTROL.autoplaced_fissures, type = {"resource"}}
	if (table_size(fissures) > 0) then
		for _,fissure in pairs(fissures) do
			-- destroy first
			local position = fissure.position
			local direction = fissure.direction
			local force = fissure.force
			local name = fissure.name
			fissure.destroy{raise_destroy=true}
			-- create
			local new = surface.create_entity {
				name = name,
				position = position,
				direction = direction,
				force = force,
				fast_replace = false,
				raise_built = true,
				create_build_effect_smoke = false,
				spawn_decorations = false,
			}
			if new and new.valid then surface.destroy_decoratives{area = new.bounding_box} end
		end
	end
	-- for x = area.left_top.x, area.right_bottom.x do
		-- for y = area.left_top.y, area.right_bottom.y do
			-- local p = surface.calculate_tile_properties({"ir-fissure-type-noise"}, {{x=x,y=y}})
			-- local n = p["ir-fissure-type-noise"] and math.floor(p["ir-fissure-type-noise"][1]*10)/10 or "X"
			-- local c = (type(n)=="number") and DIR.hsva2rgba((n+1)/2,1,1) or {1,1,1}
			-- rendering.draw_text{text=n,surface=surface,target={x=x+0.5,y=y+0.5},color=c,scale=1,font="default-bold"}
		-- end
	-- end
end

function CONTROL.replenish_fissure(entity)
	if string.find(entity.name,"fissure") then
		entity.amount = entity.prototype.normal_resource_amount
	end
end

function CONTROL.add_starting_resources(surface)
	if surface and surface.valid then
		-- starting area fissures
		local resources = {"copper-ore","coal","tin-ore"}
		local nearest = {}
		for _,resource in pairs(resources) do
			local entities = surface.find_entities_filtered{type = "resource", name = resource}
			if entities and table_size(entities) > 0 then			
				for _,entity in pairs(entities) do
					if nearest[resource] == nil or DIR.get_distance_squared({x=0,y=0},entity.position) < DIR.get_distance_squared({x=0,y=0},nearest[resource]) then
						nearest[resource] = entity.position
					end
				end
			else
				nearest[resource] = {x=0,y=0}
			end
		end
		local fissure_origin = {x = 0, y = 0}
		for _,resource in pairs(nearest) do
			fissure_origin.x = fissure_origin.x + resource.x
			fissure_origin.y = fissure_origin.y + resource.y
		end
		fissure_origin = {x = fissure_origin.x / table_size(nearest), y = fissure_origin.y / table_size(nearest)}
		for _,fissure in pairs(CONTROL.start_location_fissures) do
			local theta = CONTROL.get_RNG(surface)*math.pi*2
			local distance = 10
			local fp = { x = fissure_origin.x + (math.cos(theta)*distance), y = fissure_origin.y + (math.sin(theta)*distance) }
			local p = surface.find_non_colliding_position(fissure, fp, 32, 0.5, true)
			if p then
				local fe = surface.create_entity{name = fissure, position = p, raise_built = true}
				if fe and fe.valid then surface.destroy_decoratives{area = fe.bounding_box} end
			end
		end
	end

end

function CONTROL.get_is_tile_mineable(s,p)
	local p = game.tile_prototypes[s.get_tile(p).name]
	return p and p.mineable_properties.minable or false -- ugh, inconsistent spelling of "mineable"
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- resource replacement. because why not

-- local function get_first_non_autoplaced_ore_in_chunk(surface,chunk_position)
	-- local entities = surface.find_entities_filtered{type = "resource", area = chunk_position.area}
	-- if entities and table_size(entities) > 0 then
		-- for _,e in pairs(entities) do
			-- if CONTROL.non_autoplaced_ores[e.name] then return e.name end
		-- end
	-- end
	-- return nil
-- end

-- local function get_ChunkPositionAndArea(x,y)
	-- return {
		-- x = x,
		-- y = y,
		-- area = {{x=x*32,y=y*32},{x=(x*32)+31,y=(y*32)+31}}
	-- }
-- end

-- local function get_first_non_autoplaced_ore_in_neighbours(surface,chunk_position)
	-- for dx = -1,1 do
		-- for dy = -1,1 do
			-- local result = get_first_non_autoplaced_ore_in_chunk(surface,get_ChunkPositionAndArea(chunk_position.x+dx,chunk_position.y+dy))
			-- if result ~= nil then return result end
		-- end
	-- end
	-- return nil
-- end

-- function CONTROL.replace_generic_ores(surface,chunk_position,area)
	-- local entities = surface.find_entities_filtered{type = "resource", name = "generic", area = area}
	-- if entities and table_size(entities)> 0 then
		-- local found_ore = get_first_non_autoplaced_ore_in_neighbours(surface,chunk_position)
		-- if found_ore == nil then
			-- local group = CONTROL.weighted_ore_groups[CONTROL.get_RNG(surface,1,table_size(CONTROL.weighted_ore_groups))]
			-- found_ore = CONTROL.ores_by_group[group][CONTROL.get_RNG(surface,1,table_size(CONTROL.ores_by_group[group]))]
		-- end
		-- if found_ore ~= nil then
			-- for _,e in pairs(entities) do
				-- surface.create_entity{name = found_ore, amount = e.amount, position = e.position}
				-- e.destroy()
			-- end
		-- end
	-- end
-- end

------------------------------------------------------------------------------------------------------------------------------------------------------
