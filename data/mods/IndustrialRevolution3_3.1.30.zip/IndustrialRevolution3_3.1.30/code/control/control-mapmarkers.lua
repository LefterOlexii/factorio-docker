------------------------------------------------------------------------------------------------------------------------------------------------------

function CONTROL.get_map_markers(entity)
	return entity.force.find_chart_tags(entity.surface, entity.bounding_box)
end

function CONTROL.get_map_markers_at_position(surface, position)
	return entity.force.find_chart_tags(surface, { left_top = position, right_bottom = position})
end

function CONTROL.add_map_marker(entity, icon_type, icon_name, text, player)
	if icon_type and icon_name then
		entity.force.add_chart_tag(entity.surface, { icon = { type = icon_type, name = icon_name}, position = entity.position, text = text })
		if player and player.valid then player.play_sound{path = "map-marker-ping"} end
	end
end

function CONTROL.change_map_markers(entity, icon_type, icon_name)
	local markers = CONTROL.get_map_markers(entity)
	if markers then
		for _,marker in pairs(markers) do
			marker.icon = { type = icon_type, name = icon_name}
		end
	end
end

function CONTROL.get_has_map_marker(entity)
	return next(CONTROL.get_map_markers(entity)) ~= nil
end

function CONTROL.remove_markers(entity)
	if entity and entity.valid then
		for _,marker in pairs(CONTROL.get_map_markers(entity)) do
			marker.destroy()
		end
	end
end

function CONTROL.remove_markers_at_position(surface, position)
	for _,marker in pairs(CONTROL.get_map_markers_at_position(surface, position)) do
		marker.destroy()
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
