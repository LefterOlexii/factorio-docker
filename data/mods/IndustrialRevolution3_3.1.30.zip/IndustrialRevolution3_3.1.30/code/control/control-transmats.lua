------------------------------------------------------------------------------------------------------------------------------------------------------

-- transmats

function CONTROL.get_transmat_cache_name(surface,force)
	return "transmat_caches_v2_"..surface.name.."_"..force.name
end

local function get_surfaces_sharing_tags(surface_name)
	local surfaces = { game.surfaces[surface_name] }
	local tags = global["transmat-tags-"..surface_name]
	if tags ~= nil and table_size(tags) > 0 then 
		for _,surface in pairs(game.surfaces) do
			if surface.name ~= surface_name and not global["transmat-bans-"..surface.name] then
				local other_tags = global["transmat-tags-"..surface.name]
				if other_tags ~= nil and table_size(other_tags) > 0 then
					for other_tag,_ in pairs(other_tags) do
						if tags[other_tag] then
							table.insert(surfaces,surface)
							break
						end
					end
				end
			end
		end
	end
	return surfaces
end

function CONTROL.reset_transmat_caches()
	for _,force in pairs(game.forces) do
		for _,surface in pairs(game.surfaces) do
			local cache_name = CONTROL.get_transmat_cache_name(surface,force)
			if global[cache_name] ~= nil then
				DIR.spam_log("on_config_changed: resetting cached transmat list for "..surface.name.."/"..force.name, DIR.log_level.warning)
				global[cache_name] = nil
			end
		end
	end
end

local function transmat_can_connect(from,to,player)
	return (CONTROL.get_transmat_status(from,false) == "transmat-status-ready") and (CONTROL.get_transmat_status(to,true) == "transmat-status-ready")
end

function CONTROL.create_limbo_surface(name, size, width, daytime)
	local width = width or 1
	local size = size or 16
	local surface = game.create_surface(name, {
		width = 64,
		height = 64,
		starting_points = {},
		default_enable_all_autoplace_controls = false,
		property_expression_names = {cliffiness = 0},
	})
	surface.request_to_generate_chunks({0,0},1)
	surface.force_generate_chunk_requests()
	for x=math.ceil(-(size*width)/64),math.floor((size*width)/64) do
		for y=math.ceil(-size/64),math.floor(size/64) do
			if x ~= 0 or y ~= 0 then
				surface.clone_area{
					source_area = {left_top = {0,0}, right_bottom = {32,32}},
					destination_area = {left_top = {x*32,y*32}, right_bottom = {(x*32)+32, (y*32)+32}},
					clone_tiles = true,
					clone_entities = false,
					clone_decoratives = false,
					expand_map = true,
				}
				surface.set_chunk_generated_status({x,y}, defines.chunk_generated_status.entities)
			end
		end
	end
	surface.daytime = daytime or 0
	surface.freeze_daytime = true
	return surface
end

function CONTROL.get_or_create_limbo()
	if not game.surfaces[CONTROL.limbo_surface_name] then CONTROL.create_limbo_surface(CONTROL.limbo_surface_name) end
	return game.surfaces[CONTROL.limbo_surface_name]
end

local function get_or_create_static()
	local limbo = CONTROL.get_or_create_limbo()
	local static = limbo.find_entity("static",{0,0})
	if not static then static = limbo.create_entity({name = "static", position = {0,0}}) end
	return static	
end

function CONTROL.get_transmat_reference_by_data(surface_name, force_name, position)
	return "transmat_"..surface_name.."_"..force_name.."_"..position.x.."_"..position.y
end

function CONTROL.get_transmat_reference(transmat)
	return CONTROL.get_transmat_reference_by_data(transmat.surface.name, transmat.force.name, transmat.position)
end

function CONTROL.get_cached_transmats(player)
	local transmats = {}
	local surfaces = get_surfaces_sharing_tags(player.surface.name)
	for _,surface in pairs(surfaces) do
		local changed = false
		local cache_name = CONTROL.get_transmat_cache_name(surface,player.force)
		local cache = global[cache_name]
		if cache == nil then 
			cache = {}
			for _,transmat in pairs(surface.find_entities_filtered{name="chrome-transmat", force=player.force}) do
				cache[transmat.unit_number] = transmat
				transmats[transmat.unit_number] = transmat
			end
			changed = true
		else
			for unit_number,transmat in pairs(cache) do
				if not (transmat and transmat.valid and transmat.force == player.force) then
					cache[unit_number] = nil
					changed = true
				else
					transmats[unit_number] = transmat
				end
			end
		end
		if changed then global[cache_name] = cache end
	end
	return transmats
end

function CONTROL.cache_transmat(transmat)
	local cache_name = CONTROL.get_transmat_cache_name(transmat.surface,transmat.force)
	local cache = global[cache_name] or {}
	cache[transmat.unit_number] = transmat
	global[cache_name] = cache
end

function CONTROL.set_cutscene_state(state,character,player,from,to,target_position)
	if state then
		CONTROL.set_player_global(player.index, "transmat_from", from)
		CONTROL.set_player_global(player.index, "transmat_to", to)
		CONTROL.set_player_global(player.index, "teleport_target_position", target_position)
		CONTROL.set_player_global(player.index, "character", character)
		CONTROL.set_player_global(player.index, "destructible", character.destructible)
		if from and from.valid then
			from.operable = false
			from.destructible = false
			from.minable = false
		end
		if to and to.valid then
			to.operable = false
			to.destructible = false
			to.minable = false
		end
		if character and character.valid then
			character.destructible = false
			character.color = player.color
		end
	else
		if from and from.valid then
			from.operable = true
			from.destructible = true
			from.minable = true
		end
		if to and to.valid then
			to.operable = true
			to.destructible = true
			to.minable = true
		end
		if character and character.valid then
			if CONTROL.get_player_global(player.index,"destructible") == nil then character.destructible = true 
			else character.destructible = CONTROL.get_player_global(player.index,"destructible") end
		end
		CONTROL.set_player_global(player.index, "transmat_from", nil)
		CONTROL.set_player_global(player.index, "transmat_to", nil)
		CONTROL.set_player_global(player.index, "teleport_target_position", nil)
		CONTROL.set_player_global(player.index, "character", nil)
		CONTROL.set_player_global(player.index, "destructible", nil)
		-- CONTROL.set_player_global(player.index, "transmat-car", nil)	
		player.set_controller{type=defines.controllers.character, character=character}
	end
end

function CONTROL.get_characters_in_range(transmat)
	return transmat.surface.find_entities_filtered{position=transmat.position, type="character", name="character", radius = CONTROL.transmat_radius}
end

function CONTROL.get_vehicles_in_range(transmat)
	return transmat.surface.find_entities_filtered{position=transmat.position, type="car", radius = CONTROL.transmat_radius}
end

function CONTROL.clone_on_surface(entity,surface,position)
	return entity.clone({surface = surface, position = position, force = entity.force, create_build_effect_smoke = false})
end

function CONTROL.clone_in_limbo(entity)
	return CONTROL.clone_on_surface(entity, CONTROL.get_or_create_limbo(), {0,0})
end

function CONTROL.send_player_to_limbo(player)
	local limbo = CONTROL.get_or_create_limbo()
	player.teleport({0,0}, limbo.name, true)
end

function CONTROL.send_player_to_limbo_and_return(player,start_position,surface)
	CONTROL.send_player_to_limbo(player)
	player.teleport(start_position, surface, true)
end

function CONTROL.transmat_sparks_effect(surface,position,disappear)
	local explosion_name = "transmat-sparks-" .. (disappear and "disappear" or "appear")
	surface.create_entity{name=explosion_name, position=position, create_build_effect_smoke=false}
end

local function swap_inventory(from,to)
	for i=1,#from.get_main_inventory() do
		if to.get_main_inventory()[i] ~= nil then
			to.get_main_inventory()[i].swap_stack(from.get_main_inventory()[i])
		end
	end
end

function CONTROL.hide_character_in_limbo(character,player_index,no_sparks)
	local clone = CONTROL.clone_in_limbo(character)
	log(serpent.block(clone.crafting_queue or ""))
	swap_inventory(character,clone) -- to preserve quickbar filter references to blueprints etc.
	CONTROL.set_player_global(player_index,"character",clone)
	character.destroy()
end

function CONTROL.unhide_and_move_character(character,player_index,surface,destination,no_sparks)
	local clone = CONTROL.clone_on_surface(character,surface,destination)
	swap_inventory(character,clone)
	CONTROL.set_player_global(player_index,"character",clone)
	game.players[player_index].associate_character(clone)
	character.destroy()
end

function CONTROL.transmat_ring_effects(surface,position,no_base,base_entity,no_sound)
	if not no_base then surface.create_entity{name=base_entity or "transmat-base", position=position, create_build_effect_smoke=false} end
	surface.create_entity{name="transmat-rings-front", position=position, create_build_effect_smoke=false}
	surface.create_entity{name="transmat-rings-back", position=DIR.get_vector_sum(position,{x=0,y=-1}), create_build_effect_smoke=false}
	if not no_sound then
		CONTROL.add_delayed_action(15,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
		CONTROL.add_delayed_action(30,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
		CONTROL.add_delayed_action(45,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
		CONTROL.add_delayed_action(105,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
		CONTROL.add_delayed_action(120,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
		CONTROL.add_delayed_action(135,{action = "play_sound", sound = "transmat-whoosh", position = position, surface = surface})
	end
end

CONTROL.teleport_cutscene_stages = {
	[0] = function(player,character,from,to,target)
		from.surface.play_sound{path = "transmat-spinup", position = from.position}
	end,
	-- 1 to 6 = rim light glow sprites inserted here, below
	[7] = function(player,character,from,to,target)
		CONTROL.transmat_ring_effects(from.surface,from.position)
	end,
	[8] = function(player,character,from,to,target)
		CONTROL.hide_character_in_limbo(character,player.index)
		CONTROL.transmat_sparks_effect(from.surface,from.position,true)
	end,
	-- [9] - no action, just waiting
	[10] = function(player,character,from,to,target)
		-- intra- and cross-surface teleport diverge here
		-- need to interrupt and restart sequence at stage 3 since character teleports and cutscenes in general don't work cross-surface
		if from.surface.index ~= to.surface.index then
			player.exit_cutscene()
			player.teleport(target,to.surface,true)
			local waypoints = CONTROL.get_teleport_waypoints(target, target, 2, 3)	
			player.set_controller{type=defines.controllers.cutscene, start_position=target, waypoints=waypoints, start_zoom = 1, chart_mode_cutoff=0.5}
			player.jump_to_cutscene_waypoint(11)
		end
	end,
	-- [11] - no action, just transitioning
	[12] = function(player,character,from,to,target)
		player.force.chart(to.surface,to.bounding_box) -- sounds don't play in uncharted areas and player cutscene controller doesn't chart
		to.surface.play_sound{path = "transmat-spindown", position = to.position}
		CONTROL.transmat_ring_effects(to.surface,to.position)
	end,
	[13] = function(player,character,from,to,target)
		CONTROL.unhide_and_move_character(character,player.index,to.surface,target)
		CONTROL.transmat_sparks_effect(to.surface,to.position,false)
	end,
	[14] = function(player,character,from,to,target)
		CONTROL.set_cutscene_state(false,character,player,from,to)
	end,
}

function CONTROL.transmat_hex_lights(i,from,to,ttl)
local light_intensity = 0.75
	local light_color = {1.0,0.95,0.9}
	local r = 0.95
	local squished_hexagonal_offset = {x = r * math.cos((i-2.5)*(math.pi/3)), y = r * 0.707 * math.sin((i-2.5)*(math.pi/3))}
	if ttl == nil then ttl = (from.surface.index == to.surface.index) and 600 or 560 end
	-- if from == to then ttl = 180 end
	local unit_numbers_drawn = {}
	for _,transmat in pairs({from,to}) do
		if transmat and transmat.valid and not unit_numbers_drawn[transmat.unit_number] then
			unit_numbers_drawn[transmat.unit_number] = true
			rendering.draw_sprite {
				target=transmat,
				sprite="transmat-glow-"..i,
				x_scale=0.5,
				y_scale=0.5,
				render_layer = "lower-object",
				surface=transmat.surface,
				time_to_live = ttl
			}
			rendering.draw_light {
				sprite = "utility/light_medium",
				scale = 0.5,
				intensity = light_intensity,
				color = light_color,
				target = transmat,
				target_offset = squished_hexagonal_offset,
				surface = transmat.surface,
				time_to_live = ttl
			}
			transmat.surface.play_sound{path = "transmat-note-low", position = transmat.position}
		end
	end
end

for i=1,6 do
	CONTROL.teleport_cutscene_stages[i] = function(player,character,from,to,target)
		CONTROL.transmat_hex_lights(i,from,to)
	end
end

function CONTROL.on_cutscene(event)
	local target = CONTROL.get_player_global(event.player_index,"teleport_target_position")
	local player = game.players[event.player_index]
	if target then
		local from = CONTROL.get_player_global(event.player_index,"transmat_from")
		local to = CONTROL.get_player_global(event.player_index,"transmat_to")
		if from and from.valid and to and to.valid then
			local character = CONTROL.get_player_global(event.player_index,"character")
			if CONTROL.teleport_cutscene_stages[event.waypoint_index] then
				CONTROL.teleport_cutscene_stages[event.waypoint_index](player,character,from,to,target)
			end
		end
	end
	local intro_clone = CONTROL.get_player_global(event.player_index,"intro_character")
	if intro_clone then
		local intro_transmat = CONTROL.get_player_global(event.player_index,"intro_transmat")
		if CONTROL.intro_cutscene_stages[event.waypoint_index] then
			CONTROL.intro_cutscene_stages[event.waypoint_index](player,intro_clone,intro_transmat)
		end
	end
end

function CONTROL.get_teleport_waypoints(start_position, target_position, transition_zoom, stage)
	if stage == nil or type(stage) ~= "number" or stage > 3 or stage < 0 then error("Bad transmat cutscene stage. Must be 1-3") end
	local transition_zooms = {
		[1] = transition_zoom,
		[2] = 1,
		[3] = 1,
	}
	transition_zoom = transition_zooms[stage]
	local waypoints = {}
	-- parts 1 & 2
	-- [0] zoom in
	table.insert(waypoints,
		{
			position = start_position,
			transition_time = 30,
			time_to_wait = 0,
			zoom = 2,
		}
	)
	-- [1] to [6] ring lights
	for i=1,6 do
		table.insert( waypoints, { position = start_position, transition_time = 0, time_to_wait = 20, zoom = 2})
	end
	-- [7] rings up
	table.insert(waypoints,
		{
			position = start_position,
			transition_time = 0,
			time_to_wait = 30,
			zoom = 2,
		}
	)
	-- [8] teleport
	table.insert(waypoints,
		{
			position = start_position,
			transition_time = 0,
			time_to_wait = 60,
			zoom = 2,
		}
	)
	-- [9] wait
	table.insert(waypoints,
		{
			position = start_position,
			transition_time = 0,
			time_to_wait = 90,
			zoom = 2,
		}
	)
	-- [10] zoom out (stage 2 ends here)
	table.insert(waypoints,
		{
			position = start_position,
			transition_time = 60,
			time_to_wait = (stage == 2) and 30 or 0,
			zoom = transition_zoom,
		}
	)
	-- stage 3 restarts here
	-- [11] intra-surface transition
	table.insert(waypoints,
		{
			position = target_position,
			transition_time = (stage == 3) and 30 or 90,
			time_to_wait = 0,
			zoom = transition_zoom,
		}
	)
	-- [12] rings up
	table.insert(waypoints,
		{
			position = target_position,
			transition_time = 0,
			time_to_wait = 0,
			zoom = transition_zoom,
		}
	)
	-- [13] wait and rematerialise
	table.insert(waypoints,
		{
			position = target_position,
			transition_time = 60,
			time_to_wait = 0,
			zoom = 2,
		}
	)
	-- [14] wait
	table.insert(waypoints,
		{
			position = target_position,
			transition_time = 0,
			time_to_wait = 90,
			zoom = 2,
		}
	)
	return waypoints
end

function CONTROL.player_nuhuh(player)
	if player and player.valid then player.play_sound{path = "transmat-error"} end
end

function CONTROL.fancy_teleport(player, from, to)
	if not from or not to or not from.valid or not to.valid or not transmat_can_connect(from,to,player) then
		CONTROL.player_nuhuh(player)
		return false
	end	
	-- player initiated teleport, but it applies to any characters in range of the pad
	local characters = CONTROL.get_characters_in_range(from)
	-- take the power
	from.energy = from.energy - DIR.transmat_cost
	to.energy = to.energy - DIR.transmat_cost	
	-- set up waypoint stages
	for _,character in pairs(characters) do
		if character.player then
			local start_position = character.position
			local target_position = DIR.get_vector_difference(to.position, DIR.get_vector_difference(from.position,start_position))
			local distance_squared =  DIR.get_distance_squared(start_position,target_position)
			local transition_zoom = (distance_squared >= 1000000) and 0.1 or 1 -- zoom up to map level if more than 1km away
			-- we now have 3 cutscene segments: 1 for intra-surface, 2 and 3 for cross-surface; 3 is triggered at the end of 2
			local waypoints = CONTROL.get_teleport_waypoints(start_position, target_position, transition_zoom, (from.surface.index == to.surface.index) and 1 or 2)	
			-- discourage local biters from targeting the character
			-- cross-surface transport for less than a tick turns out be the least annoying mass de-aggro and is very cheap, regardless of any aggro'd unit's distance from player
			-- in the following tick the character is invulnerable so not re-targeted
			CONTROL.send_player_to_limbo_and_return(character.player, start_position, character.surface)
			-- start the cutscene
			CONTROL.set_cutscene_state(true,character,character.player,from,to,target_position)
			character.player.set_controller{type=defines.controllers.cutscene, start_position=start_position, waypoints=waypoints, chart_mode_cutoff=0.5}
		end
	end
	return true
end

function CONTROL.client_quits_during_teleport_cutscene(event)
	local from = CONTROL.get_player_global(event.player_index,"transmat_from")
	local to = CONTROL.get_player_global(event.player_index,"transmat_to")
	local target = CONTROL.get_player_global(event.player_index,"teleport_target_position")
	local character = CONTROL.get_player_global(event.player_index,"character")
	local player = game.players[event.player_index]
	player.exit_cutscene()
	CONTROL.unhide_and_move_character(character,player.index,to.surface,target)
	CONTROL.set_cutscene_state(false,character,player,from,to)
end

function CONTROL.get_transmat_text(transmat)
	return global[CONTROL.get_transmat_reference(transmat)] or ""
end

function CONTROL.get_transmat_text_by_data(surface_name, force_name, position)
	return global[CONTROL.get_transmat_reference_by_data(surface_name, force_name, position)] or ""
end

function CONTROL.render_drop_text(text, target, offset)
	if offset == nil then offset = {x=0,y=0} end
	rendering.draw_text{text=text, surface=target.surface, target=target, target_offset=DIR.get_vector_sum(offset,{x=3/64,y=3/64}), alignment="center", color={0,0,0,0.75}, scale=1, font="default-bold", forces={target.force}, draw_on_ground=true, only_in_alt_mode=true}
	rendering.draw_text{text=text, surface=target.surface, target=target, target_offset=offset, alignment="center", color={255, 230, 192}, scale=1, font="default-bold", forces={target.force}, draw_on_ground=true, only_in_alt_mode=true}
end

function CONTROL.set_transmat_text(transmat, text)
	global[CONTROL.get_transmat_reference(transmat)] = text
	local found = false
	local renders = rendering.get_all_ids(DIR.IR)
	for _,render in pairs(renders) do
		local target = rendering.get_target(render)
		if target and target.entity and target.entity == transmat and rendering.get_type(render) == "text" then
			rendering.set_text(render,text)
			found = true
		end
	end
	if not found then
		CONTROL.render_drop_text(text, transmat, {x=0,y=1.4})
	end
end

function CONTROL.get_transmat_label(transmat)
	local name = CONTROL.get_transmat_text(transmat)
	if name == "" then
		local id = ((transmat.unit_number + 16^6) ^ 2) % 16^6
		id = string.upper(string.format("%06x",id))
		id = string.sub(id,1,3) .. "-" .. string.sub(id,4,6)
		name = id
	end
	return name
end

function CONTROL.get_transmat_indicator_icon(status)
	local mapping = {
		["transmat-status-ready"] = "ready",
		["transmat-status-busy"] = "busy",
		["transmat-status-blocked"] = "busy",
		["transmat-status-no-passengers"] = "busy",
		["transmat-status-passenger-busy"] = "busy",
		["transmat-status-no-energy"] = "lowenergy",
	}
	local indicator = mapping[status] or "error"
	return "[img=transmat-"..indicator.."]"
end

function CONTROL.get_transmat_status_localisation(status)
	-- local icon = CONTROL.get_transmat_indicator_icon(status)
	if type(status) == "string" then status = {"gui."..status} end
	return status
end

local function get_characters_crafting_count(list)
	if not list then return 0 end
	local count = 0
	for _,c in pairs(list) do
		if c.crafting_queue_size > 0 then count = count + 1 end
	end
	return count
end

function CONTROL.get_transmat_status(transmat,remote)
	if not transmat or not transmat.valid then return "transmat-status-unknown" end
	local banned = global["transmat-bans-"..transmat.surface.name]
	if banned ~= nil then return (banned == true) and "transmat-status-error" or banned
		elseif transmat.operable == false then return "transmat-status-busy"
		elseif (transmat.energy < DIR.transmat_cost) then return "transmat-status-no-energy"
		elseif table_size(CONTROL.get_vehicles_in_range(transmat)) > 0 then return "transmat-status-blocked"
	end
	local chars = CONTROL.get_characters_in_range(transmat)
	local cc = get_characters_crafting_count(chars)
	if remote and table_size(chars) > 0 then return "transmat-status-blocked"	
		elseif not remote and table_size(chars) == 0 then return "transmat-status-no-passengers"	
		elseif not remote and cc > 0 then return "transmat-status-passenger-busy"	
		elseif remote and table_size(chars) == 0 then return "transmat-status-ready"	
		else return "transmat-status-ready" 
	end
end

function CONTROL.update_transmat_label(player_index, text)
	local player = game.players[player_index]
	local transmat = CONTROL.get_current_transmat_from_gui(player)
	if transmat and transmat.valid then
		CONTROL.set_transmat_text(transmat,text)
		if player.gui.screen[CONTROL.transmat_gui] then
			player.gui.screen[CONTROL.transmat_gui]["transmat-header"]["transmat-header-title"].caption = CONTROL.get_transmat_label(transmat)
		end
		if CONTROL.get_has_map_marker(transmat) then
			CONTROL.remove_markers(transmat)
			CONTROL.add_map_marker(transmat, "virtual", "ir-transmat-signal", CONTROL.get_transmat_label(transmat))
		end
	end
end

function CONTROL.close_edit(event)
	local player = game.players[event.player_index]
	local textfield = player.gui.screen[CONTROL.transmat_gui]["transmat-header"]["transmat-edit-textfield"]
	local button = player.gui.screen[CONTROL.transmat_gui]["transmat-header"]["transmat-edit-button"]
	if textfield and button then
		textfield.visible = false
		button.style = "transmat_small_button"
		CONTROL.update_transmat_label(event.player_index,textfield.text)
	end
end

function CONTROL.refresh_transmat_gui(player)
	local frame = player.gui.screen[CONTROL.transmat_gui]
	if frame then
		local transmat = CONTROL.get_current_transmat_from_gui(player)
		-- destroyed or walked away?
		if not (transmat and transmat.valid and player.can_reach_entity(transmat)) then
			CONTROL.set_player_global(player.index,"transmat_gui_location",frame.location)
			frame.destroy()
			return false
		end
		-- destinations
		local selected_index = frame["t_table"]["t_list_table"]["t_list_frame"]["t_list"].selected_index
		local unit_numbers = frame["t_table"]["t_list_table"]["t_list_frame"]["t_list"].tags
		local cache = CONTROL.get_cached_transmats(player)
		local destination = cache[unit_numbers["unit_number_"..selected_index]]
		local frame_to_transmat = {
			["t_frame_camera"] = transmat or "nil",
			["t_frame_minimap"] = destination or "nil",
		}
		for mapframename,this_transmat in pairs(frame_to_transmat) do
			if this_transmat == "nil" then this_transmat = nil end
			local mapframe = frame["t_table"][mapframename]
			local map = mapframe["c_table"]["t_map"]
			local status = CONTROL.get_transmat_status(this_transmat , this_transmat ~= transmat)
			local enabled = this_transmat and this_transmat.valid and
				this_transmat.energy > 0 and
				status ~= "transmat-status-unknown" and
				status ~= "transmat-status-error"
			map.parent["t_panels"]["t_status_panel"]["t_status"].caption = CONTROL.get_transmat_status_localisation(status)
			map.parent["t_panels"]["t_indicator_panel"]["t_indicator"].caption = CONTROL.get_transmat_indicator_icon(status)
			if enabled then
				map.position = this_transmat.position
				map.surface_index = this_transmat.surface.index
			end
			if map.visible ~= enabled then
				map.visible = enabled
				map.parent["t_static"].visible = not enabled
			end
			local energy = math.min(1, this_transmat and this_transmat.valid and (this_transmat.energy / this_transmat.electric_buffer_size) or 0)
			if map.parent["t_panels"]["t_power_panel"]["t_bar"].value ~= energy then
				map.parent["t_panels"]["t_power_panel"]["t_bar"].value = energy
				map.parent["t_panels"]["t_power_panel"]["t_bar"].tooltip = {"", "[font=default-bold][color=230,208,175]", {"description.electricity"}, ": ", "[/color][/font]", math.floor(energy*100), "%"}
			end
		end
		local button = frame["t_table"]["t_list_table"]["t_activate_button"]
		button.enabled = transmat_can_connect(transmat,destination,player)
		return true
	end
	return false
end

CONTROL.transmat_gui_function = {}

function CONTROL.transmat_gui_function.deep_frame(name)
	return {
		name = name,
		type = "frame",
		style = "transmat_deep_frame",
	}
end

function CONTROL.transmat_gui_function.bare_table(name,columns)
	return {
		name = name,
		type = "table",
		column_count = columns or 1,
		style = "transmat_bare_table",
	}
end

function CONTROL.transmat_gui_function.camera_or_minimap(name,kind,entity,zoom)
	return {
		name = name,
		type = kind,
		position = entity.position,
		surface_index = entity.surface.index,
		zoom = zoom or 1,
	}
end

function CONTROL.transmat_gui_function.add_status_panel(root,align,caption)
	local panel = root.add {
		name = "t_status_panel",
		type = "frame",
		style = "tooltip_panel_background",
	}
	panel.style.height = CONTROL.transmat_list_status_height
	panel.style.width = CONTROL.transmat_list_item_width - CONTROL.transmat_list_battery_width - CONTROL.transmat_list_indicator_width
	panel.style.horizontal_align = align
	local status = panel.add {
		name = "t_status",
		type = "label",
		caption = caption or "",
		style = "caption_label",
	}
	-- status.style.left_margin = -6
	-- status.style.right_margin = -6
end

function CONTROL.transmat_gui_function.add_indicator_panel(root)
	local panel = root.add {
		name = "t_indicator_panel",
		type = "frame",
		style = "tooltip_panel_background",
	}
	panel.style.height = CONTROL.transmat_list_status_height
	panel.style.width = CONTROL.transmat_list_indicator_width
	panel.style.padding = 0
	panel.style.margin = 0
	panel.style.horizontal_align = "center"
	panel.style.vertical_align = "center"
	local status = panel.add {
		name = "t_indicator",
		type = "label",
		caption = "",
		style = "caption_label",
	}
end

function CONTROL.transmat_gui_function.add_power_panel(root)
	local t_power_panel = root.add {
		name = "t_power_panel",
		type = "frame",
		style = "tooltip_panel_background",
	}
	t_power_panel.style.height = CONTROL.transmat_list_status_height
	t_power_panel.style.width = CONTROL.transmat_list_battery_width
	t_power_panel.style.vertical_align = "center"
	local bar = t_power_panel.add {
		name = "t_bar",
		type = "progressbar",
		style = "transmat_energy_bar",
	}
	bar.style.padding = 0
	bar.style.margin = 0

end

function CONTROL.transmat_gui_function.add_status_panels(root, align)
	if align == nil then align = "left" end
	local panels = root.add {
		name = "t_panels",
		type = "table",
		style = "transmat_bare_table",
		column_count = 3,
	}
	if align == "right" then
		CONTROL.transmat_gui_function.add_power_panel(panels)
		CONTROL.transmat_gui_function.add_status_panel(panels,align)
		CONTROL.transmat_gui_function.add_indicator_panel(panels)
	else
		CONTROL.transmat_gui_function.add_indicator_panel(panels)
		CONTROL.transmat_gui_function.add_status_panel(panels,align)
		CONTROL.transmat_gui_function.add_power_panel(panels)
	end
end

local function t_name_sort(a,b)
	return CONTROL.get_transmat_label(a) < CONTROL.get_transmat_label(b)
end

function CONTROL.get_current_transmat_from_gui(player)
	local frame = player.gui.screen[CONTROL.transmat_gui]
	if frame and frame.tags and frame.tags.unit_number then
		local cache = CONTROL.get_cached_transmats(player)
		return cache[frame.tags.unit_number]
	end
	return nil
end

function CONTROL.create_transmat_gui(player, selected)

    if not player or not selected then return end
	
	player.opened = player.gui.screen
	if player.gui.screen[CONTROL.transmat_gui] then player.gui.screen[CONTROL.transmat_gui].destroy() end
	
	-- create frame

	local frame = player.gui.screen.add {
		type = "frame",
		name = CONTROL.transmat_gui,
		direction = "vertical",
		style = "transmat_frame",
	}
	-- cache which entity this gui belongs to
	frame.tags = { unit_number = selected.unit_number }
		
	-- update frame location if cached
	if CONTROL.get_player_global(player.index,"transmat_gui_location") then
		frame.location = CONTROL.get_player_global(player.index,"transmat_gui_location")
	else
		frame.force_auto_center()
	end

	-- header
	local header = frame.add {
		type = "flow",
		direction = "horizontal",
		name = "transmat-header",
	}
	header.style.bottom_padding = -4
	header.style.horizontally_stretchable = true
	
	-- icon
	local icon = header.add {
		name = "icon",
		type = "sprite",
		sprite = "item/chrome-transmat",
		style = "transmat_header_icon",
	}
	icon.style.size = 24
	icon.style.margin = 0
	icon.style.padding = 0
	icon.style.right_margin = 4
	
	-- title
	local title = header.add {
		name = "transmat-header-title",
		type = "label",
		caption = CONTROL.get_transmat_label(selected),
		style = "frame_title",
	}
	title.style.right_padding = 8

	-- "drag filler"
	local filler = header.add {
		type = "empty-widget",
		style = "draggable_space_header",
	}
	filler.style.natural_height = 24
	filler.style.horizontally_stretchable = true
	filler.drag_target = frame

	-- edit textfield
	local search_textfield = header.add {
		name = "transmat-edit-textfield",
		type = "textfield",
		style = "search_popup_textfield",
		lose_focus_on_confirm = true,
	}
	search_textfield.style.height = 24
	search_textfield.style.width = 160
	search_textfield.visible = false

	-- edit button
	local edit_button = header.add {
		name = "transmat-edit-button",
		type = "sprite-button",
		sprite = "edit-button",
		hovered_sprite = "edit-button-black",
		clicked_sprite = "edit-button-black",
		style = "transmat_small_button",
		tooltip = {"gui.edit"},
	}

	local map_button = header.add {
		name = "transmat-map-marker",
		type = "sprite-button",
		sprite = CONTROL.get_has_map_marker(selected) and "map-marker-black" or "map-marker",
		hovered_sprite = "map-marker-black",
		clicked_sprite = "map-marker-black",
		style = CONTROL.get_has_map_marker(selected) and "transmat_small_button_active" or "transmat_small_button",
		tooltip = {"controls.ir-map-marker"},
	}
	-- map_button.enabled = CONTROL.get_has_map_marker(selected)

	-- help button
	local help_button = header.add {
		name = "transmat-header-help",
		type = "sprite-button",
		style = "transmat_small_button",
		sprite = "help-button",
		hovered_sprite = "help-button-black",
		clicked_sprite = "help-button-black",
		tooltip = {"gui.open-manifesto"},
	}

	-- close button
	local close_button = header.add {
		name = "transmat-header-close",
		type = "sprite-button",
		style = "transmat_small_button",
		sprite = "utility/close_white",
		hovered_sprite = "utility/close_black",
		clicked_sprite = "utility/close_black",
		tooltip = {"gui.close-gui"},
	}
	
	-- table of transmats
	
	local static = get_or_create_static()
	local transmats_by_unit = CONTROL.get_cached_transmats(player)
	local transmats = {}
	for _,transmat in pairs(transmats_by_unit) do table.insert(transmats,transmat) end
	table.sort(transmats, function(a, b) return t_name_sort(a,b) end)
	local transmat_list = {}
	local transmat_list_tags = {}
	local count = 0
	for _,transmat in pairs(transmats) do
		if transmat ~= selected then
			count = count + 1
			transmat_list[count] = CONTROL.get_transmat_label(transmat)
			transmat_list_tags["unit_number_"..count] = transmat.unit_number
		end
	end
	if count == 0 then
		transmat_list[1] = {"gui.transmat-status-unknown"}
		transmat_list_tags["unit_number_1"] = -1
	end

	-- 3 main panels
	
	local t_table = frame.add(CONTROL.transmat_gui_function.bare_table("t_table",3))
	t_table.style.horizontal_spacing = 8
	t_table.style.vertical_spacing = 8
	t_table.style.padding = 0
	t_table.style.margin = 0
	t_table.style.top_margin = 8
	
	-- label panels
	
	-- left: selfie
	
	local dframe = t_table.add(CONTROL.transmat_gui_function.deep_frame("t_frame_camera"))
	dframe.style.padding = 0
	dframe.style.height = CONTROL.transmat_list_item_height
	dframe.style.width = CONTROL.transmat_list_item_width

	local cell_table = dframe.add(CONTROL.transmat_gui_function.bare_table("c_table",1))

	local map = cell_table.add(CONTROL.transmat_gui_function.camera_or_minimap("t_map","camera",selected,player.display_scale))
	map.style.height = CONTROL.transmat_list_map_height
	map.style.width = CONTROL.transmat_list_item_width

	local static_camera = cell_table.add(CONTROL.transmat_gui_function.camera_or_minimap("t_static","camera",static,player.display_scale*2))
	static_camera.style.height = CONTROL.transmat_list_map_height
	static_camera.style.width = CONTROL.transmat_list_item_width
	static_camera.visible = false
	
	CONTROL.transmat_gui_function.add_status_panels(cell_table,"left")

	-- middle: list box
	
	local cell_table = t_table.add(CONTROL.transmat_gui_function.bare_table("t_list_table",1))
	cell_table.style.vertical_spacing = 8
	cell_table.style.horizontal_align = "center"
	local dframe = cell_table.add(CONTROL.transmat_gui_function.deep_frame("t_list_frame"))
	dframe.style.padding = 0
	dframe.style.width = CONTROL.transmat_list_middle_width
	local list = dframe.add {
		name = "t_list",
		type = "list-box",
		style = "transmat_list_box",
		items = transmat_list,
		selected_index = 1,
	}
	list.style.margin = 0
	list.style.vertically_stretchable = true
	list.tags = transmat_list_tags
	local button = cell_table.add {
		name = "t_activate_button",
		type = "button",
		style = "transmat_green_button",
		caption = {"gui.transmat-engage"},
	}
	button.style.margin = 0
	button.style.bottom_margin = -2
	button.style.width = CONTROL.transmat_list_middle_width
	button.style.height = CONTROL.transmat_list_status_height + 2
	
	-- right: minimap
	
	local dframe = t_table.add(CONTROL.transmat_gui_function.deep_frame("t_frame_minimap"))
	dframe.style.padding = 0
	dframe.style.height = CONTROL.transmat_list_item_height
	dframe.style.width = CONTROL.transmat_list_item_width

	local cell_table = dframe.add(CONTROL.transmat_gui_function.bare_table("c_table",1))
	
	local map = cell_table.add(CONTROL.transmat_gui_function.camera_or_minimap("t_map","minimap",selected,player.display_scale/2))
	map.style.height = CONTROL.transmat_list_map_height
	map.style.width = CONTROL.transmat_list_item_width

	local static_camera = cell_table.add(CONTROL.transmat_gui_function.camera_or_minimap("t_static","camera",static,player.display_scale*2))
	static_camera.style.height = CONTROL.transmat_list_map_height
	static_camera.style.width = CONTROL.transmat_list_item_width
	static_camera.visible = false
	
	CONTROL.transmat_gui_function.add_status_panels(cell_table,"left")

	-- update labels
	CONTROL.refresh_transmat_gui(player)
	
	-- start delayed action loop
	CONTROL.add_delayed_action(CONTROL.transmat_gui_refresh_interval, {action = "refresh_transmat_gui", player = player})
	
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- transmat remote interface stuff

function CONTROL.transmat_ban_surface(surface, condition, message)
	if surface == nil or not game.surfaces[surface] then
		DIR.spam_log("ir-transmats ban/unban: invalid surface name", DIR.log_level.error)
		return false
	end
	if condition == false or condition == nil then message = nil end
	if condition == true and message == nil then message = true end
	global["transmat-bans-"..surface] = message
	return true
end


function CONTROL.transmat_surface_is_banned(surface_name)
	if surface == nil or not game.surfaces[surface] then
		DIR.spam_log("ir-transmats is-banned: invalid surface name", DIR.log_level.error)
		return false
	end
	return global["transmat-bans-"..surface] ~= nil
end


function CONTROL.transmat_tag_surface(surface, tag, condition)
	if surface == nil or not game.surfaces[surface] then
		DIR.spam_log("ir-transmats tag/untag: invalid surface name", DIR.log_level.error)
		return false
	end
	if condition == false then condition = nil end
	local surface_tags = global["transmat-tags-"..surface] or {}
	surface_tags[tag] = condition
	global["transmat-tags-"..surface] = surface_tags
	return true
end

function CONTROL.transmat_clear_tags(surface)
	if surface == nil or not game.surfaces[surface] then
		DIR.spam_log("ir-transmats clear: invalid surface name", DIR.log_level.error)
		return false
	end
	global["transmat-tags-"..surface] = nil
	return true
end

function CONTROL.transmat_player_is_teleporting(player_index)
	local player = game.players[player_index]
	if not player then
		DIR.spam_log("ir-transmats is-teleporting: invalid player index", DIR.log_level.error)
		return false
	end
	return CONTROL.get_player_global(player_index, "teleport_target_position") ~= nil
end

------------------------------------------------------------------------------------------------------------------------------------------------------
