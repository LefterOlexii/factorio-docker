------------------------------------------------------------------------------------------------------------------------------------------------------

-- delayed action queue
-- runs on_tick, but deregisters itself if there's nothing left in the queue

CONTROL.delayed_actions = {
    appear = function(action)
        if action.surface and action.surface.valid and action.position then
            CONTROL.transmat_sparks_effect(action.surface, action.position)
        end
    end,
    disappear = function(action)
        if action.surface and action.surface.valid and action.position then
            CONTROL.transmat_sparks_effect(action.surface, action.position, true)
        end
    end,
	rings = function(action)
        if action.surface and action.surface.valid and action.position then
			if (action.entity == nil) or (action.entity and action.entity.valid) then
				if action.no_base == nil then action.no_base = true end
				CONTROL.transmat_ring_effects(action.surface,action.position,action.no_base,action.base_entity,action.no_sound)
			end
        end
	end,
    teleport = function(action)
        if action.entity and action.entity.valid and action.position then
            action.entity.teleport(action.position, nil, true)
        end
    end,
    zoom = function(action)
        local player = game.players[action.player_index]
        if player and player.valid and action.factor then
            player.zoom = action.factor
        end
    end,
    print = function(action)
		local player = game.players[action.player_index]
		if player and player.valid and action.text then
			player.print(action.text, {sound = defines.print_sound.never})
		end
    end,
    clone_and_destroy = function(action)
        if action.entity and action.entity.valid and action.surface and action.surface.valid and action.position then
            local clone =
                action.entity.clone(
                {
                    position = action.position,
                    surface = action.surface,
                    force = action.entity.force,
                    create_build_effect_smoke = false
                }
            )
            if clone and clone.valid then
                action.entity.destroy()
            end
        end
    end,
    refresh_transmat_gui = function(action)
        if action.player and action.player.valid then
            if CONTROL.refresh_transmat_gui(action.player) then
                CONTROL.add_delayed_action(
                    CONTROL.transmat_gui_refresh_interval,
                    {action = "refresh_transmat_gui", player = action.player}
                )
            end
        end
    end,
    add_notification = function(action)
        local player = game.players[action.player_index]
        if player and player.valid and action.text and action.sprite and action.id then
            CONTROL.add_notification(player, action.id, action.sprite, action.text)
        end
    end,
    remove_notification = function(action)
        local player = game.players[action.player_index]
        if player and player.valid and action.id then
            CONTROL.destroy_notification(player, action.id)
        end
    end,
    decrease_lightning_alpha = function(action)
        if action.ids and action.decrease and action.delay then
			local again = false
            for _, id in pairs(action.ids) do
                if rendering.is_valid(id) then
					local c = rendering.get_color(id)
					c.a = c.a - action.decrease
					if c.a > 0 then
						rendering.set_color(id, {r = c.a, g = c.a, b = c.a, a = c.a})
						rendering.set_y_scale(id, 1 + ((1 - c.a) / 6))
						again = true
					end
                end
            end
			if again then CONTROL.add_delayed_action(action.delay, action) end
        end
    end,
	process_forestry_chunk = function(action)
		if action.chunk_position and game.surfaces[action.surface_index] and game.surfaces[action.surface_index].valid then
			CONTROL.process_forestry_chunk(game.surfaces[action.surface_index], action.chunk_position)
		end
	end,
	explode_waterfill = function(action)
		local entity = action.entity
		if entity and entity.valid then
			if not CONTROL.get_entity_has_water_neighbours(entity) then return end
			local tile = {
				position = { x = math.floor(entity.position.x), y = math.floor(entity.position.y) },
				name = "water-mud",
			}
			local entities = entity.surface.find_entities_filtered{position = entity.position, radius = 1.1, name = entity.name}
			if entities then
				for _,e in pairs(entities) do
					rendering.draw_animation{animation="waterfill-explosive-glow", render_layer="object", target=e, surface=e.surface, time_to_live=CONTROL.waterfill_explosive_chain_delay}
					CONTROL.add_delayed_action(CONTROL.waterfill_explosive_chain_delay, {action = "explode_waterfill", entity = e})
				end
			end
			entity.surface.create_entity{name = "waterfill-explosion", position = { x = entity.position.x, y = entity.position.y + 1 } }
			entity.surface.set_tiles({tile}, true, true, true, true)
			entity.destroy{raise_destroy=false}
		end
	end,
	play_sound = function(action)
		if action.surface and action.surface.valid then
			action.surface.play_sound{path = action.sound, position = action.position}
		end
	end,
	reset_controller_and_occupy_character = function(action)
		local player = game.players[action.player_index]
		local characters = action.surface.find_entities_filtered{position = action.position, type = "character", radius = 0.5}
		if characters and characters[1] then
			player.set_controller{type=defines.controllers.character, character = characters[1]}
		end
	end,
	render_animation_on_target = function(action)
		if action.target and action.target.valid then
			rendering.draw_animation{
				animation=action.animation,
				render_layer=action.render_layer,
				target=action.target,
				surface=action.target.surface,
				time_to_live=action.ttl,
				animation_speed=action.speed,
				tint=action.tint,
			}
		end
	end,
	render_transmat_hex_light = function(action)
		if action.from and action.from.valid and action.to and action.to.valid and action.light then
			CONTROL.transmat_hex_lights(action.light, action.from, action.to, action.ttl or 240)
		end
	end,	
	explode_if_no_player_loop = function(action)
		if action.target and action.target.valid then
			local characters = action.target.surface.find_entities_filtered{type="character",radius=8,position=action.target.position}
			if characters and table_size(characters) > 0 then
				action.target.surface.play_sound{path = "klaxon", volume_modifier = 0.5}
				CONTROL.add_delayed_action(180,{action = "explode_if_no_player_loop", target=action.target})
			else
				action.target.destructible = true
				action.target.damage(99999, "neutral", "impact")
			end
		end
	end,
	create_entity = function(action)
		if action.surface and action.surface.valid and action.position and action.name then
			action.surface.create_entity{name = action.name, position = action.position, raise_built = action.raise_built}
		end
	end,
	set_player_global = function(action)
		if action.player_index and action.info then
			CONTROL.set_player_global(action.player_index, action.info, action.value)
		else
			error("Bad delayed set_player_global")
		end
	end,
	set_surface_global = function(action)
		if action.surface_index and action.info then
			CONTROL.set_surface_global(action.surface_index, action.info, action.value)
		else
			error("Bad delayed set_surface_global")
		end
	end,
	player_flying_text = function(action)
		if action.player and action.player.valid and action.text then
			CONTROL.player_flying_notification(action.player, action.text, action.time_to_live, action.position)
		end
	end,
	fetchport_projectile = function(action)
		-- game.print(action.source.name.." "..action.target.name)
		if action.item and action.source and action.source.valid and action.target and action.target.valid then
			action.source_height = action.source_height or 0.5
			action.bundle = action.bundle and DIR.clamp(action.bundle,1,8) or 1
			local sourcep = action.position or DIR.get_vector_sum(action.source.position, {x=0,y=-action.source_height})
			if action.source_distance then
				local dnormal = DIR.multiply_vector(DIR.get_vector_difference_normal(action.target.position, sourcep), action.source_distance)
				sourcep = DIR.get_vector_sum(sourcep, dnormal)
			end
			action.target.surface.play_sound{path = "suck", position = sourcep}
			local known_wooden_entities = {
				["wooden-chest"] = true,
				["wood-pallet"] = true,
			}
			local proj = (action.target.type == "character") and "fetchport-projectile-body" or (known_wooden_entities[action.target.name] and "fetchport-projectile-wood" or "fetchport-projectile-solid")
			local p = action.target.surface.create_entity {
				name = proj,
				target = action.target_height and DIR.get_vector_sum(action.target.position, {x=0,y=-action.target_height}) or action.target,
				position = sourcep,
				source = action.source,
				speed = 0.25,
			}
			local offsets = {}
			for i=1,action.bundle do
				offsets[i] = (i==1) and {0,0} or {(CONTROL.get_RNG(p.surface)*0.4)-0.2,(CONTROL.get_RNG(p.surface)*0.4)-0.2}
				rendering.draw_sprite {
					sprite = "item/"..action.item,
					x_scale = 0.5,
					y_scale = 0.5,
					render_layer = action.render_layer or "air-object",
					target = p,
					surface = p.surface,
					target_offset = offsets[i],
				}
			end
			if not action.target_height then
				for i=1,action.bundle do
					rendering.draw_sprite {
						sprite = "flying-item-shadow",
						x_scale = 0.5,
						y_scale = 0.5,
						render_layer = "floor-mechanics",
						target = p,
						surface = p.surface,
						target_offset = DIR.get_vector_sum(offsets[i], {action.source_height, action.source_height}),
					}
				end
			else
				local ps = action.target.surface.create_entity {
					name = "fetchport-projectile",
					target = DIR.get_vector_sum(action.target.position, {x=action.target_height,y=0}),
					position = DIR.get_vector_sum(action.source.position, {x=action.source_height,y=0}),
					source = action.source,
					speed = 0.25,
				}
				for i=1,action.bundle do
					rendering.draw_sprite{
						sprite = "flying-item-shadow",
						x_scale = 0.5,
						y_scale = 0.5,
						render_layer = "floor-mechanics",
						target = ps,
						surface = ps.surface,
						target_offset = offsets[i],
					}
				end
			end
		end
	end,
	pseudo_flying_text = function(action)
		if action.position and action.surface and action.text then
			if action.surface.valid then
				local id = rendering.draw_text {
					text = action.text,
					surface = action.surface,
					target = action.position,
					scale = 2,
					time_to_live = 120,
					players = action.players,
					scale_with_zoom = true, 
					use_rich_text = true,
					color = {1,1,1,1},
					alignment = "center",
					vertical_alignment = "bottom",
				}
				CONTROL.add_delayed_action(1, {action = "pft_lifetime", id = id})
			end
		else
			error("Bad parameters passed to DA pseudo_flying_text")
		end
	end,
	pft_lifetime = function(action)
		if rendering.is_valid(action.id) then
			local a = math.min(60,rendering.get_time_to_live(action.id)) / 60
			rendering.set_color(action.id, {1,1,1,a})
			local t = rendering.get_target(action.id)
			if t.position then
				t.position.y = t.position.y - 0.0125
			end
			rendering.set_target(action.id, t.position)
			CONTROL.add_delayed_action(1, action)
		end
	end,
	insert_into_inventory = function(action)
		if action.inventory and action.inventory.valid and action.item then
			action.inventory.insert({name = action.item, count = action.count or 1})
		end
	end,
	item_cannon_cycle = function(action)
		local vehicle = action.entity and action.entity.valid and action.entity or nil
		if vehicle then
			local gic = global.vehicle_queues and global.vehicle_queues[vehicle.unit_number] or nil
			if gic and gic.queue and gic.active then
				if table_size(gic.queue) > 0 then
					-- game.print("dong")
					local target = nil
					local new_queue = {}
					for _,entity in ipairs(gic.queue) do
						if not target and entity and entity.valid then
							if CONTROL.consume_item(vehicle,entity.ghost_name) then
								target = entity
							end
						elseif entity and entity.valid then
							table.insert(new_queue, entity)
						end
					end
					gic.queue = new_queue
					if target then
						local item_to_revive = target.ghost_name
						if item_to_revive and game.item_prototypes[item_to_revive] then
							local p = target.surface.create_entity {
								name = "itemcannon-projectile-"..(target.type=="entity-ghost" and "entity" or "tile"),
								target = target.position,
								position = vehicle.position,
								source = vehicle,
								speed = 0.5,
							}
							rendering.draw_sprite {
								sprite = "item/"..item_to_revive,
								x_scale = 0.5,
								y_scale = 0.5,
								render_layer = "air-object",
								target = p,
								surface = p.surface,
							}
						end
					end
					if table_size(gic.queue) > 0 then
						CONTROL.add_delayed_action(5,{action="item_cannon_cycle",entity=action.entity})		
					else
						gic.active = false
						game.print("Cannon "..vehicle.unit_number.." cycled down")
					end
				end
			end
		end
	end,
}

local function bininsert(t, value, fcomp)
    local iStart, iEnd, iMid, iState = 1, #t, 1, 0
    while iStart <= iEnd do
        iMid = math.floor((iStart + iEnd) / 2)
        if fcomp(value, t[iMid]) then
            iEnd, iState = iMid - 1, 0
        else
            iStart, iState = iMid + 1, 1
        end
    end
    table.insert(t, (iMid + iState), value)
    return (iMid + iState)
end

function CONTROL.add_delayed_action(delay, parameters)

    if parameters.action == nil then error("No action") end
    if CONTROL.delayed_actions[parameters.action] == nil then error("Called non-existent action "..parameters.action) end
    if delay < 1 then error("Delay must be at least 1 tick") end

    if global.action_queue == nil then global.action_queue = {} end
    parameters.tick = game.tick + delay

    -- insert so that soonest is at the end
	bininsert(global.action_queue, parameters, function(a,b) return (a.tick > b.tick) end)

    -- boot on_tick if it's not already active
    if not script.get_event_handler(defines.events.on_tick) then
        script.on_event(defines.events.on_tick, CONTROL.tick_tock)
		global.delayed_actions_tick = true
    end
	
end

function CONTROL.tick_tock(event)

    if #global.action_queue == 0 then
        -- nothing in queue, power down
        script.on_event(defines.events.on_tick, nil)
		global.delayed_actions_tick = false
        return
    end
    local action = global.action_queue[#global.action_queue]
    if action.tick == game.tick then
        -- we hit an action, run it and then recursively run self (may be more actions in the same tick)
        CONTROL.delayed_actions[action.action](action)
        table.remove(global.action_queue)
        CONTROL.tick_tock(event)
        return
    elseif action.tick < game.tick then
        -- shouldn't ever happen
        table.remove(global.action_queue)
        CONTROL.tick_tock(event)
        return
    end
	
end

------------------------------------------------------------------------------------------------------------------------------------------------------
