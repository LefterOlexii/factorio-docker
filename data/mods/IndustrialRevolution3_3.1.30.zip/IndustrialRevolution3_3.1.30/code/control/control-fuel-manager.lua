------------------------------------------------------------------------------------------------------------------------------------------------------

-- fuel manager

local function get_item_name_first_slot_in_inventory_matching_fuel_categories(source_inventory, fuel_categories)
	local filters = {}
	for category,_ in pairs(fuel_categories) do table.insert(filters, {filter = "fuel-category", ["fuel-category"] = category}) end
	local matching_items = game.get_filtered_item_prototypes(filters)
	for _,filtered in pairs({false,true}) do
		for i=1,#source_inventory do
			if source_inventory[i] and source_inventory[i].valid_for_read and matching_items[source_inventory[i].name] then
				if filtered or source_inventory.get_filter(i) then
					return source_inventory[i].name
				end
			end
		end
	end
	return nil
end

function CONTROL.fill_fuel_inventory(player, source_inventories, target_inventory, used, fuel_categories)
	if used == nil then used = {} end
	local item_counts = target_inventory.get_contents()
	if table_size(item_counts) > 0 then
		for index,source_inventory in pairs(source_inventories) do
			for item,count in pairs(item_counts) do
				local item_stack_size = game.item_prototypes[item].stack_size
				local stack_target = math.max(2, math.floor(item_stack_size/10))
				if item_stack_size > 1 and count < stack_target then
					local removed = source_inventory.remove({name = item, count = stack_target - count})
					if removed > 0 then
						if not used[item] then used[item] = 0 - removed
						else used[item] = used[item] - removed end
						target_inventory.insert({name=item, count=removed})
						item_counts[item] = item_counts[item] + removed
					elseif index == #source_inventories then
						if player == nil or settings.get_player_settings(player)["ir-fuelman-pingnofuel"].value then
							used["warning-fuel-yellow"] = true
						end
					end
				end
			end
		end
	else 
		for index,source_inventory in pairs(source_inventories) do
			local item = get_item_name_first_slot_in_inventory_matching_fuel_categories(source_inventory, fuel_categories)
			if item ~= nil then
				local item_stack_size = game.item_prototypes[item].stack_size
				local stack_target = math.max(2, math.floor(item_stack_size/10))
				local removed = source_inventory.remove({name = item, count = stack_target})
				if removed > 0 then
					if not used[item] then used[item] = 0 - removed
					else used[item] = used[item] - removed end
					target_inventory.insert({name=item, count=removed})
					return used
				end
			end
		end
		if player == nil or settings.get_player_settings(player)["ir-fuelman-pingemptyslot"].value then
			used["warning-fuel-red"] = true
		end
	end
	return used
end

function CONTROL.empty_burnt_inventory(player, source_inventories, target_inventory, used)
	if used == nil then used = {} end
	local item_counts = target_inventory.get_contents()
	if table_size(item_counts) > 0 then
		for index,source_inventory in pairs(source_inventories) do
			for item,count in pairs(item_counts) do
				local inserted = source_inventory.insert({name=item, count=count})
				if inserted > 0 then
					if not used[item] then used[item] = inserted
					else used[item] = used[item] + inserted end
					target_inventory.remove({name=item, count=inserted})
					item_counts[item] = item_counts[item] - inserted
					if item_counts[item] == 0 then item_counts[item] = nil end
				elseif index == #source_inventories then
					if player == nil or settings.get_player_settings(player)["ir-fuelman-pingnoinv"].value then
						used["warning-inventory"] = true
					end
				end
			end
		end
	end
	return used
end

function CONTROL.refuel_grid(player, inventories, spent_inventories, grid, used)
	if used == nil then used = {} end
	if grid.equipment then
		for _,equipment in pairs(grid.equipment) do
			if equipment.burner then
				if equipment.burner.inventory then
					used = CONTROL.fill_fuel_inventory(player, inventories, equipment.burner.inventory, used, equipment.burner.fuel_categories)
				end
				if equipment.burner.burnt_result_inventory then
					used = CONTROL.empty_burnt_inventory(player, spent_inventories, equipment.burner.burnt_result_inventory, used)
				end
			end
		end
	end
	return used
end

function CONTROL.refuel_vehicle(player, inventories, spent_inventories, vehicle, used)
	if used == nil then used = {} end
	if not vehicle.burner then return used end
	if vehicle.get_fuel_inventory() then
		used = CONTROL.fill_fuel_inventory(player, inventories, vehicle.get_fuel_inventory(), used, vehicle.burner.fuel_categories)
	end
	if vehicle.get_burnt_result_inventory() then
		used = CONTROL.empty_burnt_inventory(player, spent_inventories, vehicle.get_burnt_result_inventory(), used)
	end
	return used
end

function CONTROL.refuel(player)
	local main = player.get_main_inventory()
	if not main then return end
    local armour_inventory = player.get_inventory(defines.inventory.character_armor)
    if not armour_inventory then return end

    local armour = armour_inventory[1]
	local text = ""
	local used = {}
	local vehicle = player.vehicle
	if vehicle and vehicle.type ~= "car" and vehicle.type ~= "spider-vehicle" then vehicle = nil end
	local trunk = vehicle and vehicle.get_inventory(defines.inventory.car_trunk)

    if armour and armour.valid_for_read and armour.grid then
		local inventories = trunk and { main, trunk } or { main }
		used = CONTROL.refuel_grid(player, inventories, inventories, armour.grid, used)
    end
	if vehicle and vehicle.valid then
		local inventories = trunk and { trunk, main } or { main }
		local spent_inventories = (settings.get_player_settings(player)["ir-fuelman-spent-fuel-inventory"].value and trunk) and { main, trunk } or inventories
		used = CONTROL.refuel_vehicle(player, inventories, spent_inventories, vehicle, used)
		if vehicle.grid then
			used = CONTROL.refuel_grid(player, inventories, spent_inventories, vehicle.grid, used)
		end
	end
	local text = ""
	local warning = false
	local inventory = false
	for icon,value in pairs(used) do
		if type(value) == "number" then
			if settings.get_player_settings(player)["ir-fuelman-inventorynumbers"].value then
				text = text .. (text == "" and "" or " ") .. "[img=item/"..icon.."] " .. (value >= 0 and CONTROL.grey_text.."+" or CONTROL.red_text) .. value .. "[/color]"
			end
			inventory = true
		end
	end
	for icon,value in pairs(used) do
		if value == true then
			text = text .. (text == "" and "" or " ") .. "[img="..icon.."]"
			warning = true
		end
	end
	if text ~= "" then
		CONTROL.player_flying_notification(player, text)
	end
	if inventory and settings.get_player_settings(player)["ir-fuelman-inventorysounds"].value then
		player.play_sound{path = "fuelman-inventory"}
	end
	if warning and settings.get_player_settings(player)["ir-fuelman-pingsounds"].value then
		player.play_sound{path = "fuelman-warning"}
	end
end

local function grid_has_a_burner(grid)
	if not grid.equipment then return false end
	for _,equipment in pairs(grid.equipment) do
		if equipment.valid and equipment.burner then return true end
	end
	return false
end

function CONTROL.is_fuel_manager_unlockable(player)
	local ainv = player.get_inventory(defines.inventory.character_armor)
    local armour = ainv and ainv[1]
    if armour and armour.valid_for_read and armour.grid and grid_has_a_burner(armour.grid) then return true end
    if player.vehicle and (player.vehicle.type == "car" or player.vehicle.type == "spider-vehicle") then return true end
    return false
end

------------------------------------------------------------------------------------------------------------------------------------------------------
