------------------------------------------------------------------------------------------------------------------------------------------------------

-- event handlers

local function get_intro_waypoints(position)
	return {
		{
			position = DIR.get_vector_sum(position,{x=0,y=-50}),
			transition_time = 0,
			time_to_wait = 180,
			zoom = 1,
		},
		{
			position = position,
			transition_time = 180,
			time_to_wait = 0,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 20,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 0,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 60,
			zoom = 2,
		},
		{
			position = position,
			transition_time = 0,
			time_to_wait = 60,
			zoom = 2,
		},
	}
end

CONTROL.intro_cutscene_stages = {
	[1] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			transmat.surface.play_sound{path = "transmat-energiser-slide", position = transmat.position}
		end
	end,
	[2] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(1,transmat,transmat,240)
		end
	end,
	[3] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(2,transmat,transmat,240)
		end
	end,
	[4] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(3,transmat,transmat,240)
		end
	end,
	[5] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(4,transmat,transmat,240)
		end
	end,
	[6] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(5,transmat,transmat,240)
		end
	end,
	[7] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			CONTROL.transmat_hex_lights(6,transmat,transmat,240)
		end
	end,
	[8] = function(player,clone,transmat)
		if player and player.valid and transmat and transmat.valid then
			transmat.surface.play_sound{path = "transmat-spindown", position = transmat.position}
			CONTROL.transmat_ring_effects(player.surface,player.position,true)
		end
	end,
	[9] = function(player,clone,transmat)
		if player and player.valid and clone and clone.valid then
			CONTROL.transmat_sparks_effect(player.surface,player.position,false)
			local character = CONTROL.clone_on_surface(clone,player.surface,player.position)
			clone.destroy()
			character.direction = defines.direction.south
			CONTROL.set_player_global(player.index,"intro_character",character)
		end
	end,
	[10] = function(player,clone,transmat)
		if player and player.valid then
			player.exit_cutscene()
			if clone and clone.valid then player.set_controller{type=defines.controllers.character, character=clone} end
			CONTROL.set_player_global(player.index,"intro_character",nil)
		end
	end,
}

function CONTROL.on_player_created(event)

    local player = game.players[event.player_index]
	
	-- disable fuel manager shortcut until something is equipped
    player.set_shortcut_available("ir-fuel-manager", false)
	
	-- disable manifesto if informatron is installed
	player.set_shortcut_available("ir-manifesto", not game.active_mods["informatron"])

	-- 3.1.12: build sim surface so it's here for this game / until config_refresh
    local surface = game.surfaces[CONTROL.sim_surface_name]
    if not surface then CONTROL.set_sim_surface_state(false) end

	-- 3.0.2 - past this point, we need it to be the freeplay scenario
	if script.level.level_name ~= "freeplay" then return end

    -- RTFM
	if not game.active_mods["informatron"] then 
		CONTROL.add_delayed_action(800,{action="print", player_index=player.index, text={"IndustrialRevolution3.manifesto_rtfm"}})
	end
		
	-- beam-in intro cutscene for first player
	if global.use_ir_intro_cutscene then
		global.use_ir_intro_cutscene = false
		if player.character and player.character.valid then
			local transmat = player.surface.create_entity{name="fake-transmat",position=player.position,force="neutral"}
			local clone = CONTROL.clone_in_limbo(player.character)
			CONTROL.set_player_global(player.index,"intro_transmat",transmat)
			CONTROL.set_player_global(player.index,"intro_character",clone)
			player.character.destroy()
			player.set_controller{type=defines.controllers.cutscene, waypoints=get_intro_waypoints(player.position), start_position=transmat.position, start_zoom=1}
			CONTROL.add_delayed_action(720,{action = "render_animation_on_target", animation="transmat-glow-status",render_layer="lower-object-above-shadow",target=transmat,speed=1/60,tint={1,0,0}})
			CONTROL.add_delayed_action(720,{action = "explode_if_no_player_loop", target=transmat})
			for x=-3,2 do
				for y=-3,2 do
					player.surface.set_tiles({{position=DIR.get_vector_sum(transmat.position,{x=x,y=y}),name="stone-path"}})
				end
			end
			for x=-7,6 do
				for y=-7,6 do
					if CONTROL.get_RNG(player.surface) > 0.5 and DIR.get_distance(transmat.position,{x=x,y=y}) <= 7 then
						player.surface.set_tiles({{position=DIR.get_vector_sum(transmat.position,{x=x,y=y}),name="stone-path"}})
					end
				end
			end
			local clear = player.surface.find_entities_filtered{type={"tree","simple-entity","resource","decorative"}, position=transmat.position, radius=7}
			for _,e in pairs(clear) do e.destroy() end
			local sss = {8,9,12}
			for _,ss in pairs(sss) do
				for x=-ss,ss do
					for _,p in pairs({{x=x,y=ss},{x=x,y=-ss},{x=ss,y=x},{x=-ss,y=x}}) do
						if CONTROL.get_RNG(player.surface) <= math.abs(x/ss)^2 then
							player.surface.create_entity{position=DIR.get_vector_sum(transmat.position,p),name="ancient-wall",force="player"}
							player.surface.set_tiles({{position=DIR.get_vector_sum(transmat.position,p),name="stone-path"}})
						end
					end
				end
			end
			-- CONTROL.spell_out_letters("steel","NAUVIS",player.surface,{x=0,y=2})
		end
	end
	
	-- start containers & resources
	if global.generated_start_containers ~= true then
		global.generated_start_containers = true
		local psurface = game.surfaces["nauvis"]
		local items = global.crate_items -- set in on_init() or remote calls 
		if psurface and items then -- if items is nil then most likely this is a pre-2.2.0 saved game
			local age = settings.global["ir-starting-age"].value
			if global.generate_non_crate_spawns ~= false then
				-- set up initial resources
				CONTROL.add_starting_resources(psurface)
				-- junkpiles
				local scraps = {
					iron = "iron-copper-junkpile",
					steel = "steel-iron-junkpile",
					chrome = "steel-iron-junkpile",
				}
				local scrap = scraps[age] or "copper-tin-junkpile"
				scrap = (global.generate_non_crate_spawns == "scrap") and scrap.."-scrap" or scrap
				for i = 1,3 do
					local theta = CONTROL.get_RNG(psurface)*math.pi*2
					local distance = 8 + CONTROL.get_RNG(psurface)*12
					local p = psurface.find_non_colliding_position(scrap, {math.cos(theta)*distance, math.sin(theta)*distance}, 16, 0.25, false)
					if p then psurface.create_entity{name = scrap, position = p, create_build_effect_smoke = false} end
				end
			end
			-- crates
			local crate = nil
			local crate_var = 1
			local crates = {}
			local size = table_size(items) > 6 and "medium" or "small"
			for name,count in pairs(items) do
				while count > 0 do
					if crate == nil or crate.get_inventory(defines.inventory.chest).get_insertable_count(name) < count then 
						crate = nil
						local theta = CONTROL.get_RNG(psurface)*math.pi*2
						local distance = 3 + CONTROL.get_RNG(psurface)*2
						local crate_prototype = "starter-crate-"..size.."-"..crate_var
						local p = psurface.find_non_colliding_position(crate_prototype, {math.cos(theta)*distance, math.sin(theta)*distance}, 16, 0.25, false)
						if p then
							crate = psurface.create_entity{name = crate_prototype, force = "player", position = p, create_build_effect_smoke = false}
							if crate then
								crate_var = (crate_var < 4) and (crate_var + 1) or 1
								table.insert(crates,crate)
							end
						end
					end
					if crate then count = count - crate.get_inventory(defines.inventory.chest).insert({name=name,count=count})
					else count = 0 end
				end
			end
		end
	end
	
end

function CONTROL.recursive_force_research(force, tech_name)
    if force.technologies[tech_name] and not force.technologies[tech_name].researched then
        force.technologies[tech_name].researched = true
        if force.technologies[tech_name].prerequisites then
            for _,prereq in pairs(force.technologies[tech_name].prerequisites) do
                CONTROL.recursive_force_research(force, prereq.name)
            end
        end
    end
end

function CONTROL.initialise()
	local freeplay = (remote.interfaces["freeplay"] ~= nil)
	-- validate all starter kits and techs
	for age,list in pairs(CONTROL.starter_kits.tech) do
		for _,tech in pairs(list) do
			if not game.technology_prototypes[tech] then error("Starter kits data specifies missing technology "..tech.." in "..age) end
		end
	end
	for age,list in pairs(CONTROL.starter_kits.kits) do
		for item,count in pairs(list) do
			if not game.item_prototypes[item] then error("Starter kits data specifies missing item "..item.." in "..age) end
		end
	end
	-- unlock techs from map settings
	local age = settings.global["ir-starting-age"].value
	-- 3.0.19: turning off trees or rubber trees enforces minimum tech level of "wood"
	if (age == "stone") and game.surfaces["nauvis"] and game.surfaces["nauvis"].map_gen_settings.autoplace_controls then
		local tt = game.surfaces["nauvis"].map_gen_settings.autoplace_controls["trees"]
		local rt = game.surfaces["nauvis"].map_gen_settings.autoplace_controls["ir-rubber-trees"]
		if (tt and tt.size == 0) or (rt and rt.size == 0) then age = "wood" end
	end
    if CONTROL.starter_kits.tech[age] then
		for _,tech in pairs(CONTROL.starter_kits.tech[age]) do
			CONTROL.recursive_force_research(game.forces.player, tech)
		end
	else
		error("Starting age setting specifies missing age "..age)
    end
	-- load the starter kit into global
	if global.crate_items == nil then
		global.crate_items = freeplay and CONTROL.starter_kits.kits[age] or {}
	end
	-- turn off freeplay stuff and get IR starter defaults
	local ir_intro_default = false
	if freeplay then
		ir_intro_default = not remote.call("freeplay","get_skip_intro")
		remote.call("freeplay", "set_skip_intro", true)
		remote.call("freeplay", "set_disable_crashsite", true)
		remote.call("freeplay", "set_respawn_items", {})
		remote.call("freeplay", "set_created_items", {})
	end
	-- set up other globals
	if global.use_ir_intro_cutscene == nil then global.use_ir_intro_cutscene = ir_intro_default end
	if global.generate_non_crate_spawns == nil then global.generate_non_crate_spawns = freeplay end
	-- check bottomless pit and any other non-tech-unlocked recipes
	CONTROL.refresh_non_tech_recipe_unlocks()
	CONTROL.refresh_hidden_military_techs()
end

function CONTROL.on_load()
    -- reboot cycles if necessary
	if global.delayed_actions_tick then
		script.on_event(defines.events.on_tick, CONTROL.tick_tock)
	else
		script.on_event(defines.events.on_tick, nil)
	end
	if global.handle_sim_surface then
		script.on_nth_tick(CONTROL.handle_sim_surface_interval, CONTROL.handle_sim_surface)
	else
		script.on_nth_tick(CONTROL.handle_sim_surface_interval, nil)
	end
end

local function reset_tech_effects()
	for _,force in pairs(game.forces) do
		force.reset_technology_effects()
	end
end

function CONTROL.config_refresh(event)
	-- actions on any config change
	for index,player in pairs(game.players) do
		player.set_shortcut_available("ir-manifesto", not game.active_mods["informatron"])
	end
    -- actions on IR update/rollback
	if (event.mod_changes[DIR.IR] and (event.mod_changes[DIR.IR].new_version ~= event.mod_changes[DIR.IR].old_version)) then
		DIR.spam_log("IR3 version change", DIR.log_level.notice)
		-- reset tech effects
		reset_tech_effects()
		-- reset any transmat caches in case of shenanigans
		CONTROL.reset_transmat_caches()
		-- ditto forestries
		CONTROL.initialise_forestry_caches()
		global.cached_trees = nil
		global.item_colours = nil
		-- 3.1.0 - don't delete transmat limbo surface, because of saved-game-during-cutscene issues
		for _,player in pairs(game.players) do
			local frame = player.gui.screen[CONTROL.transmat_gui]
			if frame then
				frame.destroy()
				player.opened = nil
			end
		end
		-- 3.1.12 - delete and rebuild sim surface, then put it to sleep
		local surface = game.surfaces[CONTROL.sim_surface_name]
		if surface then
			game.delete_surface(surface) 
		end
		CONTROL.set_sim_surface_state(false) -- rebuilds
	-- other mod-specific actions
	elseif (event.mod_changes["Dectorio"] and (event.mod_changes["Dectorio"].new_version ~= event.mod_changes["Dectorio"].old_version)) then
		reset_tech_effects()
		global.cached_trees = nil
	elseif (event.mod_changes["textplates"] and (event.mod_changes["textplates"].new_version ~= event.mod_changes["textplates"].old_version)) then
		reset_tech_effects()
	end
end

function CONTROL.runtime_setting_changed(event)
	if event.setting == "ir-bottomless-pit" then
		CONTROL.refresh_non_tech_recipe_unlocks()
	elseif event.setting == "ir-hide-military-technologies" then
		CONTROL.refresh_hidden_military_techs()
	end
end

function CONTROL.refresh_non_tech_recipe_unlocks(force)
	local bp = (settings.global["ir-bottomless-pit"].value == "available")
	local forces = force and {force} or game.forces
	for _,force in pairs(forces) do
		if force.recipes["bottomless-pit"] then force.recipes["bottomless-pit"].enabled = bp end
	end
end

local function hide_techs_and_children(techlist,bool)
	local children = {}
	for tech,_ in pairs(techlist) do
		for _,force in pairs(game.forces) do
			force.technologies[tech].enabled = bool
			force.technologies[tech].visible_when_disabled = bool
		end
	end
	for techpname,techp in pairs(game.technology_prototypes) do
		for prereq,_ in pairs(techp.prerequisites) do
			if techlist[prereq] then children[techpname] = true end
		end
	end
	if table_size(children) > 0 then hide_techs_and_children(children,bool) end
end

function CONTROL.refresh_hidden_military_techs()
	local enabled = (settings.global["ir-hide-military-technologies"].value ~= "hidden")
	hide_techs_and_children(DIR.values_to_keys(CONTROL.military_technologies), enabled)
end

function CONTROL.technology_effects_reset(event)
	CONTROL.refresh_non_tech_recipe_unlocks(event.force)
end

function CONTROL.get_entity_has_water_neighbours(entity)
	local offsets = {{x=-1,y=0},{x=1,y=0},{x=0,y=-1},{x=0,y=1}}
	for _,offset in pairs(offsets) do
		if string.find(entity.surface.get_tile(math.floor(entity.position.x+offset.x), math.floor(entity.position.y+offset.y)).name, "water") then
			return true
		end
	end
	return false
end

function CONTROL.event_built(event)
	local entity = event.created_entity or event.entity or event.destination
    if entity and entity.valid then
		if string.find(entity.name,"aetheric") and entity.get_recipe() == nil then
			entity.set_recipe(DIR.default_aetheric_recipe)
		elseif entity.name == "steel-boiler" then
			entity.recipe_locked = true
			if entity.get_recipe() == nil then entity.set_recipe(DIR.default_boiler_recipe) end
		elseif entity.name == "iron-geothermal-exchanger" then
			entity.recipe_locked = true
			if entity.get_recipe() == nil then entity.set_recipe(DIR.default_geothermal_recipe) end
		elseif entity.name == "chrome-transmat" then
			CONTROL.cache_transmat(entity)		
			if event.tags and event.tags["ir-transmat-name"] then
				CONTROL.set_transmat_text(entity, event.tags["ir-transmat-name"])
			end
		elseif entity.name == "bottomless-pit" then
			entity.infinity_container_filters = {}
			entity.remove_unfiltered_items = true
		elseif entity.type == "resource" and string.find(entity.name,"fissure") then
			entity.surface.create_entity{name=entity.name.."-smoke", position=entity.position}
		elseif entity.type == "simple-entity" and string.find(entity.name,"gem%-rock%-") then
			local material = string.gsub(entity.name, "gem%-rock%-", "")
			if DIR.materials[material] then
				for i=1,CONTROL.get_RNG(entity.surface,3,5) do
					local theta = CONTROL.get_RNG(entity.surface)*math.pi*2
					local distance = 0.25 + CONTROL.get_RNG(entity.surface)/5
					rendering.draw_animation{
						animation = "twinkle-animation-"..CONTROL.get_RNG(entity.surface,1,4),
						animation_offset = CONTROL.get_RNG(entity.surface,0,100),
						orientation = CONTROL.get_RNG(entity.surface),
						x_scale = 1,
						y_scale = 1,
						render_layer = "higher-object-under",
						animation_speed = 1,
						target = entity,
						target_offset = {math.cos(theta)*distance, math.sin(theta)*distance},
						surface = entity.surface,
						tint = DIR.hsva2rgba(DIR.materials[material].hue,DIR.get_saturation(DIR.materials[material].hue,0.3),1,0.85),
					}
				end
			end
		elseif string.find(entity.name, "derrick") then
			local smokes = entity.surface.find_entities_filtered{area=entity.bounding_box, type="particle-source"}
			if smokes then
				for _,smoke in pairs(smokes) do smoke.destroy() end
			end				
		elseif entity.type == "tree" or string.find(entity.name, "forestry") then
			CONTROL.update_forestries_in_chunk(entity.surface, entity.position)
			if string.find(entity.name, "forestry") then entity.recipe_locked = true end
		elseif string.find(entity.name, "tree%-planter%-") then
			local tree = string.gsub(entity.name,"tree%-planter%-","") .. "-planted"
			entity.surface.create_entity{name=tree,position=entity.position,raise_built=true}
		elseif entity.name == "waterfill-explosive" then
			-- if there is a water tile on any neighbour, trigger countdown
			if CONTROL.get_entity_has_water_neighbours(entity) then
				rendering.draw_animation{animation="waterfill-explosive-glow", render_layer="object", target=entity, surface=entity.surface, time_to_live=CONTROL.waterfill_explosive_initial_delay}
				CONTROL.add_delayed_action(CONTROL.waterfill_explosive_initial_delay,{action = "explode_waterfill", entity = entity})
			end
		elseif entity.name == "ir3-linked-filter-chest" then
			local inv = entity.get_inventory(defines.inventory.chest) 
			local index = 1
			local d = {
				["mining-tool"] = true,
				["rail-planner"] = true,
				["blueprint"] = true,
				["deconstruction-item"] = true,
				["upgrade-item"] = true,
				["blueprint-book"] = true,
				["copy-paste-tool"] = true,
				["selection-tool"] = true,				
			}
			for i,p in pairs(game.item_prototypes) do
				if not d[p.type] and not p.place_result and not p.place_as_tile_result and not p.place_as_equipment_result then
					inv.set_filter(index, i)
					index = index + 1
					inv.set_filter(index, i)
					index = index + 1
					-- if index > #inv then return end
				end
			end
			while index <= #inv do
				inv.set_filter(index, "splitter-blocker")
				index = index + 1
			end
			for i=1,#inv do
				if inv[i] and inv[i].valid_for_read and (inv[i].name ~= inv.get_filter(i)) then inv[i].clear() end
			end
		elseif string.find(entity.name,"item%-cannon") then
			CONTROL.register_itemcannon(entity,true)
		end
    end
end

function CONTROL.event_destroyed(event)
	local entity = event.entity
    if entity and entity.valid then
		if event.name == defines.events.on_robot_mined_entity then 
			local path = (game.is_valid_sound_path("entity-mined/"..entity.name) and "entity-mined/"..entity.name)
				or ((DIR.get_area_of_bounding_box(entity.selection_box) > 8.9) and "utility/deconstruct_big")
				or ((DIR.get_area_of_bounding_box(entity.selection_box) > 2.9) and "utility/deconstruct_medium")
				or "utility/deconstruct_small"
			game.play_sound{
				position = entity.position,
				path = path,
				volume_modifier = 0.5,
			}
		end
		if entity.type == "tree" then
			CONTROL.update_forestries_in_chunk(entity.surface, event.old_position or entity.position, entity)
			if event.old_position == nil then
				local planters = entity.surface.find_entities_filtered{area=entity.bounding_box, name=CONTROL.tree_planters}
				if planters and table_size(planters) > 0 then 
					for _,planter in pairs(planters) do
						planter.destroy{raise_destroy=false}
					end
				end
			end
			if event.cause and event.cause.valid and event.cause.name == "heavy-roller" then
				local p = entity.prototype
				if p.mineable_properties and p.mineable_properties.minable and p.mineable_properties.products then
					local message = ""
					for _,product in pairs(p.mineable_properties.products) do
						local amount = product.amount or DIR.get_RNG(entity.surface, product.amount_min, product.amount_max)
						local inserted = event.cause.get_inventory(defines.inventory.car_trunk).insert({name=product.name, count=amount})
						if inserted > 0 then
							local a = CONTROL.green_text.."+"..inserted..CONTROL.end_colour_text
							if message ~= "" then message = message .. " " end
							message = message .. "[item="..product.name.."] " .. a
						end
					end
					if message ~= "" then
						CONTROL.entity_flying_notification(entity,message)
					end
				end
			end
		elseif CONTROL.is_a_polluter(entity) then 
			CONTROL.fluid_destroyed(entity)
		elseif entity.name == "chrome-transmat" then
			global[CONTROL.get_transmat_reference(entity)] = nil
			CONTROL.remove_markers(entity)
		elseif string.find(entity.name, "derrick") then
			local resources = entity.surface.find_entities_filtered{area=entity.bounding_box, type="resource"}
			if not resources or table_size(resources) == 0 then return end
			for _,resource in pairs(resources) do
				if (resource.prototype.resource_category == "ir-gas") or (resource.prototype.resource_category == "ir-steam") then
					entity.surface.create_entity{name=resource.name.."-smoke", position=entity.position}
				end
			end
		elseif string.find(entity.name, "forestry") then
			CONTROL.update_forestries_in_chunk(entity.surface, event.old_position or entity.position, entity)
		elseif string.find(entity.name, "tree%-planter%-") then
			local trees = entity.surface.find_entities_filtered{area=entity.bounding_box, type="tree"}
			if not trees or table_size(trees) == 0 then return end
			for _,tree in pairs(trees) do
				tree.destroy{raise_destroy=true}
			end
		elseif entity.type == "resource" and string.find(entity.name,"fissure") then
			local smoke = entity.surface.find_entity(entity.name.."-smoke", entity.position)
			if smoke and smoke.valid then smoke.destroy{raise_destroy=true} end
		elseif string.find(entity.name,"item%-cannon") then
			CONTROL.register_itemcannon(entity,false)
		end
    end
end

function CONTROL.event_died(event)
	if event.entity and event.entity.valid and event.entity.name == "chrome-transmat" then
		-- this was a died event - leave transmat name intact for post_entity_died
		return
	else
		CONTROL.event_destroyed(event)
	end
end

function CONTROL.event_setup_blueprint(event)
    local player = game.players[event.player_index]
	if not player then return end
	local blueprint = nil
	if player.blueprint_to_setup and player.blueprint_to_setup.valid_for_read then blueprint = player.blueprint_to_setup
	elseif player.cursor_stack.valid_for_read and player.cursor_stack.name == "blueprint" then blueprint = player.cursor_stack end
	if blueprint and blueprint.is_blueprint_setup() then
		for index,entity in pairs(event.mapping.get()) do
			if entity.valid and entity.name == "chrome-transmat" then
				local name = CONTROL.get_transmat_text(entity)
				if name ~= "" then
					blueprint.set_blueprint_entity_tag(index, "ir-transmat-name", name)
				end
			end
		end
	end
end

function CONTROL.event_post_entity_died(event)
	if event.prototype and event.prototype.name == "chrome-transmat" then
		-- if the transmat had a name and there is a ghost, add name tag to ghost
		if event.ghost and event.ghost.valid then
			local name = CONTROL.get_transmat_text(event.ghost)
			if name ~= "" then
				if event.ghost.tags == nil then event.ghost.tags = {["ir-transmat-name"] = name}
				else event.ghost.tags["ir-transmat-name"] = name end
			end
		end
		-- remove cached data from global
		global[CONTROL.get_transmat_reference_by_data(game.surfaces[event.surface_index].name, event.force.name, event.position)] = nil
	end
end

function CONTROL.cycle_glow_recipe(event,delta)
	local player = game.players[event.player_index]
	if player and player.cursor_stack and player.cursor_stack.valid_for_read then return end
	local selected = player and player.selected
	if selected and selected.valid and string.find(selected.name,"aetheric") and (player.force == selected.force or player.force.get_friend(selected.force)) then
		if player.can_reach_entity(selected) then
			if selected.get_recipe() == nil then
				selected.set_recipe(DIR.default_aetheric_recipe)
			else
				local q,w = string.find(selected.get_recipe().name, "-%d+$")
				local index = tonumber(string.sub(selected.get_recipe().name,q+1,w))
				index = index + delta
				if index >= DIR.glow_recipe_count then index = 0
				elseif index < 0 then index = DIR.glow_recipe_count - 1 end
				selected.set_recipe("aetheric-glow-"..index)
			end
		else
			CONTROL.player_cannot_reach(player,selected)
		end
	end
end

-- function CONTROL.get_first_entity_render(entity,rtype)
	-- for _,id in pairs(rendering.get_all_ids(DIR.IR)) do
		-- if rendering.get_type(id) == rtype and rendering.get_target(id).entity == entity then return id end
	-- end
	-- return nil
-- end

function CONTROL.filter_container(entity,filter)
	if entity and entity.valid then
		local inv = entity.get_inventory(defines.inventory.chest)
		for i=1,#inv do
			inv.set_filter(i, filter)
		end
	end
end

function CONTROL.highlight_chunk_at_position(surface,position,player,offset)
	local c = {x = math.floor(position.x/32), y = math.floor(position.y/32)}
	local cc = (offset == nil) and {x = (c.x*32)+16, y = (c.y*32)+16} or {x = position.x + offset.x, y = position.y + offset.y}
	local sprite = rendering.draw_sprite{sprite="utility/white_square", target=cc, x_scale=102.4, y_scale=102.4, tint = CONTROL.chunk_visualisation_tint, render_layer="radius-visualization", surface=surface, players=player and {player.index} or nil, only_in_alt_mode=false}
	local renders = {sprite}
	local line = {
		{{cc.x-17,cc.y-16},{cc.x+17,cc.y-16}},
		{{cc.x-17,cc.y+16},{cc.x+17,cc.y+16}},
		{{cc.x-16,cc.y-17},{cc.x-16,cc.y+17}},
		{{cc.x+16,cc.y-17},{cc.x+16,cc.y+17}},
	}
	for _,l in pairs(line) do
		table.insert(renders, rendering.draw_line{color=CONTROL.chunk_visualisation_tint_line, width=1, gap_length=1/16, dash_length=1/16, filled=false, from=l[1], to=l[2], surface=surface, players=player and {player.index} or nil, only_in_alt_mode=false})
	end
	return renders
end

function CONTROL.on_selected_entity_changed(event)
	local last_renders = CONTROL.get_player_global(event.player_index,"last_selected_highlight_renders")
	if last_renders then
		for _,render in pairs(last_renders) do
			if rendering.is_valid(render) then rendering.destroy(render) end
		end
		CONTROL.set_player_global(event.player_index,"last_selected_highlight_renders",nil)
	end
	local last_entities = CONTROL.get_player_global(event.player_index,"last_selected_highlight_entities")
	if last_entities then
		for _,entity in pairs(last_entities) do
			if entity and entity.valid then entity.destroy() end
		end
		CONTROL.set_player_global(event.player_index,"last_selected_highlight_entities",nil)
	end
	local player = game.players[event.player_index]
	-- negative pollution entities
	if player.selected and CONTROL.get_emissions(player.selected) < 0 then
		local renders = CONTROL.highlight_chunk_at_position(player.surface,player.selected.position,player)
		if string.find(player.selected.name,"forestry") then
			local highlights = {}
			local trees = CONTROL.get_husbanded_trees(player.selected.surface,player.selected.position)
			if trees and table_size(trees) > 0 then
				for _,tree in pairs(trees) do
					local highlight = player.selected.surface.create_entity{
						type="highlight-box",
						name="highlight-box",
						position=player.selected.position,
						bounding_box=tree.bounding_box,
						box_type="logistics",
						render_player_index = player.index,
					}
					table.insert(highlights,highlight)
				end
			end
			local entities = CONTROL.get_forestries_in_chunk(player.selected.surface,player.selected.position,player.selected)
			if entities and table_size(entities) > 0 then
				for _,e in pairs(entities) do
					local highlight = player.selected.surface.create_entity{type="highlight-box", name="highlight-box", position=player.selected.position, bounding_box=e.bounding_box, box_type="not-allowed"}
					table.insert(highlights,highlight)
				end
			end
			CONTROL.set_player_global(event.player_index,"last_selected_highlight_entities", highlights)
		end
		CONTROL.set_player_global(event.player_index,"last_selected_highlight_renders",renders)
		return
	end
    -- containers ("fetchport")
	if player.selected and player.can_reach_entity(player.selected) and CONTROL.fetchport_targets[player.selected.type] then
		local settings = CONTROL.fetchport_settings[settings.get_player_settings(player)["ir-fetchport-containers"].value]
		if settings.type == nil then return end
		if DIR.list_contains(settings.type,player.selected.type) and ((settings.name == nil) or DIR.list_contains(settings.name,player.selected.name)) then
			local entities = player.surface.find_entities_filtered{
				type = settings.type,
				name = settings.name,
				force = player.force,
				position = player.selected.position,
				radius = CONTROL.fetchport_target_radius,
			}
			if entities ~= nil and #entities > 0 then
				local highlights = {}
				for _,e in pairs(entities) do
					if e ~= player.selected then
						local highlight = player.selected.surface.create_entity{
							type="highlight-box",
							name="highlight-box",
							position=e.position,
							bounding_box=e.selection_box,
							box_type="logistics",
							render_player_index = player.index
						}
						table.insert(highlights,highlight)
					end
				end
				CONTROL.set_player_global(event.player_index,"last_selected_highlight_entities",highlights)
			end
			return
		end
	end
end

-- gui stuff

local function get_filter_if_all_same(inv)
	local last = nil
	for i=1,#inv do
		if last == nil then
			last = inv.get_filter(i)
		elseif last ~= inv.get_filter(i) then
			return nil
		end
	end
	return last
end

function CONTROL.create_filter_gui(player,entity,inv)
	if player.gui.relative["cargo-filters"] then player.gui.relative["cargo-filters"].destroy() end
	local f = player.gui.relative.add {
		name = "cargo-filters",
		type = "frame",
		direction = "vertical",
		anchor = {
			gui = defines.relative_gui_type.container_gui,
			position = defines.relative_gui_position.right,
			name = entity.name,
		},
	}
	f.style.padding = 8
	f.style.top_padding = 4
	local filler = f.add {
		type = "empty-widget",
		style = "draggable_space_header",
		drag_target = f,
	}
	filler.style.natural_height = 24
	filler.style.margin = 0
	filler.style.bottom_margin = 4
	filler.style.horizontally_stretchable = true
	local t = f.add {
		type = "frame",
		style = "inside_shallow_frame_with_padding",
		direction = "vertical",
	}
	t.style.padding = 0
	t = t.add {
		type = "frame",
		style = "slot_button_deep_frame",
		direction = "vertical",
	}
	local b = t.add {
		name = "inventory-filter",
		type = "choose-elem-button",
		elem_type = "item",
		item = get_filter_if_all_same(inv),
		tooltip = {"gui.inventory-filter"},
	}
	local h = f.add {
		type = "sprite",
		sprite = "slot-filters",
		tooltip = {"gui-help.slot-filters"}
	}
	h.style.width = 40
	h.style.height = 13
	h.style.stretch_image_to_widget_size = true
	h.style.top_margin = 5
end

CONTROL.gui_click = {
    ["transmat-header-close"] = function (event)
        CONTROL.on_gui_close(event)
    end,
    ["transmat-header-help"] = function (event)
        CONTROL.toggle_manifesto(event, "ir_transmats")
    end,
	["transmat-edit-button"] = function (event)
		local player = game.players[event.player_index]
		local textfield = player.gui.screen[CONTROL.transmat_gui]["transmat-header"]["transmat-edit-textfield"]
		if textfield then
			textfield.visible = not textfield.visible
			event.element.style = textfield.visible and "transmat_small_button_active" or "transmat_small_button"
			event.element.sprite = textfield.visible and "edit-button-black" or "edit-button"
			if not textfield.visible then
				textfield.text = ""
			else
				textfield.text = CONTROL.get_transmat_text(CONTROL.get_current_transmat_from_gui(player))
				textfield.focus()
			end
		end
	end,
    ["transmat-map-marker"] = function (event)
		local player = game.players[event.player_index]
		local transmat = CONTROL.get_current_transmat_from_gui(player)
		if transmat and transmat.valid then 
			if CONTROL.get_has_map_marker(transmat) then
				event.element.style = "transmat_small_button"
				event.element.sprite = "map-marker"
				CONTROL.remove_markers(transmat)
				player.play_sound{path = "map-marker-pong"}
			else
				CONTROL.add_map_marker(transmat, "virtual", "ir-transmat-signal", CONTROL.get_transmat_label(transmat), player)
				event.element.style = "transmat_small_button_active"
				event.element.sprite = "map-marker-black"
			end
		end
    end,
	["t_list"] = function (event)
		local player = game.players[event.player_index]
		CONTROL.refresh_transmat_gui(player)
	end,
	["t_activate_button"] = function (event)
		local player = game.players[event.player_index]
		local parent_table = event.element.parent.parent
		local selected_index = parent_table["t_list_table"]["t_list_frame"]["t_list"].selected_index
		local selected_tags = parent_table["t_list_table"]["t_list_frame"]["t_list"].tags
		local from = CONTROL.get_current_transmat_from_gui(player)
		local cache = CONTROL.get_cached_transmats(player)
		local to = cache[selected_tags["unit_number_"..selected_index]]
		if CONTROL.fancy_teleport(player, from, to) then CONTROL.on_gui_close(event) end
	end,
	["t_map"] = function (event)
		if event.element.parent and event.element.parent.parent and event.element.parent.parent.name == "t_frame_minimap" then
			local player = game.players[event.player_index]
			player.open_map(event.element.position, 0.1)
		end
	end,
    ["manifesto-header-close"] = function (event)
        CONTROL.toggle_manifesto(event)
    end,
	["manifesto-list"] = function (event)
		CONTROL.select_manifesto_page(event.element, event.player_index)
	end,
	["manifesto-icon"] = function (event)
		local player = game.players[event.player_index]
		if player.admin then
			local element = event.element.parent.parent["manifesto-body"]["manifesto-list"]
			game.take_screenshot {
				surface = player.surface,
				by_player = player,
				resolution = {x=3840,y=2160}, 
				zoom = 0.25,
				path = element.selected_index..".jpg",
				show_gui = true,
				show_entity_info = false,
				anti_alias = true,
				quality = 100,
			}
			game.print("Screenshot "..element.selected_index, {sound = defines.print_sound.never})
		end
	end,
    ["inventory-filter"] = function (event)
		local player = game.players[event.player_index]
		CONTROL.filter_container(player.opened, event.element.elem_value)
	end,
}

function CONTROL.on_gui_click(event)
	if CONTROL.gui_click[event.element.name] then
		CONTROL.gui_click[event.element.name](event)
	end
end

function CONTROL.on_gui_opened(event)
	if event.gui_type ~= defines.gui_type.entity then return end
    local player = game.players[event.player_index]
    local selected = event.entity
    if selected and selected.valid then
		if selected.name == "chrome-transmat" then
			CONTROL.create_transmat_gui(player, selected)
		end
		local inv = selected.get_inventory(defines.inventory.chest) or selected.get_inventory(defines.inventory.cargo_wagon)
		if inv and inv.valid and #inv > 1 and inv.supports_filters() and not selected.has_flag("hide-alt-info") then
			CONTROL.create_filter_gui(player,selected,inv)
		end
	end
end

function CONTROL.on_gui_close(event)
    local player = game.players[event.player_index]
	if player.gui.relative["cargo-filters"] then player.gui.relative["cargo-filters"].destroy() end
    local frame = player.gui.screen[CONTROL.transmat_gui]
    if frame then
		CONTROL.set_player_global(player.index,"transmat_gui_location",frame.location)
		player.opened = nil
        return frame.destroy()
    end
    local frame = player.gui.screen[CONTROL.manifesto_gui]
    if frame then
		player.opened = nil
        return frame.destroy()
    end
	return false
end

function CONTROL.on_gui_text_changed(event)
    local player = game.players[event.player_index]
	if player and player.valid and event.element and event.element.valid then
		if event.element.name == "transmat-edit-textfield" then
			if string.len(event.element.text) > CONTROL.transmat_max_name_length then
				event.element.text = string.sub(event.element.text, 1, CONTROL.transmat_max_name_length)
				return
			end
			CONTROL.update_transmat_label(event.player_index, event.element.text)
		end
	end
end

function CONTROL.on_gui_confirmed(event)
    local player = game.players[event.player_index]
	if player and event.element.name == "transmat-edit-textfield" then
		CONTROL.close_edit(event)
	end
end

function CONTROL.on_gui_location_changed(event)
	if event.element.name == CONTROL.transmat_gui then
		CONTROL.set_player_global(event.player_index, "transmat_gui_location", event.element.location)
	end
end

local function rezoom_camera_children(root,scale,old_scale)
	for _,child in pairs(root.children) do
		if child.name == "sim_camera" or child.name == "t_static" or child.name == "t_map" then child.zoom = (child.zoom/old_scale)*scale end
		if child.children then rezoom_camera_children(child,scale,old_scale) end
	end
end

function CONTROL.display_scale_changed(event)
    local player = game.players[event.player_index]
	local root = player.gui.screen[CONTROL.transmat_gui] or player.gui.screen[CONTROL.manifesto_gui] or player.gui.screen[CONTROL.informatron_gui]
	if root and root.children then rezoom_camera_children(root, player.display_scale, event.old_scale) end
end

local function normalise_orientation(o) 
    while (o < -0.5) do o = o + 1 end
    while (o > 0.5) do o = o - 1 end
	return o
end

local function is_orientation_in_range(test, a, b)
    a = a - test
    b = b - test
    normalise_orientation(a)
    normalise_orientation(b)
    if a * b >= 0 then return false end
    return math.abs(a-b) < 0.5
end

-- script effects

function CONTROL.script_trigger_effect(event)
	if event.effect_id == "ir-emp-direct" then
		local target = event.target_entity
		local source = event.source_entity
		if not target.valid or not source.valid then return end
		local height = source.type == "character" and 1.25 or 0.875
		local radius = source.type == "character" and 0.05 or 0.5
		local source_position = CONTROL.get_turret_beam_origin(source.position,height,radius,source.orientation)
		local target_position = DIR.get_vector_sum(target.position,{x=0,y=-0.5})
		local midpoint = DIR.get_vector_midpoint(source_position,target_position)
		local width = DIR.get_distance(source_position,target_position)+0.5
		local midpoint_ground = DIR.get_vector_midpoint(source.position,target.position)
		local width_ground = DIR.get_distance(source.position,target.position)+1.5
		local variant = math.ceil(CONTROL.get_RNG(target.surface)*8)
		local w = 8 + math.floor(DIR.clamp(math.floor(width)-8,0,8)/4)*4
		local render_layer = (source.orientation < 0.25 or source.orientation > 0.75) and "object" or "air-object"
		local base_ttl = 32
		local base_delay = 16
		local delay = 2
		local id1 = rendering.draw_sprite {
			sprite = "lightning-"..w.."-"..variant,
			x_scale = width/w,
			y_scale = 1,
			render_layer = render_layer,
			orientation_target = source_position,
			orientation = 0.25,
			surface = source.surface,
			time_to_live = (base_ttl * delay) + base_delay,
			target = midpoint,
		}		
		local id2 = rendering.draw_sprite {
			sprite = "lightning-ground-"..w.."-"..variant,
			x_scale = width_ground/(w+1),
			y_scale = 1,
			render_layer = "floor-mechanics",
			orientation_target = source.position,
			orientation = 0.25,
			surface = source.surface,
			time_to_live = (base_ttl * delay) + base_delay,
			target = midpoint_ground,
		}		
		source.surface.create_entity{name="emp-shock", position=target_position, create_build_effect_smoke=false}
		source.surface.play_sound({path = "emp-hit", position = midpoint})
		CONTROL.add_delayed_action(delay, {action="decrease_lightning_alpha", ids = {id1,id2}, decrease = 1/32, delay = delay})
	elseif event.effect_id == "ir-pollution-bomb" then
		game.surfaces[event.surface_index].pollute(event.target_position, CONTROL.nuke_pollution)
		-- if global.last_artillery then
			-- game.print(math.floor((game.tick-global.last_artillery)/60).." seconds")
		-- end
	elseif event.effect_id == "ir-poison-capsule" then
		game.surfaces[event.surface_index].pollute(event.target_position, DIR.get_spilled_pollution_value(200))
	elseif event.effect_id == "ir-slowdown-capsule" then
		game.surfaces[event.surface_index].pollute(event.target_position, DIR.get_spilled_pollution_value(100))
	elseif event.effect_id == "ir-transfer-plate" then
		local target = event.target_entity
		local source = event.source_entity
		source.timeout = 300
		local player = nil
		if target.type == "character" then player = target.player
		elseif target.type == "car" or target.type == "spider-vehicle" then
			player = target.get_driver()
			if player and player.valid and player.type == "character" then player = player.player end
		end
		if player and player.valid then
			local r = DIR.delivery_plate_radius - ((source.name == "transfer-plate-2x2") and 0.5 or 0)
			CONTROL.fetchport_replenish(player,"transfer-plate",source,"all",r,true)
		end
	end
end

-- entity toggle key

local function are_friends(force1, force2)
	return (force1 == force2) or force1.get_friend(force2)
end

local function rotate(vector,direction)
	local directions = {
		[defines.direction.north] = 0,
		[defines.direction.east] = 90,
		[defines.direction.south] = 180,
		[defines.direction.west] = 270,
	}
	local radians = math.rad(directions[direction])
	local dx = math.cos(radians)
	local dy = math.sin(radians)
	return {x = dx * vector.x - dy * vector.y, y = dy * vector.x + dx * vector.y}
end

local function get_connection_position_index(direction)
	return directions[direction]
end

function CONTROL.entity_adjustment(event)

	local player = game.players[event.player_index]
	if not (player and player.valid) then return end
	local selected = (player.selected and player.selected.valid) and player.selected or nil
	
	-- toggle locos between manual/auto: special case because train can be ridden instead of selected
	local train = player.vehicle and player.vehicle.valid and player.vehicle.train
	if not train and selected and selected.train and are_friends(player.force, selected.force)
	then train = selected.train end
	if train then
		train.manual_mode = not train.manual_mode
		player.play_sound{path = train.manual_mode and "deactivate" or "activate"}
	end

	-- ghosts
	-- if selected and ((selected.type == "entity-ghost") or (selected.type == "tile-ghost")) then
		-- local vehicle = player.vehicle and player.vehicle.valid and player.vehicle
		-- if vehicle and (vehicle.type == "car" or vehicle.type == "spider-vehicle") then
			-- CONTROL.fire_item_cannon(vehicle, vehicle.surface.find_entities_filtered{radius=20,position=selected.position,type={"entity-ghost","tile-ghost"},force=selected.force})
		-- end
		-- return
	-- end

	-- everything past this needs a valid selected entity that belongs to a friendly force
	if selected and are_friends(player.force, selected.force) then
	
		-- 3.1.7: support RC
		local can_reach_entity = game.active_mods["RemoteConfiguration"] or player.can_reach_entity(selected)

		-- linked belts: not accessible to players without editor, used in menu sim
		if selected.type == "linked-belt" and string.find(selected.name,"ir3") then
			local target = CONTROL.get_player_global(player.index, "last-linked-belt")
			if target and target.valid and (selected == target) then
				player.print("Linked belt selection cleared", {sound = defines.print_sound.never})
				CONTROL.set_player_global(player.index, "last-linked-belt", nil)
			elseif target and target.valid then
				target.disconnect_linked_belts()
				selected.disconnect_linked_belts()
				target.linked_belt_type = "input"
				selected.linked_belt_type = "output"
				selected.connect_linked_belts(target)
				player.print("Linked belt connected", {sound = defines.print_sound.never})
				CONTROL.set_player_global(player.index, "last-linked-belt", nil)
			else
				player.print("Linked belt selected", {sound = defines.print_sound.never})
				CONTROL.set_player_global(player.index, "last-linked-belt", selected)
			end
		-- power switch
		elseif selected.type == "power-switch" then
			player.play_sound{path = selected.power_switch_state and "deactivate-heavy" or "activate-heavy"}
			selected.power_switch_state = not selected.power_switch_state
		-- constant combinator
		elseif selected.type == "constant-combinator" then
			player.play_sound{path = selected.get_control_behavior().enabled and "deactivate" or "activate"}
			selected.get_control_behavior().enabled = not selected.get_control_behavior().enabled
		-- inventory transfers
		elseif CONTROL.fetchport_targets[selected.type] then
			local settings = CONTROL.fetchport_settings[settings.get_player_settings(player)["ir-fetchport-containers"].value]
			if settings.type ~= nil then 
				if DIR.list_contains(settings.type,selected.type) and ((settings.name == nil) or DIR.list_contains(settings.name,selected.name)) then
					if player.can_reach_entity(selected) then -- Don't pull items from across the map, even with RC
						CONTROL.fetchport_replenish(player,"hotkey",selected)
					else
						CONTROL.player_cannot_reach(player,selected)
					end
				end
			end
		-- steel boiler
		elseif selected.name == "steel-boiler" then
			if can_reach_entity then
				if selected.get_recipe() and (selected.get_recipe().name == "electric-hot-water") then
					selected.set_recipe("electric-steam")
				else
					selected.set_recipe("electric-hot-water")
				end
				player.play_sound{path = (selected.get_recipe() and (selected.get_recipe().name == "electric-hot-water")) and "deactivate" or "activate"}
			else
				CONTROL.player_cannot_reach(player,selected)			
			end
		-- geothermal exchange
		elseif selected.name == "iron-geothermal-exchanger" then
			if can_reach_entity then
				if selected.get_recipe() and (selected.get_recipe().name == "geothermal-exchange") then
					selected.set_recipe("geothermal-hot-water")
				else
					selected.set_recipe("geothermal-exchange")
				end
				player.play_sound{path = (selected.get_recipe() and (selected.get_recipe().name == "geothermal-hot-water")) and "deactivate" or "activate"}
			else
				CONTROL.player_cannot_reach(player,selected)			
			end
		-- elseif (selected.type == "cargo-wagon") or (selected.type == "fluid-wagon") then
			-- selected.color = {0,0,0,0}
		-- all other entities: "fast-replace toggling"
		-- note: entity pairs must be in the same fast-replace group or dupe exploits will ensue
		elseif CONTROL.entity_toggle.name_pairs[selected.name] then
			if can_reach_entity then
				local properties = {}
				local new_name = CONTROL.entity_toggle.name_pairs[selected.name]
				for _,property in pairs(CONTROL.entity_toggle.properties[selected.type]) do
					properties[property] = selected[property]
				end
				local fluid_contents = {}
				if #selected.fluidbox > 0 then
					for i = 1,#selected.fluidbox do
						fluid_contents[i] = selected.fluidbox[i] -- done like this to get non-user-data copy of table to write back later
					end
				end
				selected.clear_fluid_inside()
				local new = player.surface.create_entity{
					name = new_name,
					position = selected.position,
					direction = selected.direction,
					force = selected.force,
					player = nil, -- has to be nil for spill = false to work, last_user put back in properties below
					raise_built = false,
					create_build_effect_smoke = false,
					fast_replace = true,
					spill = false
				}
				if new and new.valid then
					player.play_sound{path = CONTROL.entity_toggle.sounds[new_name] or "inserter-squeak"}
					for property,value in pairs(properties) do
						new[property] = value
					end
					if #fluid_contents > 0 then
						for i,fluid in ipairs(fluid_contents) do
							new.insert_fluid(fluid)
						end
					end
					-- entities such as aetheric lamps rotated to connect remaining pipes
					if CONTROL.entity_toggle.rotate_to_pipes[new_name] then
						local connected_directions = {}
						local directions = ((new.direction == defines.direction.north) or (new.direction == defines.direction.south)) and {
							[defines.direction.north] = {x = 0, y = -1},
							[defines.direction.south] = {x = 0, y = 1},
						} or {
							[defines.direction.east] = {x = 1, y = 0},
							[defines.direction.west] = {x = -1, y = 0},
						}
						for d,v in pairs(directions) do
							local e = new.surface.find_entities_filtered{type = {"pipe","pipe-to-ground","storage-tank","assembling-machine","furnace","infinity-pipe"}, position = DIR.get_vector_sum(new.position,v), limit = 1}
							if table_size(e) > 0 then connected_directions[d] = true end
						end
						if table_size(connected_directions) > 0 and not connected_directions[new.direction] then
							for d,_ in pairs(connected_directions) do
								new.direction = d
								break
							end
						end
					end
				end
			else
				CONTROL.player_cannot_reach(player,selected)
			end
		end
	end
end

function CONTROL.driving_autocorrect()
	for _,player in pairs(game.players) do
		if player and player.valid and settings.get_player_settings(player)["ir-driving-autocorrect"].value then
			local vehicle = player.vehicle
			if vehicle and vehicle.valid and vehicle.type == "car" and vehicle.riding_state.direction == defines.riding.direction.straight then
				if CONTROL.get_is_tile_mineable(vehicle.surface,vehicle.position) then
					local v = math.floor(((vehicle.orientation*8)+0.5))/8
					if vehicle.orientation ~= v then
						if math.abs(v-vehicle.orientation) < 0.015625 then
							vehicle.orientation = v
						else
							vehicle.orientation = vehicle.orientation + ((v-vehicle.orientation) > 0 and 0.015625 or -0.015625)
						end
					end
				end
			end			
		end
	end
end

function CONTROL.event_teleported(event)
	local entity = event.entity
	if entity and entity.valid then
		local event_data = { entity = entity, old_position = event.old_position }
		if entity.name == "chrome-transmat" then
			-- don't allow transmats to be teleported - too many things can go wrong
			if event.old_position then
				entity.teleport(event.old_position) -- don't raise event, to prevent infinite loop
			end
		elseif CONTROL.tree_planters_by_index[entity.name] then
			-- move any tree at the old position
			-- tree movement raises event for tree
			for _,tree in pairs(entity.surface.find_entities_filtered{position = event.old_position, type = "tree"}) do
				tree.teleport(entity.position, nil, true)
			end
		elseif entity.type == "tree" then
			-- move any tree planter at the old position
			for _,planter in pairs(entity.surface.find_entities_filtered{position = event.old_position, name = CONTROL.tree_planters}) do
				planter.teleport(entity.position) -- don't raise event, to prevent infinite loop - planter entity doesn't affect forestry maths anyhow
			end
			CONTROL.event_destroyed(event_data)
			CONTROL.event_built(event_data)
		elseif string.find(entity.name, "forestry") then
			CONTROL.event_destroyed(event_data)
			CONTROL.event_built(event_data)
		end
	end
end

local function match_hue(name)
	local _, _, itype, iname = string.find(name, "%[img=(.+)/(.+)]")
	if itype == nil then _, _, itype, iname = string.find(name, "%[(.+)=(.+)]") end
	if itype ~= "item" and itype ~= "fluid" and itype ~= "virtual-signal" then return end
	
	if itype == "fluid" then
		local f = game.fluid_prototypes[iname] and game.fluid_prototypes[iname].base_color
		if f then
			local hsva = DIR.rgba2hsva(f.r,f.g,f.b,0.5)
			f = DIR.hsva2rgba(hsva.h, (hsva.s > 0.05) and 0.8 or 0, 1, 0.5)
			return f
		else
			return nil
		end
	end

	if itype == "virtual-signal" then
		local map = {
			["signal-red"] = {1,0,0,0.5},
			["signal-orange"] = {1,0.5,0,0.5},
			["signal-yellow"] = {1,1,0,0.5},
			["signal-green"] = {0,1,0,0.5},
			["signal-cyan"] = {0,1,1,0.5},
			["signal-blue"] = {0,0,1,0.5},
			["signal-pink"] = {1,0,1,0.5},
			["signal-black"] = {0,0,0,0.5},
			["signal-grey"] = {0.5,0.5,0.5,0.5},
			["signal-white"] = {1,1,1,0.5},
		}
		return map[iname]
	end

	global.item_colours = global.item_colours or {}
	local cached_colour = global.item_colours[itype.."/"..iname]
	if cached_colour then
		return (type(cached_colour) == "table") and cached_colour or nil
	end

	for component,cdata in pairs(DIR.components) do
		for _,material in pairs(cdata.materials) do
			if DIR.materials[material].hue and DIR.get_item_name(material,component) == iname then
				local c = DIR.hsva2rgba(DIR.materials[material].hue, DIR.materials[material].saturation or 1, DIR.materials[material].value or 1, 0.5)
				global.item_colours[itype.."/"..iname] = c
				return c
			end
		end
	end
	global.item_colours[itype.."/"..iname] = -1
	return nil
end

function CONTROL.train_changed_state(event)
	local enabled = (settings.global["ir-colour-trains"].value ~= "no")
	if enabled and event.train and event.train.valid and event.train.state == defines.train_state.wait_station then
		local stop = event.train.station
		if stop then
			local c = match_hue(stop.backer_name)
			if c then
				stop.color = c
				local train = (settings.global["ir-colour-trains"].value == "loco") and {event.train.locomotives.front_movers,event.train.locomotives.back_movers} or {event.train.locomotives.front_movers,event.train.locomotives.back_movers, event.train.cargo_wagons, event.train.fluid_wagons}
				for _,locos in pairs(train) do
					for _,loco in pairs(locos) do
						loco.color = c
					end
				end
			end
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
