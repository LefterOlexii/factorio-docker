------------------------------------------------------------------------------------------------------------------------------------------------------

-- tank/pipe pollution

function CONTROL.is_a_polluter(entity)
	for property,propertylist in pairs(CONTROL.polluting_entities) do
		if propertylist[entity[property]] then return true end
	end
	return false
end

function CONTROL.get_pollution_event_text(amount)
	return "[img=warning-pollution] "..CONTROL.red_text.."+"..string.format("%.1f", DIR.nice_round(amount,1)).."[/color]"
end

local function pollute(entity,pollution)
	local pollution = DIR.get_spilled_pollution_value(pollution)
	if entity.surface.name ~= CONTROL.sim_surface_name then entity.surface.pollute(entity.position, pollution) end
	local size = DIR.clamp(math.ceil(pollution/25),1,10)
	entity.surface.create_entity({name = "pollution-cloud-"..size, position = entity.position})
	CONTROL.entity_flying_notification(entity,CONTROL.get_pollution_event_text(pollution))
end

-- 3.1.9 - runtime equivalent of function DIR.get_fluid_spill_multiplier()
function CONTROL.get_fluid_spill_multiplier(fluid)
	local f = game.fluid_prototypes[fluid]
	if not f then error("CONTROL.get_fluid_spill_multiplier() called on non-existent fluid "..fluid) end
	local i = game.item_prototypes[fluid.."-spill-data"]
	return i and i.fuel_emissions_multiplier or 0
end

function CONTROL.fluid_destroyed(entity)
	local pollution = 0
	for fluid,amount in pairs(entity.get_fluid_contents()) do
		pollution = pollution + (CONTROL.get_fluid_spill_multiplier(fluid) * amount)
	end
	if pollution > 0 then pollute(entity, pollution) end
end

function CONTROL.event_raised_flush(event)
	if not event.fluid then return end
	if event.entity and event.amount then
		local pollution = CONTROL.get_fluid_spill_multiplier(event.fluid) * event.amount
		if pollution > 0 then pollute(event.entity,pollution) end
	end
end

function CONTROL.get_emissions(entity)
	local p = entity.prototype
	local sources = {"electric_energy_source_prototype","burner_prototype","fluid_energy_source_prototype","heat_energy_source_prototype","void_energy_source_prototype"}
	for _,source in pairs(sources) do
		if p[source] and p[source].emissions ~= nil then return p[source].emissions end
	end
	return 0
end

------------------------------------------------------------------------------------------------------------------------------------------------------
