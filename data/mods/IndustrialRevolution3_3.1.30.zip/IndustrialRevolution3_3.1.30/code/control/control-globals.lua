------------------------------------------------------------------------------------------------------------------------------------------------------

require("code.data.globals")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- misc constants - not changed at runtime

CONTROL.bigint = 2^32
CONTROL.orefields = require("code.data.orefields")
CONTROL.orefield_groups = require("code.data.orefield-groups")
CONTROL.starter_kits = require("code.data.kits")
CONTROL.red_text = "[color=1,0.375,0.375]"
CONTROL.green_text = "[color=0.375,1,0.375]"
CONTROL.grey_text = "[color=0.75,0.75,0.75]"
CONTROL.end_colour_text = "[/color]"
CONTROL.chunk_visualisation_tint = {r=0.0,g=0.125,b=0.025,a=0.1}
CONTROL.chunk_visualisation_tint_line = {r=0.05,g=0.2,b=0.1,a=0.1}
CONTROL.sim_character_colour = { r = 0.815, g = 0.024, b = 0.0, a = 0.5 }
CONTROL.fuel_manager_interval = DIR.seconds_to_ticks(10)
CONTROL.handle_sim_surface_interval = DIR.seconds_to_ticks(4)
CONTROL.driving_autocorrect_interval = 30 -- ticks
CONTROL.transmat_gui_refresh_interval = DIR.seconds_to_ticks(1)
CONTROL.transmat_list_item_width = 256
CONTROL.transmat_list_status_height = 28
CONTROL.transmat_list_map_height = CONTROL.transmat_list_item_width
CONTROL.transmat_list_item_height = CONTROL.transmat_list_map_height + CONTROL.transmat_list_status_height
CONTROL.transmat_list_middle_width = 256
CONTROL.transmat_list_battery_width = 64
CONTROL.transmat_list_indicator_width = 28
CONTROL.transmat_radius = 1.3
CONTROL.transmat_max_name_length = 20
CONTROL.manifesto_content_height = 616 -- 22 list items
CONTROL.nuke_pollution = 7500
CONTROL.limbo_surface_name = "IR-limbo"
CONTROL.sim_surface_name = "IR-simsurface"
CONTROL.transmat_gui = "IR-transmat-gui"
CONTROL.manifesto_gui = "IR-manifesto"
CONTROL.informatron_gui = "informatron"
CONTROL.forestry_cycle_interval = 12500 -- length of forestry tree growth/decay cycle, in ticks (0.5 game days)
CONTROL.forestry_cycle_chunk_interval = 30 -- spacing between chunk updates triggered by cycle, in ticks

CONTROL.autoplaced_fissures = {}
CONTROL.start_location_fissures = {}
local fissures = require("code.data.fissures")
for material,data in pairs(fissures) do
	if data.autoplace then table.insert(CONTROL.autoplaced_fissures, DIR.get_item_name(material,"gas").."-fissure") end
	if data.scripted_start_location then table.insert(CONTROL.start_location_fissures, DIR.get_item_name(material,"gas").."-fissure") end
end

CONTROL.polluting_entities = {
	type = {
		["storage-tank"] = true,
		["pipe"] = true,
		["pipe-to-ground"] = true,
		["fluid-wagon"] = true,
		["pump"] = true,
	},
	name = {
		["iron-gas-vent"] = true,
	},
}
CONTROL.base_fissure_chance = 1/1000
CONTROL.waterfill_explosive_initial_delay = 180
CONTROL.waterfill_explosive_chain_delay = 30
CONTROL.forestry_names = {"bronze-forestry","iron-forestry","chrome-forestry"}
CONTROL.fetchport_target_radius = 5
CONTROL.fetchport_settings = {
	all = {
		type = {"container","logistic-container","linked-container"},
		name = nil,
	},
	nonlogistics = {
		type = {"container","linked-container"},
		name = nil,
	},
	pallets = {
		type = {"container"},
		name = {"wood-pallet","tin-pallet"},
	},
	logistics = {
		type = {"logistic-container"},
		name = {"logistic-chest-storage","logistic-chest-active-provider","logistic-chest-passive-provider"},
	},
	none = {
		type = nil,
		name = nil,
	},
}
CONTROL.fetchport_targets = {
	["container"] = true,
	["logistic-container"] = true,
	["linked-container"] = true,
}
CONTROL.military_technologies = {
	"physical-projectile-damage-1",
	"weapon-shooting-speed-1",
	"military",
	"ir-scattergun-turret",
	"ir-scatterbot",
}

-- event filters

CONTROL.destroy_event_filters = {
	{filter = "name", name = "chrome-transmat"},
	{filter = "name", name = "steel-derrick"},
	{filter = "name", name = "copper-derrick"},
	{filter = "name", name = "bronze-forestry"},
	{filter = "name", name = "iron-forestry"},
	{filter = "name", name = "chrome-forestry"},
	{filter = "type", type = "tree"},
	{filter = "type", type = "resource"},
}
for property,propertylist in pairs(CONTROL.polluting_entities) do
	for entity,_ in pairs(propertylist) do 
		table.insert(CONTROL.destroy_event_filters, {filter = property, [property] = entity})
	end
end

CONTROL.post_died_event_filters = {
	{filter = "type", type = "electric-energy-interface"},
}

CONTROL.build_event_filters = {
	{filter = "name", name = "chrome-transmat"},
	{filter = "name", name = "copper-aetheric-lamp-end"},
	{filter = "name", name = "copper-aetheric-lamp-straight"},
	{filter = "name", name = "bottomless-pit"},
	{filter = "type", type = "resource"},
	{filter = "type", type = "simple-entity"},
	{filter = "name", name = "steel-derrick"},
	{filter = "name", name = "copper-derrick"},
	{filter = "name", name = "bronze-forestry"},
	{filter = "name", name = "iron-forestry"},
	{filter = "name", name = "chrome-forestry"},
	{filter = "type", type = "tree"},
	{filter = "name", name = "waterfill-explosive"},
	{filter = "name", name = "ir3-linked-filter-chest"},	
	{filter = "name", name = "steel-boiler"},	
	{filter = "name", name = "iron-geothermal-exchanger"},	
}

CONTROL.teleport_event_filters = {
	{filter = "name", name = "chrome-transmat"},
	{filter = "name", name = "bronze-forestry"},
	{filter = "name", name = "iron-forestry"},
	{filter = "name", name = "chrome-forestry"},
	{filter = "type", type = "tree"},
}

CONTROL.known_trees = {}
CONTROL.tree_planters = {}
CONTROL.tree_planters_by_index = {}

for _,tree in pairs(DIR.plantable_trees) do
	table.insert(CONTROL.destroy_event_filters, {filter = "name", name = "tree-planter-"..tree})
	table.insert(CONTROL.build_event_filters, {filter = "name", name = "tree-planter-"..tree})
	table.insert(CONTROL.teleport_event_filters, {filter = "name", name = "tree-planter-"..tree})
	table.insert(CONTROL.tree_planters, "tree-planter-"..tree)
	CONTROL.tree_planters_by_index["tree-planter-"..tree] = true
end

CONTROL.gem_rocks = {}
for _,gem in pairs(DIR.components.gem.materials) do
	if DIR.components.gem.ore_patch_chances[gem] then table.insert(CONTROL.gem_rocks, "gem-rock-"..gem) end
end

-- entity toggle hotkey data

CONTROL.entity_toggle = {
	name_pairs = {
		-- per name
		["photon-turret"] = "photon-turret-narrow",
		["photon-turret-narrow"] = "photon-turret",
		["copper-aetheric-lamp-straight"] = "copper-aetheric-lamp-end",
		["copper-aetheric-lamp-end"] = "copper-aetheric-lamp-straight",
		["iron-battery-discharger"] = "iron-battery-discharger-active",
		["iron-battery-discharger-active"] = "iron-battery-discharger",
		["steel-battery-discharger"] = "steel-battery-discharger-active",
		["steel-battery-discharger-active"] = "steel-battery-discharger",
		["ingot-cast"] = "plate-cast",
		["plate-cast"] = "rod-cast",
		["rod-cast"] = "gear-wheel-cast",
		["gear-wheel-cast"] = "ingot-cast",
		["barrelling-machine"] = "unbarrelling-machine",
		["unbarrelling-machine"] = "barrelling-machine",
		["steam-barrelling-machine"] = "steam-unbarrelling-machine",
		["steam-unbarrelling-machine"] = "steam-barrelling-machine",
		["valve"] = "valve-overflow",
		["valve-overflow"] = "valve-underflow",
		["valve-underflow"] = "valve",
		["air-valve"] = "air-valve-overflow",
		["air-valve-overflow"] = "air-valve-underflow",
		["air-valve-underflow"] = "air-valve",
		["steam-valve"] = "steam-valve-overflow",
		["steam-valve-overflow"] = "steam-valve-underflow",
		["steam-valve-underflow"] = "steam-valve",
		["copper-valve"] = "copper-valve-overflow",
		["copper-valve-overflow"] = "copper-valve-underflow",
		["copper-valve-underflow"] = "copper-valve",
		["rocket-turret"] = "rocket-turret-all",
		["rocket-turret-all"] = "rocket-turret",
	},
	properties = {
		-- per type
		["ammo-turret"] = {"last_user","health","kills","damage_dealt"},
		["electric-turret"] = {"last_user","health","energy","kills","damage_dealt"},
		["assembling-machine"] = {"last_user","health","energy","products_finished"},
		["furnace"] = {"last_user","health","energy","products_finished"},
		["burner-generator"] = {"last_user","health","energy"},
		["simple-entity-with-owner"] = {"last_user","health"},
		["storage-tank"] = {"last_user","health"},
	},
	sounds = {
		-- per name - otherwise uses default ye olde inserter squeak
		["photon-turret"] = "deactivate-heavy",
		["photon-turret-narrow"] = "activate-heavy",
		["rocket-turret"] = "deactivate-heavy",
		["rocket-turret-all"] = "activate-heavy",
	},
	rotate_to_pipes = {
		-- per name
		["copper-aetheric-lamp-end"] = true,
	},
}
  
-- CONTROL.non_autoplaced_ores = {}
-- for ore,oredata in pairs(CONTROL.orefields) do
	-- if oredata.group then CONTROL.non_autoplaced_ores[ore] = true end
-- end

-- CONTROL.weighted_ore_groups = {}
-- for group,weight in pairs(CONTROL.orefield_groups) do
	-- for i=1,weight do table.insert(CONTROL.weighted_ore_groups, group) end
-- end

-- CONTROL.ores_by_group = {}
-- for ore,oredata in pairs(CONTROL.orefields) do
	-- if oredata.group then
		-- if CONTROL.ores_by_group[oredata.group] == nil then CONTROL.ores_by_group[oredata.group] = {} end
		-- table.insert(CONTROL.ores_by_group[oredata.group], ore)
	-- end
-- end
  
------------------------------------------------------------------------------------------------------------------------------------------------------

-- "global" player data

function CONTROL.get_player_global(player_index,info)
	if global.players == nil then global.players = {} end
	if global.players[player_index] == nil then global.players[player_index] = {} end
	return global.players[player_index][info]
end

function CONTROL.set_player_global(player_index,info,value)
	if global.players == nil then global.players = {} end
	if global.players[player_index] == nil then global.players[player_index] = {} end
	global.players[player_index][info] = value
end

-- "global" surface data

function CONTROL.get_surface_global(surface_index,info)
	if global.surfaces == nil then global.surfaces = {} end
	if global.surfaces[surface_index] == nil then global.surfaces[surface_index] = {} end
	return global.surfaces[surface_index][info]
end

function CONTROL.set_surface_global(surface_index,info,value)
	if global.surfaces == nil then global.surfaces = {} end
	if global.surfaces[surface_index] == nil then global.surfaces[surface_index] = {} end
	global.surfaces[surface_index][info] = value
end

------------------------------------------------------------------------------------------------------------------------------------------------------
