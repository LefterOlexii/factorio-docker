------------------------------------------------------------------------------------------------------------------------------------------------------

-- general gui sprites

data:extend({
	{
		type = "sound",
		name = "fuelman-inventory",
		variations = {
			{
				filename = DIR.sound_path .. "/fuelman-inventory.ogg",
				volume = 1
			},
			{
				filename = DIR.sound_path .. "/fuelman-inventory-2.ogg",
				volume = 1
			},
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "fuelman-warning",
		variations = {
			filename = DIR.sound_path .. "/fuelman-warning.ogg",
			volume = 0.9,
			min_speed = 0.975,
			max_speed = 1.025,
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "inserter-squeak",
		variations = {
			filename = DIR.sound_path .. "/squeak.ogg",
			volume = 1
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "activate",
		variations = {
			filename = DIR.sound_path .. "/activate.ogg",
			volume = 1
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "deactivate",
		variations = {
			filename = DIR.sound_path .. "/deactivate.ogg",
			volume = 1
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "activate-heavy",
		variations = {
			filename = DIR.sound_path .. "/activate-heavy.ogg",
			volume = 0.75
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "deactivate-heavy",
		variations = {
			filename = DIR.sound_path .. "/deactivate-heavy.ogg",
			volume = 0.75
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "transmat-activate",
		variations = {
			filename = DIR.sound_path .. "/transmat-activate.ogg",
			volume = 0.5,
			min_speed = 0.975,
			max_speed = 1.025,
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-error",
		variations = {
			filename = DIR.sound_path .. "/error.ogg",
			volume = 1
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "transmat-spinup",
		variations = {
			filename = DIR.sound_path .. "/transmat-spinup.ogg",
			volume = 1
		},
		audible_distance_modifier = 1,
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-spindown",
		variations = {
			filename = DIR.sound_path .. "/transmat-spindown.ogg",
			volume = 1
		},
		audible_distance_modifier = 1,
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-spinup",
		variations = {
			filename = DIR.sound_path .. "/transmat-spinup.ogg",
			volume = 1
		},
		audible_distance_modifier = 1,
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-energiser-slide",
		variations = {
			filename = DIR.sound_path .. "/energiser-slide.ogg",
			volume = 1
		},
		audible_distance_modifier = 1,
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-whoosh",
		variations = {
			filename = DIR.sound_path .. "/transmat-air-whoosh.ogg",
			min_speed = 0.975,
			max_speed = 1.025,
			volume = 1
		},
		audible_distance_modifier = 1,
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-note-high",
		variations = {
			filename = DIR.sound_path .. "/transmat-spang-high.ogg",
			volume = 1
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "transmat-note-low",
		variations = {
			filename = DIR.sound_path .. "/transmat-spang.ogg",
			volume = 1
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "klaxon",
		variations = {
			filename = DIR.sound_path .. "/klaxon.ogg",
			volume = 1
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "suck",
		variations = {
			{
				filename = DIR.sound_path .. "/whoosh-1.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				audible_distance_modifier = 0.5,
				volume = 1
			},
			{
				filename = DIR.sound_path .. "/whoosh-2.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				audible_distance_modifier = 0.5,
				volume = 1
			},
			{
				filename = DIR.sound_path .. "/whoosh-3.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				audible_distance_modifier = 0.5,
				volume = 1
			},
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "emp-hit",
		audible_distance_modifier = 1.25,
		allow_random_repeat = true,
		variations = {
			{
				filename = DIR.sound_path.."/thunderclap1.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				volume = 1
			},
			{
				filename = DIR.sound_path.."/thunderclap2.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				volume = 1
			},
			{
				filename = DIR.sound_path.."/thunderclap3.ogg",
				min_speed = 0.975,
				max_speed = 1.025,
				volume = 1
			},
		},
		category = "environment",
	},
	{
		type = "sound",
		name = "map-marker-ping",
		variations = {
			filename = DIR.sound_path.."/ping.ogg",
			volume = 0.95
		},
		category = "gui-effect",
	},
	{
		type = "sound",
		name = "map-marker-pong",
		variations = {
			filename = DIR.sound_path.."/pong.ogg",
			volume = 0.95
		},
		category = "gui-effect",
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------
