------------------------------------------------------------------------------------------------------------------------------------------------------

-- 3.1.5: Update vanilla construction shortcuts
-- See issue #283

local ctechs = {
	["construction-robotics"] = true,
	["personal-roboport-equipment"] = true,
}

for _,shortcut in pairs(data.raw.shortcut) do
	if shortcut.technology_to_unlock and ctechs[shortcut.technology_to_unlock] then
		shortcut.technology_to_unlock = nil
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- entity adjustment

data:extend({
    {
        type = "custom-input",
        name = "ir-entity-adjustment",
        key_sequence = "SHIFT + E",
    },
    {
        type = "custom-input",
        name = "ir-open-gui",
		linked_game_control = "open-gui",
		key_sequence = "",
    },
    {
        type = "custom-input",
        name = "ir-increase",
		linked_game_control = "larger-terrain-building-area",
		key_sequence = "",
    },
    {
        type = "custom-input",
        name = "ir-decrease",
		linked_game_control = "smaller-terrain-building-area",
		key_sequence = "",
    },
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- fuel manager

data:extend({
    {
        type = "custom-input",
        name = "ir-control-fuel-manager",
        key_sequence = "CONTROL + G",
    },
    {
        name = "ir-fuel-manager",
        type = "shortcut",
        toggleable = true,
        action = "lua",
        associated_control_input = "ir-control-fuel-manager",
        icon = {
            filename = DIR.get_icon_path("fuel-manager-black-32",32),
            priority = "extra-high-no-scale",
            size = 32,
            scale = 1,
            flags = {"icon"}
        },
        disabled_icon = {
            filename = DIR.get_icon_path("fuel-manager-white-32",32),
            priority = "extra-high-no-scale",
            size = 32,
            scale = 1,
            flags = {"icon"}
        },
        small_icon = {
            filename = DIR.get_icon_path("fuel-manager-black-24",24),
            priority = "extra-high-no-scale",
            size = 24,
            scale = 1,
            flags = {"icon"}
        },
        disabled_small_icon = {
            filename = DIR.get_icon_path("fuel-manager-white-24",24),
            priority = "extra-high-no-scale",
            size = 24,
            scale = 1,
            flags = {"icon"}
        },
    }
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- manifesto

data:extend({
	{
		type = "custom-input",
		name = "ir-manifesto",
		key_sequence = "I",
	},
	{
		name = "ir-manifesto",
		type = "shortcut",
		toggleable = false,
		action = "lua",
		associated_control_input = "ir-manifesto",
		style = "blue",
		icon = {
			filename = DIR.get_icon_path("manifesto-32",32),
			priority = "extra-high-no-scale",
			size = 32,
			scale = 1,
			flags = {"icon"}
		},
		disabled_icon = {
			filename = DIR.get_icon_path("manifesto-32",32),
			priority = "extra-high-no-scale",
			size = 32,
			scale = 1,
			flags = {"icon"}
		},
		small_icon = {
			filename = DIR.get_icon_path("manifesto-24",24),
			priority = "extra-high-no-scale",
			size = 24,
			scale = 1,
			flags = {"icon"}
		},
		disabled_small_icon = {
			filename = DIR.get_icon_path("manifesto-24",24),
			priority = "extra-high-no-scale",
			size = 24,
			scale = 1,
			flags = {"icon"}
		},
	}
})

------------------------------------------------------------------------------------------------------------------------------------------------------

