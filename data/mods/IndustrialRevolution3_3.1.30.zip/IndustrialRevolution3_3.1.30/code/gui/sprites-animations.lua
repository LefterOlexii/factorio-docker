------------------------------------------------------------------------------------------------------------------------------------------------------

-- general gui sprites

data:extend(
    {
        {
            type = "sprite",
            name = "fuel-manager",
            filename = DIR.get_icon_path("fuel-manager-white-32", 32),
            priority = "extra-high",
            width = 32,
            height = 32,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "edit-button",
            filename = DIR.get_icon_path("edit-32", 32),
            priority = "extra-high",
            width = 32,
            height = 32,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "edit-button-black",
            filename = DIR.get_icon_path("edit-black-32", 32),
            priority = "extra-high",
            width = 32,
            height = 32,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "edit-inline",
            filename = DIR.get_icon_path("edit-32x64", 32),
            priority = "extra-high",
            width = 32,
            height = 64,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "help-button",
            filename = DIR.get_icon_path("help-32", 32),
            priority = "extra-high",
            width = 32,
            height = 32,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "help-button-black",
            filename = DIR.get_icon_path("help-black-32", 32),
            priority = "extra-high",
            width = 32,
            height = 32,
            flags = {"gui-icon"}
        },
        {
            type = "sprite",
            name = "warning-fuel-red",
            filename = DIR.get_icon_path("warning-fuel-red"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "warning-fuel-yellow",
            filename = DIR.get_icon_path("warning-fuel-yellow"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "warning-inventory",
            filename = DIR.get_icon_path("warning-inventory"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "warning-pollution",
            filename = DIR.get_icon_path("warning-pollution"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "bronze-bullet",
            filename = DIR.get_icon_path("bronze-bullet",32),
            priority = "extra-high",
            flags = {"gui-icon"},
            width = 32,
            height = 64,
        },
        {
            type = "sprite",
            name = "plus-bullet",
            filename = DIR.get_icon_path("plus-bullet",32),
            priority = "extra-high",
            flags = {"gui-icon"},
            width = 32,
            height = 64,
        },
        {
            type = "sprite",
            name = "manifesto",
            filename = DIR.get_icon_path("manifesto"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "ir-fissures",
            filename = DIR.get_icon_path("generic-fissure"),
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
            mipmap_count = 4
        },
        {
            type = "sprite",
            name = "selection-box",
            filename = "__core__/graphics/cursor-boxes-32x32.png",
            priority = "extra-high",
            flags = {"icon"},
            width = 64,
            height = 64,
        },
        {
            type = "sprite",
            name = "tooltip-category-battery",
            filename = DIR.get_icon_path("tooltip-category-battery", 40),
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-barrel",
            filename = DIR.get_icon_path("tooltip-category-barrel", 40),
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-canister",
            filename = DIR.get_icon_path("tooltip-category-canister", 40),
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-fluid",
            filename = DIR.get_icon_path("tooltip-category-fluid", 40),
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-natural-gas",
            filename = DIR.get_icon_path("tooltip-category-fluid", 40),
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-steam-cell",
            filename = "__base__/graphics/icons/tooltips/tooltip-category-steam.png",
			mipmap_count = 2,
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
        {
            type = "sprite",
            name = "tooltip-category-coke",
            filename = "__base__/graphics/icons/tooltips/tooltip-category-chemical.png",
            priority = "extra-high-no-scale",
            width = 40,
            height = 40,
			mipmap_count = 2,
            flags = {"gui-icon"},
            scale = 0.5
        },
		{
			name = "pollution-warning-animation",
			type = "animation",
			animation_speed = 1/30,
			stripes = {
				{
					width_in_frames = 1,
					height_in_frames = 1,
					filename = DIR.get_icon_path("warning-pollution"),
				},
				{
					width_in_frames = 1,
					height_in_frames = 1,
					filename = DIR.get_icon_path("blank"),
				},
			},
			frame_count = 2,
			height = DIR.icon_size,
			width = DIR.icon_size,
			scale = 0.5,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "map-marker",
			filename = DIR.get_icon_path("map-marker-32",32),
			priority = "extra-high",
			width = 32,
			height = 32,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "map-marker-black",
			filename = DIR.get_icon_path("map-marker-black-32",32),
			priority = "extra-high",
			width = 32,
			height = 32,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "map-marker-inline",
			filename = DIR.get_icon_path("map-marker-32x64",32),
			priority = "extra-high",
			width = 32,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "updated-info",
			filename = DIR.get_icon_path("updated-info",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "peace",
			filename = DIR.get_icon_path("peace",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "transfer-plate-1",
			filename = DIR.get_icon_path("transfer-plate-example-1",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "transfer-plate-2",
			filename = DIR.get_icon_path("transfer-plate-example-2",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "transfer-plate-3",
			filename = DIR.get_icon_path("transfer-plate-example-3",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "stone-wall-vanilla",
			filename = "__base__/graphics/icons/wall.png",
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "stone-wall-ir3",
			filename = DIR.get_icon_path("stone-wall",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "inserter-overlay-off",
			filename = DIR.get_icon_path("burner-inserter",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "inserter-overlay-on",
			filename = DIR.get_icon_path("inserter-overlay-on",64),
			priority = "extra-high",
			width = 64,
			height = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		},
		{
			type = "sprite",
			name = "slot-filters",
			filename = DIR.gui_images_path.."/slot-filters.png",
			priority = "extra-high",
			width = 80,
			height = 26,
			flags = {"gui-icon"},
		},
    }
)

for hue, h in pairs(DIR.hues) do
    data:extend(
        {
            {
                type = "sprite",
                name = "colour-" .. hue,
                filename = DIR.get_icon_path("square-white"),
                tint = DIR.hsva2rgba(h, DIR.get_saturation(h,1), 1),
                priority = "extra-high",
				flags = {"gui-icon"},
                width = 64,
                height = 64,
                mipmap_count = 4
            }
        }
    )
end

data:extend({
	{
		type = "sprite",
		name = "colour-belt-vanilla",
		filename = DIR.get_icon_path("square-white"),
		tint = data.raw["utility-constants"]["default"].chart.default_friendly_color_by_type["transport-belt"],
		priority = "extra-high",
		flags = {"gui-icon"},
		width = 64,
		height = 64,
		mipmap_count = 4
	},
	{
		type = "sprite",
		name = "colour-belt-tiers",
		filename = DIR.get_icon_path("square-belts"),
		priority = "extra-high",
		flags = {"gui-icon"},
		width = 64,
		height = 64,
		mipmap_count = 4
	}
})

------------------------------------------------------------------------------------------------------------------------------------------------------
