------------------------------------------------------------------------------------------------------------------------------------------------------

-- Set up Manifesto / Informatron images

local images = {
	ir_fuelman = {
		path = DIR.doc_images_path .. "/fuel-manager.png",
		width = 529,
		height = 192
	},
	ir_transmats = {
		path = DIR.doc_images_path .. "/transmats.png",
		width = 1200,
		height = 500
	},
}

for image, imagedata in pairs(images) do
	data:extend({
		{
			type = "sprite",
			name = "help-image-"..image,
			height = imagedata.height,
			width = imagedata.width,
			filename = imagedata.path,
			scale = 1,
			flags = {"gui"},
			priority = "extra-high",
		},
	})
	data.raw["gui-style"]["default"]["help-image-"..image] = {
		type = "image_style",
		width = imagedata.width/2,
		height = imagedata.height/2,
		padding = 0,
		margin = 0,
	}
end
	
------------------------------------------------------------------------------------------------------------------------------------------------------
