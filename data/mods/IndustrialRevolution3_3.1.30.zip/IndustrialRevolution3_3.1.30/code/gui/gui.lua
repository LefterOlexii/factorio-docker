------------------------------------------------------------------------------------------------------------------------------------------------------

-- fonts

data:extend({{
	type = "font",
	from = "default-bold",
	name = "notification-bold",
	border = true,
	border_color = {},
	size = 14
}})


------------------------------------------------------------------------------------------------------------------------------------------------------

-- utility constant adjustments

data.raw["utility-constants"]["default"].item_outline_radius = 6
data.raw["utility-constants"]["default"].item_outline_color = {0, 0, 0, 0.75}
data.raw["utility-constants"]["default"].disabled_recipe_slot_tint = {1, 1, 1, 1}

if data.raw["gui-style"]["default"]["inventory_slot"] then
	data.raw["gui-style"]["default"]["inventory_slot"].draw_shadow_under_picture = true
end

if data.raw["gui-style"]["default"]["filter_group_tab"] then
	data.raw["gui-style"]["default"]["filter_group_tab"].minimal_width = 48
	data.raw["gui-style"]["default"]["filter_group_tab"].height = 64
	local bx = 52
	local by = 52
	local spacing = 24
	data.raw["gui-style"]["default"]["filter_group_button_tab"].size = {bx, by}
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_horizontal_size = bx-spacing
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_vertical_size = by-spacing
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_horizontal_spacing = spacing
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_vertical_spacing = spacing
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_horizontal_padding = spacing/2
	data.raw["gui-style"]["default"]["filter_group_table"].background_graphical_set.overall_tiling_vertical_padding = spacing/2
	data.raw["utility-constants"]["default"].select_group_row_count = 8
    data.raw["utility-constants"]["default"].select_slot_row_count = DIR.slot_row_count or 10
    -- data.raw["utility-constants"]["default"].inventory_width = 12
end

if data.raw["utility-constants"]["default"]["ghost_tint"] then
	local h = DIR.hues[settings.startup["ir-ghost-tint"].value]
	data.raw["utility-constants"]["default"]["ghost_tint"] = DIR.hsva2rgba(h, DIR.get_saturation(h,0.5), 0.6, 0.3)
end

-- 3.1.3 - railblock icons now generated externally in python because of shenanigans with sprite composition in rich text

local blockset = settings.startup["ir-rail-blocks"].value

for _,set in pairs({"ir","old","new"}) do
	data:extend({
		{
			type = "sprite",
			name = "rail-block-colour-" .. set,
			filename = DIR.get_icon_path("rail-block-colour-" .. set),
			size = 64,
			mipmap_count = 4,
			flags = {"gui-icon"},
		}
	})
end

-- override hardcoded status "lamps" for entity guis

local sprites = {
    ["status_working"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-working"].value], 1, 1),
    ["status_not_working"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-disabled"].value], 1, 1),
    ["status_yellow"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-low-power"].value], 1, 1)
}

for sprite, tint in pairs(sprites) do
    data.raw["utility-sprites"]["default"][sprite] = {
        layers = {
            {
                filename = DIR.get_icon_path("status-lamp-tint", 32),
                size = {32, 32},
                scale = 0.5,
                flags = {"gui-icon"},
                tint = tint
            },
            {
                filename = DIR.get_icon_path("status-lamp-white", 32),
                size = {32, 32},
                scale = 0.5,
                flags = {"gui-icon"}
            }
        }
    }
end

-- custom status "lamps" for transmat gui

local sprites = {
    ["transmat-ready"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-working"].value], 1, 1),
    ["transmat-busy"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-full-output"].value], 1, 1),
    ["transmat-lowenergy"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-low-power"].value], 1, 1),
    ["transmat-error"] = DIR.hsva2rgba(DIR.hues[settings.startup["ir-status-disabled"].value], 1, 1)
}

for sprite, tint in pairs(sprites) do
    data:extend(
        {
            {
                type = "sprite",
                name = sprite,
                layers = {
                    {
                        filename = DIR.get_icon_path("status-lamp-tint", 32),
                        size = {32, 32},
                        scale = 0.5,
                        flags = {"gui-icon"},
                        tint = tint
                    },
                    {
                        filename = DIR.get_icon_path("status-lamp-white", 32),
                        size = {32, 32},
                        scale = 0.5,
                        flags = {"gui-icon"}
                    }
                },
                size = {32, 32},
                scale = 0.5,
                flags = {"gui-icon"}
            }
        }
    )
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- styles

local function add_styles(styles)
    local default_styles = data.raw["gui-style"]["default"]
    for name, style in pairs(styles) do
        default_styles[name] = style
    end
end

add_styles({
	transmat_frame = {
		type = "frame_style",
		parent = "frame",
		left_padding = 6,
		right_padding = 6,
		bottom_padding = 6,
		top_padding = 6,
		vertical_flow_style = {
			type = "vertical_flow_style",
			vertical_spacing = 0,
			horizontal_align = "center"
		},
	},
	transmat_deep_frame = {
		type = "frame_style",
		parent = "inside_deep_frame",
		vertical_flow_style = {
			type = "vertical_flow_style",
			vertical_spacing = 0,
			horizontal_align = "center"
		},
		padding = 0
	},
	transmat_bare_frame = {
		type = "frame_style",
		graphical_set = {},
		vertical_flow_style = {
			type = "vertical_flow_style",
			vertical_spacing = 0,
			horizontal_align = "center"
		},
		padding = 0
	},
	transmat_bare_table = {
		type = "table_style",
		horizontal_spacing = 0,
		vertical_spacing = 0,
		padding = 0,
		margin = 0
	},
	transmat_small_button = {
		type = "button_style",
		parent = "frame_action_button",
		left_margin = 1,
		right_margin = 1
	},
	transmat_small_button_active = {
		type = "button_style",
		parent = "transmat_small_button",
		default_graphical_set = data.raw["gui-style"]["default"]["frame_button"].clicked_graphical_set
	},
	transmat_header_icon = {
		type = "image_style",
		vertically_stretchable = "on",
		horizontally_stretchable = "off",
		stretch_image_to_widget_size = true,
		horizontal_align = "left"
	},
	transmat_energy_bar = {
		type = "progressbar_style",
		bar_width = 16,
		width = 48,
		height = 16,
		color = {g = 1},
		other_colors = {
			{less_than = DIR.transmat_cost / DIR.transmat_buffer_joules, color = {r = 1}}
		}
	},
	transmat_list_box = {
		type = "list_box_style",
		scroll_pane_style = {
			type = "scroll_pane_style",
			parent = "list_box_scroll_pane"
		},
		item_style = {
			type = "button_style",
			parent = "list_box_item",
			horizontal_align = "left",
			font = "default-semibold",
			default_font_color = {255, 230, 192},
			clicked_font_color = {0,0,0},
		}
	},
	transmat_green_button = {
		type = "button_style",
		parent = "green_button",
		tooltip = "",
		disabled_graphical_set = data.raw["gui-style"]["default"]["button"].disabled_graphical_set,
		disabled_font_color = data.raw["gui-style"]["default"]["button"].disabled_font_color,
	},
	notification_deep_frame = {
		type = "frame_style",
		parent = "inside_deep_frame",
		vertical_flow_style = {
			type = "vertical_flow_style",
			vertical_spacing = 0,
			vertical_align = "center",
			vertically_stretchable = "on",
		},
		padding = 0
	},
	inner_hard_shadow_frame = {
		type = "frame_style",
		vertical_flow_style = {
			type = "vertical_flow_style",
			vertical_spacing = 0,
			vertical_align = "center",
			vertically_stretchable = "on",
		},
		padding = 0,
		graphical_set = {
			shadow = {
				filename = DIR.gui_images_path.."/inner-border.png",
				position = {0,0},
				corner_size = 32,
				scale = 0.5,
				draw_type = "inner"
			}
		},
	},
	manifesto_paragraph = {
		type = "label_style",
		single_line = false,
		bottom_margin = 8,
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------
