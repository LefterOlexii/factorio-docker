------------------------------------------------------------------------------------------------------------------------------------------------------

-- CHEEVMENTS
-- nope

------------------------------------------------------------------------------------------------------------------------------------------------------

local cheevments = {
	["dont-craft-manually-achievement"] = {"lazy-bastard"},
	["dont-use-entity-in-energy-production-achievement"] = {"solaris","steam-all-the-way"},
	["produce-per-hour-achievement"] = {"iron-throne-1","iron-throne-2","iron-throne-3"},
	["research-achievement"] = {"eco-unfriendly"},
}

for ptype,prototypes in pairs(cheevments) do
	for _,prototype in pairs(prototypes) do
		if data.raw[ptype][prototype] then data.raw[ptype][prototype].hidden = true
		else DIR.spam_log("Achievement "..prototype.." not found", DIR.log_level.warning)
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
