------------------------------------------------------------------------------------------------------------------------------------------------------

-- GLOBAL VARIABLES AND FUNCTIONS

DIR = DIR or {}
DIR.IR = "IndustrialRevolution3"
DIR.IR_short = "IR3"
DIR.IR_path = "__"..DIR.IR.."__"

require(DIR.IR_path.."/code/functions/functions-data")

------------------------------------------------------------------------------------------------------------------------------------------------------

-- debugging

DIR.dump_recipe_icons = false
DIR.dump_vanilla_techs = false
DIR.show_item_scrap = (settings.startup["ir-scrap-localisation"].value == "yes")

DIR.log = {
	[DIR.log_level.debug] = false,
	[DIR.log_level.milestone] = false,
	[DIR.log_level.notice] = true,
	[DIR.log_level.warning] = true,
	[DIR.log_level.error] = true,
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- graphics paths and sizes

DIR.technologies = require(DIR.IR_path.."/code/data/backbone-tech")
DIR.vanilla_techs = require(DIR.IR_path.."/code/data/vanilla-tech")
DIR.vanilla_sounds = require("__base__/prototypes/entity/sounds")
DIR.anim_speed = 0.75
DIR.icon_size = 64
DIR.icon_mipmaps = 4
DIR.high_icon_size = 256
DIR.high_icon_mipmaps = 4
DIR.vanilla_tech_icon_size = 256
DIR.vanilla_tech_icon_mipmaps = 4
DIR.slot_row_count = 10
DIR.icon_path = "__"..DIR.IR.."Assets1__/graphics/icons"
DIR.entities_path_1 = "__"..DIR.IR.."Assets1__/graphics/entities"
DIR.entities_path_2 = "__"..DIR.IR.."Assets2__/graphics/entities"
DIR.entities_path_3 = "__"..DIR.IR.."Assets3__/graphics/entities"
DIR.entities_path_4 = "__"..DIR.IR.."Assets4__/graphics/entities"
DIR.resource_path = DIR.entities_path_2.."/resources"
DIR.projectiles_path = DIR.entities_path_2.."/projectiles"
DIR.particles_path = DIR.entities_path_2.."/particles"
DIR.doc_images_path = "__"..DIR.IR.."__/graphics/images"
DIR.gui_images_path = "__"..DIR.IR.."__/graphics/gui"
DIR.sound_path = "__"..DIR.IR.."Assets1__/sound"
DIR.base_icons_path = "__base__/graphics/icons"
DIR.base_sound_path = "__base__/sound"
DIR.core_sound_path = "__core__/sound"
DIR.core_graphics_path = "__core__/graphics"
DIR.core_constant_icons_path = "__core__/graphics/icons/technology/effect-constant"
DIR.sprite_paths_lookup = {
	["assemblers"] = DIR.entities_path_1,
	["bots"] = DIR.entities_path_2,
	["inserters"] = DIR.entities_path_2,
	["particles"] = DIR.entities_path_2,
	["pipes"] = DIR.entities_path_2,
	["projectiles"] = DIR.entities_path_2,
	["resources"] = DIR.entities_path_2,
	["tiles"] = DIR.entities_path_2,
	["vehicles"] = DIR.entities_path_2,
	["walls"] = DIR.entities_path_2,
	["furnaces"] = DIR.entities_path_2,
	["grinders"] = DIR.entities_path_2,
	["washers"] = DIR.entities_path_2,
	["decorative"] = DIR.entities_path_3,
	["fluids"] = DIR.entities_path_3,
	["forestry"] = DIR.entities_path_3,
	["misc"] = DIR.entities_path_3,
	["power"] = DIR.entities_path_3,
	["storage"] = DIR.entities_path_3,
	["turrets"] = DIR.entities_path_3,
	["drills"] = DIR.entities_path_4,
	["labs"] = DIR.entities_path_4,	
}
DIR.pipe_front_patch_cut = 92
DIR.patchable_pipe_sprites = {
	["vw"] = DIR.pipe_front_patch_cut,
	["vw"] = DIR.pipe_front_patch_cut,
	["te"] = DIR.pipe_front_patch_cut,
	["tw"] = DIR.pipe_front_patch_cut,
	["ts"] = DIR.pipe_front_patch_cut,
	["sw"] = DIR.pipe_front_patch_cut,
	["se"] = DIR.pipe_front_patch_cut,
	["en"] = DIR.pipe_front_patch_cut,
	["x"] = DIR.pipe_front_patch_cut,
}
DIR.vanilla_polluting_fluids = require(DIR.IR_path.."/code/data/polluting-fluids")
DIR.belt_brightness_variation = 0.1 -- maximum darkness
DIR.belt_brightness_variation_steps = 4 -- steps to maximum

------------------------------------------------------------------------------------------------------------------------------------------------------

-- graphics flags

DIR.recommended_sprite_flags = (settings.startup["ir-trilinear-filtering"].value ~= "none") and {"trilinear-filtering"} or nil
DIR.general_sprite_flags = (settings.startup["ir-trilinear-filtering"].value == "all") and {"trilinear-filtering"} or nil

------------------------------------------------------------------------------------------------------------------------------------------------------

-- misc constants

-- recipes in subgroups in these item groups will have hide_from_player_crafting set in data-final-fixes
-- this stops the recipe appearing in player crafting menu but still shows it in machines

DIR.hidden_item_groups = {"ir-reclamation","ir-lighting"}

-- progression of science pack costs based on tree depth

DIR.technology_costs = {
	10,20,30,40,50,
	75,100,125,150,175,
	200,250,300,350,400,
	500,600,700,800,900,
	1000,1100,1200,1300,1400,
	1500,1750,2000,2250,2500
}

-- technologies with a tree depth beyond the range of the table above will have cost calculated as
-- the last entry in the table above + (this value * each additional level)

DIR.technology_cost_beyond_max_depth = 500

-- terrain-related constants (e.g. rubber tree and gem rock exclusion zone)

DIR.starting_area_clearing_radius = 300
DIR.starting_area_clearing_border = 150

------------------------------------------------------------------------------------------------------------------------------------------------------

-- technology lists/caches, populated in the data-updates tech pass

DIR.ancestors = {}
DIR.scrappable_recipes = {}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- GENERATED BASICS

-- crafting, speed ratios, belt speeds, energy usage

DIR.scale_steam_machine_fluid_usage = true
DIR.default_belt_speed = 15 -- yellow belt items/s
DIR.base_energy_unit = 4 -- MJ
DIR.belt_energy_value = DIR.base_energy_unit * DIR.default_belt_speed -- MW
DIR.machines_per_belt = 12 -- how many furnaces/assemblers should saturate a yellow belt at speed 1 with a recipe speed of 1
DIR.machine_to_belt_ratio = DIR.machines_per_belt / DIR.default_belt_speed -- with default numbers, 0.8
DIR.standard_crafting_time = 1
DIR.smelting_to_crafting_ratio = 4
DIR.standard_smelting_time = DIR.standard_crafting_time * DIR.smelting_to_crafting_ratio
DIR.standard_petro_time = DIR.standard_crafting_time * 6
DIR.standard_inserter_rotation = 1/60 -- burner/yellow inserter speed
DIR.standard_inserter_extension = DIR.standard_inserter_rotation * 2.5
DIR.clusters_per_energy_belt = 10 -- how many "arrays of machines_per_belt" uses up one "energy belt" (a yellow belt full of coal) at crafting speed 1
DIR.washing_base = 10 -- how much fluid is used in washing recipes
DIR.washers_to_cleaners = 6 -- number of washers dealt with by 1 cleaner
DIR.washing_ratio = 5/6 -- proportion of water reclaimed from dirty water filtering
DIR.standard_drain = 0.04 -- percentage of energy use drained when typical machines are inactive
DIR.max_tiers = 3 -- highest material tier
DIR.default_stack_size = 100
DIR.max_scrap_types = 8 -- output slots on electric scrapper, also caps material types per scrapped item
DIR.scrap_minimum_rate = 0.5 -- the proportion of scrap that is guaranteed to be returned - average amount is halfway between this and 100%
DIR.scrap_divider = 1 -- how many ingots is 1 scrap worth (was higher when a lootable scrap was a thing)
DIR.molten_to_ingot_ratio = 10 -- how many units of molten liquid is a basic metal unit
DIR.arc_furnace_raw_multiplier = 3 -- the ratio of minerals to ingots when oxygen is used
DIR.gas_per_ingot = 5 -- ratio of gas to solid in blast/arc furnace processes
DIR.drills_per_belt = 12 -- how many drills saturate a belt of equivalent tier (copper drill = yellow belt, electric = red, chrome = blue)
DIR.basic_drill_speed = DIR.default_belt_speed / DIR.drills_per_belt -- matching drill tiers to belt tiers
DIR.base_research_time = 60 -- the basic multiplier of research time in seconds
DIR.default_crafting_speed = 1 -- any vanilla item that doesn't specify a crafting time is treated as if the recipe specified this multiple of standard time (instead of game default 0.5s)
DIR.standard_pickup_time = 0.2 -- "mining" pickup time in s for IR machines
DIR.transmat_buffer_joules = 240 * 10^6 -- joules
DIR.transmat_cost = 200 * 10^6 -- joules
DIR.transmat_charge_rate = math.ceil(DIR.transmat_buffer_joules/30) -- watts
DIR.arc_turret_shooting_speed = 240 -- ticks
DIR.arc_turret_jump_distance = 4 -- range of arc turret slowdown AOE
DIR.arc_turret_max_range = 21
DIR.arc_turret_min_range = 7
DIR.glow_recipe_count = 20 -- number of hues for aetheric lamps (19 colours from around the HSV wheel + 1 white)
DIR.hydrogen_energy_value_MJ = 0.4 -- MJ per hydrogen unit (and all other liquid/gas hydrocarbons that are directly burnable)
DIR.hydrogen_to_base_energy_unit = DIR.base_energy_unit / DIR.hydrogen_energy_value_MJ -- how much hydrogen is energy equivalent to 1 standard energy unit (1 coal)
DIR.hydrogen_component_fuel_modifier = 1 / DIR.hydrogen_to_base_energy_unit
DIR.hydrogen_cell_MJ = 40
DIR.hydrogen_in_cell = (DIR.hydrogen_cell_MJ / DIR.hydrogen_energy_value_MJ) * 3 -- hydrogen has more energy than methane by mass, but a third of it by volume
DIR.fluid_in_barrels = 60
DIR.liquified_gas_ratio = 0.25
DIR.laser_coolant_amount = 2.5
DIR.inert_gas_amount = 20
DIR.max_forestry_trees = 50
DIR.forestry_fluid_minimum = 15
DIR.rubber_tree_map_colour = {r=80,g=100,b=10,a=255}
DIR.plantable_trees = {"tree-01","tree-02","tree-03","tree-04","tree-05","tree-07","tree-09","ir-rubber-tree"}
DIR.chemical_pollution_rate = DIR.get_standard_emissions(4) -- pollution/minute
DIR.voiding_per_cycle = 20
DIR.standard_voiding_time = 1
DIR.plating_solution_amount = 10
DIR.standard_cleaning_emissions = DIR.get_standard_emissions(-10)
DIR.refinery_power = 3
DIR.chemplant_power = 2
DIR.gas_amount_in_canisters = 80
DIR.delivery_plate_radius = 9.5
DIR.low_priority_target_health = 200 -- vanilla big spitters have 200, big biters have 375
DIR.vehicle_fuel_modifier_tiers = {
	copper = {
		acceleration = 1.15,
		top_speed = 1,
	},
	iron = {
		acceleration = 1.2,
		top_speed = 1.05,
	},
	steel = {
		acceleration = 1.25,
		top_speed = 1.10,
	},
    hydrogen = {
		acceleration = 1.5,
		top_speed = 1.15,
	},
	chromium = {
		acceleration = 1.8,
		top_speed = 1.15,
	},
}

-- tables which need loading after constants

DIR.machines = require(DIR.IR_path.."/code/data/machines")

-- named material hues - used by ammo and some crafting/status tints - names must not be a substring of other hues

DIR.hues = {
	red = 1, -- we use 1 to mean red and 0 to mean white/grey
	orange = 1/12,
	yellow = 2/12,
	lime = 3/12,
	green = 4/12,
	teal = 5/12,
	cyan = 6/12,
	azure = 7/12,
	blue = 8/12,
	violet = 9/12,
	magenta = 10/12,
	pink = 11/12,
	greyscale = 0,
}

DIR.tier_hues = {
	[1] = 0.3, 
	[2] = DIR.hues.red,
	[3] = 0.625,
	[4] = DIR.hues.violet,
	[5] = DIR.hues.yellow,
}

-- materials - must be loaded before components and after constants above

DIR.materials = require(DIR.IR_path.."/code/data/materials")

-- components - must be loaded after materials

DIR.components = require(DIR.IR_path.."/code/data/components")

-- all known crafting categories

DIR.crafting_categories = {
	"advanced-crafting",
	"advanced-molten-alloying",
	"advanced-washing",
	"air-compression",
	"air-purification",
	"air-separation",
	"alloying",
	"barrelling",
	"blast-alloying",
	"blast-multi-smelting",
	"blast-smelting",
	"centrifuging",
	"charcoal-kiln",
	"charging",
	"chemistry",
	"cleaning",
	"cooling",
	"crafting",
	"crafting-small",
	"crafting-with-fluid",
	"cryogenics",
	"electric-boiler",
	"electroplating",
	"forestry",
	"forestry-advanced",
	"gear-wheel-casting",
	"geothermal-exchange",
	"glowing",
	"grinding",
	"heating",
	"ingot-casting",
	"laser-crafting",
	"melting",
	"melting-with-gas",
	"mixing",
	"module-loading",
	"molten-alloying",
	"multi-smelting",
	"plate-casting",
	"pressing",
	"rod-casting",
	"scrapping",
	"smelting",
	"steam-barrelling",
	"steam-unbarrelling",
	"supermagnet",
	"unbarrelling",
	"venting",
	"washing",
}

-- tiered crafting categories - creates tier suffix per category, e.g. smelting-2, smelting-3

DIR.tiered_categories = {
	"grinding", 
	"smelting",
	"alloying",
}

-- tweaky prefixes for recipe order in crafting menu

DIR.category_orders = {
	["advanced-washing"] = "b",
	["pressing"] = "x",
	["smelting"] = "a",
	["alloying"] = "a",
	["washing"] = "a",
}

-- crafting category icons, rendered as if an ingredient overlay (top left)
-- also applied to generated machines (?)
-- numeric suffixes are stripped before matching
-- blocks display of ingredient overlays (hopefully)

DIR.category_overlays = {
	["electroplating"] = "electroplating-overlay",
	["heating"] = "heating-overlay",
	["laser-crafting"] = "laser-overlay",
	["cryogenics"] = "cryogenics-overlay",
	["cooling"] = "cryogenics-overlay",
	["washing"] = "water",
	["advanced-washing"] = "heating-overlay",
}

-- these icons are never added to ingredient/result overlays in recipe icons

DIR.icon_overlay_ingredient_ignores = {
	["steam"] = true,
	["nitrogen-gas"] = true,
	["iron-pellet"] = true,
	["nickel-pellet"] = true,
	["platinum-pellet"] = true,
	["copper-cable"] = true,
	["solid-fuel"] = true,
}

DIR.icon_overlay_result_ignores = {
	["dirty-water"] = true,
	["water"] = true,
	["steam"] = true,
	["sulphur-gas"] = true,
	["carbon-gas"] = true,
	["nitrogen-gas"] = true,
	["helium-gas"] = true,
}

-- basic recipe list for productivity modules
-- this is added to later by the generated item process (for all components with productivity flag set)
-- also some batch recipes add to this e.g. gasification

DIR.productivity_limitation = {
	"coal-liquefaction",
	-- "concrete", -- removed in 3.1.28 due to scrapping exploit
	"kovarex-enrichment-process",
	"landfill",
	-- "refined-concrete", -- removed in 3.1.28 due to scrapping exploit
	"rocket-part",
	"sulfuric-acid",
	"uranium-processing",
	"ir-crude-oil-processing",
	"ir-heavy-oil-processing",
	"ir-light-oil-processing",
	"ir-petroleum-processing",
	"ir-natural-gas-processing",
	"ir-bitumen-upgrading",
}

-- categories that count as "crafting" for scrap generation - these are treated as substrings so match e.g. advanced-crafting, crafting-with-fluid

DIR.scrapping_categories = {
	"crafting",
	"electronics",
	"electroplating",
	"charging",
	"loading",
}

-- usually, multi-product recipes are skipped by scrap calculation (no way of knowing which ingredients go into which product)
-- this table allows specific fluids to be ignored, so if it is just that fluid and one item as results, the recipe still counts as reversible
-- to-do: 3.0.0 started handling catalyst_amount a bit more seriously/consistently so likely that could be used instead

DIR.scrapping_ignored_fluids = {
	["nitrogen-gas"] = true,
	["helium-gas"] = true,
}

-- generated recipes in these categories will attempt to force the fluidbox_index if there are fewer fluid ingredients than pipe connections
-- ditto for results
-- this prevents e.g. arc furnaces with three of the same input connectors
-- this also happens with chemplant recipes but that's the way it is in vanilla - there it is only enforced with refinery

DIR.force_fluidbox_index_by_category = {
	["melting-with-gas"] = { {2}, {1,3}, {1,3,4} },
	["melting"] = { {2}, {1,3}, {1,3,4} },
	["molten-alloying"] = { {2}, {1,3}, {1,3,4} },
	["advanced-molten-alloying"] = { {2}, {1,3}, {1,3,4} },
	["cryogenics"] = { {1} }, -- TODO: there are more combos here but matcomp system doesn't produce them (yet)
}

-- Recipe subgroups starting with the substring "ir-" are automatically broken apart into separate lines if they have 11-19 members
-- This is also applied to the following vanilla subgroups:

DIR.long_subgroups = {
	["fill-barrel"] = true,
	["empty-barrel"] = true,
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGY

-- vanilla ignore list for ancestors search - sets IR_tech_rebuild_ignore on each of these
-- as of 3.0.0 native techs and specific recipes have the flag set in their own definitions if necessary

DIR.tech_rebuild_tech_ignore_list = {
	"coal-liquefaction", 
	"nuclear-fuel-reprocessing", 
	"kovarex-enrichment-process",
}

-- recipe ignore list - set IR_tech_rebuild_ignore on any recipe matching these substrings
-- now only used for non-native recipes from other mods
-- currently only DSB/DCM because of all the data stage chicken-and-egg shenanigans those mods create
-- 3.0.0: those mods are currently blocked, but leaving this here in case someone wants to manually enable them

DIR.tech_rebuild_recipe_substring_ignore_list = {
	"deadlock-packrecipe",
	"deadlock-unpackrecipe",
	"deadlock-stacks",
}

-- ingredients which are always available from the world so shouldn't ever be treated as tech requirements

DIR.tech_rebuild_ingredient_ignore_list = {
	["carbon-gas"] = true,
	["coal"] = true,
	["copper-ore"] = true, 
	["crude-oil"] = true,
	["diamond-gem"] = true, 
	["dirty-steam"] = true,
	["dirty-water"] = true,
	["fossil-gas"] = true,
	["gold-ore"] = true, 
	["iron-ore"] = true, 
	["natural-gas"] = true,
	["rubber-wood"] = true,
	["ruby-gem"] = true, 
	["steam"] = true,
	["stone"] = true, 
	["sulphur-gas"] = true,
	["tin-ore"] = true, 
	["water"] = true, 
	["wood"] = true,
}

------------------------------------------------------------------------------------------------------------------------------------------------------

-- MISC

-- don't ever auto-generate shrapnel/explosions for these entity types

DIR.explosion_blacklist = {
	["fish"] = true,
	["tree"] = true,
	["unit"] = true,
	["land-mine"] = true,
	["character"] = true,
}

-- recipes which newly placed entities use

DIR.default_aetheric_recipe = "aetheric-glow-15"
DIR.default_boiler_recipe = "electric-hot-water"
DIR.default_geothermal_recipe = "geothermal-exchange"

-- laser beam colours

local laser_sat = 0.75
local laser_val = 1
DIR.laser_colours = {
	red = {index = 0, rgb = DIR.hsva2rgba(DIR.hues.red,laser_sat,laser_val) },
	orange = {index = 1, rgb = DIR.hsva2rgba(DIR.hues.orange,laser_sat,laser_val) },
	yellow = {index = 2, rgb = DIR.hsva2rgba(DIR.hues.yellow,laser_sat,laser_val) },
	lime = {index = 3, rgb = DIR.hsva2rgba(DIR.hues.lime,laser_sat,laser_val) },
	green = {index = 4, rgb = DIR.hsva2rgba(DIR.hues.green,laser_sat,laser_val) },
	teal = {index = 5, rgb = DIR.hsva2rgba(DIR.hues.teal,laser_sat,laser_val) },
	cyan = {index = 6, rgb = DIR.hsva2rgba(DIR.hues.cyan,laser_sat,laser_val) },
	azure = {index = 7, rgb = DIR.hsva2rgba(DIR.hues.azure,laser_sat,laser_val) },
	blue = {index = 8, rgb = DIR.hsva2rgba(DIR.hues.blue,laser_sat,laser_val) },
	violet = {index = 9, rgb = DIR.hsva2rgba(DIR.hues.violet,laser_sat,laser_val) },
	magenta = {index = 10, rgb = DIR.hsva2rgba(DIR.hues.magenta,laser_sat,laser_val) },
	pink = {index = 11, rgb = DIR.hsva2rgba(DIR.hues.pink,laser_sat,laser_val) },
}

-- sigh

DIR.all_the_item_types = {
	"item","gun","ammo","armor","module","tool","repair-tool","capsule","rail-planner",
	"item-with-entity-data","blueprint","blueprint-book","upgrade-item","deconstruction-item"
}

-- 3.1.3: fast-replace/upgrade sensitivity list
-- these entities are checked and their upgrade-sensitive properties enforced in the data-final-fixes stage - see DIR.final_entities_pass()
-- the outer key is entity type
-- the inner key is the reference entity (prefer vanilla entities as these are typically going to be the ones changed by other mods)
-- the inner value list is the comparison entities, usually those intended to be fast-replaceable or upgradable with the reference entity

DIR.entity_upgrade_properties_checklist = {
	["electric-pole"] = {
		["big-electric-pole"] = {"big-wooden-pole"},
	},
}

------------------------------------------------------------------------------------------------------------------------------------------------------
