return {
	["air-compressor"] = true,
	["air-purifier"] = true,
	["arc-furnace"] = true,
	["bronze-forestry"] = true,
	["bronze-furnace"] = true,
	["chrome-drill"] = true,
	["copper-boiler"] = true,
	["electric-furnace"] = true,
	["electric-mining-drill"] = true,
	["iron-gas-vent"] = true,
	["oil-refinery"] = true,
	["steam-drill"] = true,
}
