-- 3.1.17 - fissures are now described here (was previously in gas component properties)

local fissures = {
	water = {
		autoplace = true,
		low_band = 0,
		high_band = 0.15,
		yield_at_start = 60,
		temperature = 165,
		min_distance = 900,
		scripted_start_location = true,
		map_colour = {0.5,0.5,1.0},
	},
	["dirty-water"] = {
		autoplace = true,
		low_band = 0.15,
		high_band = 0.4,
		yield_at_start = 120,
		temperature = 200,
		map_colour = {1.0,0.75,0.5},
	},
	sulphur = {
		autoplace = true,
		low_band = 0.4,
		high_band = 0.65,
		yield_at_start = 30,
		map_colour = {1.0,0.9,0.5},
	},
	fossil = {	
		autoplace = true,
		low_band = 0.65,
		high_band = 1,
		yield_at_start = 30,
		min_distance = 600,
		map_colour = {0.9,0.5,1.0},
	},
	natural = {
		autoplace = false,
		yield_at_start = 30,
		map_colour = {0.5,0.9,1.0},
	},
}

return fissures