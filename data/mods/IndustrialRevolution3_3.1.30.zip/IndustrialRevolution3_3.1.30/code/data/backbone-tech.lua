-- main IR technology progression

return {
	["ir-charcoal"] = {
		machines = {"stone-charcoal-kiln"},
		unlocks = {
		},
		additional_unlocks = {"charcoal-from-ore"},
		icon = "stone-charcoal-kiln",
		prerequisites = {},
	},
	["ir-grinding-1"] = {
		machines = {"copper-grinder"},
		unlocks = {
			["stone"] = {"crushed","powder"},
			["carbon"] = {"crushed"},
			["copper"] = {"crushed","ingot-from-crushed"},
			["tin"] = {"crushed","ingot-from-crushed"},
			["wood"] = {"scrap"},
			["rubber"] = {"plate"},
		},
		additional_unlocks = {"charcoal-from-scrap"},
		icon = "copper-grinder",
		prerequisites = {"logistics","automation","ir-charcoal"},
	},
	["ir-bronze-milestone"] = {
		machines = {"stone-alloy-furnace"},
		unlocks = {
			["bronze"] = {"ingot","ingot-from-scrap","derivatives","beam","repair-tool"},
		},
		additional_unlocks = {"bronze-chest","bronze-cartridge"},
		icon = "bronze-components",
		prerequisites = {"logistics","automation","ir-grinding-1"},
	},
	["ir-glass-milestone"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"glass","glass-from-scrap","copper-aetheric-lamp-straight"},
		icon = "glass",
		prerequisites = {"ir-grinding-1","ir-bronze-milestone"},
	},
	["ir-bronze-furnace"] = {
		machines = {"bronze-furnace","bronze-alloy-furnace"},
		unlocks = {
			-- bronze = {"plate-special","plate-special-manual"},
		},
		additional_unlocks = {},
		icon = "bronze-furnace",
		prerequisites = {"ir-bronze-milestone"},
	},
	-- bronze analysis
	["ir-iron-milestone"] = {
		machines = {},
		unlocks = {
			["iron"] = {"ingot","ingot-from-scrap","derivatives","piston","beam","frame-small","repair-tool"},
		},
		additional_unlocks = {"iron-chest","pipe","pipe-to-ground","pipe-to-ground-short","valve","offshore-pump"},
		icon = "iron-components",
		prerequisites = {"ir-grinding-1","ir-bronze-furnace"},
	},
	["ir-steam-power"] = {
		machines = {"steam-engine","boiler","small-electric-pole","small-bronze-pole","small-iron-pole","big-wooden-pole"},
		unlocks = {
			["copper"] = {"cable","cable-heavy","coil"},
		},
		additional_unlocks = {},
		icon = "steam-power",
		prerequisites = {"ir-iron-milestone"},
	},
	["ir-electronics-1"] = {
		machines = {},
		unlocks = {
			["copper"] = {"foil","gate","circuit","computer"},
			["iron"] = {"frame-large"},
		},
		additional_unlocks = {},
		icon = "electronics-1-components",
		prerequisites = {"ir-steam-power"},
	},
	["ir-electric-furnace"] = {
		machines = {"electric-furnace","electric-alloy-furnace"},
		unlocks = {
		},
		additional_unlocks = {},
		icon = "electric-furnace",
		prerequisites = {"ir-steam-power"},
	},
	["ir-coking"] = {
		machines = {},
		unlocks = {
			["carbon"] = {"ingot"},
		},
		additional_unlocks = {},
		icon = "solid-fuel",
		prerequisites = {"ir-electric-furnace"},
	},
	["ir-grinding-2"] = {
		machines = {"iron-grinder","iron-mixer"},
		unlocks = {
			["iron"] = {"crushed","ingot-from-crushed"},
		},
		icon = "iron-grinder",
		prerequisites = {},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-mining-1"] = {
		machines = {"electric-mining-drill"},
		unlocks = {},
		icon = "electric-mining-drill",
		prerequisites = {"ir-steam-power","ir-inserters-1"},
	},
	["ir-gold-milestone"] = {
		machines = {},
		unlocks = {
			["gold"] = {"ingot","crushed","ingot-from-crushed","ingot-from-scrap","foil"},
		},
		additional_unlocks = {},
		icon = "gold-components",
		prerequisites = {"ir-mining-1"},
	},
	-- steel analysis
	["ir-steel-milestone"] = {
		machines = {},
		unlocks = {
			["steel"] = {"ingot","ingot-from-scrap","derivatives","piston","beam","frame-small"},
		},
		additional_unlocks = {"steel-chest"},
		icon = "steel-components",
		prerequisites = {"ir-coking"},
	},
	["ir-graphite"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"graphite","graphitic-coke-from-ingot","graphitic-coke-from-powder"},
		icon = "graphite",
		prerequisites = {"ir-crude-oil-processing","ir-coking","ir-steel-milestone"},
	},
	["ir-silicon"] = {
		machines = {},
		unlocks = {
			["stone"] = {"pure"}, -- silicon
		},
		additional_unlocks = {},
		icon = "silicon",
		prerequisites = {"ir-coking","ir-steel-milestone"},
	},
	["ir-silicon-carbide"] = {
		machines = {},
		unlocks = {
			["stone"] = {"block"}, -- refractory brick
		},
		additional_unlocks = {},
		icon = "silicon-carbide-components",
		prerequisites = {"ir-steel-milestone"},
	},
	["ir-gas-furnace"] = {
		machines = {"steel-furnace"},
		unlocks = {
		},
		additional_unlocks = {},
		icon = "steel-furnace",
		prerequisites = {"ir-light-oil-processing"},
	},
	["ir-electronics-2"] = {
		machines = {},
		unlocks = {
			["gold"] = {"gate","circuit","computer"},
			["tin"] = {"cable"},
			["steel"] = {"frame-large"},
		},
		additional_unlocks = {"junction-box"},
		icon = "electronics-2-components",
		prerequisites = {"ir-gold-milestone","ir-steel-milestone"},
	},
	["ir-washing-1"] = {
		machines = {"steel-washer","steel-cleaner"},
		unlocks = {
			["copper"] = {"pure","ingot-from-pure"},
			["tin"] =  {"pure","ingot-from-pure"},
			["iron"] =  {"pure","ingot-from-pure"},
			["gold"] =  {"pure","ingot-from-pure"},
			["lead"] = {"ingot-from-pure","ingot-from-scrap","derivatives"},
			["nickel"] = {"ingot-from-pure","pellet"}, -- don't use derivatives because electroplating
			["chromium"] = {"ingot-from-pure"}, -- don't use derivatives because electroplating
			["platinum"] = {"ingot-from-pure","pellet"},
		},
		additional_unlocks = {"dirty-water-cleaning"},
		icon = "steel-washer",
		prerequisites = {"ir-electronics-2"},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-washing-2"] = {
		machines = {"steel-boiler"},
		unlocks = {
			["copper"] = {"pure-advanced"},
			["tin"] = {"pure-advanced"},
			["iron"] = {"pure-advanced"},
			["gold"] = {"pure-advanced"},
		},
		additional_unlocks = {"electric-hot-water","electric-steam"},
		icon = "steel-washer",
		prerequisites = {"ir-washing-1"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-brass-milestone"] = {
		machines = {},
		unlocks = {
			["brass"] = {"ingot","ingot-from-scrap","derivatives"},
		},
		additional_unlocks = {},
		icon = "brass-components",
		prerequisites = {"ir-washing-1"},
	},
	["ir-electroplating"] = {
		machines = {"steel-electroplater"},
		unlocks = {
			["chromium"] = {"plating-solution","plate","rod","rivet","plate-heavy","piston","beam","frame-small"}, 
			["gold"] = {"plating-solution","cable","plate"},
		},
		additional_unlocks = {},
		icon = "chromium-components",
		prerequisites = {"ir-electronics-2","ir-washing-1"},
	},
	["ir-advanced-engine"] = {
		machines = {},
		unlocks = {
			["chromium"] = {"engine-unit"}, 
		},
		additional_unlocks = {},
		icon = "chromium-engine-tech",
		prerequisites = {"ir-electroplating"},
	},
	["ir-grinding-3"] = {
		machines = {"steel-grinder","steel-mixer"},
		unlocks = {
			diamond = {"gear-wheel","powder"},
			ruby = {"powder"},
			steel = {"repair-tool"},
		},
		additional_unlocks = {},
		icon = "steel-grinder",
		prerequisites = {"ir-washing-1"},
	},
	["ir-pressing"] = {
		machines = {"chrome-press"},
		unlocks = {
			["ruby"] = {"gem"},
			["diamond"] = {"gem"},
		},
		additional_unlocks = {},
		icon = "chrome-press",
		prerequisites = {"automation-3","ir-grinding-3"},
		IR_tech_rebuild_ignore = false,
	},
	["ir-electrum-milestone"] = {
		machines = {},
		unlocks = {
			["electrum"] = {"gem","plate","plate-special"},
		},
		additional_unlocks = {},
		icon = "electrum-gem",
		prerequisites = {"ir-pressing","automation-4"},
	},
	["ir-electronics-3"] = {
		machines = {},
		unlocks = {
			["electrum"] = {"foil","gate","circuit","computer"},
			["chromium"] = {"frame-large"},
		},
		additional_unlocks = {},
		icon = "electronics-3-components",
		prerequisites = {"ir-electrum-milestone","automation-4","ir-graphene"},
	},
	["ir-air-compression"] = {
		machines = {"air-compressor","air-purifier","air-pipe","air-pipe-to-ground","air-pipe-to-ground-short","air-valve"},
		unlocks = {},
		additional_unlocks = {"carbon-filter","air-compression","air-purification"},
		icon = "air-purifier",
		prerequisites = {"ir-gold-milestone"},
	},
	["ir-blast-furnace"] = {
		machines = {"blast-furnace"},
		unlocks = {
			copper = {"ingot-blast","ingot-from-crushed-blast","ingot-from-pure-blast"},
			iron = {"ingot-blast","ingot-from-crushed-blast","ingot-from-pure-blast"},
			steel = {"ingot-blast"},
		},
		additional_unlocks = {"silicon-blast"},
		icon = "blast-furnace",
		prerequisites = {"ir-electric-furnace","ir-air-compression","ir-electroplating"},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-arc-furnace"] = {
		machines = {"arc-furnace","steel-cast","graphite-electrode"},
		unlocks = {
		},
		additional_unlocks = {},
		category_unlocks = {"melting-with-gas","melting","molten-alloying","ingot-casting","plate-casting","gear-wheel-casting","rod-casting"},
		icon = "arc-furnace",
		prerequisites = {"ir-electronics-3","ir-blast-furnace"},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-arc-furnace-2"] = {
		machines = {},
		unlocks = {},
		additional_unlocks = {},
		category_unlocks = {"advanced-molten-alloying"},
		icon = "arc-furnace",
		prerequisites = {"space-science-pack"},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-mining-2"] = {
		machines = {"chrome-drill"},
		unlocks = {},
		icon = "chrome-drill",
		prerequisites = {"ir-electroplating"},
	},
	["ir-cryogenics"] = {
		machines = {"steel-cryo-tower","steel-vaporiser", "copper-heatsink", "air-separation", "air-separation-reversed", "air-separation-oxygen", "air-separation-nitrogen", "air-separation-helium"},
		unlocks = {
			oxygen = {"cryofluid","gas"},
			nitrogen = {"cryofluid","gas"},
			hydrogen = {"cryofluid","gas"},
			helium = {"cryofluid","gas"},
			natural = {"cryofluid","gas"},
			carbon = {"cryofluid","gas"},
			water = {"fluid"},
			["dirty-water"] = {"fluid"},
			-- not ammonia
		},
		additional_unlocks = {"fossil-gas-separation", "fossil-gas-separation-reversed", "fossil-gas-separation-natural"},
		icon = "steel-cryo-tower",
		prerequisites = {"ir-natural-gas-processing","ir-air-compression"},
		-- IR_tech_rebuild_ignore = true,
	},
	["ir-gasification"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"coke-gasification"},
		icon = "coke-gasification",
		prerequisites = {"coal-liquefaction","ir-natural-gas-processing"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-hydrogen-battery"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"hydrogen-battery","charged-hydrogen-battery"},
		icon = "charged-hydrogen-battery",
		prerequisites = {"ir-natural-gas-processing"},
	},
	["ir-ethanol-1"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ethanol"},
		icon = "ethanol",
		prerequisites = {"ir-steel-milestone","ir-crude-oil-processing"},
	},
	["ir-ethanol-2"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ethanol-from-gas"},
		icon = "ethanol",
		prerequisites = {"ir-light-oil-processing","ir-washing-1"},
		IR_tech_rebuild_ignore_as_provider = true,
	},
	["ir-steel-derrick"] = {
		machines = {"steel-derrick"},
		unlocks = {
		},
		additional_unlocks = {},
		icon = "steel-derrick",
		prerequisites = {"ir-steel-milestone"},
	},
	["ir-geothermal-exchange"] = {
		machines = {"iron-geothermal-exchanger"},
		unlocks = {
		},
		additional_unlocks = {"geothermal-exchange","geothermal-hot-water"},
		icon = "iron-geothermal-exchanger",
		prerequisites = {"ir-steel-derrick","ir-washing-2"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-crude-oil-processing"] = {
		machines = {"oil-refinery","chemical-plant","pumpjack","iron-gas-vent"},
		unlocks = {
		},
		additional_unlocks = {"ir-crude-oil-processing","tarmac","fill-petroleum-gas-iron-canister","empty-petroleum-gas-iron-canister"},
		icon = "ir-crude-oil-processing",
		prerequisites = {"fluid-handling"},
	},
	["ir-heavy-oil-processing"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ir-heavy-oil-processing"},
		icon = "ir-heavy-oil-processing",
		prerequisites = {"ir-crude-oil-processing"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-light-oil-processing"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ir-light-oil-processing"},
		icon = "ir-light-oil-processing",
		prerequisites = {"ir-heavy-oil-processing"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-petroleum-processing"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ir-petroleum-processing"},
		icon = "ir-petroleum-processing",
		prerequisites = {"ir-light-oil-processing","ir-washing-1"},
		IR_tech_rebuild_ignore = true,
	},
	["ir-natural-gas-processing"] = {
		machines = {},
		unlocks = {
		},
		additional_unlocks = {"ir-natural-gas-processing"},
		icon = "ir-natural-gas-processing",
		prerequisites = {"ir-petroleum-processing"},
	},
	["ir-bitumen-upgrading"] = {
		machines = {"ir-bitumen-upgrading"},
		unlocks = {
			bitumen = {"fluid"},
		},
		additional_unlocks = {},
		icon = "bitumen-upgrading",
		prerequisites = {"ir-petroleum-processing"},
		IR_tech_rebuild_ignore = true,
	},
	-- ["ir-water-electrolysis"] = {
		-- machines = {},
		-- unlocks = {
		-- },
		-- additional_unlocks = {"water-electrolysis"},
		-- icon = "water-electrolysis",
		-- prerequisites = {"ir-modules-3"},
		-- IR_tech_rebuild_ignore = true,
	-- },
}
