------------------------------------------------------------------------------------------------------------------------------------------------------

-- STARTER KITS
-- Items made available in crates to the first player that joins the game
-- See control-remote.lua for remote access to these tables at runtime

------------------------------------------------------------------------------------------------------------------------------------------------------

local function merge(into, from)
    for k, v in pairs(from) do
        into[k] = v
    end
end

local basic_weapons = {
    ["shotgun"] = 1,
    ["shotgun-shell"] = 50
}

local better_weapons = {
    ["submachine-gun"] = 1,
    ["firearm-magazine"] = 100
}

local basic_resources = {
    ["wood"] = 200,
    ["rubber-wood"] = 200,
    ["coal"] = 200,
    ["copper-ingot"] = 200,
    ["tin-ingot"] = 200,
    ["stone-brick"] = 200
}

local medium_resources = {
    ["glass"] = 200,
    ["bronze-ingot"] = 200,
    ["iron-ingot"] = 200,
	["rubber"] = 100,
}

local basic_building = {
	["empty-cell"] = 20,
	["steam-barrelling-machine"] = 1,
    ["copper-roboport-equipment"] = 2,
    ["light-armor"] = 1,
    ["steambot"] = 10
}

local medium_building = {
	["empty-cell"] = 30,
	["steam-barrelling-machine"] = 1,
    ["copper-roboport-equipment"] = 4,
    ["heavy-armor"] = 1,
    ["steambot"] = 20
}

local high_building = {
    ["construction-robot"] = 20,
    ["iron-burner-generator-equipment"] = 2,
    ["modular-armor"] = 1,
    ["personal-roboport-equipment"] = 2
}

local basic_belts = {
    ["transport-belt"] = 300,
    ["underground-belt"] = 50,
    ["splitter"] = 20
}

local better_belts = {
    ["fast-transport-belt"] = 300,
    ["fast-underground-belt"] = 50,
    ["fast-splitter"] = 20
}

local steam_power = {
	["copper-boiler"] = 4,
	["copper-pipe"] = 200,
	["steam-pipe"] = 200,
	["copper-pump"] = 1,
	["copper-derrick"] = 1,
}

local electric_power = {
	["boiler"] = 8,
	["pipe"] = 200,
	["steam-engine"] = 16,
    ["small-iron-pole"] = 100,
	["offshore-pump"] = 1,
	["copper-derrick"] = 1,
	["steam-pipe"] = 200,
}

local start = {
    tech = {
		["none"] = {},
		["stone"] = {},
		["wood"] = {},
		["copper"] = {
			"automation",
			"logistics",
			"ir-steambot",
		},
        ["bronze"] = {
			"ir-steambot",
			"ir-bronze-furnace",
			"ir-scattergun-turret",
			"heavy-armor",
			"ir-monowheel"
		},
        ["iron"] = {
            "ir-steambot",
            "ir-steam-power",
            "ir-scattergun-turret",
            "automation-2",
			"ir-mining-1",
			"ir-electric-furnace",
            "heavy-armor",
            "ir-research-1",
            "optics",
            "ir-heavy-roller",
        },
        ["steel"] = {
            "ir-steambot",
            "ir-steel-milestone",
            "modular-armor",
            "ir-scattergun-turret",
            "gun-turret",
            "automation-2",
			"ir-electric-furnace",
            "logistics-2",
            "personal-roboport-equipment",
            "optics",
            "ir-heavy-roller"
        },
        ["chrome"] = {
            "ir-steambot",
            "ir-electroplating",
            "modular-armor",
			"ir-electric-furnace",
            "ir-scattergun-turret",
            "gun-turret",
            "automation-2",
            "logistics-2",
            "personal-roboport-equipment",
            "optics",
            "ir-heavy-roller"
        }
    },
    kits = {
		["none"] = {},
        ["stone"] = {
            ["burner-mining-drill"] = 4,
            ["stone-furnace"] = 4,
        },
        ["wood"] = { -- this option isn't included in the GUI but is triggered by disabling trees in mapgen settings
            ["burner-mining-drill"] = 4,
            ["stone-furnace"] = 4,
			["wood"] = 200,
			["rubber-wood"] = 200,
        },
        ["copper"] = {
            ["assembling-machine-1"] = 12,
            ["small-assembler-1"] = 12,
            ["stone-furnace"] = 12,
            ["burner-inserter"] = 32,
            ["burner-mining-drill"] = 8,
            ["copper-lab"] = 4,
			["copper-derrick"] = 1,
        },
        ["bronze"] = {
            ["assembling-machine-1"] = 12,
            ["small-assembler-1"] = 12,
            ["bronze-furnace"] = 12,
            ["bronze-ingot"] = 200,
            ["burner-inserter"] = 32,
            ["burner-mining-drill"] = 8,
            ["copper-lab"] = 4,
        },
        ["iron"] = {
            ["assembling-machine-2"] = 12,
            ["small-assembler-2"] = 12,
            ["bronze-furnace"] = 12,
            ["burner-inserter"] = 32,
            ["burner-mining-drill"] = 12,
            ["lab"] = 4,
        },
        ["steel"] = {
            ["assembling-machine-2"] = 12,
            ["small-assembler-2"] = 12,
            ["electric-furnace"] = 12,
            ["electric-mining-drill"] = 12,
            ["electronic-circuit"] = 200,
            ["inserter"] = 32,
            ["iron-grinder"] = 12,
            ["lab"] = 6,
            ["medium-electric-pole"] = 100,
            ["steel-ingot"] = 200,
        },
        ["chrome"] = {
            ["assembling-machine-2"] = 16,
            ["small-assembler-2"] = 16,
            ["electric-furnace"] = 24,
            ["electric-mining-drill"] = 16,
            ["electronic-circuit"] = 200,
            ["fast-inserter"] = 32,
            ["inserter"] = 48,
            ["lab"] = 8,
            ["medium-electric-pole"] = 100,
            ["steel-grinder"] = 12,
            ["steel-ingot"] = 200,
        }
    }
}

merge(start.kits.stone, basic_weapons)
merge(start.kits.wood, basic_weapons)
merge(start.kits.copper, basic_weapons)
merge(start.kits.bronze, basic_weapons)
merge(start.kits.iron, basic_weapons)
merge(start.kits.steel, better_weapons)
merge(start.kits.chrome, better_weapons)

merge(start.kits.copper, basic_resources)
merge(start.kits.bronze, basic_resources)
merge(start.kits.iron, basic_resources)
merge(start.kits.steel, basic_resources)
merge(start.kits.chrome, basic_resources)

merge(start.kits.iron, medium_resources)
merge(start.kits.steel, medium_resources)
merge(start.kits.chrome, medium_resources)

merge(start.kits.copper, basic_belts)
merge(start.kits.bronze, basic_belts)
merge(start.kits.iron, basic_belts)
merge(start.kits.steel, basic_belts)
merge(start.kits.chrome, basic_belts)

merge(start.kits.steel, better_belts)
merge(start.kits.chrome, better_belts)

merge(start.kits.copper, basic_building)
merge(start.kits.bronze, medium_building)
merge(start.kits.iron, medium_building)
merge(start.kits.steel, high_building)
merge(start.kits.chrome, high_building)

merge(start.kits.bronze, steam_power)
merge(start.kits.iron, electric_power)
merge(start.kits.steel, electric_power)
merge(start.kits.chrome, electric_power)

------------------------------------------------------------------------------------------------------------------------------------------------------

return start

------------------------------------------------------------------------------------------------------------------------------------------------------
