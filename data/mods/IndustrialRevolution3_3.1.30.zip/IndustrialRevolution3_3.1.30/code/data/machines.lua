-- items that place machines
-- order defines item/recipe order unless overridden

local machines = {
    ["burner-mining-drill"] = {
        ingredients = {{"copper-frame-large", 1}, {"tin-plate", 24}, {"copper-piston", 8}, {"copper-engine-unit",1}},
        enabled = true,
        subgroup = "ir-machines-resources",
        time = 3,
        order = "a",
		result_overlay = "heating-overlay",
    },
    ["steam-drill"] = {
        ingredients = {{"burner-mining-drill", 1}, {"steam-pipe", 4}},
        enabled = true,
        subgroup = "ir-machines-resources",
        time = 3,
        order = "ab",
		icon = "burner-mining-drill",
		result_overlay = "steam",
    },
    ["electric-mining-drill"] = {
        ingredients = {
            {"iron-frame-large", 1},
            {"iron-plate-heavy", 24},
			{"iron-motor", 8},
            {"iron-piston", 8},
        },
        enabled = false,
        subgroup = "ir-machines-resources",
        time = 5,
        order = "b"
    },
    ["chrome-drill"] = {
        ingredients = {
            {"chromium-frame-large", 1},
            {"chromium-plate-heavy", 48},
            {"chromium-beam", 48},
            {"chromium-engine-unit", 4},
            {"diamond-gear-wheel", 16}
        },
        enabled = false,
        time = 12,
        subgroup = "ir-machines-resources",
        stack_size = 10,
        order = "c"
    },
    ["bronze-forestry"] = {
        ingredients = {{"bronze-plate", 40}, {"glass", 16}, {"copper-pipe", 3}},
        enabled = false,
        subgroup = "ir-machines-resources",
        time = 6
    },
    ["iron-forestry"] = {
        ingredients = {{"iron-plate", 40}, {"glass", 16}, {"pipe", 3}, {"small-lamp", 4}},
        enabled = false,
        subgroup = "ir-machines-resources",
        time = 6
    },
    ["chrome-forestry"] = {
        ingredients = {{"chromium-plate", 60}, {"nanoglass", 24}, {"pipe", 9}, {"small-lamp", 4}},
        enabled = false,
        subgroup = "ir-machines-resources",
        time = 6,
    },
    ["stone-furnace"] = {
        ingredients = {{"stone-brick", 16}, {"wood-beam", 8}},
        enabled = true,
        subgroup = "ir-machines-furnaces",
		result_overlay = "heating-overlay",
    },
    ["stone-alloy-furnace"] = {
        ingredients = {{"stone-furnace", 1}, {"tin-plate", 8}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "alloying-overlay",
    },
    ["stone-charcoal-kiln"] = {
        ingredients = {{"stone-brick", 12}, {"wood-beam", 6}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "heating-overlay",
    },
    ["bronze-furnace"] = {
        ingredients = {{"bronze-beam",4},{"bronze-plate-heavy",12}, {"stone-furnace", 1}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "heating-overlay",
    },
    ["bronze-alloy-furnace"] = {
        ingredients = {{"bronze-beam",4},{"bronze-plate-heavy",12}, {"stone-alloy-furnace", 1}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "alloying-overlay",
    },
    ["electric-furnace"] = {
        ingredients = {{"iron-frame-large", 1}, {"iron-plate-heavy", 12}, {"copper-cable", 20}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "heating-overlay-electric",
    },
    ["electric-alloy-furnace"] = {
        ingredients = {{"electric-furnace", 1}, {"iron-plate", 8}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "alloying-overlay-electric",
    },
    ["steel-furnace"] = {
        ingredients = {{"steel-beam", 12}, {"steel-plate-heavy", 20}, {"silicon-block",20}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "natural-gas",
    },
    ["blast-furnace"] = {
        ingredients = {{"chromium-beam", 12}, {"chromium-plate-heavy", 30}, {"silicon-block",30}},
        enabled = false,
        subgroup = "ir-machines-furnaces",
		result_overlay = "heating-overlay",
    },
    ["arc-furnace"] = {
        ingredients = {
            {"chromium-frame-large", 1},
            {"junction-box", 1},
			{"silicon-block",80},
            {"chromium-plate-heavy", 80},
            {"graphite-electrode", 3}
        },
        enabled = false,
        subgroup = "ir-machines-furnaces",
        stack_size = 20,
        time = 8,
		result_overlay = "heating-overlay-electric",
    },
    ["copper-grinder"] = {
        ingredients = {{"copper-frame-large", 1}, {"copper-gear-wheel", 16}, {"copper-piston", 4}, {"steam-pipe", 2}},
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["iron-grinder"] = {
        ingredients = {{"iron-frame-large", 1}, {"iron-gear-wheel", 16}, {"iron-piston", 4}, {"iron-motor", 4}},
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["steel-grinder"] = {
        ingredients = {{"steel-frame-large", 1}, {"diamond-gear-wheel", 16}, {"steel-piston", 6}, {"electric-engine-unit", 6}},
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    -- ["copper-mixer"] = {
        -- ingredients = {{"copper-frame-large", 1}, {"tin-gear-wheel", 16}, {"copper-piston", 2}, {"steam-pipe", 2}},
        -- enabled = false,
        -- subgroup = "ir-machines-processing"
    -- },
    ["iron-mixer"] = {
        ingredients = {{"iron-frame-large", 1}, {"iron-gear-wheel", 16}, {"iron-piston", 2}, {"iron-motor", 2}},
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["steel-mixer"] = {
        ingredients = {
            {"steel-frame-large", 1},
            {"diamond-gear-wheel", 8},
            {"steel-piston", 2},
            {"electric-engine-unit", 2}
        },
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["steel-washer"] = {
        ingredients = {{"steel-frame-large", 1}, {"electric-engine-unit", 2}, {"steel-plate", 16}, {"steel-piston", 2}},
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["steel-cleaner"] = {
        ingredients = {
            {"steel-frame-small", 1},
            {"electric-engine-unit", 2},
            {"electronic-circuit", 2}
        },
        enabled = false,
        subgroup = "ir-machines-processing"
    },
    ["iron-scrapper"] = {
        ingredients = {{"iron-frame-large", 1}, {"iron-piston", 8}, {"iron-motor", 4}, {"iron-gear-wheel", 4}},
        enabled = false,
        subgroup = "ir-machines-production",
        order = "ba"
    },
    ["steel-electroplater"] = {
        ingredients = {
            {"steel-frame-large", 1},
            {"steel-plate", 40},
            {"copper-rod", 8},
            {"electric-engine-unit", 2}
        },
        enabled = false,
        subgroup = "ir-machines-production",
        order = "bc"
    },
    ["steel-cast"] = {
        ingredients = {{"steel-frame-small", 1}, {"silicon-block", 4}, {"steel-piston", 2}},
        enabled = false,
        subgroup = "ir-machines-production",
        order = "z",
		place = "ingot-cast",
		localised_name = {"item-name.steel-cast"},
		localised_description = {"item-description.steel-cast"},
    },
    ["chrome-press"] = {
        ingredients = {
            {"chromium-piston", 12},
            {"chromium-engine-unit", 6},
            {"computer-mk2", 1},
            {"chromium-plate-heavy", 48}
        },
        enabled = false,
        subgroup = "ir-machines-processing",
        order = "z"
    },
    ["copper-lab"] = {
        ingredients = {{"copper-frame-large", 1}, {"steam-pipe", 4}, {"copper-gear-wheel", 12}, {"copper-engine-unit",1}},
        enabled = true,
        subgroup = "ir-machines-labs",
        order = "a"
    },
    ["lab"] = {
        ingredients = {{"iron-frame-large", 1}, {"copper-coil", 1}, {"glass", 12}, {"copper-cable-heavy", 1}},
        enabled = false,
        subgroup = "ir-machines-labs",
        order = "ba"
    },
    ["quantum-lab"] = {
        ingredients = {
            {name = "junction-box", type = "item", amount = 1},
            {name = "quantum-ring", type = "item", amount = 3},
            {name = "computer-mk3", type = "item", amount = 8},
            {name = "chromium-rod", type = "item", amount = 24},
            {name = "electrum-plate-special", type = "item", amount = 80},
        },
		category = "crafting",
        enabled = false,
        time = 16,
        subgroup = "ir-machines-labs",
        order = "c",
        stack_size = 10
    },
    ["steambot"] = {
        ingredients = {{"copper-rotor", 1}, {"copper-piston", 1}, {"copper-rod",2}},
        enabled = false,
        subgroup = "logistic-network",
        order = "aa",
        time = 2
    },
    ["small-bronze-pole"] = {
        ingredients = {{"bronze-beam", 1}, {"copper-cable", 1}},
        enabled = false,
        subgroup = "energy-pipe-distribution",
        order = "a[energy]-a[za]",
        time = 1
    },
    ["small-iron-pole"] = {
        ingredients = {{"iron-beam", 1}, {"copper-cable", 1}},
        enabled = false,
        subgroup = "energy-pipe-distribution",
        order = "a[energy]-a[zb]",
        time = 1
    },
    ["big-wooden-pole"] = {
        ingredients = {{"wood", 4}, {"copper-cable-heavy", 1}, {"iron-plate", 2}},
        enabled = false,
        subgroup = "energy-pipe-distribution",
        order = "a[energy]-c[a]",
        time = 1
    },
    ["steel-plate-wall"] = {
        ingredients = {{"steel-plate-heavy", 4}, {"stone-wall", 1}},
        enabled = false,
        subgroup = "ir-walls",
        order = "b",
        time = 4
    },
    ["tin-chest"] = {
        ingredients = {{"tin-rod", 6}, {"tin-plate", 6}},
        enabled = true,
        subgroup = "storage",
        order = "a[items]-b[aaaa]",
        time = 2
    },
    ["bronze-chest"] = {
        ingredients = {{"bronze-rod", 6}, {"bronze-plate", 6}},
        enabled = false,
        subgroup = "storage",
        order = "a[items]-b[aaab]",
        time = 2
    },
    ["wood-pallet"] = {
        ingredients = {{"wood-beam", 3}},
        enabled = true,
        subgroup = "storage",
        order = "a[items]-a[aa]",
        time = 2
    },
    ["tin-pallet"] = {
        ingredients = {{"tin-plate", 3}},
        enabled = true,
        subgroup = "storage",
        order = "a[items]-a[ab]",
        time = 2
    },
    ["bottomless-pit"] = {
        ingredients = {{"stone-brick", 100}},
        enabled = false, -- enabled by map setting
        subgroup = "storage",
        order = "a[items]-z",
        time = 10
    },
    ["waterfill-explosive"] = {
        ingredients = {{"explosives", 4},{"wooden-chest",1},{"copper-gate",1}},
        enabled = false,
        subgroup = "ir-tiles",
        order = "d[boom]",
        time = 2
    },
    ["bronze-telescope"] = {
        ingredients = {{"steam-pipe",4}, {"bronze-beam", 8}, {"bronze-plate",24}, {"glass",8}},
        enabled = false,
        subgroup = "ir-walls",
        order = "y",
        time = 2
    },
    ["robotower"] = {
        ingredients = {{"steel-frame-small", 4}, {"computer-mk2", 1}, {"electric-engine-unit", 1}, {"battery", 4}},
        enabled = false,
        subgroup = "logistic-network",
        order = "ad"
    },
    ["steam-inserter"] = {
        ingredients = {{"steam-pipe", 1}, {"copper-piston", 1}, {"copper-motor", 1}, {"tin-rod", 3}},
        enabled = true,
        subgroup = "inserter",
        order = "a[burner-x]",
        time = 1,
        stack_size = 100
    },
    ["long-handed-steam-inserter"] = {
        ingredients = {{"steam-inserter", 1}, {"copper-piston", 1}, {"tin-rod", 3}},
        enabled = true,
        subgroup = "inserter",
        order = "a[burner-y]",
        time = 1,
        stack_size = 100
    },
    ["slow-filter-inserter"] = {
        ingredients = {{"inserter", 1}, {"electronic-circuit", 2}},
        enabled = false,
        subgroup = "inserter",
        order = "b[z]",
        time = 1,
        stack_size = 100
    },
    ["copper-pipe"] = {
        ingredients = {{"copper-plate", 2}, {"copper-rivet", 1}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "aa",
        time = 1,
        stack_size = 100
    },
    ["copper-valve"] = {
        ingredients = {{"copper-pipe", 1}, {"copper-gear-wheel", 1}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "aab",
        time = 1,
        stack_size = 100
    },
    ["copper-pipe-to-ground"] = {
        ingredients = {{"copper-pipe", 10}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "ab",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["copper-pipe-to-ground-short"] = {
        ingredients = {{"copper-pipe", 5}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "ab",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["steam-pipe"] = {
        ingredients = {{"copper-plate", 1}, {"copper-rivet", 1}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "ac",
        time = 1,
		count = 2,
        stack_size = 100
    },
    ["steam-valve"] = {
        ingredients = {{"steam-pipe", 1}, {"copper-gear-wheel", 1}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "acb",
        time = 1,
        stack_size = 100
    },
    ["steam-pipe-to-ground"] = {
        ingredients = {{"steam-pipe", 10}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "ad",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["steam-pipe-to-ground-short"] = {
        ingredients = {{"steam-pipe", 5}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "ad",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["pipe"] = {
        ingredients = {{"iron-plate", 2}, {"iron-rivet", 1}},
        enabled = false,
        subgroup = "ir-pipes-2",
        -- order = "ae",
        time = 1,
        stack_size = 100
    },
    ["valve"] = {
        ingredients = {{"pipe", 1}, {"iron-gear-wheel", 1}},
        enabled = false,
        subgroup = "ir-pipes-2",
        -- order = "aeb",
        time = 1,
        stack_size = 100
    },
    ["pipe-to-ground"] = {
        ingredients = {{"pipe", 15}},
        enabled = false,
        subgroup = "ir-pipes-2",
        -- order = "af",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["pipe-to-ground-short"] = {
        ingredients = {{"pipe", 5}},
        enabled = false,
        subgroup = "ir-pipes-2",
        -- order = "af",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["air-pipe"] = {
        ingredients = {{"iron-plate", 1}, {"iron-rivet", 1}},
        enabled = false,
        subgroup = "ir-pipes-2",
        time = 1,
		count = 2,
        stack_size = 100
    },
    ["air-valve"] = {
        ingredients = {{"air-pipe", 1}, {"iron-gear-wheel", 1}},
        enabled = false,
        subgroup = "ir-pipes-2",
        time = 1,
        stack_size = 100
    },
    ["air-pipe-to-ground"] = {
        ingredients = {{"air-pipe", 10}},
        enabled = false,
        subgroup = "ir-pipes-2",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["air-pipe-to-ground-short"] = {
        ingredients = {{"air-pipe", 5}},
        enabled = false,
        subgroup = "ir-pipes-2",
        time = 2,
        count = 2,
        stack_size = 50
    },
    ["small-tank-steam"] = {
        ingredients = {{"copper-rivet", 3}, {"copper-plate", 6}, {"steam-pipe", 1}},
        enabled = true,
        subgroup = "energy-pipe-distribution",
        order = "za",
        time = 2
    },
    ["small-tank"] = {
        ingredients = {{"iron-rivet", 3}, {"iron-plate", 6}, {"pipe", 1}},
        enabled = false,
        subgroup = "energy-pipe-distribution",
        order = "zb",
        time = 2
    },
    ["copper-pump"] = {
        ingredients = {{"copper-plate", 2}, {"copper-rod", 2}, {"copper-pipe", 2}, {"copper-gear-wheel", 2}},
        enabled = true,
        subgroup = "ir-pipes",
        -- order = "c",
        time = 1,
        stack_size = 100
    },
    ["copper-boiler"] = {
        ingredients = {{"stone-brick", 20}, {"copper-pipe", 3}, {"copper-plate", 10}},
        enabled = true,
        subgroup = "energy",
        order = "aaa"
    },
    ["steel-boiler"] = {
        ingredients = {{"concrete-block", 20}, {"pipe", 3}, {"steel-plate", 12}, {"copper-rod",12}},
        enabled = false,
        subgroup = "energy",
        order = "aab"
    },
    ["petro-generator"] = {
        ingredients = {{"concrete-block", 20}, {"engine-unit", 4}, {"iron-plate", 40}, {"copper-coil",8}},
        enabled = false,
        subgroup = "energy",
        order = "z-z",
    },
    ["copper-aetheric-lamp-straight"] = {
        ingredients = {{"steam-pipe", 1}, {"glass", 2}, {"copper-rod", 3}},
        enabled = false,
        subgroup = "ir-lamps",
        order = "aba",
        time = 1,
        stack_size = 100,
        icon = "copper-aetheric-lamp"
    },
    ["solar-array"] = {
        ingredients = {{"solar-panel", 4}, {"computer-mk3", 1}, {"junction-box", 1}},
        enabled = false,
        subgroup = "energy",
        order = "d[solar-panel]-b[solar-array]"
    },
    ["steam-barrelling-machine"] = {
        ingredients = {{"copper-rod",4}, {"steam-pipe", 1}, {"copper-rotor",1}},
        enabled = false,
        subgroup = "production-machine",
        order = "fa",
        time = 2,
    },
    ["barrelling-machine"] = {
        ingredients = {{"iron-frame-small",1}, {"electronic-circuit", 3}, {"iron-motor",1}, {"pipe",1}},
        enabled = false,
        subgroup = "production-machine",
        order = "fb",
        time = 2,
    },
    ["iron-gas-vent"] = {
        ingredients = {{"pipe", 2}, {"iron-rotor",1}},
        enabled = false,
        subgroup = "production-machine",
        order = "fc",
        time = 2
    },
    ["air-compressor"] = {
        ingredients = {{"steel-frame-small",1}, {"advanced-circuit", 3}, {"flying-robot-frame",1}, {"steel-piston",2}},
        enabled = false,
        subgroup = "production-machine",
        order = "fd",
        time = 2,
    },
    ["air-purifier"] = {
        ingredients = {{"air-compressor", 1}, {"iron-gas-vent", 4}},
        enabled = false,
        subgroup = "production-machine",
        order = "fe"
    },
    ["iron-battery-charger"] = {
        ingredients = {{"iron-frame-large", 1}, {"copper-rod", 2}, {"copper-cable-heavy", 1}},
        enabled = false,
        time = 3,
        subgroup = "ir-battery-entities",
        order = "a"
    },
    ["steel-battery-charger"] = {
        ingredients = {{"steel-frame-large", 1}, {"copper-rod", 2}, {"junction-box", 1}},
        enabled = false,
        time = 3,
        subgroup = "ir-battery-entities",
        order = "b"
    },
    ["iron-battery-discharger"] = {
        ingredients = {
            {"iron-frame-large", 1},
            {"copper-coil", 2},
            {"copper-cable-heavy", 1},
        },
        enabled = false,
        time = 3,
        subgroup = "ir-battery-entities",
        order = "c"
    },
    ["steel-battery-discharger"] = {
        ingredients = {
            {"steel-frame-large", 1},
            {"copper-coil", 8},
            {"junction-box", 1},
        },
        enabled = false,
        time = 3,
        subgroup = "ir-battery-entities",
        order = "d",
    },
    ["supermagnet"] = {
        ingredients = {
            {"chromium-frame-large", 1},
            {"carbon-coil", 3},
            {"junction-box", 1},
            {"electrum-plate-special", 8},
        },
        enabled = false,
        time = 5,
        subgroup = "ir-battery-entities",
        order = "e",
    },
    ["scattergun-turret"] = {
        ingredients = {{"copper-plate", 12}, {"copper-motor", 2}, {"tin-plate", 12}, {"tin-gear-wheel", 4}},
        enabled = false,
        subgroup = "defensive-structure",
        order = "b[turret]-a",
        time = 3,
		icon_masks = {base = "scattergun-turret", mask = "scattergun-turret-mask", tint = DIR.get_player_color("orange")},
    },
    ["arc-turret"] = {
        ingredients = {
            {"steel-frame-turret", 1},
            {"copper-coil", 4},
            {"advanced-battery", 1},
            {"copper-cable-heavy", 1}
        },
        enabled = false,
        subgroup = "defensive-structure",
        order = "b[turret]-e",
        time = 6,
		icon_masks = {base = "arc-turret", mask = "arc-turret-mask", tint = DIR.get_player_color("blue")},
    },
    ["rocket-turret"] = {
        ingredients = {{"steel-beam",8},{"brass-gear-wheel",8},{"rocket-launcher",2},{"steel-plate-heavy",24}},
        enabled = false,
        time = 12,
        subgroup = "defensive-structure",
        order = "b[turret]-f",
		icon_masks = {base = "rocket-turret", mask = "rocket-turret-mask", tint = DIR.get_player_color("purple")},
    },
    ["photon-turret"] = {
        ingredients = {{"chromium-frame-turret", 1}, {"advanced-battery", 3}, {"helium-laser", 4}, {"junction-box", 1}},
        enabled = false,
        time = 12,
        subgroup = "defensive-structure",
        order = "b[turret]-g",
		icon_masks = {base = "photon-turret", mask = "photon-turret-mask", tint = DIR.get_player_color("yellow")},
    },
    ["monowheel"] = {
        ingredients = {
            {"copper-frame-small", 1},
            {"copper-engine-unit", 1},
            {"tin-gear-wheel", 8},
            {"tin-rod", 16},
            {"copper-rod", 16}
        },
        enabled = false,
        subgroup = "transport",
        order = "ab",
        type = "item-with-entity-data",
        stack_size = 1
    },
    ["heavy-roller"] = {
        ingredients = {
            {"copper-boiler", 1},
            {"copper-gear-wheel", 16},
            {"bronze-plate-heavy", 40},
            {"bronze-beam", 12},
            {"steam-pipe", 4}
        },
        enabled = false,
        subgroup = "transport",
        order = "ac",
        type = "item-with-entity-data",
        stack_size = 1
    },
    ["heavy-picket"] = {
        ingredients = {
            {"field-effector", 12},
            {"chromium-frame-large", 1},
            {"chromium-plate-heavy", 80},
            {"electrum-plate-special", 36},
            {"chromium-engine-unit", 8}
        },
        enabled = false,
        subgroup = "transport",
        order = "ad",
        type = "item-with-entity-data",
        stack_size = 1
    },
    ["chrome-transmat"] = {
        ingredients = {
            {"accumulator", 4},
            {"junction-box", 1},
            {"computer-mk3", 1},
            {"quantum-ring", 1},
            {"electrum-plate-special", 18}
        },
        enabled = false,
        subgroup = "train-transport",
		category = "crafting",
        order = "z"
    },
    -- ["iron-flare-stack"] = {
        -- ingredients = {{"iron-frame-small", 1}, {"pipe", 4}, {"copper-cable", 1}, {"iron-stick", 16}},
        -- enabled = false,
        -- subgroup = "production-machine",
        -- order = "f[a-flare-stack]"
    -- },
	["gun-turret"] = {
		ingredients = {{"iron-beam",8},{"iron-motor",2},{"iron-gear-wheel",16},{"iron-plate-heavy",10}},
        enabled = false,
        subgroup = "defensive-structure",
        order = "b[turret]-b",
		icon_masks = {base = "autogun-turret", mask = "autogun-turret-mask", tint = DIR.get_player_color("green")},
	},
	["laser-turret"] = {
		ingredients = {{"steel-frame-turret",1},{"helium-laser",1},{"advanced-battery",1},{"copper-cable-heavy",1}},
        enabled = false,
        subgroup = "defensive-structure",
        order = "b[turret]-d",
		icon_masks = {base = "laser-turret", mask = "laser-turret-mask", tint = DIR.get_player_color("red")},
	},
    ["small-assembler-1"] = {
        ingredients = {
            {"copper-frame-small", 1},
            {"copper-motor", 1},
            {"copper-piston", 2},
            {"steam-pipe", 2},
        },
        enabled = false,
        subgroup = "ir-machines-production",
		order = "ae",
		time = 2,
    },
    ["small-assembler-2"] = {
        ingredients = {
            {"iron-frame-small", 1},
            {"iron-motor", 1},
            {"iron-piston", 3},
            {"electronic-circuit", 3}
        },
        enabled = false,
        subgroup = "ir-machines-production",
		order = "af",
		time = 2,
    },
    ["small-assembler-3"] = {
        ingredients = {
            {"steel-frame-small", 1},
            {"electric-engine-unit", 1},
            {"steel-piston", 3},
            {"advanced-circuit", 3}
        },
        enabled = false,
        subgroup = "ir-machines-production",
		order = "ag",
		time = 2,
    },
    ["steel-cryo-tower"] = {
        ingredients = {
            {name = "flying-robot-frame", type = "item", amount = 4},
            {name = "steel-frame-large", type = "item", amount = 1},
            {name = "glass", type = "item", amount = 40},
            {name = "copper-heatsink", type = "item", amount = 4},
        },
		category = "crafting",
        enabled = false,
        subgroup = "production-machine",
		order = "g",
		time = 3,
    },
    ["steel-vaporiser"] = {
        ingredients = {
            {name = "steel-frame-small", type = "item", amount = 1},
            {name = "pipe", type = "item", amount = 2},
            {name = "steel-rivet", type = "item", amount = 2},
            {name = "copper-heatsink", type = "item", amount = 1},
        },
        enabled = false,
        subgroup = "production-machine",
		order = "h",
		time = 2,
    },
    ["iron-geothermal-exchanger"] = {
        ingredients = {
            {"iron-frame-small", 2},
            {"pipe", 4},
            {"iron-motor", 4},
            {"steam-pipe", 6}
        },
        enabled = false,
        subgroup = "ir-machines-processing",
		time = 3,
    },
    ["copper-derrick"] = {
        ingredients = {
			{"copper-beam",12},
			{"steam-pipe",8},
			{"tin-plate",12},
			{"copper-piston",4},
        },
        enabled = true,
        subgroup = "ir-machines-resources",
		order = "cb",
        time = 3,
    },
    ["steel-derrick"] = {
        ingredients = {
			{"steel-beam",18},
			{"pipe",8},
			{"steel-plate-heavy",12},
			{"steel-piston",8},
        },
        enabled = false,
        subgroup = "ir-machines-resources",
		order = "cc",
        time = 3,
    },
    ["laser-assembler"] = {
        ingredients = {
			{name = "assembling-machine-3", type = "item", amount = 1}, 
			{name = "ruby-laser", type = "item", amount = 2}, 
			{name = "flying-robot-frame", type = "item", amount = 4},
        },
        enabled = false,
        subgroup = "ir-machines-production",
		order = "ad",
        time = 8,
    },
    ["module-loader"] = {
        ingredients = {
			{name = "computer-mk1", type = "item", amount = 3}, 
			{name = "copper-cable", type = "item", amount = 6}, 
			{name = "rubber", type = "item", amount = 2}, 
			{name = "iron-rivet", type = "item", amount = 2}, 
        },
        enabled = false,
        subgroup = "ir-machines-labs",
		order = "y",
        time = 3,
    },
    ["transfer-plate-2x2"] = {
        ingredients = {{"tin-plate", 2},{"tin-rod",2}},
        enabled = false,
        subgroup = "storage",
        order = "za",
        time = 2,
    },
    ["transfer-plate"] = {
        ingredients = {{"tin-plate", 4},{"tin-rod",4}},
        enabled = false,
        subgroup = "storage",
        order = "zb",
        time = 2,
		icon = "transfer-plate-3x3",
    },
    ["ir3-linked-filter-chest"] = {
        ingredients = {{"steel-chest", 1}},
        enabled = false,
        subgroup = "cheats",
        order = "z",
        time = 2,
		icon = "special-chest",
		hidden = true,
		result_overlay = "placeholder",
    },
    ["pipe-to-ground-massive"] = {
        ingredients = {{"pipe", 1}},
        enabled = false,
        subgroup = "cheats",
        -- order = "af",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		icon = "pipe-to-ground",
    },
    ["copper-pipe-to-ground-massive"] = {
        ingredients = {{"copper-pipe", 1}},
        enabled = false,
        subgroup = "cheats",
        -- order = "af",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		icon = "copper-pipe-to-ground",
    },
    ["steam-pipe-to-ground-massive"] = {
        ingredients = {{"steam-pipe", 1}},
        enabled = false,
        subgroup = "cheats",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		icon = "steam-pipe-to-ground",
    },
    ["air-pipe-to-ground-massive"] = {
        ingredients = {{"air-pipe", 1}},
        enabled = false,
        subgroup = "cheats",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		icon = "air-pipe-to-ground",
    },
    ["ir3-linked-belt-yellow"] = {
        ingredients = {{"transport-belt", 1}},
        enabled = false,
        subgroup = "cheats",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		use_vanilla_icon = true,
		icon = "underground-belt",
    },
    ["ir3-linked-belt-red"] = {
        ingredients = {{"transport-belt", 1}},
        enabled = false,
        subgroup = "cheats",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		use_vanilla_icon = true,
		icon = "fast-underground-belt",
    },
    ["ir3-linked-belt-blue"] = {
        ingredients = {{"transport-belt", 1}},
        enabled = false,
        subgroup = "cheats",
        time = 2,
        count = 2,
        stack_size = 50,
		hidden = true,
		result_overlay = "placeholder",
		use_vanilla_icon = true,
		icon = "express-underground-belt",
    },
}

for _,tree in pairs(DIR.plantable_trees) do
	local wood = (tree == "ir-rubber-tree") and "rubber-wood" or "wood"
    machines["tree-planter-"..tree] = {
        ingredients = {{"stone-brick", 8}, {wood, 12}}, -- must be in short format (see entities-decorative)
        enabled = false,
        subgroup = "ir-trees",
        time = 3,
		icon = ((tree == "ir-rubber-tree") and "tree-08" or tree) .. "-bed",
		result_overlay = wood,
    }
end

return machines


-- retired
-- ["steel-storage-depot"] = {ingredients = {{"steel-beam",12}, {"steel-plate-heavy",24},{"steel-rivet",4}}, enabled = false, subgroup = "storage", order = "a[items]-e"},
-- ["steel-logistics-depot-active"] = {ingredients = {{"steel-storage-depot",1}, {"advanced-circuit",4}, {"electric-engine-unit",1}}, enabled = false, subgroup = "logistic-network"},
-- ["steel-logistics-depot-passive"] = {ingredients = {{"steel-storage-depot",1}, {"advanced-circuit",4}, {"electric-engine-unit",1}}, enabled = false, subgroup = "logistic-network"},
-- ["steel-logistics-depot-storage"] = {ingredients = {{"steel-storage-depot",1}, {"advanced-circuit",4}, {"electric-engine-unit",1}}, enabled = false, subgroup = "logistic-network"},
-- ["steel-logistics-depot-buffer"] = {ingredients = {{"steel-storage-depot",1}, {"processing-unit",4}, {"electric-engine-unit",1}}, enabled = false, subgroup = "logistic-network"},
-- ["steel-logistics-depot-requester"] = {ingredients = {{"steel-storage-depot",1}, {"processing-unit",4}, {"electric-engine-unit",1}}, enabled = false, subgroup = "logistic-network"},
