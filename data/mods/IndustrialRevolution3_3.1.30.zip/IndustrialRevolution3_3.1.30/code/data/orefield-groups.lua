return {
	COPPER = 4,
	GOLD = 2,
	IRON = 6,
	TIN = 3,
	LEAD = 2,
	NICKEL = 3,
	CHROMIUM = 2,
	URANIUM = 2,
	METEOR = 1,
}