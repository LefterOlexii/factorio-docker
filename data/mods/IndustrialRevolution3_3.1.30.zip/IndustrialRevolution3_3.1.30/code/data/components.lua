------------------------------------------------------------------------------------------------------------------------------------------------------

-- COMPONENTS

local main_metals = {}
local metals = {}
local non_alloy_main_metals = {}
for material,materialdata in pairs(DIR.materials) do
	if materialdata.metal then
		table.insert(metals, material)
		if not DIR.is_value_in_list({"gold","platinum","nickel","nichrome"}, material) then
			table.insert(main_metals, material)
			if not materialdata.alloy then table.insert(non_alloy_main_metals, material) end
		end
	end
end

local main_components = main_metals
local natural_metals = {"copper","tin","iron","gold","uranium","lead","nickel","chromium","platinum"}
local natural_metals_with_ingots = {"copper","tin","iron","gold","lead"}
local main_ores = {"copper","tin","iron","gold"}
local natural_ores_metals = {"copper","tin","iron","gold","uranium"}
local natural_ores = DIR.append_list({"carbon","stone"}, natural_ores_metals)
local ingots = DIR.append_list({"carbon","bitumen","glass","nanoglass","plastic","stone","steel","bronze","platinum","nickel","brass","chromium"}, natural_metals_with_ingots)
local moltens = {"copper","tin","bronze","iron","gold","lead","steel","nickel","brass","platinum","chromium"}

table.sort(main_metals)
table.sort(natural_metals)
table.sort(ingots)

local explosives = {}
for i=1,7 do table.insert(explosives, "stronger-explosives-"..i) end
for i=1,4 do table.insert(explosives, "ir-photon-turret-damage-"..i) end

local hundredpercent = 1.0000000001

local molten_made_from = {
	-- clean = { amount = 1, result = DIR.molten_to_ingot_ratio * DIR.arc_furnace_raw_multiplier},
	pure = { amount = 4, result = DIR.molten_to_ingot_ratio * DIR.arc_furnace_raw_multiplier * 4},
	ingot = { amount = 12, result = DIR.molten_to_ingot_ratio * 12},
	scrap = { amount = 12 / DIR.scrap_divider, result = DIR.molten_to_ingot_ratio * 12},
}

local molten_alloys_made_from = {
	mix = { amount = 0, result = DIR.molten_to_ingot_ratio * 12},
	ingot = { amount = 12, result = DIR.molten_to_ingot_ratio * 12 },
	scrap = { amount = 12 / DIR.scrap_divider, result = DIR.molten_to_ingot_ratio * 12},
	molten = { amount = 0, result = DIR.molten_to_ingot_ratio * 12 }
}

return {
	["ore"] = {
		type = "item",
		order = "aa",
		materials = DIR.append_list({"wood","rubber","sulphur"}, natural_ores),
		name_overrides = {		
			carbon = "coal",
			rubber = "rubber-wood",
			stone = "stone",
			sulphur = "sulfur",
			wood = "wood",
		},
		start = true,
		skip_scan = true,
		speed = DIR.standard_smelting_time,
		scale_speed = false,
		category = "smelting",
		crafting_category_exceptions = {
			sulphur = "chemistry",
		},
		made_from_exceptions = {
			sulphur = {
				gas = { amount = 20, result = 2 },
			},
		},
		bonus_results = {
			sulphur = { ["water"] = 10, ["carbon-gas"] = 5 },
		},
		category_results_icon_ignore = false,
		speed_exceptions = {
			sulphur = DIR.standard_crafting_time * 4,
		},
		belt_variations = 6,
		belt_variation_exceptions = {
			wood = 1,
			rubber = 1,
			sulphur = 1,
			uranium = 4,
		},
		belt_variation_lights = {
			uranium = true,
		},
		use_vanilla_icons = {
			sulphur = true,
			uranium = true,
		},
		subgroup = "ore",
		item_subgroup = "ore",
		item_subgroup_exceptions = {
			wood = "natural",
			rubber = "natural",
		},
		subgroup_exceptions = {
			wood = "wood",
			rubber = "wood",
			sulphur = "ir-fluid-recipes",
		},
		tabgroup = "ir-processing",
		productivity = false,
		productivity_material_exceptions = {
			sulphur = true,
		},
		fuel_values = {
			carbon = { multiplier = 1 },
			wood = { multiplier = 0.5 },
			rubber = { multiplier = 0.375, emissions_multiplier = 1.25 },
		},
		order_exceptions = {
			sulphur = "s",
		},
		rotate_icon_variants = {
			copper = true,
			tin = true,
			iron = true,
			gold = true,
			carbon = true,
			stone = true,
		},
	},
	["crushed"] = {
		type = "item",
		order = "b",
		materials = DIR.append_list({"stone","carbon"}, natural_ores_metals),
		name_overrides = {
			stone = "gravel",
			uranium = "uranium-238",
		},
		skip_scan = true,
		speed = DIR.standard_smelting_time/2,
		scale_speed = false,
		category = "grinding",
		made_from = {
			ore = { amount = 1, result = 1 },
		},
		made_from_exceptions = {
			stone = {
				ore = { amount = 1, result = 2 },
			},
		},
		no_recipe = {
			uranium = true,
		},
		tabgroup = "ir-processing",
		subgroup_exceptions = {
			uranium = "pure",
		},
		item_subgroup_exceptions = {
			uranium = "ir-fuels",
		},
		productivity = true,
		use_vanilla_icons = {
			uranium = true,
		},
		belt_variations = 4,
		belt_variation_exceptions = {
			uranium = 1,
		},
		fuel_values = {
			carbon = { multiplier = 1, emissions_multiplier = 0.75, category = "chemical" },
		},
	},
	["ingot"] = {
		type = "item",
		order = "in",
		materials = ingots,
		name_overrides = {
			carbon = "solid-fuel",
			glass = "glass",
			nanoglass = "nanoglass",
			plastic = "plastic-bar",
			stone = "stone-brick",
			bitumen = "bitumen",
		},
		start = true,
		speed = DIR.standard_smelting_time,
		scale_speed = true,
		category = "smelting",
		do_not_decompose = true,
		do_not_decompose_exceptions = {
			stone = false,
		},
		no_recipe = {
			bitumen = true, -- made in oil chain
		},
		made_from = {
			ore = { amount = 1, result = 1 },
			crushed = { amount = 1, result = 1.5 },
			pure = { amount = 1, result = 2 },
			mix = { amount = 0, result = 12 },
			scrap = { amount = 1, result = DIR.scrap_divider },
			molten = { amount = DIR.molten_to_ingot_ratio, result = 1},
		},
		made_from_exceptions = {
			glass = {
				mix = { amount = 0, result = 24 },
				scrap = { amount = 1, result = 2 * DIR.scrap_divider },
			},
			nanoglass = {
				ingot = { amount = 0, result = 1 },
			},
			plastic = {
				ingot = { amount = 0, result = 2 }, -- plastic bar
			},
			stone = {
				ore = { amount = 1, result = 1 }, -- brick
			},
			carbon = {
				crushed = { amount = 1, result = 1 }, -- coke / solid fuel
			},
		},
		made_from_quaternary = {
			ingot = {
				plastic = { ["steam"] = 20, ["petroleum-gas"] = 20 },
				nanoglass = { ["glass"] = 1, ["carbon-foil"] = 2 },
			},
			mix = {
				bronze = { ["copper-ingot"] = 8, ["tin-ingot"] = 4 }, -- alloy
				steel = { ["iron-ingot"] = 12, ["solid-fuel"] = 1 }, -- alloy
				brass = { ["bronze-ingot"] = 10, ["lead-ingot"] = 2 }, -- alloy
				glass = { ["silica"] = 9, ["tin-ingot"] = 3 }, -- glass
			},			
		},
		always_show_source_overlay = {
			mix = true,
		},
		force_overlay_for_material = {
			plastic = true,
		},
		duplications = {
			-- {
				-- materials = {bronze = true},
				-- affix = "primitive",
				-- category = "alloying",
				-- add_results = {
					-- { name = "copper-scrap", type = "item", amount = 1, probability = 0.5 },
					-- { name = "tin-scrap", type = "item", amount = 1, probability = 0.25 },
				-- },
				-- result_probability = 1,
				-- result_multiplier = 0.5,
				-- subgroup = "ingots-2",
				-- strip_numeric_suffix = true,
				-- ignore_sources = { scrap = true },
				-- enabled = false,
				-- productivity = false,
			-- },
			{
				materials = {iron = true, copper = true},
				affix = "blast",
				category = "smelting",
				add_ingredient = { name = "air-gas", type = "fluid", amount = DIR.gas_per_ingot },
				add_result = { name = "carbon-gas", type = "fluid", amount = DIR.gas_per_ingot },
				result_probability = 1,
				subgroup = "blast-smelting",
				strip_numeric_suffix = true,
				ignore_sources = { scrap = true },
				enabled = false,
				productivity = false,
			},
			{
				materials = {steel = true},
				affix = "blast",
				category = "alloying",
				add_ingredient = { name = "air-gas", type = "fluid", amount = DIR.gas_per_ingot * 12 },
				add_result = { name = "carbon-gas", type = "fluid", amount = DIR.gas_per_ingot * 12 },
				remove_ingredient = "solid-fuel",
				result_probability = 1,
				subgroup = "blast-smelting",
				strip_numeric_suffix = true,
				ignore_sources = { scrap = true },
				resource_multiplier = 1/12,
				speed_multiplier = 1/12,
				productivity = false,
			},
			{
				materials = {plastic = true},
				affix = "from-ethanol",
				category = "chemistry",
				replace_category = "chemistry",
				replace_ingredients = { ["petroleum-gas"] = "ethanol" },
				add_ingredient = { name = "platinum-pellet", type = "item", amount = 1 },
				result_probability = 1,
			},
		},
		-- bonus_results = {
			-- bronze = {},
		-- },
		source_emissions_multiplier = {
			ore = 1.25,
			crushed = hundredpercent,
			mix = 0.5,
			pure = 0.75,
			scrap = 0.5,
		},
		specific_emissions_multiplier = {
			["steel-ingot"] = hundredpercent,
			["stone-brick"] = 1,
			["solid-fuel"] = hundredpercent,
			["solid-fuel-from-crushed"] = 0.75,
		},
		crafting_category_exceptions = {
			stone = "crafting-small",
			plastic = "chemistry",
			carbon = "smelting-3", -- coke has to be restricted to electric furnaces because coal is already a fuel
			nanoglass = "laser-crafting",
		},
		material_category_exceptions = {
			glass = {
				mix = "alloying",
			},
			bronze = {
				mix = "alloying",
			},
			brass = {
				mix = "alloying-2",
			},
			steel = {
				mix = "alloying-3",
			},
		},
		source_category_exceptions = {
			molten = "ingot-casting",
		},
		speed_exceptions_from_source = {
			molten = DIR.standard_crafting_time,
		},
		speed_exceptions = {
			glass = DIR.standard_smelting_time / 2,
			nanoglass = DIR.standard_crafting_time * 2,
			plastic = DIR.standard_crafting_time,
			stone = DIR.standard_crafting_time,
		},
		tabgroup = "ir-processing",
		subgroup = "ingots",
		item_subgroup = "ingots",
		subgroup_exceptions = {
			copper = "ingots-1",
			tin = "ingots-1",
			bronze = "ingots-2",
			glass = "ingots-2",
			iron = "ingots-2",
			gold = "ingots-3",
			steel = "ingots-3",
			brass = "ingots-3",
			lead = "ingots-4",
			nickel = "ingots-4",
			chromium = "ingots-4",
			platinum = "ingots-4",
			plastic = "ingots-3",
			stone = "beam",
			carbon = "wood",
			nanoglass = "ir-electronics-2",
		},
		item_subgroup_exceptions = {
			stone = "beam",
			carbon = "ir-fuels",
		},
		tabgroup_source_exceptions = {
			molten = "ir-molten",
		},
		subgroup_source_exceptions = {
			molten = "ir-ingot-from-molten",
		},
		order_exceptions = {
			stone = "aa",
			plastic = "z",
			carbon = "zzzza",
			bitumen = "zzzzb",
			nanoglass = "z",
		},
		ignore_category_order_prefix = {
			carbon = true,
			bitumen = true,
		},
		no_affix = {
			ore = true,
			mix = true,
			ingot = true,
		},
		productivity = false,
		productivity_source_exceptions = {
			ore = true,
			crushed = true,
			pure = true,
			mix = true,
		},
		productivity_material_exceptions = { 
			stone = false, -- 3.1.28 due to scrapping exploit
			plastic = true,
		},
		tile_walking_speed = {
			stone = 1.2,
		},
		fuel_values = {
			carbon = { multiplier = 1.5, emissions_multiplier = 0.75, category = "coke" },
		},
		belt_variation_exceptions = {
			carbon = 4,
		},
		start_exceptions = {
			carbon = false,
		},
		brightness_variations = true,
	},
	["powder"] = {
		type = "item",
		order = "ca",
		materials = {"stone","ruby","diamond","carbon"},
		name_overrides = {
			stone = "silica",
			carbon = "graphitic-coke",
			-- bitumen = "bituminous-sand",
		},
		skip_scan = true,
		speed = DIR.standard_smelting_time / 2,
		scale_speed = false,
		category = "grinding",
		made_from = {
			ingot = { amount = 1, result = 1 },
		},
		no_affix = {
			crushed = true,
		},
		no_recipe = {
			bitumen = true,
		},
		made_from_exceptions = {
			stone = {
				crushed = { amount = 1, result = 2 },
			},
			diamond = {
				gem = { amount = 1, result = 2 },
			},
			ruby = {
				gem = { amount = 1, result = 2 },
			},
			carbon = {
				ingot = { amount = 1, result = 2 },
				powder = { amount = 0, result = 2 },
			},
		},
		made_from_quaternary = {
			ingot = {
				carbon = { ["heavy-oil"] = 10 },
			},
			powder = {
				carbon = { ["solid-fuel"] = 1, ["bitumen"] = 1 },
			},
		},
		crafting_category_exceptions = {
			carbon = "mixing",
		},
		allow_as_intermediate = {
			diamond = false,
			ruby = false,
		},
		order_exceptions = {
			stone = "b",
			carbon = "z",
		},
		subgroup_exceptions = {
			carbon = "crushed",
		},
		tabgroup = "ir-processing",
		productivity = false,
		productivity_material_exceptions = {
			stone = true,
		},
		belt_variations = 4,
		rotate_icon_variants = {
			-- stone = true,
			-- ruby = true,
			-- diamond = true,
		},
		fuel_values = {
			carbon = { multiplier = 0.75, emissions_multiplier = 1.25, category = "coke" },
		},
	},
	["pure"] = {
		type = "item",
		order = "cb",
		materials = DIR.append_list({"wood","stone","carbon","electrum"}, natural_metals),
		name_overrides = {
			carbon = "graphite",
			electrum = "electrum-gem-charged",
			stone = "silicon",
			wood = "charcoal",
			uranium = "uranium-235",
		},
		skip_scan = true,
		speed = DIR.standard_smelting_time/4,
		scale_speed = false,
		category = "washing",
		show_non_source_ingredients = false,
		ignore_source_overlay = {"crushed","pure","mix"},
		no_overlay = {
		    pure = true,
		    gem = true,
		},
		no_affix = {
			pure = true,
		},
		no_recipe = {
			uranium = true,
		},
		strict_ingredient_overlay = {
			stone = {
				mix = "silicon-mix",
			},
		},
		made_from = {
			crushed = { amount = 1, result = 1 },
		},
		made_from_exceptions = {
			carbon = { -- graphite
				powder = { amount = 1, result = 1 },
			},
			stone = { -- silicon
				mix = { amount = 0, result = 12 }, 
			},
			wood = { -- charcoal
				ore = { amount = 25, result = 25 },
				scrap = { amount = 50, result = 25 },
			},
			electrum = {
				gem = { amount = 1, result = 1 }, -- charged cystal
			},
		},
		made_from_category = {
			["washing"] = { ["water"] = DIR.washing_base },
		},
		made_from_category_maximum_temperature = 60,
		made_from_tertiary = {
			stone = { ["silica"] = 12, ["solid-fuel"] = 1 }, -- silicon
		},
		made_from_quaternary = {
			gem = {
				electrum = { ["helium-fluid"] = 40 },
			},
		},
		bonus_results = {
			copper = { 
				["nickel-pure"] = 0.1,
			},
			tin = {
				["lead-pure"] = 0.1,
			},
			iron = {
				["chromium-pure"] = 0.1,
			},
			gold = {
				["platinum-pure"] = 0.1,
			},
			electrum = {
				["helium-gas"] = 40 / DIR.liquified_gas_ratio,
			},
		},
		mark_bonus_results_as_non_provider = true,
		duplications = {
			{
				affix = "advanced",
				category = "washing",
				replace_ingredients = { water = "water" },
				result_probability = 1,
				byproduct_probability_multiplier = 5,
				minimum_temperature = 60,
			},
			{
				materials = {stone = true},
				affix = "blast",
				category = "multi-smelting",
				add_ingredient = { name = "air-gas", type = "fluid", amount = DIR.gas_per_ingot * 12 },
				add_result = { name = "carbon-gas", type = "fluid", amount = DIR.gas_per_ingot * 12 },
				remove_ingredient = "solid-fuel",
				result_probability = 1,
				subgroup = "blast-smelting",
				strip_numeric_suffix = true,
				ignore_sources = { scrap = true },
				resource_multiplier = 1/12,
				speed_multiplier = 1/12,
				productivity = false,
			},
		},
		category_results_secondary = {
			["washing"] = { name = "dirty-water", type = "fluid", amount = DIR.washing_base, catalyst_amount = DIR.washing_base },
			["advanced-washing"] = { name = "dirty-water", type = "fluid", amount = DIR.washing_base, catalyst_amount = DIR.washing_base},
		},
		fuel_values = {
			wood = { multiplier = 1, emissions_multiplier = 0.5 },
		},
		belt_variations = 4,
		use_vanilla_icons = {
			uranium = true,
		},
		belt_variation_exceptions = {
			stone = 1, -- silicon
			uranium = 1,
			electrum = 1, -- charged cystal
		},
		belt_variation_lights = {
			uranium = true,
		},
		tabgroup = "ir-processing",
		subgroup_exceptions = {
			wood = "wood",
			stone = "ingots-4",
			carbon = "ingots-4",
			electrum = "powder",
		},
		item_subgroup_exceptions = {
			stone = "ingots",
			carbon = "ingots",
			wood = "natural",
			uranium = "ir-fuels",
		},
		crafting_category_exceptions = {
			wood = "charcoal-kiln",
			stone = "multi-smelting",
			carbon = "smelting-3",
			electrum = "supermagnet",
		},
		order_exceptions = {
			stone = "za",
			carbon = "zc",
			wood = "b",
			electrum = "zzz",
		},
		specific_emissions_multiplier = {
			["graphite"] = hundredpercent,
			["silicon"] = hundredpercent,
		},
		speed_exceptions = {
			wood = DIR.standard_smelting_time * 25,
			stone = DIR.standard_smelting_time * 12,
			carbon = DIR.standard_smelting_time,
			electrum = DIR.standard_crafting_time * 120,
		},
		productivity = true,
		productivity_material_exceptions = {
			wood = false,
			electrum = false,
		},
	},
	["fluid"] = {
		type = "fluid",
		order = "z",
		materials = {"water","dirty-water","concrete","natural","nitrates","high-octane","bitumen"},
		name_overrides = {
			water = "water",
			["dirty-water"] = "dirty-water",
			natural = "ethanol",
			nitrates = "liquid-fertiliser",
		},
		speed = DIR.standard_crafting_time,
		speed_exceptions = {
			natural = DIR.standard_crafting_time * 10,
			nitrates = DIR.standard_crafting_time * 6,
			concrete = DIR.standard_crafting_time * 5,
			["high-octane"] = DIR.standard_crafting_time * 6,
			water = DIR.standard_crafting_time * 2,
			["dirty-water"] = DIR.standard_crafting_time * 2,
			bitumen = DIR.standard_petro_time,
		},
		skip_scan = true,
		do_not_decompose = true,
		show_non_source_ingredients = false,
		-- no_recipe = {
			-- water = true,
			-- ["dirty-water"] = true,
		-- },
		no_affix = {
			fluid = true,
		},
		made_from_exceptions = {
			natural = {
				fluid = { amount = 0, result = 100 },
				gas = { amount = 100, result = 100 },
			},
			nitrates = {
				fluid = { amount = 0, result = 120 }, -- fertiliser
			},
			concrete = {
				fluid = { amount = 0, result = 100 },
				scrap = { amount = 10, result = 100 },
			},
			["high-octane"] = {
				fluid = { amount = 0, result = 120 },
			},
			water = {
				gas = { amount = 40, result = 40 },
			},
			["dirty-water"] = {
				gas = { amount = 40, result = 40 },
			},
			bitumen = {
				ingot = { amount = 3, result = 60 },
				-- powder = { amount = 4, result = 60 },
			},
		},
		made_from_quaternary = {
			fluid = {
				natural =  { ["water"] = 80, ["sulfuric-acid"] = 20, ["wood-chips"] = 20 }, -- ethanol
				concrete =  { ["water"] = 100, ["gravel"] = 10, ["silica"] = 10 },
				nitrates = { ["ammonia-gas"] = 60, ["water"] = 120, ["platinum-pellet"] = 1 }, -- fertiliser
				["high-octane"] =  { ["petroleum-gas"] = 90, ["ethanol"] = 30 },
			},
			gas = {
				natural =  { ["water"] = 100, ["nickel-pellet"] = 1 }, -- ethanol
			},
			scrap = {
				concrete = { ["water"] = 100, },
			},
			ingot = {
				bitumen = { ["petroleum-gas"] = 30 },
			},
			-- powder = {
				-- bitumen = { ["petroleum-gas"] = 30 },
			-- },
		},
		quaternary_catalyst_amounts = {
			["petroleum-gas"] = 30,
		},
		bonus_results_from_source = {
			powder = { ["silica"] = 1 },
		},
		mark_bonus_results_as_non_provider = true,
		strict_ingredient_overlay = {
			natural = {
				fluid = "wood-chips",
				gas = "natural-gas",
			},
			concrete = {
				fluid = "silica",
				scrap = "concrete-scrap",
			},
		},
		category = "chemistry",
		crafting_category_exceptions = {
			concrete = "mixing",
			natural = "chemistry",
			water = "cooling",
			["dirty-water"] = "cooling",
		},
		tabgroup = "ir-processing",
		subgroup = "ir-fluid-recipes",
		subgroup_exceptions = {
			concrete = "crushed",
			-- ["high-octane"] = "ir-fluid-recipes",
			-- natural = "ir-fluid-recipes",
			-- nitrates = "ir-fluid-recipes",
			water = "ir-gas",
			["dirty-water"] = "ir-gas",
			bitumen = "fluid-recipes",
		},
		order_exceptions = {
			concrete = "zzz",
			natural = "zb",
			nitrates = "z",
			water = "a",
			["dirty-water"] = "a",
			["high-octane"] = "zc",
			bitumen = "o8",
		},
		item_order_exceptions = {
			nitrates = "z-c",
		},
		item_subgroup = "fluid",
		productivity = true,
		productivity_material_exceptions = {
			["high-octane"] = false,
			water = false,
			["dirty-water"] = false,
			bitumen = false,
		},
		productivity_source_exceptions = {
			scrap = false, -- 3.1.28 due to scrapping exploit
		},
		auto_barrel = true,
		auto_barrel_exceptions = {
			["high-octane"] = false,
		},
		fuel_values = {
			natural = { multiplier = DIR.hydrogen_component_fuel_modifier, emissions_multiplier = 0.5 },
			["high-octane"] = { multiplier = DIR.hydrogen_component_fuel_modifier * 1.5, emissions_multiplier = 1 },
		},
		specific_emissions_multiplier = {
			["bitumen-fluid"] = 1.25,
		},
		fluid_temperature_properties = {
			water = {
				max_temperature = 100,
				heat_capacity = "0.2KJ",
			},
			["dirty-water"] = {
				max_temperature = 100,
				heat_capacity = "0.2KJ",
			},
		},
		fluid_hue_exceptions = {
			natural = 0.425
		},
		fluid_saturation_exceptions = {
			natural = 0.4, 
		},
		material_hide_from_player_crafting = {
			water = true,
			["dirty-water"] = true,
		},
		crafting_tint_override = {
			bitumen = DIR.get_crafting_tints_from_hues(0.333,DIR.hues.magenta,DIR.hues.violet,DIR.hues.magenta,DIR.hues.violet,0.75,0.5),
		},
	},
	["acid"] = {
		type = "fluid",
		order = "z",
		materials = {"sulphur"},
		name_overrides = {
			sulphur = "sulfuric-acid",
		},
		speed = DIR.standard_crafting_time * 6,
		skip_scan = true,
		do_not_decompose = true,
		show_non_source_ingredients = false,
		made_from = {
			ore = { amount = 3, result = 60 },
		},
		made_from_tertiary = {
			sulphur = { ["water"] = 60, ["iron-pellet"] = 1 },
		},
		category = "chemistry",
		tabgroup = "ir-processing",
		subgroup = "ir-fluid-recipes",
		order_exceptions = {
			sulphur = "sa",
		},
		item_subgroup = "fluid",
		productivity = true,
		auto_barrel = true,
	},
	["gas"] = {
		type = "fluid",
		gas_temperature = -250,
		auto_barrel = false,
		order = "z",
		materials = {"water","dirty-water","sulphur","hydrogen","oxygen","nitrogen","helium","natural","carbon","air","ammonia","fossil"},
		name_overrides = {
			["dirty-water"] = "dirty-steam",
			water = "steam",
		},
		speed = DIR.standard_smelting_time / 2,
		speed_exceptions = {
			nitrates =  DIR.standard_crafting_time * 6,
			helium = DIR.standard_smelting_time / 20,
		},
		scale_speed = false,
		category = "chemistry",
		skip_scan = true,
		do_not_decompose = true,
		show_non_source_ingredients = false,
		made_from = {
			cryofluid = { amount = 40 * DIR.liquified_gas_ratio, result = 40 },
		},
		no_affix = {
			gas = true,
		},
		no_overlay = {
			gas = true,
		},
		made_from_exceptions = {
			ammonia = {
				gas = { amount = 0, result = 60 }, 
			},
			helium = {
				cryofluid = { amount = 4 * DIR.liquified_gas_ratio, result = 4 },
			},
		},
		made_from_quaternary = {
			gas = {
				ammonia = { ["hydrogen-gas"] = 90, ["nitrogen-gas"] = 30, ["iron-pellet"] = 1 }, -- ammonia
			},
		},
		no_recipe = {
			air = true,
			water = true,
			["dirty-water"] = true,
			sulphur = true,
			fossil = true,
		},
		source_category_exceptions = {
			cryofluid = "heating",
		},
		source_hide_from_player_crafting = {
			cryofluid = {
				oxygen = true,
				hydrogen = true,
				nitrogen = true,
				helium = true,
				carbon = true,
				natural = true,
			},
		},
		tabgroup = "fluids",
		subgroup = "ir-fluid-recipes",
		subgroup_exceptions = {
			oxygen = "ir-gas",
			hydrogen = "ir-gas",
			nitrogen = "ir-gas",
			helium = "ir-gas",
			carbon = "ir-gas",
			natural = "ir-gas",
		},
		order_exceptions = {
			wood = "ab",
			carbon = "z-ze-zz",
			water = "a-b",
		},
		item_subgroup = "gas",
		productivity = false,
		fluid_temperature_properties = {
			water = {
				max_temperature = 1000,
				heat_capacity = "0.2KJ",
			},
			["dirty-water"] = {
				max_temperature = 1000,
			},
			air = {
				max_temperature = 1000,
			},
		},
		fuel_values = {
			natural = { multiplier = DIR.hydrogen_component_fuel_modifier, emissions_multiplier = 0.75 },
		},
		fluid_saturation_exceptions = {
			water = 0.000001, -- not 0 because false
		},
	},
	["molten"] = {
		type = "fluid",
		order = "ia",
		materials = moltens,
		scale_speed = true,
		category = "melting",
		gas_temperature = 2000,
		skip_scan = true,
		show_non_source_ingredients = true,
		do_not_decompose = true,
		made_from = molten_made_from,
		made_from_exceptions = {
			bronze = molten_alloys_made_from,
			steel = molten_alloys_made_from,
			brass = molten_alloys_made_from,
		},
		made_from_category = {
			["melting-with-gas"] = { ["oxygen-gas"] = DIR.gas_per_ingot * DIR.arc_furnace_raw_multiplier },
		},
		speed = DIR.standard_smelting_time / DIR.molten_to_ingot_ratio,
		speed_exceptions_from_source = {
			ingot = DIR.standard_crafting_time / DIR.molten_to_ingot_ratio,
			scrap = DIR.standard_crafting_time / DIR.molten_to_ingot_ratio,
		},
		source_category_exceptions = {
			mix = "molten-alloying",
			molten = "molten-alloying",
			pure = "melting-with-gas",
			gem = "melting-with-gas",
		},
		made_from_quaternary = {
			molten = {
				bronze = { ["copper-molten"] = 80, ["tin-molten"] = 40 }, -- alloy
				steel = { ["iron-molten"] = 120, ["solid-fuel"] = 1 }, -- alloy
				brass = { ["bronze-molten"] = 100, ["lead-molten"] = 20 }, -- alloy
			},
			mix = {
				bronze = { ["copper-ingot"] = 8, ["tin-ingot"] = 4 }, -- alloy
				steel = { ["iron-ingot"] = 12, ["solid-fuel"] = 1 }, -- alloy
				brass = { ["bronze-ingot"] = 10, ["lead-ingot"] = 2 }, -- alloy
			},
		},
		always_show_source_overlay = {
			mix = true,
		},
		bonus_results_from_source = {
			pure = { ["carbon-gas"] = DIR.gas_per_ingot * DIR.arc_furnace_raw_multiplier},
		},
		duplications = {
			{
				materials = {steel = true},
				affix = "advanced",
				category = "molten-alloying",
				add_ingredient = { name = "hydrogen-gas", amount = 30, type = "fluid" },
				remove_ingredient = "solid-fuel",
				subgroup = "ir-molten-molten",
				strip_numeric_suffix = true,
				ignore_sources = { scrap = true },
			},
		},
		mark_bonus_results_as_non_provider = true,
		source_emissions_multiplier = {
			pure =  hundredpercent,
			mix = 0.5,
			molten = 0.25,
			scrap = 0.25,
			ingot = 0.25,
		},
		specific_emissions_multiplier = {
			["steel-molten-from-molten"] = hundredpercent,
			["steel-molten-from-mix"] = hundredpercent,
		},
		tabgroup = "ir-molten",
		subgroup = "source",
		item_subgroup = "fluid",
		item_order = "zzzz",
		subgroup_source_exceptions = {
			gem = "ir-molten-pure",
			mix = "ir-molten-molten",
		},
		productivity = false,
		productivity_source_exceptions = {
			pure = true,
		},
		auto_barrel = false,
		mass_unlock_technology = "ir-arc-furnace",
		spill_emissions = 1,
	},
	["cryofluid"] = {
		type = "fluid",
		order = "z",
		materials = {"natural","hydrogen","oxygen","nitrogen","helium","carbon"},
		name_overrides = {
			natural = "natural-fluid",
			hydrogen = "hydrogen-fluid",
			oxygen = "oxygen-fluid",
			nitrogen = "nitrogen-fluid",
			helium = "helium-fluid",
			carbon = "carbon-fluid",
			-- ammonia = "ammonia-fluid",
		},
		speed = DIR.standard_crafting_time,
		skip_scan = true,
		do_not_decompose = true,
		show_non_source_ingredients = false,
		made_from = {
			gas = { amount = 40, result = 40 * DIR.liquified_gas_ratio },
		},
		category = "cryogenics",
		localised_description = {"recipe-description.can-be-warmed"},
		tabgroup = "ir-processing",
		subgroup = "ir-gas",
		order_exceptions = {
			carbon = "zze",
			helium = "zzd",
			hydrogen = "zzb",
			natural = "zzf",
			nitrogen = "zzc",
			oxygen = "zza",
			-- ammonia = "zzg",
		},
		item_subgroup = "gas",
		productivity = false,
		auto_barrel = false,
		fluid_temperature_properties = {
			oxygen = {
				default_temperature = -250,
				max_temperature = -250,
			},
			hydrogen = {
				default_temperature = -250,
				max_temperature = -250,
			},
			nitrogen = {
				default_temperature = -250,
				max_temperature = -250,
			},
			helium = {
				default_temperature = -270,
				max_temperature = -270,
			},
			carbon = {
				default_temperature = -35,
				max_temperature = -35,
			},
			natural = {
				default_temperature = -150,
				max_temperature = -150,
			},
			ammonia = {
				default_temperature = -150,
				max_temperature = -150,
			},
		},
	},
	["scrap"] = {
		type = "item",
		order = "z",
		materials = {"wood","copper","tin","bronze","iron","gold","steel","lead","brass","glass","concrete"},
		separately_handled_materials = {"concrete"}, -- concrete treats fluid as base for scrapping, not ingot/block
		name_overrides = {
			wood = "wood-chips",
		},
		start = true,
		start_exceptions = {
			wood = false,
		},
		skip_scan = true,
		category = "scrapping",
		belt_variations = 4,
		tabgroup = "ir-processing",
		made_from_exceptions = {
			wood = {
				ore = { amount = 1, result = 2 },
			},
		},
		crafting_category_exceptions = {
			wood = "grinding",
		},
		fuel_values = {
			wood = { multiplier = 0.25 },
		},
		subgroup_exceptions = {
			wood = "wood",
		},
		item_subgroup_exceptions = {
			wood = "natural",
		},
		speed_exceptions = {
			wood = DIR.standard_crafting_time * 2,
		},
		stack_size = 100,
		productivity = false,
		productivity_material_exceptions = {
			wood = true,
		},
		rotate_icon_variants = {
			copper = true,
			tin = true,
			bronze = true,
			iron = true,
			gold = true,
			steel = true,
			lead = true,
		},
	},
	["mix"] = {
		-- this component was used before 3.1.0 to make alloys - now only used for ease of distinguishing alloy recipe sources
		type = "item",
		-- order = "ib",
		materials = {"bronze","glass","steel","stone","brass"},
		-- name_overrides = {
			-- stone = "silicon-mix",
		-- },
		start = false,
		skip_scan = true,
		-- speed = DIR.standard_smelting_time / 4,
		-- scale_speed = true,
		-- category = "mixing",
		-- made_from = {
			-- mix = { amount = 0, result = 12 }, 
		-- },
		no_recipe = {
			bronze = true,
			glass = true,
			steel = true,
			stone = true,
			brass = true,
		},
		no_item = {
			bronze = true,
			glass = true,
			steel = true,
			stone = true,
			brass = true,
		},
		-- made_from_tertiary = {
			-- bronze = { ["copper-ingot"] = 8, ["tin-ingot"] = 4 }, -- alloy
			-- steel = { ["iron-ingot"] = 12, ["solid-fuel"] = 1 }, -- alloy
			-- brass = { ["bronze-ingot"] = 10, ["lead-ingot"] = 2 }, -- alloy
			-- glass = { ["silica"] = 9, ["tin-ingot"] = 3 }, -- glass
			-- stone = { ["silica"] = 12, ["solid-fuel"] = 1 }, -- silicon
		-- },
		-- tabgroup = "ir-processing",
		-- subgroup = "powder",
		-- order_exceptions = {
			-- stone = "ib-q",
		-- },
		-- productivity = false,
	},
	["plating-solution"] = {
		type = "fluid",
		order = "a",
		materials = {"chromium","gold"},
		start = false,
		skip_scan = true,
		speed = DIR.standard_crafting_time * 4,
		scale_speed = false,
		category = "chemistry",
		made_from = {
			["ingot"] = { amount = 4, result = 40 }, 
		},
		made_from_exceptions = {
			chromium = {
				["ingot"] = { amount = 2, result = 40 }, 
			},
		},
		made_from_tertiary = {
			chromium = { ["nickel-ingot"] = 2 },
		},
		made_from_category = {
			["chemistry"] = { ["sulfuric-acid"] = 20, ["water"] = 20 },
		},
		order_exceptions = {
			chromium = "a1",
			gold = "a2",
		},
		item_order_exceptions = {
			chromium = "zzz1",
			gold = "zzz2",
		},
		tabgroup = "ir-processing",
		subgroup = "ir-fuels",
		item_subgroup = "fluid",
		productivity = false,
		auto_barrel = true,
		spill_emissions = 1,
	},
	["plate"] = {
		type = "item",
		order = "j",
		start = true,
		derivative = true,
		scale_speed = false,
		materials = DIR.append_list({"rubber","gold","electrum"}, main_components),
		name_overrides = {
			rubber = "rubber",
		},
		made_from = {
			ingot = { amount = 1, result = 1 },
			molten = { amount = DIR.molten_to_ingot_ratio, result = 1},
		},
		made_from_exceptions = {
			chromium = {
				["plating-solution"] = {amount = DIR.plating_solution_amount, result = 1},
			},
			gold = {
				["plating-solution"] = {amount = DIR.plating_solution_amount, result = 1},
			},
			rubber = {
				ore = {amount = 1, result = 1},
			},
			electrum = {
				gem = {amount = 1, result = 10},
			},
		},
		made_from_tertiary = {
			chromium = { ["steel-plate"] = 1 },
			gold = { ["chromium-plate"] = 1 },
		},
		order_exceptions = {
			rubber = "zb",
			chromium = "ya",
			gold = "yb",
			electrum = "a",
		},
		bonus_results = {
			rubber = { 
				["wood-chips"] = 1.5,
			},
		},
		mark_bonus_results_as_non_provider = true,
		subgroup_exceptions = {
			rubber = "wood",
			electrum = "ir-electronics-2",
		},
		item_subgroup_exceptions = {
			rubber = "natural",
			carbon = "ir-fuels",
		},
		source_category_exceptions = {
			molten = "plate-casting",
		},
		no_affix = {
			ingot = true,
			ore = true,
		},
		no_overlay = {
			ingot = true,
		},
		tabgroup_source_exceptions = {
			molten = "ir-molten",
		},
		subgroup_source_exceptions = {
			molten = "ir-plate-from-molten",
		},
		category = "crafting-small",
		crafting_category_exceptions = {
			rubber = "grinding",
			nickel = "electroplating",
			gold = "electroplating",
			chromium = "electroplating",
			electrum = "laser-crafting",
		},
		source_category_exceptions = {
			molten = "plate-casting",
		},
		speed_exceptions = {
			rubber = DIR.standard_crafting_time * 2,
			electrum = DIR.standard_crafting_time * 10,
		},
		crafting_tint_override = {
			electrum = {
				primary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
				secondary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
				tertiary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
			},
		},
		productivity = false,
		productivity_material_exceptions = {
			rubber = true,
		},
		brightness_variations = true,
	},
	["plate-heavy"] = {
		type = "item",
		order = "k",
		materials = {"bronze","iron","steel","chromium"},
		start = true,
		derivative = true,
		made_from = {
			plate = { amount = 2, result = 1 },
		},
		order_exceptions = {
			iron = "x",
			steel = "ya",
			nickel = "yb",
			chromium = "zb",
		},
		made_from_secondary = {
			rivet = 1,
		},
		speed = DIR.standard_crafting_time * 2,
		scale_speed = false,
		productivity = false,
		brightness_variations = true,
	},
	["plate-special"] = {
		type = "item",
		order = "ka",
		materials = {"lead","electrum"},
		start = true,
		derivative = false,
		made_from = {
			plate = { amount = 1, result = 1 },
		},
		made_from_exceptions = {
			-- bronze = {
				-- ["plate-heavy"] = { amount = 1, result = 1 },
			-- },
			lead = {
				plate = { amount = 2, result = 1 },
			},
		},
		made_from_tertiary = {
			lead = { ["steel-plate"] = 2, ["steel-rivet"] = 2, ["concrete-block"] = 2 },
			electrum = { ["chromium-plate"] = 1, ["chromium-rivet"] = 1 },
		},
		-- bonus_results = {
			-- bronze = {},
		-- },
		-- duplications = {
			-- {
				-- materials = {bronze = true},
				-- affix = "manual",
				-- category = "fusing",
				-- add_result = { name = "bronze-scrap", type = "item", amount = 1, probability = 0.95 },
				-- result_probability = .05,
				-- strip_numeric_suffix = true,
				-- speed_multiplier = 4,
				-- productivity = false,
			-- },
		-- },
		crafting_category_exceptions = {
			-- bronze = "fusing",
			electrum = "laser-crafting",
		},
		subgroup_exceptions = {
			lead = "ir-intermediates",
			electrum = "ir-electronics-2",
		},
		order_exceptions = {
			lead = "yb",
			electrum = "b",
		},
		speed = DIR.standard_crafting_time * 2,
		-- speed_exceptions = {
			-- bronze = DIR.standard_crafting_time * 4,
		-- },
		scale_speed = false,
		productivity = false,
		subgroup = "plate-heavy",
		brightness_variations = true,
	},
	["beam"] = {
		type = "item",
		order = "l",
		materials = {"wood","copper","bronze","iron","steel","chromium"},
		start = true,
		speed = DIR.standard_crafting_time * 2,
		speed_exceptions = {
			wood = DIR.standard_crafting_time,
		},
		category = "crafting",
		crafting_category_exceptions = {
			wood = "crafting-small",
		},
		made_from = {
			plate = { amount = 2, result = 1 },
		},
		made_from_exceptions = {
			wood = {
				ore = {amount = 1, result = 2},
			},
		},
		made_from_secondary = {
			rivet = 1,
		},
		made_from_tertiary = {
			copper = { ["wood-beam"] = 1 },
			bronze = { ["wood-beam"] = 1 }, 
			iron = { ["iron-ingot"] = 1 },
			steel = { ["steel-ingot"] = 1 },
			chromium = { ["chromium-rod"] = 2 },
		},
		fuel_values = {
			wood = { multiplier = 0.25 },
		},
		productivity = false,
		brightness_variations = true,
	},
	["gear-wheel"] = {
		type = "item",
		order = "n",
		materials = {"tin","copper","iron","steel","brass","diamond"},
		start = true,
		derivative = true,
		scale_speed = false,
		made_from = {
			plate = { amount = 1, result = 1 },
			molten = { amount = DIR.molten_to_ingot_ratio, result = 1},
		},
		made_from_exceptions = {
			diamond = {
				["gem"] = {amount = 1, result = 1},
			},
		},
		made_from_tertiary = {
			diamond = { ["steel-plate"] = 2, ["brass-gear-wheel"] = 1 },
		},
		subgroup_exceptions = {
			diamond = "intermediate-product",
		},
		order_exceptions = {
			chromium = "y",
			diamond = "z-e-z",
		},
		category = "crafting-small",
		source_category_exceptions = {
			molten = "gear-wheel-casting",
			gem = "crafting",
		},
		no_affix = {
			plate = true,
		},
		no_overlay = {
			plate = true,
		},
		tabgroup_source_exceptions = {
			molten = "ir-molten",
		},
		subgroup_source_exceptions = {
			molten = "ir-gear-wheel-from-molten",
		},
		productivity = false,
		brightness_variations = true,
	},
	["rod"] = {
		type = "item",
		order = "o",
		materials = {"copper","tin","bronze","iron","steel","chromium","ruby"},
		name_overrides = {
			iron = "iron-stick",
		},
		start = true,
		derivative = true,
		made_from = {
			ingot = { amount = 1, result = 2 },
			molten = { amount = DIR.molten_to_ingot_ratio, result = 2},
		},
		made_from_exceptions = {
			chromium = {
				["plating-solution"] = {amount = DIR.plating_solution_amount, result = 2},
			},
			ruby = {
				gem = { amount = 1, result = 1 },
			},
		},
		made_from_tertiary = {
			chromium = { ["steel-rod"] = 2 },
			ruby = { ["gold-foil"] = 1 },
		},
		order_exceptions = {
			chromium = "z",
		},
		category = "crafting-small",
		crafting_category_exceptions = {
			nickel = "electroplating",
			chromium = "electroplating",
			ruby = "advanced-crafting",
		},
		source_category_exceptions = {
			molten = "rod-casting",
		},
		no_affix = {
			ingot = true,
		},
		no_overlay = {
			ingot = true,
			gem = true,
		},
		tabgroup_source_exceptions = {
			molten = "ir-molten",
		},
		subgroup_source_exceptions = {
			molten = "ir-rod-from-molten",
		},
		subgroup_exceptions = {
			ruby = "intermediate-product",
		},
		order_exceptions = {
			ruby = "zzz-t",
		},
		stack_size = 200,
		stack_size_exceptions = {
			ruby = 100,
		},
		productivity = false,
		brightness_variations = true,
	},
	["cable"] = {
		type = "item",
		order = "pa",
		start = false,
		derivative = false,
		materials = {"copper","tin","gold"},
		made_from = {
			ingot = { amount = 1, result = 2 },
		},
		made_from_exceptions = {
			gold = {
				["plating-solution"] = {amount = DIR.plating_solution_amount, result = 2},
			},
			tin = {
				ingot = { amount = 1, result = 2 },
			},
		},
		made_from_tertiary = {
			tin = { ["copper-cable"] = 2 },
			gold = { ["copper-cable"] = 2 },
		},
		category = "crafting-small",
		crafting_category_exceptions = {
			gold = "electroplating",
			tin = "advanced-crafting",
		},
		order_exceptions = {
			gold = "pb",
		},
		speed_exceptions = {
			plastic = DIR.standard_crafting_time * 2,
		},
		-- subgroup_exceptions = {
			-- carbon = "ir-electronics-2",		
		-- },
		stack_size = 200,
		productivity = false,
		brightness_variations = true,
	},
	["cable-heavy"] = {
		type = "item",
		order = "q",
		speed = DIR.standard_crafting_time * 2,
		materials = {"copper"},
		made_from = {
			cable = { amount = 8, result = 1 },
		},
		made_from_tertiary = {
			copper = { ["rubber"] = 1 },
		},
		-- show_non_source_ingredients = true,
		-- duplications = {
			-- {
				-- affix = "from-plastic",
				-- category = "crafting",
				-- replace_category = "crafting",
				-- replace_ingredients = { rubber = "plastic-bar" },
				-- result_probability = 1,
			-- },
		-- },
		tabgroup = "ir-basics",
		subgroup = "cable",
		stack_size = 50,
		productivity = false,
	},
	["rivet"] = {
		type = "item",
		order = "r",
		materials = {"copper","bronze","iron","steel","chromium"},
		start = true,
		derivative = true,
		speed = DIR.standard_crafting_time / 2,
		scale_speed = true,
		made_from = {
			rod = { amount = 1, result = 1 },
		},
		made_from_exceptions = {
			chromium = {
				["plating-solution"] = {amount = DIR.plating_solution_amount, result = 2},
			},
		},
		made_from_tertiary = {
			chromium = { ["steel-rivet"] = 2 },
		},
		order_exceptions = {
			chromium = "z",
		},
		category = "crafting-small",
		crafting_category_exceptions = {
			nickel = "electroplating",
			chromium = "electroplating",
		},
		stack_size = 200,
		productivity = false,
		brightness_variations = true,
	},
	["foil"] = {
		type = "item",
		order = "t",
		materials = {"copper","gold","electrum","carbon"},
		start = false,
		derivative = false,
		made_from = {
			ingot = { amount = 1, result = 2 },
		},
		made_from_exceptions = {
			electrum = {
				plate = { amount = 1, result = 1 },
			},
			carbon = {
				foil = { amount = 0, result = 2 },
			},
		},
		made_from_tertiary = {
			electrum = { ["carbon-foil"] = 1, ["sulfuric-acid"] = 5 },
			carbon = { ["helium-gas"] = DIR.inert_gas_amount, ["plastic-bar"] = 1 },
		},
		bonus_results = {
			carbon = { 
				["helium-gas"] = DIR.inert_gas_amount,
			},
		},
		mark_bonus_results_as_non_provider = true,
		category = "crafting-small",
		crafting_category_exceptions = {
			electrum = "laser-crafting",
			carbon = "laser-crafting",
		},
		subgroup = "cable",
		subgroup_exceptions = {
			electrum = "ir-electronics-2",
			carbon = "ir-electronics-2",
		},
		speed_exceptions = {
			electrum = DIR.standard_crafting_time * 2,
			carbon = DIR.standard_crafting_time * 2,
		},
		stack_size = 200,
		productivity = false,
		crafting_tint_override = {
			electrum = {
				primary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
				secondary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
				tertiary = DIR.hsva2rgba(DIR.materials.electrum.hue, 1, 0.8),
			},
		},
		order_exceptions = {
			carbon = "c",
			electrum = "d",
		},
		brightness_variations = true,
	},
	["repair-tool"] = {
		type = "repair-tool",
		order = "zzzzz", -- production tab
		materials = {"copper","bronze","iron","steel"},
		name_overrides = {
			iron = "repair-pack",
		},
		start = true,
		derivative = false,
		skip_scan = true,
		made_from = {
			rod = { amount = 3, result = 1 },
		},
		made_from_exceptions = {
			stone = {
				ingot = { amount = 1, result = 1 },
			},
		},
		made_from_tertiary = {
			stone = { ["wood-beam"] = 1 },
			copper = { ["wood-beam"] = 1, ["copper-plate"] = 1 },
			bronze = { ["wood-beam"] = 1, ["bronze-plate"] = 1 },
			iron = { ["rubber"] = 1, ["iron-plate"] = 1 },
			steel = { ["rubber"] = 1, ["diamond-gear-wheel"] = 1 },
		},
		tabgroup = "ir-basics",
		productivity = false,
	},
	["piston"] = {
		type = "item",
		order = "w",
		materials = {"copper","iron","steel","chromium"},
		start = true,
		speed = DIR.standard_crafting_time * 2,
		derivative = false,
		made_from = {
			plate = { amount = 2, result = 1 },
		},
		made_from_secondary = {
			rod = 1,
		},
		tabgroup = "ir-basics",
		subgroup = "piston",
		productivity = false,
		brightness_variations = true,
	},
	["pellet"] = {
		type = "item",
		order = "vb",
		materials = {"copper","bronze","iron","steel","platinum","nickel"},
		start = true,
		derivative = true,
		speed = DIR.standard_crafting_time,
		scale_speed = false,
		made_from = {
			ingot = { amount = 1, result = 4 },
		},
		category = "crafting-small",
		stack_size = 200,
		belt_variations = 6,
		rotate_icon_variants = {
			copper = true,
			bronze = true,
			iron = true,
			lead = true,
			platinum = true,
			nickel = true,
		},
		productivity = false,
	},
	["frame-small"] = {
		type = "item",
		order = "ac", -- intermediates tab
		materials = {"copper","iron","steel","chromium"},
		speed = DIR.standard_crafting_time * 3,
		start = true,
		derivative = false,
		made_from = {
			plate = { amount = 6, result = 1 },
		},
		made_from_secondary = {
			rivet = 2,
		},
		subgroup = "frame",
		tabgroup = "intermediate-products",
		productivity = false,
		brightness_variations = true,
	},
	["frame-large"] = {
		type = "item",
		order = "ad", -- intermediates tab
		materials = {"copper","iron","steel","chromium"},
		start = true,
		speed = DIR.standard_crafting_time * 4,
		derivative = false,
		made_from = {
			["beam"] = { amount = 12, result = 1 },
		},
		made_from_secondary = {
			plate = 24,
			rivet = 4,
		},
		made_from_tertiary = {
			iron = { ["computer-mk1"] = 1 },
			steel = { ["computer-mk2"] = 1 },
			chromium = { ["computer-mk3"] = 1 },
		},
		subgroup = "frame",
		tabgroup = "intermediate-products",
		stack_size = 50,
		productivity = false,
		brightness_variations = true,
	},
	["frame-turret"] = {
		type = "item",
		order = "ae",
		materials = {"steel","chromium"},
		start = true,
		speed = DIR.standard_crafting_time * 6,
		speed_exceptions = {
			chromium = DIR.standard_crafting_time * 12,
		},
		derivative = false,
		made_from = {
			["beam"] = { amount = 4, result = 1 },
		},
		made_from_tertiary = {
			steel = { ["gyroscope"] = 1, ["computer-mk2"] = 1, ["steel-plate-heavy"] = 16, },
			chromium = { ["gyroscope"] = 3, ["computer-mk3"] = 1, ["chromium-plate-heavy"] = 24 },
		},
		subgroup = "frame",
		tabgroup = "intermediate-products",
		stack_size = 50,
		productivity = false,
		brightness_variations = true,
	},
	["motor"] = {
		type = "item",
		order = "ada",
		materials = {"copper","iron","steel"},
		name_overrides = {
			steel = "electric-engine-unit",
		},
		start = true,
		speed = DIR.standard_crafting_time * 2,
		derivative = false,
		made_from = {
			plate = { amount = 2, result = 1 },
		},
		made_from_tertiary = {
			copper = { ["copper-gear-wheel"] = 1, ["copper-rod"] = 1 },
			iron = { ["iron-gear-wheel"] = 2, ["copper-cable"] = 1, ["iron-stick"] = 1 },
			steel = { ["steel-gear-wheel"] = 2, ["copper-cable"] = 1, ["steel-rod"] = 1, ["lubricant"] = 10 },
		},
		crafting_category_exceptions = {
			steel = "advanced-crafting",
		},
		tabgroup = "intermediate-products",
		subgroup = "ir-motors",
		productivity = false,
		brightness_variations = true,
	},
	["rotor"] = {
		type = "item",
		order = "adb",
		materials = {"copper","iron","steel"}, 
		name_overrides = {
			steel = "flying-robot-frame",
		},
		start = true,
		speed = DIR.standard_crafting_time * 3,
		derivative = false,
		made_from = {
			["frame-small"] = { amount = 1, result = 1 },
		},
		made_from_secondary = {
			plate = 3,
			motor = 1,
		},
		tabgroup = "intermediate-products",
		subgroup = "ir-motors",
		productivity = false,
		brightness_variations = true,
	},
	["engine-unit"] = {
		type = "item",
		order = "adc",
		materials = {"copper","iron","chromium"}, -- steel is electric-engine-unit under the motor component for historical reasons
		name_overrides = {
			iron = "engine-unit",
		},
		start = true,
		speed = DIR.standard_crafting_time * 4,
		speed_exceptions = {
			chromium = DIR.standard_crafting_time * 6,
		},
		derivative = false,
		made_from = {
			piston = { amount = 4, result = 1 },
		},
		made_from_exceptions = {
			copper = {
				piston = { amount = 3, result = 1 },
			},
			chromium = {
				piston = { amount = 8, result = 1 },
			},
		},
		made_from_tertiary = {
			copper = { ["copper-gear-wheel"] = 4, ["copper-plate"] = 4 },
			iron = { ["iron-gear-wheel"] = 6, ["iron-plate"] = 8 },
			chromium = { ["lubricant"] = 80, ["brass-gear-wheel"] = 8, ["chromium-plate"] = 16 },
		},
		crafting_category_exceptions = {
			chromium = "advanced-crafting",
		},
		tabgroup = "intermediate-products",
		subgroup = "ir-motors",
		productivity = false,
		brightness_variations = true,
	},
	["coil"] = {
		type = "item",
		order = "y",
		materials = {"copper","carbon"}, 
		start = false,
		derivative = false,
		made_from = {
			cable = { amount = 16, result = 1 },
		},
		made_from_exceptions = {
			carbon = {
				foil = { amount = 240, result = 1},
			}
		},
		made_from_tertiary = {
			copper = { ["iron-ingot"] = 8 },
			carbon = { ["chromium-plate"] = 16, ["chromium-rivet"] = 4, ["gold-cable"] = 16},
		},
		order_exceptions = {
			carbon = "z",
		},
		speed = DIR.standard_crafting_time * 4,
		speed_exceptions = {
			carbon = DIR.standard_crafting_time * 32,
		},
		subgroup = "intermediate-product",
		productivity = false,
		brightness_variations = true,
	},
	["block"] = {
		type = "item",
		order = "zzz",
		materials = {"concrete","copper","steel","stone"}, 
		name_overrides = {
			copper = "copper-heatsink",
			steel = "low-density-structure",
			stone = "silicon-block",
		},
		start = false,
		derivative = false,
		speed = DIR.standard_smelting_time * 4,
		speed_exceptions = {
			concrete = DIR.standard_crafting_time,
			copper = DIR.standard_crafting_time * 2,
			stone = DIR.standard_smelting_time * 2,
		},
		made_from = {
			plate = { amount = 6, result = 1 },
		},
		made_from_exceptions = {
			concrete = {
				fluid = { amount = 10, result = 1 }, -- block
			},
			steel = {
				ingot = { amount = 7, result = 2 },
			},
			stone = {
				pure = { amount = 4, result = 1 },
			},
		},
		made_from_tertiary = {
			steel = { ["chromium-ingot"] = 1, ["nitrogen-gas"] = DIR.gas_per_ingot * 4 },
			copper = { ["copper-rivet"] = 4 },
			stone = { ["graphite"] = 4 },
		},
		category = "crafting",
		crafting_category_exceptions = {
			concrete = "advanced-crafting",
			steel = "multi-smelting",
			stone = "multi-smelting",
		},
		subgroup = "intermediate-product",
		subgroup_exceptions = {
			concrete = "beam",
			steel = "ingots-4",
			stone = "ingots-4",
		},
		order_exceptions = {
			concrete = "ab",		
		},
		item_subgroup = "intermediate-product",
		item_subgroup_exceptions = {
			concrete = "beam",
			steel = "ingots",
			stone = "ingots",
		},
		productivity = false,
		brightness_variations = true,
	},
	["gem"] = { -- this component must exist
		type = "item",
		order = "x",
		materials = {"ruby","diamond","electrum"},
		skip_scan = true,
		do_not_decompose = true,
		tabgroup = "ir-processing",
		speed = DIR.standard_crafting_time * 20,
		scale_speed = false,
		made_from = {
			gem = { amount = 0, result = 1 },
		},
		made_from_tertiary = {
			diamond = { ["graphite"] = 10, ["diamond-powder"] = 1},
			ruby = { ["silica"] = 5, ["chromium-pure"] = 5, ["ruby-powder"] = 1 },
			electrum = { ["gold-pure"] = 7, ["platinum-pure"] = 3 },
		},
		ore_patch_chances = { -- this property must exist for this component
			ruby = {
				["copper-ore"] = 1/400,
				["gold-ore"] = 1/250,
			},
			diamond = {
				["iron-ore"] = 1/400,
				["coal"] = 1/400,
			},
		},
		category = "pressing",
		subgroup = "powder",
		order_exceptions = {
			electrum = "z",
		},
		productivity = false,
	},
	["magazine"] = {
		type = "ammo",
		order = "b",
		materials = {"iron","steel","chromium","uranium"},
		name_overrides = {
			iron = "firearm-magazine",
			steel = "piercing-rounds-magazine",
			uranium = "uranium-rounds-magazine",
		},
		start = true,
		skip_scan = true,
		speed = DIR.standard_crafting_time * 2,
		made_from = {
			plate = { amount = 2, result = 1 },
		},
		made_from_exceptions = {
			uranium = {
				crushed = {amount = 1, result = 1},
			},
		},
		made_from_tertiary = {
			iron = { ["iron-stick"] = 4 },
			steel = { ["steel-rod"] = 4 },
			chromium = { ["steel-rod"] = 8 },
			uranium = { ["chromium-magazine"] = 1, ["lead-plate"] = 2 },		
		},
		subgroup = "ir-ammo",
		tabgroup = "military",
		ammo = {
			size = 10,
			range = 18,
			cooldown = 6,
			speed = 1.25,
			deviation = 0.025,
			category = "bullet",
			piercing = {
				uranium = true,
			},
		},
		productivity = false,
		brightness_variations = true,
	},
	["cartridge"] = {
		type = "ammo",
		order = "a",
		materials = {"copper","bronze","iron","steel"},
		name_overrides = {
			copper = "shotgun-shell",
			steel = "piercing-shotgun-shell",
		},
		start = true,
		skip_scan = true,
		speed = DIR.standard_crafting_time * 2,
		made_from = {
			pellet = { amount = 6, result = 1 },
		},
		made_from_exceptions = {
			steel = {
				pellet = { amount = 8, result = 1 },
			},
		},
		made_from_tertiary = {
			copper = { ["tin-plate"] = 1 },
			bronze = { ["tin-plate"] = 1 },
			iron = { ["tin-plate"] = 1 },
			steel = { ["plastic-bar"] = 2 },
		},
		subgroup = "ir-ammo",
		tabgroup = "military",
		ammo = {
			size = 10,
			-- reload = 120,
			cooldown = 60,
			range = 15,
			speed = 1.25,
			deviation = 0.35,
			use_pellets = true,
			category = "shotgun-shell",
		},
		productivity = false,
		brightness_variations = true,
	},
	["gate"] = {
		type = "item",
		order = "b",
		materials = {"copper","gold","electrum"},
		start = false,
		skip_scan = false,
		speed = DIR.standard_crafting_time,
		speed_exceptions = {
			electrum = DIR.standard_crafting_time * 2,
		},
		scale_speed = false,
		category = "crafting",
		crafting_category_exceptions = {
			gold = "advanced-crafting",
			electrum = "laser-crafting",
		},
		-- duplications = {
			-- {
				-- affix = "laser",
				-- category = "crafting",
				-- resource_multiplier = 2,
				-- materials = {copper = true, gold = true},
				-- strip_numeric_suffix = true,
				-- subgroup = "ir-electronics-2",
				-- order_prefix = "a-a",
			-- },
		-- },
		subgroup = "ir-electronics",
		tabgroup = "intermediate-products",
		productivity = false,
		made_from_exceptions = {
			copper = {
				foil = { amount = 1, result = 2},
			},
			gold = {
				foil = { amount = 1, result = 2 },
			},
			electrum = {
				foil = { amount = 1, result = 2 },
			},
		},
		made_from_tertiary = {
			copper = { ["glass"] = 1, ["copper-cable"] = 1 },
			gold = { ["silicon"] = 1, ["tin-cable"] = 1 },
			electrum = { ["silicon"] = 1, ["gold-cable"] = 1 },
		},
		tier_override = {
			gold = 2,
			electrum = 3,
		},
		productivity = false,
		brightness_variations = true,
	},
	["circuit"] = {
		type = "item",
		order = "c",
		materials = {"copper","gold","electrum"},
		name_overrides = {
			copper = "electronic-circuit",
			gold = "advanced-circuit",
			electrum = "processing-unit",
		},
		start = false,
		skip_scan = false,
		speed = DIR.standard_crafting_time,
		speed_exceptions = {
			gold = DIR.standard_crafting_time * 2,
			electrum = DIR.standard_crafting_time * 4,
		},
		scale_speed = false,
		category = "crafting",
		crafting_category_exceptions = {
			gold = "advanced-crafting",
			electrum = "laser-crafting",
		},
		duplications = {
			{
				affix = "laser",
				category = "crafting",
				replace_category = "laser-crafting",
				resource_multiplier = 2,
				materials = {copper = true},
				strip_numeric_suffix = true,
				subgroup = "ir-electronics-2",
				order_prefix = "a-a",
			},
			{
				affix = "laser",
				category = "advanced-crafting",
				replace_category = "laser-crafting",
				resource_multiplier = 2,
				materials = {gold = true},
				strip_numeric_suffix = true,
				subgroup = "ir-electronics-2",
				order_prefix = "a-a",
			},
		},
		subgroup = "ir-electronics",
		tabgroup = "intermediate-products",
		productivity = false,
		made_from = {
			gate = { amount = 3, result = 1 },
		},
		made_from_exceptions = {
			gold = {
				gate = { amount = 5, result = 1 },
			},
		},
		made_from_tertiary = {
			copper = { ["glass"] = 1, ["copper-cable"] = 1 },
			gold = { ["plastic-bar"] = 1, ["tin-cable"] = 1 },
			electrum = { ["nanoglass"] = 1, ["gold-gate"] = 3, ["gold-cable"] = 1 },
		},
		tier_override = {
			gold = 2,
			electrum = 3,
		},
		productivity = false,
		brightness_variations = true,
	},
	["computer"] = {
		type = "item",
		order = "x",
		materials = {"copper","gold","electrum"},
		name_overrides = {
			copper = "computer-mk1",
			gold = "computer-mk2",
			electrum = "computer-mk3",
		},
		start = false,
		skip_scan = false,
		stack_size = 50,
		speed = DIR.standard_crafting_time * 4,
		speed_exceptions = {
			gold = DIR.standard_crafting_time * 8,
			electrum = DIR.standard_crafting_time * 16,
		},
		scale_speed = false,
		category = "crafting",
		subgroup = "ir-electronics",
		tabgroup = "intermediate-products",
		productivity = false,
		made_from = {
			circuit = { amount = 8, result = 1 },
		},
		made_from_exceptions = {
		},
		made_from_tertiary = {
			copper = { ["iron-frame-small"] = 1, ["copper-gate"] = 12 },
			gold = { ["steel-frame-small"] = 1, ["electronic-circuit"] = 12 },
			electrum = { ["chromium-frame-small"] = 1, ["advanced-circuit"] = 12, ["copper-heatsink"] = 1 },
		},
		productivity = false,
		brightness_variations = true,
	},
	["laser"] = {
		type = "item",
		order = "zzz",
		materials = {"ruby","helium"},
		start = false,
		skip_scan = false,
		speed = DIR.standard_crafting_time * 4,
		scale_speed = false,
		category = "crafting",
		crafting_category_exceptions = {
			helium = "advanced-crafting",
		},
		subgroup = "intermediate-product",
		tabgroup = "intermediate-products",
		productivity = false,
		made_from = {
			rod = { amount = 1, result = 1 },
		},
		made_from_exceptions = {
			helium = {
				gas = { amount = 20, result = 1 },
			},
		},
		made_from_tertiary = {
			ruby = { ["steel-plate"] = 6, ["advanced-circuit"] = 1, ["glass"] = 1 },
			helium = { ["chromium-plate"] = 6, ["advanced-circuit"] = 2, ["gold-plate"] = 1 },
		},
		productivity = false,
	},
	["covering"] = { -- placeable tile items
		type = "item",
		order = "c[a]",
		materials = {"bitumen"},
		name_overrides = {
			bitumen = "tarmac",
		},
		skip_scan = true,
		speed = DIR.standard_crafting_time * 4,
		derivative = false,
		scale_speed = false,
		category = "mixing",
		stack_size = 100,
		made_from = {
			ingot = { amount = 3, result = 10 },
		},
		made_from_tertiary = {
			bitumen = { ["gravel"] = 10 },
		},
		tabgroup = "intermediate-products",
		subgroup = "ir-tiles",
		productivity = true,
		tile_walking_speed = {
			bitumen = 1.4,
		},
		tile_sprites = {
			bitumen = "bevel",
		},
		tile_masks = {
			bitumen = "hard-mask",
		},
		vehicle_speed = {
			bitumen = 0.6,
		},
		tile_condition_size = 2,
	},
	["analysis"] = { -- this component must exist
		type = "tool",
		order = "za",
		do_not_append_item_material_order = true,
		stack_size = 100,
		stack_size_exceptions = {
			hydrogen = 1000,
		},
		materials = {"copper","iron","steel","chromium","electrum","hydrogen"},
		name_overrides = {
			copper = "automation-science-pack",
			iron = "logistic-science-pack",
			steel = "chemical-science-pack",
			chromium = "production-science-pack",
			electrum = "utility-science-pack",
			hydrogen = "space-science-pack",
		},
		start = true,
		derivative = false,
		made_from = {
			analysis = { amount = 0, result = 1 },
		},
		made_from_tertiary = {
			copper = { ["copper-plate"] = 4, ["tin-gear-wheel"] = 3 }, -- automation
			iron = { ["iron-beam"] = 3, ["bronze-plate-heavy"] = 2, ["glass"] = 3 }, -- chemical
			steel = { ["steel-beam"] = 4, ["concrete-block"] = 4, ["electronic-circuit"] = 4 }, -- production
			chromium = { ["chromium-beam"] = 3, ["advanced-circuit"] = 4, ["electric-engine-unit"] = 1 }, -- utility
			electrum = { ["electrum-plate-special"] = 2, ["processing-unit"] = 4, ["low-density-structure"] = 2, ["advanced-battery"] = 1 }, -- utility
		},
		no_recipe = {
			hydrogen = true,
		},
		unlocking_techs = { -- must exist for this component type
			-- copper = "ir-basic-research",
			iron = "ir-iron-milestone",
			steel = "ir-steel-milestone",
			chromium = "ir-electroplating",
			electrum = "ir-electronics-3",
			hydrogen = "space-science-pack",
		},
		order_exceptions = {
			iron = "zb",
			steel = "zc",
			chromium = "zd",
			electrum = "ze",
			hydrogen = "zf",
		},
		speed = DIR.standard_crafting_time * 8,
		speed_exceptions = {
			copper = DIR.standard_crafting_time * 4,
		},
		scale_speed = false,
		productivity = true,
		subgroup = "analysis",
		tabgroup = "intermediate-products",
		brightness_variations = true,
		not_scrappable = true,
	},
	["special-analysis"] = { -- this component must exist
		type = "tool",
		order = "zz",
		do_not_append_item_material_order = true,
		materials = {"sulphur"},
		name_overrides = {
			sulphur = "military-science-pack",
		},
		start = false,
		derivative = false,
		made_from = {
			["special-analysis"] = { amount = 0, result = 1 },
		},
		made_from_tertiary = {
			sulphur = { ["explosives"] = 5 }, -- explosives / military
		},
		speed = DIR.standard_crafting_time * 8,
		scale_speed = false,
		productivity = true,
		subgroup = "analysis",
		tabgroup = "intermediate-products",
		project_info = { -- must exist for this component type
			sulphur = { -- military science pack - uses this component so that it doesn't chain
				unlocked_by = "explosives",
				used_by = DIR.append_list({"military-2","military-3", "military-4", "ir-photon-turret", "artillery", "atomic-bomb", "land-mine", "rocketry", "explosive-rocketry", "ir-rocket-turret"}, explosives),
				do_not_identify = true,
			},
		},
		brightness_variations = true,
		not_scrappable = true,
	},
}

------------------------------------------------------------------------------------------------------------------------------------------------------
