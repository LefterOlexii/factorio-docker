------------------------------------------------------------------------------------------------------------------------------------------------------

-- late pass on mod support

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Dectorio

if mods["Dectorio"] then
	-- tile subgroup
	if data.raw["item-group"]["dectorio"] then
		data.raw["item-subgroup"]["ir-tiles"].group = "dectorio"
		data.raw["item-subgroup"]["ir-tiles"].order = "0"
		DIR.change_item_and_recipe_order("hazard-concrete", "00[f-hazard-concrete]")
		DIR.change_item_and_recipe_order("refined-hazard-concrete", "00[f-refined-hazard-concrete]")
	end
	-- optional bits
	if DECT.ENABLED["wood-floor"] then
		DIR.replace_recipe_ingredients("dect-wood-floor", {{"wood-beam", 20}}, 10, "crafting", 5)
	end
	if DECT.ENABLED["landscaping"] then
		DIR.add_prereq_to_tech("dect-landscaping", "ir-grinding-1")
		DIR.replace_recipe_ingredients("dect-base-red-desert-0", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-red-desert-1", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-red-desert-2", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-red-desert-3", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-sand-1", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-sand-2", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-sand-3", {{"silica", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dry-dirt", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-1", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-2", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-3", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-4", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-5", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-6", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-dirt-7", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-grass-1", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-grass-2", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-grass-3", {{"gravel", 2}}, 10, "crafting", 5)
		DIR.replace_recipe_ingredients("dect-base-grass-4", {{"gravel", 2}}, 10, "crafting", 5)
	end
	-- IR 3.0.0 - disable waterfill, see also settings-updates.lua
	if data.raw.technology["dect-earthworks"] then
		DECT.ENABLED["waterfill"] = false
		DIR.disable_technology("dect-earthworks")
	end
	-- walls
	if DECT.ENABLED["walls"] then
		DIR.change_recipe_subgroup("dect-wood-wall","ir-walls")
		DIR.change_item_and_recipe_order("dect-wood-wall","a")
		DIR.change_recipe_subgroup("stone-wall","ir-walls")
		DIR.change_item_and_recipe_order("stone-wall","b")
		DIR.change_recipe_subgroup("gate","ir-walls")
		DIR.change_item_and_recipe_order("gate","bb")
		DIR.change_recipe_subgroup("dect-concrete-wall","ir-walls")
		DIR.change_item_and_recipe_order("dect-concrete-wall","c")
		DIR.change_recipe_subgroup("dect-concrete-wall-from-stone-wall","ir-walls")
		DIR.change_recipe_order("dect-concrete-wall-from-stone-wall","cb")
		DIR.change_recipe_subgroup("dect-chain-wall","ir-walls")
		DIR.change_item_and_recipe_order("dect-chain-wall","d")
		DIR.change_item_and_recipe_order("steel-plate-wall","e")
		DIR.replace_recipe_ingredients("dect-concrete-wall", {{"concrete-block", 10}, {"stone-brick", 5}}, 1, "crafting", 4)
		DIR.replace_recipe_ingredients("dect-concrete-wall-from-stone-wall", {{"concrete-block", 10}, {"stone-wall", 1}}, 1, "crafting", 4, "dect-concrete-wall")
		DIR.replace_recipe_ingredients("steel-plate-wall", {{"steel-plate-heavy", 4}, {"dect-concrete-wall", 1}}, 1, "crafting", 4)
		DIR.replace_recipe_ingredients("dect-chain-wall", {{"iron-stick", 8}, {"iron-rivet", 2}}, 1, "crafting", 2)
		DIR.replace_all_prereqs("ir-steel-wall", {"dect-advanced-wall","ir-steel-milestone"})
	end
	-- decorative gravel
	if DECT.ENABLED["gravel"] then
		for _, variant in pairs(DECT.CONFIG.GRAVEL_VARIANTS) do
			local name = "dect-" .. variant.name .. "-gravel"
			data:extend({{
				type = "recipe",
				name = name,
				energy_required = DIR.standard_smelting_time/2,
				enabled = false,
				category = "mixing",
				ingredients = {{variant.name, 1}},
				result = "dect-" .. variant.name .. "-gravel",
				result_count = 1
			}})
			DIR.add_unlock_to_tech("ir-grinding-2", name)
		end
	end
	-- trees
	if DECT.ENABLED["landscaping"] then
		for _, tree in pairs(DECT.CONFIG.BASE_TREES) do
			if not string.find(tree, "dead") and not string.find(tree, "dry") then
				DIR.replace_recipe_ingredients("dect-base-"..tree, {{"wood",12}}, 1, "crafting", 3)
			end
		end
	end
	-- small glowing lamp
	if data.raw.recipe["dect-small-lamp-glow"] then
		data.raw.recipe["dect-small-lamp-glow"].ingredients = table.deepcopy(data.raw.recipe["small-lamp"].ingredients)
		data.raw.recipe["dect-small-lamp-glow"].energy_required = data.raw.recipe["small-lamp"].energy_required
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
