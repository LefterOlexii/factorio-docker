------------------------------------------------------------------------------------------------------------------------------------------------------

-- PRE-TECH MODS
-- mods which need support before tree build runs and before techs are wiped

------------------------------------------------------------------------------------------------------------------------------------------------------

-- DLL

if mods["DeadlockLargerLamp"] then
	data.raw.recipe["deadlock-large-lamp"].ingredients = {
		{ "copper-gate", 4 },
		{ "copper-cable", 4 },
		{ "iron-plate", 6 },	
		{ "glass", 4 },	
	}
	data.raw.recipe["deadlock-floor-lamp"].ingredients = {
		{ "copper-gate", 2 },
		{ "copper-cable", 2 },
		{ "iron-plate", 4 },	
		{ "glass", 4 },	
	}
	DIR.change_item_subgroup("deadlock-copper-lamp", "ir-lamps")
	DIR.change_item_subgroup("deadlock-large-lamp", "ir-lamps")
	DIR.change_item_subgroup("deadlock-floor-lamp", "ir-lamps")
	DIR.change_item_order("deadlock-copper-lamp","aa")
	DIR.change_item_order("deadlock-large-lamp","ad")
	DIR.change_item_order("deadlock-floor-lamp","ae")
end

-- Beacon Rebalance

if mods["wret-beacon-rebalance-mod"] then
	if data.raw.beacon.beacon then
		data.raw.beacon.beacon.energy_usage = DIR.get_scaled_energy_usage(8, 0).active
	end
	if data.raw.item["beacon2-item"] then
		DIR.change_item_order("beacon2-item","zb")
		DIR.change_recipe_order("beacon2-recipe","zb")
		DIR.change_item_subgroup("beacon2-item", data.raw.item["beacon"].subgroup)
		DIR.change_recipe_subgroup("beacon2-recipe", data.raw.recipe["beacon"].subgroup)
		DIR.replace_recipe_ingredients("beacon2-recipe", {{"beacon", 1}, {"computer-mk3", 3}, {"field-effector", 8}, {"accumulator",1}}, 1, "crafting", 6, "beacon2-item")
		data.raw.technology["effect-transmission-2"].ir_native = true
		DIR.replace_all_prereqs("effect-transmission-2", {"effect-transmission"})
	end
	if data.raw.item["beacon3-item"] then
		DIR.change_item_order("beacon3-item","zc")
		DIR.change_recipe_order("beacon3-recipe","zc")
		DIR.change_item_subgroup("beacon3-item", data.raw.item["beacon"].subgroup)
		DIR.change_recipe_subgroup("beacon3-recipe", data.raw.recipe["beacon"].subgroup)
		DIR.replace_recipe_ingredients("beacon3-recipe", {{"beacon2-item", 1}, {"computer-mk3", 4}, {"copper-plate", 40}, {"accumulator",1}}, 1, "crafting", 12, "beacon3-item")
		data.raw.technology["effect-transmission-3"].ir_native = true
		DIR.replace_all_prereqs("effect-transmission-3", {"effect-transmission-2"})
	end
end

-- Large Storage Tank

if mods["large-storage-tank"] and data.raw.technology["large-storage-tank"] and data.raw.recipe["large-storage-tank"] then
	data.raw.technology["large-storage-tank"].prerequisites = {"fluid-handling"}
	data.raw.technology["large-storage-tank"].IR_native = true
	data.raw.recipe["large-storage-tank"].ingredients = {
		{"concrete-block",80},
		{"steel-beam",40},
		{"steel-plate-heavy",80},
	}
	data.raw.recipe["large-storage-tank"].subgroup = "ir-pipes"
	data.raw.recipe["large-storage-tank"].order = "zzz"
end

------------------------------------------------------------------------------------------------------------------------------------------------------
