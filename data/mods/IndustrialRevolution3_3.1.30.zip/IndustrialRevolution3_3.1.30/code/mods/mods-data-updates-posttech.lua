------------------------------------------------------------------------------------------------------------------------------------------------------

-- POST-TECH MODS
-- mods which need support after tree rebuild

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Text Plates

if mods["textplates"] then
	data.raw.recipe["textplate-large-iron"].enabled = false
	data.raw.recipe["textplate-small-iron"].enabled = false
	DIR.add_unlock_to_tech("ir-iron-milestone","textplate-large-iron")
	DIR.add_unlock_to_tech("ir-iron-milestone","textplate-small-iron")
	data.raw.recipe["textplate-large-gold"].enabled = false
	data.raw.recipe["textplate-small-gold"].enabled = false
	DIR.add_unlock_to_tech("ir-gold-milestone","textplate-large-gold")
	DIR.add_unlock_to_tech("ir-gold-milestone","textplate-small-gold")
	data.raw.recipe["textplate-large-gold"].ingredients = {{type = "item", name = "gold-foil", amount = 4},{type = "item", name = "textplate-large-copper", amount = 1}}
	data.raw.recipe["textplate-small-gold"].ingredients = {{type = "item", name = "gold-foil", amount = 1},{type = "item", name = "textplate-small-copper", amount = 1}}
	data.raw.recipe["textplate-large-steel"].enabled = false
	data.raw.recipe["textplate-small-steel"].enabled = false
	DIR.add_unlock_to_tech("ir-steel-milestone","textplate-large-steel")
	DIR.add_unlock_to_tech("ir-steel-milestone","textplate-small-steel")
	data.raw.recipe["textplate-large-uranium"].enabled = false
	data.raw.recipe["textplate-small-uranium"].enabled = false
	DIR.add_unlock_to_tech("uranium-processing","textplate-large-uranium")
	DIR.add_unlock_to_tech("uranium-processing","textplate-small-uranium")
	data.raw.recipe["textplate-large-concrete"].enabled = false
	data.raw.recipe["textplate-small-concrete"].enabled = false
	DIR.add_unlock_to_tech("ir-concrete-1","textplate-large-concrete")
	DIR.add_unlock_to_tech("ir-concrete-1","textplate-small-concrete")
	data.raw.recipe["textplate-large-glass"].enabled = false
	data.raw.recipe["textplate-small-glass"].enabled = false
	data.raw.recipe["textplate-large-glass"].ingredients = {{type = "item", name = "glass", amount = 4}}
	data.raw.recipe["textplate-small-glass"].ingredients = {{type = "item", name = "glass", amount = 1}}
	DIR.add_unlock_to_tech("ir-glass-milestone","textplate-large-glass")
	DIR.add_unlock_to_tech("ir-glass-milestone","textplate-small-glass")
	data.raw["item-subgroup"]["textplates"].group = data.raw["item-group"]["dectorio"] and "dectorio" or "logistics"
	data.raw["item-subgroup"]["textplates"].order = "zzz"
	-- IR 3.0.0 - at some point TP added native technologies for a subset of the plates
	-- Unfortunately there isn't one for iron, which isn't unlockable/workable at game start in IR
	-- The scheme above still works so the easy fix is to disable TP techs; also catches EMTP which uses same naming scheme
	for _,tech in pairs(data.raw.technology) do
		if string.find(tech.name, "textplates%-") then
			tech.hidden = true
		end
	end
	-- IR 3.1.24 - TP now provides its own plastic plates, EMTP only needs to handle coloured version
	data.raw.recipe["textplate-large-plastic"].enabled = false
	data.raw.recipe["textplate-small-plastic"].enabled = false
	data.raw.recipe["textplate-large-plastic"].ingredients = {{type = "item", name = "plastic-bar", amount = 4}}
	data.raw.recipe["textplate-small-plastic"].ingredients = {{type = "item", name = "plastic-bar", amount = 1}}
	DIR.add_unlock_to_tech("plastics","textplate-small-plastic")
	DIR.add_unlock_to_tech("plastics","textplate-large-plastic")
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Even More Text Plates

-- IR 3.0.0 - My deprecated original version no longer supported, only Zengineer's fork
-- IR 3.1.24 - TP now provides its own plastic plates, EMTP only needs to handle coloured version
if mods["EvenMoreTextPlates"] then
	-- data.raw.recipe["textplate-large-plastic"].enabled = false
	-- data.raw.recipe["textplate-small-plastic"].enabled = false
	-- data.raw.recipe["textplate-large-plastic"].ingredients = {{type = "item", name = "plastic-bar", amount = 4}}
	-- data.raw.recipe["textplate-small-plastic"].ingredients = {{type = "item", name = "plastic-bar", amount = 1}}
	-- DIR.add_unlock_to_tech("plastics","textplate-small-plastic")
	-- DIR.add_unlock_to_tech("plastics","textplate-large-plastic")
	data.raw.recipe["textplate-large-plasticcoloured"].enabled = false
	data.raw.recipe["textplate-small-plasticcoloured"].enabled = false
	data.raw.recipe["textplate-large-plasticcoloured"].ingredients = {{type = "item", name = "plastic-bar", amount = 4}}
	data.raw.recipe["textplate-small-plasticcoloured"].ingredients = {{type = "item", name = "plastic-bar", amount = 1}}
	DIR.add_unlock_to_tech("plastics","textplate-small-plasticcoloured")
	DIR.add_unlock_to_tech("plastics","textplate-large-plasticcoloured")
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- AAI Containers & Warehouses

if mods["aai-containers"] then
	DIR.change_item_and_recipe_subgroup("wooden-chest","storage")
	DIR.change_item_and_recipe_order("wooden-chest", "a[items]-a[ac]")
	DIR.change_item_and_recipe_subgroup("iron-chest","storage")
	DIR.change_item_and_recipe_order("iron-chest", "a[items]-c[a]")
	DIR.replace_recipe_ingredients("aai-strongbox", {{"concrete-block", 30}, {"steel-beam",6}, {"steel-plate-heavy", 8}})
	DIR.replace_recipe_ingredients("aai-storehouse", {{"concrete-block", 60}, {"steel-beam",12}, {"steel-plate-heavy", 16}})
	DIR.replace_recipe_ingredients("aai-warehouse", {{"concrete-block", 120}, {"steel-beam",24}, {"steel-plate-heavy", 32}})
	local types = {
		["strongbox"] = 2,
		["storehouse"] = 4,
		["warehouse"] = 999,
	}
	local logistics = {
		["active-provider"] = "gold",
		["passive-provider"] = "gold",
		["storage"] = "gold",
		["buffer"] = "electrum",
		["requester"] = "electrum",
	}
	for container,amount in pairs(types) do
		for logistic_type,tier in pairs(logistics) do 
			local electronics = {DIR.get_item_name(tier, amount < 999 and "circuit" or "computer"), amount < 999 and amount or 1}
			DIR.replace_recipe_ingredients("aai-"..container.."-"..logistic_type, {{"aai-"..container, 1}, {"electric-engine-unit", 1}, electronics})
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- Warehousing Mod

if mods["Warehousing"] then
	DIR.replace_recipe_ingredients("storehouse-basic", {{"concrete-block", 20}, {"steel-beam",12}, {"steel-plate", 40}})
	DIR.replace_recipe_ingredients("warehouse-basic", {{"concrete-block", 80}, {"steel-beam",24}, {"steel-plate-heavy", 60}})
	local types = {
		["storehouse"] = 4,
		["warehouse"] = 999,
	}
	local logistics = {
		["active-provider"] = "gold",
		["passive-provider"] = "gold",
		["storage"] = "gold",
		["buffer"] = "electrum",
		["requester"] = "electrum",
	}
	for container,amount in pairs(types) do
		for logistic_type,tier in pairs(logistics) do 
			local electronics = {DIR.get_item_name(tier, amount < 999 and "circuit" or "computer"), amount < 999 and amount or 1}
			DIR.replace_recipe_ingredients(container.."-"..logistic_type, {{container.."-basic", 1}, {"electric-engine-unit", 1}, electronics})
		end
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------
