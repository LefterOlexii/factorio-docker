------------------------------------------------------------------------------------------------------------------------------------------------------

-- tweak vanilla signals

local signals = {"red", "green", "blue", "cyan", "yellow", "pink", "black", "white", "grey"}

for _,signal in pairs(signals) do
	if data.raw["virtual-signal"]["signal-"..signal] then
		data.raw["virtual-signal"]["signal-"..signal].icon = DIR.get_icon_path("signal-"..signal)
		data.raw["virtual-signal"]["signal-"..signal].icon_size = DIR.icon_size
		data.raw["virtual-signal"]["signal-"..signal].icon_mipmaps = DIR.icon_mipmaps
		data.raw["virtual-signal"]["signal-"..signal].icons = nil
	end
end

------------------------------------------------------------------------------------------------------------------------------------------------------

-- new signals

data:extend({
	{
		name = "ir-signal-warning",
		icon = DIR.get_icon_path("signal-warning"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "x",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
	{
		name = "ir-signal-danger",
		icon = DIR.get_icon_path("signal-danger"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "y",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
	{
		name = "ir-signal-toxic",
		icon = DIR.get_icon_path("warning-pollution"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "za",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
	{
		name = "ir-signal-fuel-red",
		icon = DIR.get_icon_path("warning-fuel-red"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "zb",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
	{
		name = "ir-signal-fuel-yellow",
		icon = DIR.get_icon_path("warning-fuel-yellow"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "zc",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
	{
		name = "ir-transmat-signal",
		icon = DIR.get_icon_path("transmat-signal"),
		icon_size = DIR.icon_size,
		icon_mipmaps = DIR.icon_mipmaps,
		order = "zd",
		subgroup = "virtual-signal",
		type = "virtual-signal"
	},
})

------------------------------------------------------------------------------------------------------------------------------------------------------

-- rainbow!

if not mods["Dectorio"] then

	data:extend({{
		name = "signal-orange",
		icon = DIR.get_icon_path("signal-orange"),
		icon_size = 64,
		subgroup = "virtual-signal-color",
		type = "virtual-signal"
	}})

	local colours = {
		red = "a",
		orange = "b",
		yellow = "c",
		green = "d",
		cyan = "e",
		blue = "f",
		pink = "g",
		white = "h",
		grey = "i",
		black = "j",
	}

	for colour,order in pairs(colours) do
		if data.raw["virtual-signal"]["signal-"..colour] then
			data.raw["virtual-signal"]["signal-"..colour].order = "a"..order
		end
	end

end
------------------------------------------------------------------------------------------------------------------------------------------------------
