------------------------------------------------------------------------------------------------------------------------------------------------------

-- DEADLOCK'S INDUSTRIAL REVOLUTION 3
-- See LICENSE.txt for license details

------------------------------------------------------------------------------------------------------------------------------------------------------

-- REMOTE INTERFACES, for use by other mods

------------------------------------------------------------------------------------------------------------------------------------------------------

-- EVENTS

-- ir-events/get-event-id
-- Returns the generated event id for a named IR event (see below for a list of currently provided events)
-- Takes an event name string as a parameter
-- Returns a uint event id for use in script.on_event, or nil if there is no such event name string
-- Example: script.on_event(remote.call("ir-events", "get-event-id", "on_forestry_chunk_updated"), my_chunk_handler_function)

-- CUSTOM IR EVENTS

-- on_forestry_chunk_updated
-- Raised when a forestry chunk changes (due to daily tree growth/deaths, or any other creation/destruction of forestries/trees)
-- Returns a table of event data with the following key/value pairs:
-- surface_index (uint) - the index of the surface the chunk is in
-- chunk_position (ChunkPosition) - the chunk coordinates 
-- chunk_area (shorthand BoundingBox) - the area of the chunk, e.g. for use with surface.find_entities_filtered
-- tree_count (uint) - the number of husbanded trees in the chunk (at time of writing, clamped to 0-50); always 0 if there are 0 forestries
-- forestries (array of LuaEntity) - forestry entities in the chunk
-- Example: script.on_event(remote.call("ir-events", "get-event-id", "on_forestry_chunk_updated"), function(event) game.print(event.tree_count) end)

-- on_transfer_plate_or_hotkey
-- Raised when a transfer plate or hotkey moves items between player/vehicle and container
-- Not raised when no items are moved (if you want the triggers regardless of items moved, you can use on_script_trigger_effect with effect_id "ir-transfer-plate"
-- for transfer plate triggers, and script.on_event("ir-entity-adjustment") with a selected container item for the hotkey)
-- Returns a table of event data with the following key/value pairs:
-- player_index (uint) - the index of the player controlling the character/vehicle that triggered the plate or pressed the hotkey
-- identity (string) - identifier for trigger (IR3 uses "transfer-plate" and "hotkey")
-- silent (bool) - true if the flying notifications were silenced, otherwise false
-- transfers - an array of dictionaries, each containing the following key/value pairs:
---- item_name (string) - the id of the item being transferred
---- amount (uint) - the number of items transferred
---- from (LuaObject) - the source of the items, either a LuaPlayer, a LuaEntity representing a vehicle, or a LuaEntity representing a container
---- to (LuaObject) - the destination for the items, either a LuaPlayer, a LuaEntity representing a vehicle, or a LuaEntity representing a container

------------------------------------------------------------------------------------------------------------------------------------------------------

-- WORLD GENERATION / TERRAIN

-- ir-world/set-intro-cutscene
-- Set whether or not to use the IR3 intro cutscene
-- In freeplay games, if the freeplay intro cutscene has been disabled, then the IR3 cutscene is also disabled by default, unless overridden by this call
-- In non-freeplay games, the IR3 intro cutscene is disabled by default, unless overridden by this call
-- Must be set before the first player is created to have any effect
-- Takes a boolean value as parameter
-- Does not return a value
-- Example: remote.call("ir-world", "set-intro-cutscene", false) -- explicitly disable the cutscene
-- Example: remote.call("ir-world", "set-intro-cutscene", true) -- explicitly enable the cutscene

-- ir-world/set-crate-items
-- Overwrites the "kit" of starting items - items which are found in crates which spawn near the coordinate origin
-- Takes one parameter, a table of key/value pairs, where the keys are an item name and the value is the number of items to be given
-- Intended for use in your mod's on_init(), with a dependency on IR3
-- Must be set before the first player is created to have any effect
-- In freeplay games, the default kit depends on map settings, unless overridden by this call
-- In non-freeplay games, the default is an empty table and no crates are spawned, unless overridden by this call
-- To add items to the existing kits, use get-crate-items (below) to fetch the kit, add stuff to it, then put it back with this call
-- Returns true if the value is a table and was set
-- Otherwise returns false
-- Example: remote.call("ir-world", "set-crate-items", { ["iron-plate"] = 100, ["copper-plate"] = 100 } ) -- slim pickings
-- Example: remote.call("ir-world", "set-crate-items", {} ) -- no items, no crates

-- ir-world/get-crate-items
-- Takes no parameters
-- Returns a table containing the starter items currently set to be put in crates for the first player that joins
-- Table contains key/value pairs as described above (or is empty)
-- In freeplay games, the default kit depends on map settings
-- In non-freeplay games, the default is an empty table
-- Returns nil if IR3 has not yet run on_init()
-- Example: local start_items = remote.call("ir-world", "get-crate-items")

-- ir-world/allow-non-crate-spawns
-- Enables/disables the small number of non-crate entities that get spawned for the first player
-- As of 3.1.17 this consists of 3 metallic junkpiles and 1 steam fissure
-- Takes a boolean or string as a parameter:
-- - false will prevent any non-crate entities being created
-- - nil or true will enable all of them
-- - string value "scrap" will enable the fissure and the scrap pile, but remove non-scrap items from the piles
-- In freeplay games, this setting is true by default, unless overridden by this call
-- In non-freeplay games, this setting is false by default, unless overridden by this call
-- Must be set before the first player is created to have any effect
-- Crates are handled separately, see above
-- Does not return a value
-- Example: remote.call("ir-world", "allow-non-crate-spawns", false) -- turns off junkpiles etc.
-- Example: remote.call("ir-world", "allow-non-crate-spawns", true) -- turns on junkpiles etc.

-- ir-world/get-chunk-forestries
-- Takes a surface index and a map position as parameters
-- Returns an array of LuaEntity representing any forestries in the chunk that contains the given position
-- Example: local forestries = remote.call("ir-world", "get-chunk-forestry-count", entity.surface.index, entity.position)

-- ir-world/get-chunk-husbanded-trees-count
-- Takes a surface index and a map position as parameters
-- Returns 0 if there are no forestries in the chunk, otherwise the number of trees currently being husbanded by the forestries, clamped to 0-50
-- Example: local tree_count = remote.call("ir-world", "get-chunk-husbanded-trees-count", entity.surface.index, entity.position)

------------------------------------------------------------------------------------------------------------------------------------------------------

-- TRANSMATS

-- ir-transmats/ban
-- Prevents transmats from functioning on an entire surface
-- Affects both outgoing and incoming connections: a banned surface cannot be teleported from, to, or within
-- Parameter is a string representing a surface name, and an optional localised string that is displayed as the error message
-- If the optional error message is a table, it will be treated as a localised string
-- If the optional error message is a string, it will be prefixed with "gui." and converted to a localised string
-- Returns false and logs an error if the surface name is invalid
-- Otherwise returns true
-- Example: remote.call("ir-transmats", "ban", "nauvis") -- default error message
-- Example: remote.call("ir-transmats", "ban", "nauvis", {"my-locale.transmat-error-ion-storm"}) -- custom error message

-- ir-transmats/unban
-- Allows transmat connections on a surface again
-- Parameter is a string representing a surface name
-- Returns false and logs an error if the surface name is invalid
-- Otherwise returns true
-- Example: remote.call("ir-transmats", "unban", "nauvis")

-- i2-transmats/is-banned
-- Parameter is a string representing a surface name
-- Returns true if the surface exists and is banned
-- Otherwise returns false
-- Example: if remote.call("ir-transmats", "is-banned", "nauvis") then ...

-- ir-transmats/tag
-- Adds a tag to a surface, linking it to other surfaces with the same tag
-- By default, transmats will only connect to transmats on the same surface
-- Tagging surfaces allows transmats to connect to any other surface which shares any tag with the transmat's surface 
-- Surfaces can have any reasonable number of tags (less is better)
-- Parameters are a valid surface name and a tag (any valid table key)
-- Returns false and logs an error if the surface name is invalid
-- Otherwise returns true
-- Example of four calls which allow transmat connections between nauvis and underground, and nauvis and orbit, but not underground and orbit:
-- remote.call("ir-transmats", "tag", "nauvis", "nauvis-and-under")
-- remote.call("ir-transmats", "tag", "nauvis", "nauvis-and-orbit")
-- remote.call("ir-transmats", "tag", "under-nauvis", "nauvis-and-under")
-- remote.call("ir-transmats", "tag", "nauvis-orbit", "nauvis-and-orbit")

-- ir-transmats/untag
-- Removes a specific tag from a surface
-- Parameters are a valid surface name and a tag (any valid table key)
-- Returns false and logs an error if the surface name is invalid
-- Otherwise returns true
-- Example: remote.call("ir-transmats", "untag", "under-nauvis", "nauvis-and-under")

-- ir-transmats/clear
-- Removes all tags from a surface
-- Parameter is a string representing a surface name
-- Returns false and logs an error if the surface name is invalid
-- Otherwise returns true
-- Example: remote.call("ir-transmats", "clear", "nauvis")

-- ir-transmats/is-teleporting
-- Parameter is a player index
-- Returns true if the player index is valid and the player is currently in a transmat cutscene sequence
-- Otherwise returns false
-- Example: if remote.call("ir-transmats", "is-teleporting", player_index) then ...

------------------------------------------------------------------------------------------------------------------------------------------------------

-- UTILITY

-- ir-utils/fading-flying-text-player
-- Displays fancy rendered flying text above a player's head, which fades out for the last second of its time-to-live instead of suddenly vanishing
-- Only visible to the specified player
-- Parameters are a player object and text (string or localised string)
-- Does not return anything
-- Example: remote.call("ir-utils", "fading-flying-text-player", game.player, {"notification.alert"})

-- ir-utils/fading-flying-text-entity
-- Displays fancy rendered flying text (see above) at an entity's position
-- Visible to all players
-- Parameters are an entity object and text (string or localised string)
-- Does not return anything
-- Example: remote.call("ir-utils", "fading-flying-text-entity", event.entity, {"notification.alert"})

-- ir-utils/fading-flying-text-position
-- Displays fancy rendered flying text (see above) at an arbitrary position on a surface
-- Visible to all players
-- Parameters are a LuaSurface, position, and text (string or localised string)
-- Does not return anything
-- Example: remote.call("ir-utils", "fading-flying-text-position", player.surface, {x = -5, y = -5}, {"notification.alert"})

-- ir-utils/delayed-flying-item
-- Triggers a time-delayed item sprite missile of the kind used by transfer plates / transfer hotkey
-- Visuals only: no items are actually transferred
-- Takes a table of key/value parameters as a parameter: delay, item, source, target, source_height, target_height, source_distance, render_layer, bundle_size
-- Item projectile is fired from the source entity to the target entity after the specified time in ticks
-- If either entity has become invalid when the delay has elapsed, the projectile will not be rendered
-- If target_height is not specified then the projectile will home in on moving target entities
-- If target_height is specified, the projectile will aim for whatever position the target entity had when the projectile was launched
-- delay (integer, required) - delay in ticks, must be 1 or greater - not intended for very long delays, recommend max of a few seconds
-- item (string, required) - item prototype name that the item sprite will be drawn with, is not validated
-- source (entity, required) - entity emitting the projectile - if you want this to be a player, give player's character entity
-- target (entity, required) - entity targeted by the projectile - if you want this to be a player, give player's character entity
-- source_height (float, optional) - illusory height in tiles that the projectile is fired from, defaults to 0.5
-- target_height (float, optional) - illusory height in tiles that the projectile is fired to, defaults to nil
-- source_distance (float, optional) - distance in tiles along a line from source to target that the projectile start point is offset by, defaults to 0
-- render_layer (string, optional) - render layer that the item sprite is drawn on, defaults to "air-object"
-- bundle (integer, optional) - number of clustered sprites on the projectile, is silently clamped to 1-8
-- Example: remote.call("ir-utils", "delayed-flying-item", { delay = 1, item = "copper-plate", source = entity, target = player })
-- fires a copper plate from entity to player after 1 tick
-- Example: remote.call("ir-utils", "delayed-flying-item", { delay = 30, item = "iron-plate", source = player, target = entity,
--               source_height = 0.75, target_height = 4, source_distance = 0.25, render_layer = "wires", bundle_size = 5 })
-- fires a bundle of 5 iron plates from player to entity after 30 ticks, 0.75 tiles high at player, 4 tiles high at entity,
-- starting 0.25 tiles towards entity from player, on the "wires" render layer

------------------------------------------------------------------------------------------------------------------------------------------------------

-- MANIFESTO

-- ir-manifesto/open
-- Opens the Manifesto GUI, optionally to a specific page
-- Intended to be triggered by another custom GUI's element interaction event, but could work elsewhere
-- Parameter is a table with the following key/value pairs:
-- player_index (uint, required) - the index of the player to open the Manifesto GUI for
-- page_name (string, optional) - a page name (see keys in locale/en/documentation.cfg; pages names are the part after the first underscore, e.g. ir_mining)
-- If page_name is not supplied, Manifesto defaults to the last page the player clicked on, or the intro page otherwise
-- Will try to open Informatron instead if that is installed
-- Returns false if parameters are not a table, or player_index is false-ish, or the specified player is invalid
-- Returns true in any other case
-- Example: remote.call("ir-manifesto", "open", {player_index = player.index, page_name = "ir_mining"})

-- your_mod_name-ir-manifesto/titles
-- your_mod_name-ir-manifesto/content
-- Allows you to create additional Manifesto pages (or Informatron if that is installed)
-- These are interfaces that you provide in your own mods rather than interfaces in IR3 that you call
-- In the interface name, your_mod_name should be replaced with the internal name of your mod, then suffixed with "-ir-manifesto"
-- Two calls are mandatory, "titles" and "content"
-- "titles" should take no parameters and return a table of key/true pairs, where the keys are your new page names
-- "content" should take a page name and a GUI element as parameters, add GUI element content to the given element depending on page name, and return true
-- If your pages have the same names as IR3 pages, they will replace the IR3 pages
-- If your pages have the same names as other pages supplied by third party mods, one mod's page will replace the other's (probably in load order but who knows)
-- IR3 expects localised page titles for the left-hand Manifesto listbox menu to be in the format "IndustrialRevolution3.title_pagename", but the page content can be localised however you like
-- Informatron additionally expects a "IndustrialRevolution3.menu_pagename" localised menu button string (Manifesto doesn't use this)
-- See locale/en/documentation.cfg for localisation examples
-- It may be less confusing for you to conditionally call either this or Informatron's remote interfaces depending on what is installed
-- There are two more optional interfaces, "blueprint" and "cycle", designed for setting up fake simulation cameras: documentation TBD, or raise an issue
-- Example:
-- remote.add_interface("IndustrialRevolution3ExtraBits-ir-manifesto", {
	-- ["titles"] = function()
		-- return {
			-- new_page_name = true,
			-- another_new_page_name = true,
		-- }
	-- end,
	-- ["content"] = function(page_name, element)
		-- local pages = {
			-- new_page_name = function(element)
				-- element.add{type = "label", style = "manifesto_paragraph", caption = {"my-mod.page"}}
				-- element.add{type = "label", style = "manifesto_paragraph", caption = {"item-name.copper-plate"}}
				-- return true
			-- end,
			-- another_new_page_name = function(element)
				-- element.add{type = "label", style = "manifesto_paragraph", caption = {"my-mod.another-page"}}
				-- element.add{type = "label", style = "manifesto_paragraph", caption = {"item-name.iron-plate"}}
				-- return true
			-- end,
		-- }
		-- return pages[page_name](element)
	-- end,
-- })

-- ir-manifesto/add-camera
-- Adds a frame/camera GUI element pointed at the Manifesto simulation surface, based on named entities
-- Documentation TBD, or raise an issue

-- ir-manifesto/reset-surface
-- No parameters
-- Destroys and rebuilds the Manifesto simulation surface; intended for debugging, or perhaps from on_configuration_changed as part of a migration
-- If you use this in a scripted event, you should also close any opened Manifesto windows first
-- Documentation TBD, or raise an issue

-- ir-manifesto/register-cycle
-- Used by IR3 add-ons to hook into the Manifesto simulation cycle
-- Documentation TBD, or raise an issue

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir-world", {
	["set-intro-cutscene"] = function(value)
		global.use_ir_intro_cutscene = value
	end,
    ["set-crate-items"] = function(t)
		if type(t) ~= "table" then return false end
		global.crate_items = t
		return true
	end,
    ["get-crate-items"] = function()
		return global.crate_items
	end,
    ["allow-non-crate-spawns"] = function(value)
		global.generate_non_crate_spawns = value
	end,
	["get-chunk-forestries"] = function(surface_index, position)
		return CONTROL.get_forestries_in_chunk(game.surfaces[surface_index], position)
	end,
	["get-chunk-husbanded-trees-count"] = function(surface_index, position)
		if table_size(CONTROL.get_forestries_in_chunk(game.surfaces[surface_index], position)) == 0 then
			return 0
		end
		local trees, _ = CONTROL.get_husbanded_trees(game.surfaces[surface_index], position)
		return table_size(trees)
	end,
})

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir-transmats", {
    ban = function(surface_name,message)
		return CONTROL.transmat_ban_surface(surface_name,true,message)
	end,
    unban = function(surface_name,message)
		return CONTROL.transmat_ban_surface(surface_name,false,message)
	end,
	["is-banned"] = function(player_index)
		return CONTROL.transmat_surface_is_banned(surface_name)
	end,
	tag = function(surface_name,tag)
		return CONTROL.transmat_tag_surface(surface_name,tag,true)
	end,
	untag = function(surface_name,tag)
		return CONTROL.transmat_tag_surface(surface_name,tag,false)
	end,
	clear = function(surface_name)
		return CONTROL.transmat_clear_tags(surface_name)
	end,
	["is-teleporting"] = function(player_index)
		return CONTROL.transmat_player_is_teleporting(player_index)
	end,
	["reset-caches"] = function()
		CONTROL.reset_transmat_caches()
	end,
})

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir-utils", {
	["fading-flying-text-player"] = function(player,text)
		CONTROL.player_flying_notification(player, text)
	end,
	["fading-flying-text-entity"] = function(entity,text)
		CONTROL.entity_flying_notification(entity, text)
	end,
	["fading-flying-text-position"] = function(surface,position,text)
		CONTROL.add_delayed_action(1, {
			action = "pseudo_flying_text",
			surface = surface,
			text = text,
			position = position,
		})
	end,
	["delayed-flying-item"] = function(parameters)
		if (type(parameters.delay) ~= "number") or (parameters.delay < 1) then return end
		CONTROL.add_delayed_action(parameters.delay, {
			action = "fetchport_projectile",
			item = parameters.item,
			source = parameters.source,
			target = parameters.target,
			source_height = parameters.source_height,
			target_height = parameters.target_height,
			source_distance = parameters.source_distance,
			render_layer = parameters.render_layer,
			bundle = parameters.bundle,
		})
	end
})

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir-manifesto", {
	["open"] = function(parameters)
		if type(parameters) ~= "table" then return false end
		if parameters.player_index and game.players[parameters.player_index] then
			CONTROL.toggle_manifesto({player_index = parameters.player_index}, parameters.page_name)
			return true
		end
		return false
	end,
	["add-camera"] = function(root, width, height, entityname, offset)
		CONTROL.add_sim_camera_element(root, width, height, entityname, offset)
	end,
	["reset-surface"] = function()
		local surface = game.surfaces[CONTROL.sim_surface_name]
		if surface then
			game.delete_surface(surface) 
		end
		CONTROL.set_sim_surface_state(false)
	end,
	["register-cycle"] = function(mod_name, value)
		global.registered_mod_manifesto_cycles = global.registered_mod_manifesto_cycles or {}
		global.registered_mod_manifesto_cycles[mod_name] = value
	end,
})

------------------------------------------------------------------------------------------------------------------------------------------------------

remote.add_interface("ir-events", {
	["get-event-id"] = function(event_name)
		return CONTROL.generated_event_ids[event_name]
	end,
})

------------------------------------------------------------------------------------------------------------------------------------------------------
