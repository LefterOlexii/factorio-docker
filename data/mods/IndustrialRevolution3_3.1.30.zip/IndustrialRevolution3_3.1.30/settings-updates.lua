------------------------------------------------------------------------------------------------------------------------------------------------------

-- disable Dectorio waterfill setting

if data.raw["bool-setting"]["dectorio-waterfill"] then
	data.raw["bool-setting"]["dectorio-waterfill"].hidden = true
	data.raw["bool-setting"]["dectorio-waterfill"].default_value = false
end

------------------------------------------------------------------------------------------------------------------------------------------------------
