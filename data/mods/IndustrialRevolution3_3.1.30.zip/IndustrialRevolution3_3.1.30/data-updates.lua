------------------------------------------------------------------------------------------------------------------------------------------------------

-- DEADLOCK'S INDUSTRIAL REVOLUTION 3
-- See LICENSE.txt for license details

------------------------------------------------------------------------------------------------------------------------------------------------------

-- TECHNOLOGIES
require("code.technology.technology")

-- FLUIDS / BARRELLING
require("code.items-fluids-recipes.fluids-update")

-- Collision mask pass
require("code.entities.entities-collision-masks-updates")

------------------------------------------------------------------------------------------------------------------------------------------------------

